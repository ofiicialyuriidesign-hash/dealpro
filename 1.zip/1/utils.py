from aiogram.types import FSInputFile, InputMediaPhoto
from aiogram import Bot
import os

from config import BANNER_PATH
from aiogram import exceptions
import logging


async def send_message_with_banner(
        bot: Bot,
        chat_id: int,
        text: str,
        reply_markup=None,
        parse_mode: str = "HTML"
):
    if os.path.exists(BANNER_PATH):
        photo = FSInputFile(BANNER_PATH)
        try:
            await bot.send_photo(chat_id=chat_id, photo=photo, request_timeout=20)
        except Exception as e:
            logging.warning(f"send_photo failed: {e}")
    try:
        return await bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup, parse_mode=parse_mode, disable_web_page_preview=True)
    except Exception as e:
        logging.error(f"send_message failed: {e}")
        raise


async def edit_message_with_banner(message, text: str, reply_markup=None, parse_mode: str = "HTML"):
    if message.photo:
        return await message.edit_caption(caption=text, reply_markup=reply_markup, parse_mode=parse_mode)
    else:
        return await message.edit_text(text=text, reply_markup=reply_markup, parse_mode=parse_mode)


def get_deal_status_text(status: str, lang: str = 'ru') -> str:
    statuses = {
        'ru': {
            'pending': '⏳ Ожидает партнера',
            'waiting_admin': '👨‍💼 Ожидает гаранта',
            'in_progress': '🔄 В процессе',
            'waiting_confirm': '✋ Ожидает подтверждения',
            'completed': '✅ Завершена',
            'cancelled': '❌ Отменена'
        },
        'en': {
            'pending': '⏳ Waiting for partner',
            'waiting_admin': '👨‍💼 Waiting for escrow',
            'in_progress': '🔄 In progress',
            'waiting_confirm': '✋ Waiting for confirmation',
            'completed': '✅ Completed',
            'cancelled': '❌ Cancelled'
        }
    }
    return statuses.get(lang, statuses['ru']).get(status, '❓ Unknown' if lang == 'en' else '❓ Неизвестно')


def get_payment_type_text(payment_type: str, lang: str = 'ru') -> str:
    types = {
        'ru': {
            'card': '💳 Карта',
            'card_ru': '💳 Карта [РУ]',
            'card_ua': '💳 Карта [УК]',
            'card_kz': '💳 Карта [КЗ]',
            'card_by': '💳 Карта [РБ]',
            'usdt': '💎 USDT',
            'ton': '🪙 TON',
            'stars': '⭐ Звезды'
        },
        'en': {
            'card': '💳 Card',
            'card_ru': '💳 Card [RU]',
            'card_ua': '💳 Card [UA]',
            'card_kz': '💳 Card [KZ]',
            'card_by': '💳 Card [BY]',
            'usdt': '💎 USDT',
            'ton': '🪙 TON',
            'stars': '⭐ Stars'
        }
    }
    return types.get(lang, types['ru']).get(payment_type, '❓ Unknown' if lang == 'en' else '❓ Неизвестно')


def format_deal_info(deal: dict, lang: str = 'ru') -> str:
    deal_label = "Deal" if lang == 'en' else "Сделка"
    amount_label = "Amount" if lang == 'en' else "Сумма"
    method_label = "Payment method" if lang == 'en' else "Способ оплаты"
    desc_label = "Description" if lang == 'en' else "Описание"
    status_label = "Status" if lang == 'en' else "Статус"
    not_specified = "Not specified" if lang == 'en' else "Не указано"
    
    text = f"""
<b>📝 {deal_label} #{deal['id']}</b>

<b>{amount_label}:</b> {deal['amount']}₽
<b>{method_label}:</b> {get_payment_type_text(deal['payment_type'], lang)}
<b>{desc_label}:</b> {deal['description'] or not_specified}
<b>{status_label}:</b> {get_deal_status_text(deal['status'], lang)}
"""
    return text.strip()


def format_user_profile(user: dict, stats: dict, lang: str = 'ru') -> str:
    rating_stars = "⭐" * int(stats.get('avg_rating', 0)) if stats.get('avg_rating') else ("No ratings" if lang == 'en' else "Нет оценок")
    
    if lang == 'en':
        text = f"""
<b>👤 Your profile</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Name:</b> {user['full_name']}
<b>Username:</b> @{user['username'] or 'not set'}

<b>📊 Statistics:</b>
• Total deals: {stats.get('deals_count', 0)}
• Successful: {stats.get('successful_deals', 0)}
• Rating: {stats.get('avg_rating', 0)} {rating_stars}
• Reviews: {stats.get('review_count', 0)}
"""
    else:
        text = f"""
<b>👤 Ваш профиль</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Имя:</b> {user['full_name']}
<b>Username:</b> @{user['username'] or 'не указан'}

<b>📊 Статистика:</b>
• Всего сделок: {stats.get('deals_count', 0)}
• Успешных: {stats.get('successful_deals', 0)}
• Рейтинг: {stats.get('avg_rating', 0)} {rating_stars}
• Отзывов: {stats.get('review_count', 0)}
"""
    return text.strip()
