from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from keyboards import users_menu_kb, reputation_filter_kb, user_profile_kb, cancel_kb, main_menu_kb, reputation_filter_reply_kb
from states import ReviewViewStates, AppealStates
from utils import send_message_with_banner
from locales import get_text
from config import ADMIN_IDS

router = Router()


class SearchUserStates(StatesGroup):
    waiting_username = State()


@router.message(F.text.in_(["👥 Пользователи", "👥 Users"]))
async def users_menu(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    text = get_text('users_title', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))


@router.callback_query(F.data == "back_users_menu")
async def back_users_menu_callback(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    text = get_text('users_title', lang)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=users_menu_kb(lang))
    await callback.answer()


@router.message(F.text.in_(["🛡 Гаранты", "🛡 Escrow agents"]))
async def show_garants(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    garants = await db.get_garants()

    if not garants:
        text = get_text('users_garants_empty', lang)
    else:
        text = get_text('users_garants', lang) + "\n\n"
        for i, g in enumerate(garants[:10], 1):
            rep = g.get('reputation_positive', 0) - g.get('reputation_negative', 0)
            deposit = g.get('deposit', 0)
            rep_label = "Reputation" if lang == 'en' else "Репутация"
            dep_label = "Deposit" if lang == 'en' else "Депозит"
            text += f"{i}. @{g['username'] or 'user'}\n   📊 {rep_label}: {rep} | 💰 {dep_label}: {deposit}$\n\n"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))


@router.message(F.text.in_(["🏆 Топ репутации", "🏆 Top reputation"]))
async def top_reputation(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    users = await db.get_top_reputation(3)

    if not users:
        text = get_text('users_top_empty', lang)
    else:
        text = get_text('users_top_reputation', lang) + "\n\n"
        for i, u in enumerate(users, 1):
            rep_pos = u.get('reputation_positive', 0)
            rep_neg = u.get('reputation_negative', 0)
            rep = rep_pos - rep_neg
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉"
            total_label = "Total" if lang == 'en' else "Итого"
            text += f"{medal} @{u['username'] or 'user'}\n   👍 {rep_pos} | 👎 {rep_neg} | {total_label}: {rep}\n\n"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))


@router.message(F.text.in_(["🔍 Найти пользователя", "🔍 Find user"]))
async def search_user_start(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.set_state(SearchUserStates.waiting_username)
    await state.update_data(lang=lang)
    text = get_text('users_search', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(SearchUserStates.waiting_username)
async def process_search_user(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    query = message.text.strip()
    await state.clear()

    found_user = None
    if query.startswith("@"):
        found_user = await db.get_user_by_username(query)
    elif query.isdigit():
        found_user = await db.get_user(int(query))
    else:
        found_user = await db.get_user_by_username(query)

    if not found_user:
        text = get_text('users_not_found', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))
        return

    if found_user.get('is_banned'):
        reason = found_user.get('ban_reason')
        text = get_text('users_banned', lang, username=found_user.get('username') or found_user.get('user_id'), id=found_user.get('user_id'))
        if reason:
            text += f"\n{'Reason' if lang == 'en' else 'Причина'}: {reason}"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))
        return

    await show_user_profile(bot, message.chat.id, found_user, lang)


async def show_user_profile(bot: Bot, chat_id: int, user: dict, lang: str = 'ru', back_callback: str = "back_users_menu"):
    rep_pos = user.get('reputation_positive', 0)
    rep_neg = user.get('reputation_negative', 0)
    rep_total = rep_pos - rep_neg
    deposit = user.get('deposit', 0)
    is_garant = ("✅ Yes" if lang == 'en' else "✅ Да") if user.get('is_garant') else ("❌ No" if lang == 'en' else "❌ Нет")

    text = get_text('profile_title', lang, 
        username=user['username'] or ('not specified' if lang == 'en' else 'не указан'),
        id=user['user_id'],
        name=user['full_name'],
        pos=rep_pos,
        neg=rep_neg,
        total=rep_total,
        deposit=deposit,
        garant=is_garant
    )
    
    if user.get('is_banned'):
        ban_text = "\n<b>🚫 Status:</b> User is banned" if lang == 'en' else "\n<b>🚫 Статус:</b> Пользователь заблокирован"
        text += ban_text
        if user.get('ban_reason'):
            reason_label = "Reason" if lang == 'en' else "Причина"
            text += f"\n<b>{reason_label}:</b> {user.get('ban_reason')}"
    
    await send_message_with_banner(bot, chat_id, text, reply_markup=user_profile_kb(user['user_id'], back_callback))


@router.callback_query(F.data.startswith("view_reputation_"))
async def view_reputation(callback: CallbackQuery, state: FSMContext, bot: Bot):
    cur_user = await db.get_user(callback.from_user.id)
    lang = cur_user.get('language', 'ru') if cur_user else 'ru'
    user_id = int(callback.data.replace("view_reputation_", ""))
    user = await db.get_user(user_id)

    if not user:
        await callback.answer(get_text('user_not_found', lang), show_alert=True)
        return

    await state.set_state(ReviewViewStates.viewing_reviews)
    await state.update_data(viewing_user_id=user_id, lang=lang)

    text = get_text('reviews_title', lang, username=user['username'] or 'user', filter=get_text('reviews_filter_all', lang))
    reviews = await db.get_user_reviews(user_id, "all")
    
    if not reviews:
        text += get_text('reviews_empty', lang)
    else:
        for r in reviews[:10]:
            # 👍/👎 по типу отзыва
            emoji = "👍" if r.get('is_positive') else "👎"

            # кто оставил отзыв
            author = (
                    r.get('fake_username')
                    or r.get('username')
                    or r.get('full_name')
                    or ('Anonymous' if lang == 'en' else 'Аноним')
            )

            # комментарий
            comment = (r.get('comment') or "").strip()
            if not comment:
                comment = "—"

            # дата
            dt = r.get('created_at') or "—"

            # формат как ты хочешь
            text += (
                f"👤 <b>{'User' if lang == 'en' else 'Пользователь'}:</b> {author}\n"
                f"💬 <b>{'Comment' if lang == 'en' else 'Комментарий'}:</b> {comment}\n"
                f"🕒 <b>{'Date' if lang == 'en' else 'Дата'}:</b> <i>{dt}</i>\n\n"
            )

    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=reputation_filter_reply_kb(lang))
    await callback.answer()


@router.message(F.text.in_(["⭐ Моя репутация", "⭐ My reputation"]))
async def my_reputation(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    if not user:
        await send_message_with_banner(bot, message.chat.id, get_text('error', lang))
        return

    await state.set_state(ReviewViewStates.viewing_reviews)
    await state.update_data(viewing_user_id=message.from_user.id, lang=lang)

    text = get_text('reviews_my', lang, filter=get_text('reviews_filter_all', lang))
    reviews = await db.get_user_reviews(message.from_user.id, "all")
    
    if not reviews:
        text += get_text('reviews_empty', lang)
    else:
        for r in reviews[:10]:
            emoji = "👍" if r.get('is_positive') else "👎"
            author = r.get('fake_username') or r.get('username') or r.get('full_name', 'Anonymous' if lang == 'en' else 'Аноним')
            text += f"{emoji} {get_text('reviews_from', lang)} {author}\n"
            if r.get('comment'):
                text += f"💬 {r['comment']}\n"
            text += f"<i>{r.get('created_at', '')}</i>\n\n"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=reputation_filter_reply_kb(lang))


async def show_reviews_with_filter(bot: Bot, chat_id: int, user_id: int, filter_type: str, lang: str = 'ru'):
    user = await db.get_user(user_id)
    if not user:
        return
    
    reviews = await db.get_user_reviews(user_id, filter_type)

    filter_names = {
        "all": get_text('reviews_filter_all', lang),
        "positive": get_text('reviews_filter_positive', lang),
        "negative": get_text('reviews_filter_negative', lang),
        "last_positive": get_text('reviews_filter_last_pos', lang),
        "last_negative": get_text('reviews_filter_last_neg', lang)
    }

    text = get_text('reviews_title', lang, username=user['username'] or 'user', filter=filter_names.get(filter_type, get_text('reviews_filter_all', lang)))

    if not reviews:
        text += get_text('reviews_empty', lang)
    else:
        for r in reviews[:10]:
            emoji = "👍" if r.get('is_positive') else "👎"
            author = r.get('fake_username') or r.get('username') or r.get('full_name', 'Anonymous' if lang == 'en' else 'Аноним')
            text += f"{emoji} {get_text('reviews_from', lang)} {author}\n"
            if r.get('comment'):
                text += f"💬 {r['comment']}\n"
            text += f"<i>{r.get('created_at', '')}</i>\n\n"

    await send_message_with_banner(bot, chat_id, text, reply_markup=reputation_filter_reply_kb(lang))


@router.message(F.text.in_(["📋 ВСЕ", "📋 ALL"]), ReviewViewStates.viewing_reviews)
async def filter_all_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get('viewing_user_id')
    lang = data.get('lang', 'ru')
    if user_id:
        await show_reviews_with_filter(bot, message.chat.id, user_id, "all", lang)


@router.message(F.text.in_(["👍 Положительные", "👍 Positive"]), ReviewViewStates.viewing_reviews)
async def filter_positive_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get('viewing_user_id')
    lang = data.get('lang', 'ru')
    if user_id:
        await show_reviews_with_filter(bot, message.chat.id, user_id, "positive", lang)


@router.message(F.text.in_(["👎 Отрицательные", "👎 Negative"]), ReviewViewStates.viewing_reviews)
async def filter_negative_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get('viewing_user_id')
    lang = data.get('lang', 'ru')
    if user_id:
        await show_reviews_with_filter(bot, message.chat.id, user_id, "negative", lang)


@router.message(F.text.in_(["✅ Последний положит.", "✅ Last positive"]), ReviewViewStates.viewing_reviews)
async def filter_last_positive_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get('viewing_user_id')
    lang = data.get('lang', 'ru')
    if user_id:
        await show_reviews_with_filter(bot, message.chat.id, user_id, "last_positive", lang)


@router.message(F.text.in_(["❌ Последний отрицат.", "❌ Last negative"]), ReviewViewStates.viewing_reviews)
async def filter_last_negative_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data.get('viewing_user_id')
    lang = data.get('lang', 'ru')
    if user_id:
        await show_reviews_with_filter(bot, message.chat.id, user_id, "last_negative", lang)


@router.message(F.text.in_(["🔙 Назад", "🔙 Back"]), ReviewViewStates.viewing_reviews)
async def back_from_reviews_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    await state.clear()
    text = get_text('users_title', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=users_menu_kb(lang))


@router.callback_query(F.data.startswith("rep_"))
async def show_filtered_reviews(callback: CallbackQuery, state: FSMContext, bot: Bot):
    cur_user = await db.get_user(callback.from_user.id)
    lang = cur_user.get('language', 'ru') if cur_user else 'ru'
    data = callback.data

    if "_last_positive_" in data:
        filter_type = "last_positive"
        user_id = int(data.split("_last_positive_")[1])
    elif "_last_negative_" in data:
        filter_type = "last_negative"
        user_id = int(data.split("_last_negative_")[1])
    elif "_positive_" in data:
        filter_type = "positive"
        user_id = int(data.split("_positive_")[1])
    elif "_negative_" in data:
        filter_type = "negative"
        user_id = int(data.split("_negative_")[1])
    else:
        filter_type = "all"
        user_id = int(data.split("_all_")[1])

    await state.set_state(ReviewViewStates.viewing_reviews)
    await state.update_data(viewing_user_id=user_id, lang=lang)
    await show_reviews_with_filter(bot, callback.message.chat.id, user_id, filter_type, lang)
    await callback.answer()


@router.callback_query(F.data.startswith("deal_user_"))
async def view_deal_user(callback: CallbackQuery, bot: Bot):
    cur_user = await db.get_user(callback.from_user.id)
    lang = cur_user.get('language', 'ru') if cur_user else 'ru'
    parts = callback.data.split("_")
    user_id = int(parts[2])
    deal_id = int(parts[3])

    user = await db.get_user(user_id)
    if not user:
        await callback.answer(get_text('user_not_found', lang), show_alert=True)
        return

    await callback.answer()
    await show_user_profile(bot, callback.message.chat.id, user, lang, f"view_deal_{deal_id}")


@router.callback_query(F.data == "appeal_start")
async def appeal_start_callback(callback: CallbackQuery, bot: Bot, state: FSMContext):
    user = await db.get_user(callback.from_user.id)
    if not user or not user.get('is_banned'):
        await callback.answer("Недоступно", show_alert=True)
        return

    await state.set_state(AppealStates.entering_appeal)
    await state.update_data(appeal_user_id=user['user_id'])
    await callback.message.answer("📝 Отправьте текст апелляции — расскажите, почему вы считаете блокировку ошибочной или что вы готовы сделать.")
    await callback.answer()


@router.message(Command("appeal"))
async def appeal_command_start(message: Message, bot: Bot, state: FSMContext):
    user = await db.get_user(message.from_user.id)
    if not user or not user.get('is_banned'):
        await message.answer("Команда доступна только заблокированным пользователям.")
        return

    await state.set_state(AppealStates.entering_appeal)
    await state.update_data(appeal_user_id=user['user_id'])
    await message.answer("📝 Отправьте текст апелляции — расскажите, почему вы считаете блокировку ошибочной или что вы готовы сделать.")


@router.message(AppealStates.entering_appeal)
async def process_appeal_message(message: Message, state: FSMContext, bot: Bot):
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=main_menu_kb())
        return

    data = await state.get_data()
    user_id = data.get('appeal_user_id') or message.from_user.id
    text = message.text.strip() if message.text else None

    file_id = None
    if message.photo:
        file_id = message.photo[-1].file_id

    appeal_id = await db.create_appeal(user_id, text or '')
    if file_id:
        async with __import__('aiosqlite').connect(__import__('database').DB_PATH) as con:
            await con.execute("UPDATE appeals SET attachment_file_id = ? WHERE id = ?", (file_id, appeal_id))
            await con.commit()
    await state.clear()

    await send_message_with_banner(bot, message.chat.id, "✅ Ваша апелляция отправлена администратору. Ожидайте ответа.")

    appeal_notify = f"📣 Новая апелляция от <code>{user_id}</code>:\n\n{text or ''}"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Одобрить", callback_data=f"appeal_accept_{appeal_id}"), 
         InlineKeyboardButton(text="❌ Отклонить", callback_data=f"appeal_reject_{appeal_id}")]
    ])
    for admin in ADMIN_IDS:
        try:
            if file_id:
                try:
                    await bot.send_photo(admin, file_id)
                except:
                    pass
            await bot.send_message(admin, appeal_notify, parse_mode="HTML", reply_markup=kb)
        except:
            pass
