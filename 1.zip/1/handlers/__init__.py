from aiogram import Router

from .start import router as start_router
from .profile import router as profile_router
from .requisites import router as requisites_router
from .deals import router as deals_router
from .support import router as support_router
from .admin import router as admin_router
from .reviews import router as reviews_router
from .users import router as users_router
from .referral import router as referral_router
from .garant import router as garant_router


def setup_routers() -> Router:
    router = Router()

    # Middleware: block interactions from banned users (messages and callback queries)
    from aiogram import types
    import database as db
    from config import ADMIN_IDS
    from .cache import banned_notified

    async def _ban_middleware(handler, event, data):
        # Determine user from event (Message or CallbackQuery)
        user = None
        if isinstance(event, types.Message):
            user = event.from_user
        elif isinstance(event, types.CallbackQuery):
            user = event.from_user
        else:
            return await handler(event, data)

        if not user:
            return await handler(event, data)

        # Allow admins to interact regardless
        if user.id in ADMIN_IDS:
            return await handler(event, data)

        try:
            if await db.is_user_banned(user.id):
                # Try to fetch ban reason
                u = await db.get_user(user.id)
                reason = u.get('ban_reason') if u else None

                # Allow the appeal flow to proceed: if user presses the appeal button
                # or sends /appeal command, let it through so user can submit appeal.
                if isinstance(event, types.CallbackQuery) and getattr(event, 'data', None) == 'appeal_start':
                    return await handler(event, data)
                if isinstance(event, types.Message) and isinstance(getattr(event, 'text', None), str) and event.text.strip().startswith('/appeal'):
                    return await handler(event, data)

                # Check if user is currently entering appeal text
                state = data.get('state')
                if state:
                    current_state = await state.get_state()
                    from states import AppealStates
                    if current_state == AppealStates.entering_appeal.state:
                        return await handler(event, data)

                ban_text = "🚫 <b>Вы были заблокированы!</b>"
                if reason:
                    ban_text += f"\n\nПричина: {reason}"

                # Inline keyboard with appeal button for banned users
                try:
                    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
                    kb = InlineKeyboardMarkup(inline_keyboard=[[
                        InlineKeyboardButton(text="Подать на разблокировку", callback_data="appeal_start")
                    ]])
                except Exception:
                    kb = None

                # If it's a callback query, answer and optionally send alert
                if isinstance(event, types.CallbackQuery):
                    try:
                        await event.answer("Вы заблокированы", show_alert=True)
                    except:
                        pass

                # Avoid spamming the user with repeated ban notifications in short runtime
                if user.id not in banned_notified:
                    try:
                        await event.bot.send_message(user.id, ban_text, parse_mode="HTML", reply_markup=kb)
                        banned_notified.add(user.id)
                    except:
                        pass

                # Do not continue to handler
                return
        except Exception:
            # On DB errors, allow processing to continue (avoid blocking legit users)
            return await handler(event, data)

        return await handler(event, data)

    # Register middleware for messages and callback queries
    router.message.middleware(_ban_middleware)
    router.callback_query.middleware(_ban_middleware)

    router.include_router(start_router)
    router.include_router(profile_router)
    router.include_router(requisites_router)
    router.include_router(deals_router)
    router.include_router(support_router)
    router.include_router(admin_router)
    router.include_router(reviews_router)
    router.include_router(users_router)
    router.include_router(referral_router)
    router.include_router(garant_router)

    return router
