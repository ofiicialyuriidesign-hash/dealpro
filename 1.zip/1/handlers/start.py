from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
import random

import database as db
from keyboards import main_menu_kb, join_deal_reply_kb, language_select_kb, captcha_kb, webapp_inline_kb
from config import WEBAPP_URL
from states import DealViewStates, CaptchaStates
from utils import send_message_with_banner
from locales import get_text, CAPTCHA_ICONS

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, bot: Bot):
    await state.clear()

    if await db.is_user_banned(message.from_user.id):
        user = await db.get_user(message.from_user.id)
        lang = user.get('language', 'ru') if user else 'ru'
        ban_text = get_text('banned', lang)
        if user and user.get('ban_reason'):
            ban_text += get_text('ban_reason', lang, reason=user['ban_reason'])
        await message.answer(ban_text, parse_mode="HTML")
        return

    existing_user = await db.get_user(message.from_user.id)
    is_new_user = existing_user is None

    await db.create_user(
        user_id=message.from_user.id,
        username=message.from_user.username,
        full_name=message.from_user.full_name
    )
    # Always keep profile data fresh
    await db.update_user_info(
        user_id=message.from_user.id,
        username=message.from_user.username or "",
        full_name=message.from_user.full_name or ""
    )

    args = message.text.split()
    start_args = None
    if len(args) > 1:
        start_args = args[1]

    if len(args) > 1 and args[1].startswith("ref_") and is_new_user:
        try:
            referrer_id = int(args[1].replace("ref_", ""))
            referrer = await db.get_user(referrer_id)
            if referrer and referrer_id != message.from_user.id:
                await db.create_referral(referrer_id, message.from_user.id)
                try:
                    ref_lang = referrer.get('language', 'ru')
                    await bot.send_message(referrer_id, get_text('referral_joined', ref_lang), disable_web_page_preview=True)
                except:
                    pass
        except:
            pass

    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    if not user or not user.get('captcha_passed'):
        await state.update_data(start_args=start_args)
        correct_icon = random.choice(CAPTCHA_ICONS)
        icons_pool = random.sample(CAPTCHA_ICONS, 10)
        if correct_icon not in icons_pool:
            icons_pool[random.randint(0, 9)] = correct_icon
        random.shuffle(icons_pool)
        await state.set_state(CaptchaStates.waiting_captcha)
        await state.update_data(correct_icon=correct_icon)
        text = get_text('captcha_title', lang, icon=correct_icon)
        await message.answer(text, reply_markup=captcha_kb(correct_icon, icons_pool), parse_mode="HTML")
        return

    if start_args:
        deal = None
        if start_args.startswith("deal_"):
            try:
                deal_id = int(start_args.replace("deal_", ""))
                deal = await db.get_deal(deal_id)
            except (ValueError, TypeError):
                pass
        elif start_args.startswith("DP-"):
            deal = await db.get_deal_by_code(start_args)
        if deal and deal['status'] == 'pending' and deal['creator_id'] != message.from_user.id:
            from utils import format_deal_info
            await state.set_state(DealViewStates.joining_deal)
            await state.update_data(joining_deal_id=deal['id'])
            text = get_text('deal_invite_title', lang, info=format_deal_info(deal))
            await send_message_with_banner(bot, message.chat.id, text, reply_markup=join_deal_reply_kb(lang))
            return

    await send_message_with_banner(bot, message.chat.id, get_text('welcome', lang), reply_markup=webapp_inline_kb(lang))


@router.callback_query(F.data.startswith("captcha_"))
async def captcha_check(callback: CallbackQuery, state: FSMContext, bot: Bot):
    data = await state.get_data()
    correct = data.get('correct_icon')
    selected = callback.data.replace("captcha_", "")
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    if selected == correct:
        await db.set_captcha_passed(callback.from_user.id, True)
        await callback.answer(get_text('captcha_success', lang), show_alert=True)
        start_args = data.get('start_args')
        await state.clear()

        if start_args:
            deal = None
            if start_args.startswith("deal_"):
                try:
                    deal_id = int(start_args.replace("deal_", ""))
                    deal = await db.get_deal(deal_id)
                except (ValueError, TypeError):
                    pass
            elif start_args.startswith("DP-"):
                deal = await db.get_deal_by_code(start_args)
            if deal and deal['status'] == 'pending' and deal['creator_id'] != callback.from_user.id:
                from utils import format_deal_info
                await state.set_state(DealViewStates.joining_deal)
                await state.update_data(joining_deal_id=deal['id'])
                text = get_text('deal_invite_title', lang, info=format_deal_info(deal))
                await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=join_deal_reply_kb(lang))
                return

        await send_message_with_banner(bot, callback.message.chat.id, get_text('welcome', lang), reply_markup=webapp_inline_kb(lang))
    else:
        await callback.answer(get_text('captcha_fail', lang), show_alert=True)
        correct_icon = random.choice(CAPTCHA_ICONS)
        icons_pool = random.sample(CAPTCHA_ICONS, 10)
        if correct_icon not in icons_pool:
            icons_pool[random.randint(0, 9)] = correct_icon
        random.shuffle(icons_pool)
        await state.update_data(correct_icon=correct_icon)
        text = get_text('captcha_title', lang, icon=correct_icon)
        await callback.message.edit_text(text, reply_markup=captcha_kb(correct_icon, icons_pool), parse_mode="HTML")


@router.message(F.text.in_(["🌐 Язык", "🌐 Language"]))
async def change_language(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await message.answer(get_text('select_language', lang), reply_markup=language_select_kb(), parse_mode="HTML")


@router.callback_query(F.data.startswith("set_lang_"))
async def set_language(callback: CallbackQuery, bot: Bot):
    lang = callback.data.replace("set_lang_", "")
    await db.set_user_language(callback.from_user.id, lang)
    await callback.answer(get_text('language_changed', lang), show_alert=True)
    await send_message_with_banner(bot, callback.message.chat.id, get_text('welcome', lang), reply_markup=main_menu_kb(lang))


@router.message(F.text == "✅ Присоединиться к сделке", DealViewStates.joining_deal)
async def join_deal_reply_ru(message: Message, state: FSMContext, bot: Bot):
    await _join_deal_handler(message, state, bot)


@router.message(F.text == "✅ Приєднатися до угоди", DealViewStates.joining_deal)
async def join_deal_reply_uk(message: Message, state: FSMContext, bot: Bot):
    await _join_deal_handler(message, state, bot)


@router.message(F.text == "✅ Join deal", DealViewStates.joining_deal)
async def join_deal_reply_en(message: Message, state: FSMContext, bot: Bot):
    await _join_deal_handler(message, state, bot)


async def _join_deal_handler(message: Message, state: FSMContext, bot: Bot):
    from config import ADMIN_IDS
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    data = await state.get_data()
    deal_id = data.get('joining_deal_id')

    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌", reply_markup=main_menu_kb(lang))
        return

    deal = await db.get_deal(deal_id)

    if not deal:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌", reply_markup=main_menu_kb(lang))
        return

    if deal['status'] != 'pending':
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌", reply_markup=main_menu_kb(lang))
        return

    if deal['creator_id'] == message.from_user.id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌", reply_markup=main_menu_kb(lang))
        return

    await db.join_deal(deal_id, message.from_user.id)

    try:
        creator = await db.get_user(deal['creator_id'])
        creator_lang = creator.get('language', 'ru') if creator else 'ru'
        await send_message_with_banner(bot, deal['creator_id'], get_text('deal_partner_joined', creator_lang, id=deal_id))
    except:
        pass

    for admin_id in ADMIN_IDS:
        try:
            await send_message_with_banner(bot, admin_id, get_text('new_deal_admin', 'ru', id=deal_id, amount=deal['amount']))
        except:
            pass

    await state.clear()
    await send_message_with_banner(bot, message.chat.id, get_text('deal_joined', lang, id=deal_id), reply_markup=main_menu_kb(lang))


@router.message(F.text.in_(["🏠 В меню", "🏠 Вернуться в меню", "🏠 Menu", "🏠 Return to menu"]))
async def back_to_menu(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await send_message_with_banner(bot, message.chat.id, get_text('welcome', lang), reply_markup=webapp_inline_kb(lang))


@router.callback_query(F.data == "back_main_menu")
async def back_to_menu_callback(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await send_message_with_banner(bot, callback.message.chat.id, get_text('welcome', lang), reply_markup=webapp_inline_kb(lang))
    await callback.answer()
