from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter
import aiosqlite
from datetime import datetime

import database as db
from config import ADMIN_IDS, BANNER_PATH
from keyboards import (
    admin_menu_kb, admin_pending_deals_kb, admin_take_deal_kb,
    admin_deal_actions_kb, admin_open_tickets_kb, ticket_actions_kb,
    admin_settings_kb, admin_boost_kb, cancel_kb, main_menu_kb,
    admin_waiting_partner_deals_kb, admin_pending_deal_actions_kb,
    admin_my_active_deals_kb, admin_withdrawals_kb, admin_withdrawal_action_kb,
    admin_banner_kb, broadcast_attach_kb, broadcast_confirm_kb
)
from utils import send_message_with_banner, format_deal_info
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from .cache import banned_notified

router = Router()


class AdminStates(StatesGroup):
    messaging_deal_users = State()
    setting_min_deposit = State()
    boost_deposit_user = State()
    boost_deposit_amount = State()
    boost_rep_user = State()
    boost_rep_positive = State()
    boost_rep_negative = State()
    boost_deals_user = State()
    boost_deals_amount = State()
    boost_garant_user = State()
    clear_reviews_user = State()
    give_garant_user = State()
    ban_user = State()
    ban_reason = State()
    unban_user = State()
    broadcast_message = State()
    broadcast_attach = State()
    broadcast_confirm = State()
    upload_banner = State()
    boost_fake_review_user = State()
    boost_fake_review_date = State()
    boost_fake_review_name = State()
    boost_fake_review_comment = State()
    boost_fake_review_bulk = State()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


@router.message(Command("admin"))
async def cmd_admin(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        await message.answer("❌ У вас нет доступа к админ-панели.")
        return

    stats = await db.get_all_stats()
    text = f"""
<b>👨‍💼 Админ-панель</b>

<b>📊 Статистика:</b>
• Пользователей: {stats['users_count']}
• Всего сделок: {stats['deals_count']}
• Завершено: {stats['completed_deals']}
• Активных: {stats['active_deals']}
  ├ Ожидают партнера: {stats['pending_deals']}
  └ Ждут гаранта: {stats['waiting_admin_deals']}
• Открытых тикетов: {stats['open_tickets']}
• Общий депозит: {stats['total_deposit']}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())


@router.message(StateFilter("*"), F.text.in_({"❌ Отмена", "✖ Отмена", "❌Отмена", "❌ Cancel", "❌Cancel"}))
async def cancel_any_fsm(message: Message, state: FSMContext, bot: Bot):
    await state.clear()

    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    # Куда возвращать после отмены
    kb = admin_boost_kb() if is_admin(message.from_user.id) else main_menu_kb(lang)

    await send_message_with_banner(
        bot,
        message.chat.id,
        "❌ Action cancelled." if lang == "en" else "❌ Действие отменено.",
        reply_markup=kb
    )

# Callback для inline кнопки "Админ панель"
@router.callback_query(F.data == "back_admin_panel")
async def back_admin_panel_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    stats = await db.get_all_stats()
    text = f"""
<b>👨‍💼 Админ-панель</b>

<b>📊 Статистика:</b>
• Пользователей: {stats['users_count']}
• Сделок: {stats['deals_count']} (активных: {stats['active_deals']})
  ├ Ожидают партнера: {stats['pending_deals']}
  └ Ждут гаранта: {stats['waiting_admin_deals']}
• Тикетов: {stats['open_tickets']}
• Депозитов: {stats['total_deposit']}$
"""
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    await callback.answer()


@router.message(F.text == "🔙 Админ панель")
async def admin_panel_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.clear()

    stats = await db.get_all_stats()
    text = f"""
<b>👨‍💼 Админ-панель</b>

<b>📊 Статистика:</b>
• Пользователей: {stats['users_count']}
• Сделок: {stats['deals_count']} (активных: {stats['active_deals']})
  ├ Ожидают партнера: {stats['pending_deals']}
  └ Ждут гаранта: {stats['waiting_admin_deals']}
• Тикетов: {stats['open_tickets']}
• Депозитов: {stats['total_deposit']}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())


# ========== WITHDRAWALS MANAGEMENT ==========

@router.message(F.text == "💸 Выводы")
async def admin_withdrawals_list(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    
    withdrawals = await db.get_pending_withdrawals()
    
    if not withdrawals:
        await send_message_with_banner(bot, message.chat.id, "✅ Нет ожидающих заявок на вывод", reply_markup=admin_menu_kb())
        return
    
    text = f"""
<b>💸 Заявки на вывод</b>

Всего заявок: {len(withdrawals)}
Выберите заявку для обработки:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_withdrawals_kb(withdrawals))


@router.callback_query(F.data == "admin_withdrawals")
async def admin_withdrawals_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    
    withdrawals = await db.get_pending_withdrawals()
    
    if not withdrawals:
        await callback.answer("Нет заявок", show_alert=True)
        await send_message_with_banner(bot, callback.message.chat.id, "✅ Нет ожидающих заявок на вывод", reply_markup=admin_menu_kb())
        return
    
    text = f"""
<b>💸 Заявки на вывод</b>

Всего заявок: {len(withdrawals)}
Выберите заявку для обработки:
"""
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_withdrawals_kb(withdrawals))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_view_withdraw_"))
async def admin_view_withdrawal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    
    withdrawal_id = int(callback.data.replace("admin_view_withdraw_", ""))
    withdrawal = await db.get_withdrawal(withdrawal_id)
    
    if not withdrawal:
        await callback.answer("Заявка не найдена", show_alert=True)
        return
    
    user = await db.get_user(withdrawal['user_id'])
    
    text = f"""
<b>💸 Заявка #{withdrawal['id']}</b>

<b>Пользователь:</b> {user['full_name']} (@{user['username']})
<b>ID:</b> <code>{user['user_id']}</code>
<b>Сумма:</b> {withdrawal['amount']} USDT
<b>Кошелек:</b> <code>{withdrawal['wallet_address']}</code>
<b>Дата:</b> {withdrawal['created_at']}

⚠️ Проверьте, что вы перевели средства на указанный кошелек, прежде чем подтверждать!
"""
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_withdrawal_action_kb(withdrawal_id))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_confirm_withdraw_"))
async def admin_confirm_withdrawal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    
    withdrawal_id = int(callback.data.replace("admin_confirm_withdraw_", ""))
    
    # Подтверждаем вывод (средства уже списаны)
    result = await db.complete_withdrawal(withdrawal_id, transfer_id="manual_admin")
    
    if result:
        # Уведомляем пользователя
        try:
            text = f"""
<b>✅ Вывод средств подтвержден!</b>

Ваша заявка #{withdrawal_id} на сумму {result['amount']} USDT обработана.
Средства отправлены на ваш кошелек.
"""
            await bot.send_message(result['user_id'], text)
        except:
            pass
        
        await callback.answer("✅ Вывод подтвержден", show_alert=True)
        # Возвращаемся к списку
        await admin_withdrawals_callback(callback, bot)
    else:
        await callback.answer("Ошибка: заявка уже обработана", show_alert=True)


@router.callback_query(F.data.startswith("admin_reject_withdraw_"))
async def admin_reject_withdrawal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    
    withdrawal_id = int(callback.data.replace("admin_reject_withdraw_", ""))
    
    # Отменяем вывод и возвращаем средства
    await db.cancel_withdrawal(withdrawal_id)


# ========== РАССЫЛКА (Админ) ==========
@router.message(F.text == "📣 Рассылка")
async def admin_broadcast_start(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.broadcast_message)
    await send_message_with_banner(bot, message.chat.id, "📣 Введите текст рассылки или отправьте фото с подписью. Отправьте '❌ Отмена' чтобы отменить.", reply_markup=cancel_kb())


@router.message(AdminStates.broadcast_message)
async def admin_broadcast_message(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_menu_kb())
        return

    # Save text (could be empty)
    text = message.text or message.caption or ""
    await state.update_data(broadcast_text=text)

    if message.photo:
        file_id = message.photo[-1].file_id
        await state.update_data(broadcast_file_id=file_id)
        await state.set_state(AdminStates.broadcast_confirm)
        await send_message_with_banner(bot, message.chat.id, f"🖼 <b>Фото получено!</b>\n\n📝 Текст: {text}\n\nОтправить рассылку?", reply_markup=broadcast_confirm_kb())
        return

    await state.set_state(AdminStates.broadcast_attach)
    await send_message_with_banner(bot, message.chat.id, "📸 <b>Хотите прикрепить фото?</b>\n\nОтправьте фото или нажмите '➡️ Пропустить' для отправки только текста.", reply_markup=broadcast_attach_kb())


@router.message(AdminStates.broadcast_attach)
async def admin_broadcast_attach(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌ Операция отменена", reply_markup=admin_menu_kb())
        return

    if message.text and (message.text.lower() == 'пропустить' or message.text == "➡️ Пропустить"):
        await state.set_state(AdminStates.broadcast_confirm)
        data = await state.get_data()
        preview = data.get('broadcast_text', '')
        await send_message_with_banner(bot, message.chat.id, f"📄 <b>Предпросмотр рассылки:</b>\n\n{preview}\n\n🚀 Отправить?", reply_markup=broadcast_confirm_kb())
        return

    if message.photo:
        file_id = message.photo[-1].file_id
        await state.update_data(broadcast_file_id=file_id)
        await state.set_state(AdminStates.broadcast_confirm)
        data = await state.get_data()
        preview = data.get('broadcast_text', '')
        await send_message_with_banner(bot, message.chat.id, f"🖼 <b>Фото добавлено!</b>\n\n📄 <b>Предпросмотр текста:</b>\n{preview}\n\n🚀 Отправить?", reply_markup=broadcast_confirm_kb())
        return

    await send_message_with_banner(bot, message.chat.id, "📸 Отправьте фото или нажмите '➡️ Пропустить' / '❌ Отмена'.", reply_markup=broadcast_attach_kb())


@router.message(AdminStates.broadcast_confirm)
async def admin_broadcast_confirm(message: Message, state: FSMContext, bot: Bot):
    if message.text and (message.text.lower() in ('нет', 'n') or message.text == "❌ Нет"):
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "❌ Отправка отменена", reply_markup=admin_menu_kb())
        return

    if message.text and (message.text.lower() in ('да', 'yes', 'y') or message.text == "✅ Да"):
        data = await state.get_data()
        text = data.get('broadcast_text', '')
        file_id = data.get('broadcast_file_id')

        users = await db.get_all_users()
        count = 0
        for u in users:
            try:
                if file_id:
                    try:
                        await bot.send_photo(u['user_id'], file_id)
                    except Exception:
                        pass
                    
                    if text:
                        try:
                            await bot.send_message(u['user_id'], text)
                        except Exception:
                            pass
                else:
                    if text:
                        try:
                            await bot.send_message(u['user_id'], text)
                        except Exception:
                            pass
                count += 1
            except:
                pass

        await state.clear()
        await send_message_with_banner(bot, message.chat.id, f"✅ Рассылка отправлена. Попыток: {count}.", reply_markup=admin_menu_kb())
        return

    await send_message_with_banner(bot, message.chat.id, "Пожалуйста, ответьте 'Да' или 'Нет'.")


@router.message(F.text == "📊 Статистика")
async def admin_stats_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    stats = await db.get_all_stats()
    text = f"""
<b>📊 Детальная статистика</b>

<b>Пользователи:</b> {stats['users_count']}
<b>Сделки:</b> {stats['deals_count']}
  • Завершено: {stats['completed_deals']}
  • Активных: {stats['active_deals']}
    ├ Ожидают партнера: {stats['pending_deals']}
    └ Ждут гаранта: {stats['waiting_admin_deals']}
<b>Тикеты:</b> {stats['open_tickets']} открытых
<b>Депозиты:</b> {stats['total_deposit']}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())


@router.message(F.text == "⚙️ Настройки")
async def admin_settings_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    min_dep = await db.get_setting('min_deposit', '100')
    text = f"""
<b>⚙️ Настройки</b>

<b>Минимальный депозит:</b> {min_dep}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_settings_kb())


@router.message(F.text == "🖼 Управление баннером")
async def admin_banner_manage(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    
    text = "<b>🖼 Управление баннером</b>\n\nЗдесь вы можете загрузить новый баннер или удалить текущий."
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_banner_kb())


@router.message(F.text == "🔙 Настройки")
async def admin_back_settings(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await admin_settings_text(message, bot)


@router.message(F.text == "📤 Загрузить баннер")
async def admin_upload_banner_start(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.upload_banner)
    await send_message_with_banner(bot, message.chat.id, "📤 Отправьте фото для баннера:", reply_markup=cancel_kb())


@router.message(AdminStates.upload_banner, F.photo)
async def admin_upload_banner_process(message: Message, state: FSMContext, bot: Bot):
    import os
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(BANNER_PATH), exist_ok=True)
    
    # Download photo
    photo = message.photo[-1]
    await bot.download(photo, destination=BANNER_PATH)
    
    await state.clear()
    await send_message_with_banner(bot, message.chat.id, "✅ Баннер успешно обновлен!", reply_markup=admin_banner_kb())


@router.message(AdminStates.upload_banner)
async def admin_upload_banner_cancel(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_banner_kb())
        return
    await send_message_with_banner(bot, message.chat.id, "❌ Пожалуйста, отправьте фото или нажмите '❌ Отмена'", reply_markup=cancel_kb())


@router.message(F.text == "🗑 Удалить баннер")
async def admin_delete_banner(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    
    import os
    if os.path.exists(BANNER_PATH):
        os.remove(BANNER_PATH)
        await send_message_with_banner(bot, message.chat.id, "✅ Баннер удален!", reply_markup=admin_banner_kb())
    else:
        await send_message_with_banner(bot, message.chat.id, "❌ Баннер не установлен.", reply_markup=admin_banner_kb())

@router.message(F.text == '👁Пользователи сервиса')
async def show_users(message: Message):
    async with aiosqlite.connect(db.DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("SELECT user_id, username, full_name FROM users")
        rows = await cursor.fetchall()

    if not rows:
        await message.answer("❌ Пока нет активных пользователей.")
        return

    user_list = []
    for row in rows:
        username = f"@{row['username']}" if row['username'] else "—"
        full_name = row['full_name'] or "Без имени"
        user_list.append(f"Ник: {full_name} | Юзер: {username}")

    text = "<b>👥 Пользователи сервиса:</b>\n\n" + "\n".join(user_list)
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "💰 Мин. сумма депозита")
async def set_min_deposit_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.setting_min_deposit)
    text = "Введите новую минимальную сумму депозита (в $):"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.setting_min_deposit)
async def process_min_deposit(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_menu_kb())
        return

    try:
        amount = float(message.text)
        if amount < 0:
            raise ValueError()
    except:
        await send_message_with_banner(bot, message.chat.id, "❌ Введите корректное число", reply_markup=cancel_kb())
        return

    await db.set_setting('min_deposit', str(amount))
    await state.clear()
    text = f"✅ Минимальный депозит установлен: {amount}$"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_settings_kb())


@router.message(F.text == "🔧 Накрутка")
async def admin_boost_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    text = """
<b>🔧 Накрутка</b>

Выберите действие:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())



from datetime import datetime

@router.message(F.text == "💬 Накрутить отзывы")
async def boost_fake_review(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    await state.set_state(AdminStates.boost_fake_review_bulk)

    text = (
        "📝 <b>Добавление отзывов пачкой</b>\n\n"
        "Скидывай отзывы одним сообщением.\n"
        "Каждый отзыв — это 4 строки, между отзывами — пустая строка.\n\n"
        "<b>Формат:</b>\n"
        "1) Кому добавить — @username или ID\n"
        "2) Дата — <code>ДД.ММ.ГГГГ ЧЧ:ММ:СС</code> или <code>now</code>\n"
        "3) Имя автора отзыва\n"
        "4) Комментарий (или <code>-</code> чтобы без комментария)\n\n"
        "<b>Пример:</b>\n"
        "<code>"
        "@target_username\n"
        "now\n"
        "KOIN | DEALPRO SERVICE\n"
        "+rep\n"
        "\n"
        "123456789\n"
        "05.01.2026 12:04:46\n"
        "Timur709\n"
        "Уважуха\n"
        "</code>"
    )
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


def _parse_dt(txt: str) -> str:
    txt = (txt or "").strip()
    if txt.lower() == "now":
        dt = datetime.now()
    else:
        dt = datetime.strptime(txt, "%d.%m.%Y %H:%M:%S")
    return dt.strftime("%d.%m.%Y %H:%M:%S")


async def _resolve_user_id(query: str):
    query = (query or "").strip()
    user = None

    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        return None

    # у тебя в коде user["user_id"] — значит так и оставляем
    return user["user_id"] if isinstance(user, dict) else user["user_id"]


def _split_blocks(text: str):
    # блоки разделяем пустой строкой
    raw_blocks = [b.strip() for b in (text or "").strip().split("\n\n") if b.strip()]
    blocks = []

    for b in raw_blocks:
        lines = [x.strip() for x in b.splitlines() if x.strip()]
        if len(lines) < 4:
            raise ValueError(f"Блок должен содержать минимум 4 строки.\n\nПроблемный блок:\n{b}")

        to_user = lines[0]
        dt = lines[1]
        author = lines[2]
        comment = "\n".join(lines[3:])  # если коммент многострочный — норм
        blocks.append((to_user, dt, author, comment))

    return blocks


@router.message(AdminStates.boost_fake_review_bulk, F.text)
async def boost_fake_review_bulk(message: Message, state: FSMContext, bot: Bot):
    txt = (message.text or "").strip()

    # если у тебя cancel_kb() возвращает кнопку "❌ Отмена"
    if txt in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    try:
        blocks = _split_blocks(txt)
    except Exception as e:
        return await send_message_with_banner(
            bot, message.chat.id,
            f"❌ Ошибка формата:\n<code>{e}</code>",
            reply_markup=cancel_kb()
        )

    ok = 0
    errors = []

    for i, (to_user_q, dt_q, author_name, comment) in enumerate(blocks, start=1):
        try:
            to_user_id = await _resolve_user_id(to_user_q)
            if not to_user_id:
                raise ValueError(f"Пользователь не найден: {to_user_q}")

            created_at = _parse_dt(dt_q)

            author_name = (author_name or "").strip().lstrip("@")
            if not author_name:
                raise ValueError("Имя автора пустое")

            comment = (comment or "").strip()
            if comment == "-":
                comment = ""   # или None, если твоя БД принимает None
            if comment == "":
                # можно разрешить пустой, но ты раньше запрещал.
                # если хочешь строго — раскомментируй:
                # raise ValueError("Комментарий пустой")
                pass

            await save_fake_review(
                to_user_id=to_user_id,
                user_name=author_name,
                comment=comment if comment else "-",   # чтобы не падало если у тебя NOT NULL
                created_at=created_at
            )

            ok += 1

        except Exception as e:
            errors.append(f"{i}) {e}")

    await state.clear()

    result = f"✅ Готово. Добавлено: <b>{ok}</b> из <b>{len(blocks)}</b>."
    if errors:
        # покажем первые 20
        result += "\n\n❌ Ошибки:\n" + "\n".join(errors[:20])
        if len(errors) > 20:
            result += f"\n...и ещё {len(errors) - 20}"

    await send_message_with_banner(bot, message.chat.id, result, reply_markup=admin_boost_kb())




async def save_fake_review(to_user_id: int, user_name: str, comment: str, created_at: str):
    await db.add_custom_fake_review(
        to_user_id=to_user_id,
        fake_username=user_name,
        comment=comment,
        created_at=created_at,
        is_positive=True,
    )


@router.message(F.text == "💰 Накрутить депозит")
async def boost_deposit_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.boost_deposit_user)
    text = "Введите @username или ID пользователя:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_deposit_user)
async def boost_deposit_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    await state.update_data(boost_user_id=user['user_id'])
    await state.set_state(AdminStates.boost_deposit_amount)
    text = f"Пользователь: @{user['username'] or user['user_id']}\nТекущий депозит: {user.get('deposit', 0)}$\n\nВведите новую сумму депозита:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_deposit_amount)
async def boost_deposit_amount(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    try:
        amount = float(message.text)
        if amount < 0:
            raise ValueError()
    except:
        await send_message_with_banner(bot, message.chat.id, "❌ Введите корректное число", reply_markup=cancel_kb())
        return

    data = await state.get_data()
    user_id = data['boost_user_id']
    await db.set_user_deposit(user_id, amount)
    await state.clear()
    text = f"✅ Депозит пользователя установлен: {amount}$"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())


@router.message(F.text == "⭐ Накрутить репутацию")
async def boost_rep_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.boost_rep_user)
    text = "Введите @username или ID пользователя:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_rep_user)
async def boost_rep_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    await state.update_data(boost_user_id=user['user_id'])
    await state.set_state(AdminStates.boost_rep_positive)
    text = f"Пользователь: @{user['username'] or user['user_id']}\nРепутация: 👍{user.get('reputation_positive', 0)} | 👎{user.get('reputation_negative', 0)}\n\nВведите кол-во положительных отзывов:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_rep_positive)
async def boost_rep_positive(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    try:
        positive = int(message.text)
        if positive < 0:
            raise ValueError()
    except:
        await send_message_with_banner(bot, message.chat.id, "❌ Введите целое число >= 0", reply_markup=cancel_kb())
        return

    await state.update_data(boost_positive=positive)
    await state.set_state(AdminStates.boost_rep_negative)
    text = "Введите кол-во отрицательных отзывов:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(F.text == "📦 Накрутить сделки")
async def boost_deals_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.boost_deals_user)
    text = "Введите @username или ID пользователя для накрутки сделок:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_deals_user)
async def boost_deals_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    await state.update_data(boost_user_id=user['user_id'])
    await state.set_state(AdminStates.boost_deals_amount)
    text = f"Пользователь: @{user['username'] or user['user_id']}\nТекущие сделки: {user.get('deals_count', 0)}\n\nВведите количество сделок для накрутки:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_deals_amount)
async def boost_deals_amount(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    try:
        amount = int(message.text)
    except:
        await send_message_with_banner(bot, message.chat.id, "❌ Введите целое число", reply_markup=cancel_kb())
        return

    data = await state.get_data()
    user_id = data.get('boost_user_id')
    
    if user_id:
        await db.add_user_deals_count(user_id, amount)
        await state.clear()
        text = f"✅ Успешно добавлено {amount} сделок пользователю."
    else:
        await db.add_fake_global_deals(amount)
        await state.clear()
        text = f"✅ Успешно добавлено {amount} сделок к общей статистике."
    
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())


@router.message(AdminStates.boost_rep_negative)
async def boost_rep_negative(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    try:
        negative = int(message.text)
        if negative < 0:
            raise ValueError()
    except:
        await send_message_with_banner(bot, message.chat.id, "❌ Введите целое число >= 0", reply_markup=cancel_kb())
        return

    data = await state.get_data()
    user_id = data['boost_user_id']
    positive = data['boost_positive']

    await db.set_user_reputation(user_id, 0, 0)
    await db.add_fake_reviews(user_id, positive, negative)

    await state.clear()
    text = f"✅ Накручено отзывов: 👍{positive} | 👎{negative}"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())


@router.message(F.text == "🛡 Назначить гарантом")
async def boost_garant_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.boost_garant_user)
    text = "Введите @username или ID пользователя для назначения гарантом:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.boost_garant_user)
async def boost_garant_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    is_garant = user.get('is_garant', 0)
    await db.set_user_garant(user['user_id'], not is_garant)
    await state.clear()

    if is_garant:
        text = f"✅ Пользователь @{user['username'] or user['user_id']} снят с роли гаранта"
    else:
        text = f"✅ Пользователь @{user['username'] or user['user_id']} назначен гарантом"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())


@router.message(F.text == "🗑 Очистить отзывы")
async def clear_reviews_start_text(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.clear_reviews_user)
    text = "Введите @username или ID пользователя для очистки отзывов:"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.clear_reviews_user)
async def clear_reviews_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_boost_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    await db.clear_fake_reviews(user['user_id'])
    await state.clear()
    text = f"✅ Все накрученные отзывы пользователя @{user['username'] or user['user_id']} удалены!\nРепутация сброшена до 0."
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_boost_kb())


@router.message(F.text == "🔄 Ожидающие сделки")
async def admin_pending_deals_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    deals = await db.get_pending_deals()
    if not deals:
        text = "<b>🔄 Ожидающие сделки</b>\n\nНет сделок в очереди."
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>🔄 Ожидающие сделки</b>\n\nВ очереди: {len(deals)}"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_pending_deals_kb(deals))


# Callback для inline кнопки "Назад" к ожидающим сделкам
@router.callback_query(F.data == "back_admin_pending_deals")
async def back_admin_pending_deals_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deals = await db.get_pending_deals()
    if not deals:
        text = "<b>🔄 Ожидающие сделки</b>\n\nНет сделок в очереди."
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>🔄 Ожидающие сделки</b>\n\nВ очереди: {len(deals)}"
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_pending_deals_kb(deals))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_view_deal_"))
async def admin_view_deal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_view_deal_", ""))
    deal = await db.get_deal(deal_id)
    if not deal:
        await callback.answer("Сделка не найдена", show_alert=True)
        return

    creator = await db.get_user(deal['creator_id'])
    partner = await db.get_user(deal['partner_id']) if deal['partner_id'] else None

    text = f"{format_deal_info(deal)}\n\n<b>Участники:</b>\n"
    if creator:
        text += f"• Создатель: @{creator['username'] or 'user'} (Деп: {creator.get('deposit', 0)}$)\n"
    if partner:
        text += f"• Партнер: @{partner['username'] or 'user'} (Деп: {partner.get('deposit', 0)}$)"

    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_take_deal_kb(deal_id))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_take_deal_"))
async def admin_take_deal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_take_deal_", ""))
    deal = await db.get_deal(deal_id)
    if not deal or deal.get('admin_id'):
        await callback.answer("Сделка уже взята", show_alert=True)
        return

    await db.assign_admin_to_deal(deal_id, callback.from_user.id)

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                await send_message_with_banner(bot, user_id, f"<b>👨‍💼 Гарант подключился к сделке #{deal_id}!</b>")
            except:
                pass

    text = f"<b>✅ Вы взяли сделку #{deal_id}!</b>"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_deal_actions_kb(deal_id))
    await callback.answer()


@router.message(F.text == "📋 Мои активные сделки")
async def admin_my_deals_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    deals = await db.get_admin_deals(message.from_user.id)
    if not deals:
        text = "<b>📋 Мои сделки</b>\n\nНет активных сделок."
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>📋 Мои сделки</b>\n\nАктивных: {len(deals)}"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_my_active_deals_kb(deals))


# Callback для inline кнопки "К моим сделкам"
@router.callback_query(F.data == "back_admin_my_deals")
async def back_admin_my_deals_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deals = await db.get_admin_deals(callback.from_user.id)
    if not deals:
        text = "<b>📋 Мои сделки</b>\n\nНет активных сделок."
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>📋 Мои сделки</b>\n\nАктивных: {len(deals)}"
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_my_active_deals_kb(deals))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_complete_"))
async def admin_complete(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_complete_", ""))
    deal = await db.get_deal(deal_id)
    if not deal:
        return

    await db.complete_deal(deal_id)

    # Активация реферала и начисление бонуса
    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            referral = await db.get_referral_by_referred(user_id)
            if referral and referral['status'] == 'pending':
                await db.activate_referral(user_id)
                # Начисляем бонус рефереру
                referrer_stats = await db.get_referral_stats(referral['referrer_id'])
                level_data = db.REFERRAL_LEVELS.get(referrer_stats['level'], db.REFERRAL_LEVELS['bronze'])
                bonus = deal['amount'] * level_data['bonus_percent'] / 100 * 0.05  # 5% комиссия * процент от уровня
                await db.add_referral_bonus(referral['referrer_id'], bonus)
                await db.update_referral_level(referral['referrer_id'])

                try:
                    await bot.send_message(
                        referral['referrer_id'],
                        f"🎉 Ваш реферал совершил первую сделку!\n"
                        f"Бонус: +{bonus:.2f}$"
                    )
                except:
                    pass

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                await send_message_with_banner(bot, user_id, f"<b>✅ Сделка #{deal_id} завершена!</b>\nОставьте отзыв!")
            except:
                pass

    text = f"<b>✅ Сделка #{deal_id} завершена!</b>"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("admin_cancel_"))
async def admin_cancel(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_cancel_", ""))
    deal = await db.get_deal(deal_id)
    if not deal:
        return

    await db.cancel_deal(deal_id)
    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                await send_message_with_banner(bot, user_id, f"<b>❌ Сделка #{deal_id} отменена гарантом</b>")
            except:
                pass

    text = f"<b>❌ Сделка #{deal_id} отменена!</b>"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("admin_message_"))
async def admin_message_start(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_message_", ""))
    await state.update_data(deal_id=deal_id)
    await state.set_state(AdminStates.messaging_deal_users)
    text = "Введите сообщение для участников сделки:"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=cancel_kb())
    await callback.answer()


@router.message(AdminStates.messaging_deal_users)
async def admin_send_message(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_menu_kb())
        return

    data = await state.get_data()
    deal_id = data['deal_id']
    deal = await db.get_deal(deal_id)
    if not deal:
        await state.clear()
        return

    msg_text = message.text.strip()
    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                await send_message_with_banner(bot, user_id, f"<b>💬 Сообщение от гаранта (сделка #{deal_id})</b>\n\n{msg_text}")
            except:
                pass

    await state.clear()
    text = "✅ Сообщение отправлено!"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())


@router.message(F.text == "🎫 Открытые тикеты")
async def admin_tickets_text(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    tickets = await db.get_open_tickets()
    if not tickets:
        text = "<b>🎫 Тикеты</b>\n\nНет открытых тикетов."
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>🎫 Тикеты</b>\n\nОткрытых: {len(tickets)}"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_open_tickets_kb(tickets))


@router.callback_query(F.data.startswith("admin_ticket_"))
async def admin_view_ticket(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    ticket_id = int(callback.data.replace("admin_ticket_", ""))
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        return

    messages = await db.get_ticket_messages(ticket_id)
    user = await db.get_user(ticket['user_id'])

    text = f"<b>🎫 Тикет #{ticket_id}</b>\n\n<b>От:</b> @{user['username'] or 'user'}\n<b>Тема:</b> {ticket['subject']}\n\n"
    for msg in messages:
        sender = "👨‍💼 Вы" if msg['is_admin'] else f"👤 @{user['username'] or 'user'}"
        text += f"{sender}:\n{msg['message']}\n\n"

    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=ticket_actions_kb(ticket_id, True))
    await callback.answer()


@router.callback_query(F.data.startswith("close_ticket_"))
async def close_ticket(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    ticket_id = int(callback.data.replace("close_ticket_", ""))
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        return

    await db.close_ticket(ticket_id)
    try:
        await send_message_with_banner(bot, ticket['user_id'], f"<b>🔴 Тикет #{ticket_id} закрыт</b>")
    except:
        pass

    text = f"✅ Тикет #{ticket_id} закрыт!"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    await callback.answer()


# ========== СДЕЛКИ ОЖИДАЮЩИЕ ПАРТНЕРА ==========

@router.message(F.text == "⏳ Ожидают партнера")
async def admin_waiting_partner_deals(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    deals = await db.get_deals_waiting_partner()
    if not deals:
        text = "<b>⏳ Сделки ожидающие партнера</b>\n\nНет сделок в ожидании партнера."
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>⏳ Сделки ожидающие партнера</b>\n\nВсего: {len(deals)}\n\nВыберите сделку для просмотра/закрытия:"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_waiting_partner_deals_kb(deals))


@router.callback_query(F.data == "back_waiting_partner")
async def back_waiting_partner_callback(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deals = await db.get_deals_waiting_partner()
    if not deals:
        text = "<b>⏳ Сделки ожидающие партнера</b>\n\nНет сделок в ожидании."
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    else:
        text = f"<b>⏳ Сделки ожидающие партнера</b>\n\nВсего: {len(deals)}"
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_waiting_partner_deals_kb(deals))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_view_pending_"))
async def admin_view_pending_deal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_view_pending_", ""))
    deal = await db.get_deal(deal_id)
    if not deal:
        await callback.answer("Сделка не найдена", show_alert=True)
        return

    creator = await db.get_user(deal['creator_id'])

    text = f"{format_deal_info(deal)}\n\n<b>Создатель:</b>\n"
    if creator:
        rep = creator.get('reputation_positive', 0) - creator.get('reputation_negative', 0)
        dep = creator.get('deposit', 0)
        text += f"• @{creator['username'] or 'user'}\n"
        text += f"  Репутация: {rep} | Депозит: {dep}$"

    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_pending_deal_actions_kb(deal_id))
    await callback.answer()


@router.callback_query(F.data.startswith("admin_close_pending_"))
async def admin_close_pending_deal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    deal_id = int(callback.data.replace("admin_close_pending_", ""))
    deal = await db.get_deal(deal_id)
    if not deal:
        await callback.answer("Сделка не найдена", show_alert=True)
        return

    if deal['status'] != 'pending':
        await callback.answer("Сделка уже не в статусе ожидания партнера", show_alert=True)
        return

    await db.cancel_deal(deal_id)

    # Уведомляем создателя
    try:
        await send_message_with_banner(
            bot, deal['creator_id'],
            f"<b>❌ Сделка #{deal_id} закрыта администратором</b>\n\n"
            f"Причина: Превышение установленного срока ожидания партнёра"
        )
    except:
        pass

    text = f"<b>✅ Сделка #{deal_id} закрыта!</b>"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=admin_menu_kb())
    await callback.answer("Сделка закрыта!")


# ========== ВЫДАЧА РОЛИ ГАРАНТА ==========

@router.message(F.text == "🛡 Выдать гаранта")
async def give_garant_start(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.give_garant_user)
    text = """
<b>🛡 Выдать роль гаранта</b>

Укажите @username пользователя для выдачи роли "Гарант":

<i>После получения роли пользователь сможет использовать команду /garant_open для просмотра и взятия сделок.</i>
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.give_garant_user)
async def give_garant_user(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_menu_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    is_garant = user.get('is_garant', 0)
    await db.set_user_garant(user['user_id'], not is_garant)
    await state.clear()

    if is_garant:
        text = f"""
<b>✅ Роль гаранта снята</b>

Пользователь: @{user['username'] or user['user_id']}
Статус: Обычный пользователь
"""
        # Уведомляем пользователя
        try:
            await bot.send_message(
                user['user_id'],
                "❌ Ваша роль гаранта была снята администратором."
            )
        except:
            pass
    else:
        text = f"""
<b>✅ Роль гаранта выдана</b>

Пользователь: @{user['username'] or user['user_id']}
Статус: Гарант

<i>Пользователь теперь может использовать команду /garant_open для просмотра и взятия сделок.</i>
"""
        # Уведомляем пользователя
        try:
            await bot.send_message(
                user['user_id'],
                "🛡 <b>Вам выдана роль гаранта!</b>\n\n"
                "Теперь вы можете:\n"
                "• Использовать команду /garant_open для просмотра сделок\n"
                "• Брать сделки как гарант\n"
                "• Завершать и отменять сделки\n\n"
                "Используйте /garant_open чтобы начать!",
                parse_mode="HTML"
            )
        except:
            pass

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_menu_kb())


# ========== БЛОКИРОВКА ПОЛЬЗОВАТЕЛЕЙ ==========

@router.message(F.text == "🚫 Заблокировать пользователя")
async def ban_user_start(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.ban_user)
    text = """
<b>🚫 Заблокировать пользователя</b>

Введите @username или ID пользователя:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.ban_user)
async def ban_user_process(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_settings_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    if user['user_id'] in ADMIN_IDS:
        await send_message_with_banner(bot, message.chat.id, "❌ Нельзя заблокировать администратора", reply_markup=admin_settings_kb())
        await state.clear()
        return

    if user.get('is_banned'):
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь уже заблокирован", reply_markup=admin_settings_kb())
        await state.clear()
        return

    await state.update_data(ban_user_id=user['user_id'], ban_username=user.get('username'))
    await state.set_state(AdminStates.ban_reason)

    text = f"""
<b>🚫 Блокировка пользователя</b>

Пользователь: @{user['username'] or user['user_id']}

Введите причину блокировки (или отправьте "-" чтобы пропустить):
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.ban_reason)
async def ban_user_reason(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_settings_kb())
        return

    data = await state.get_data()
    user_id = data.get('ban_user_id')
    username = data.get('ban_username')
    reason = message.text.strip() if message.text.strip() != "-" else None

    await db.ban_user(user_id, reason)
    await state.clear()

    # Уведомляем пользователя
    try:
        ban_text = "🚫 <b>Вы были заблокированы!</b>"
        if reason:
            ban_text += f"\n\nПричина: {reason}"
        # send with appeal button
        from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
        try:
            kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Подать на разблокировку", callback_data="appeal_start")]])
        except Exception:
            kb = None
        await bot.send_message(user_id, ban_text, parse_mode="HTML", reply_markup=kb)
    except:
        pass

    text = f"""
<b>✅ Пользователь заблокирован!</b>

Пользователь: @{username or user_id}
"""
    if reason:
        text += f"Причина: {reason}"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_settings_kb())


@router.message(F.text == "✅ Разблокировать пользователя")
async def unban_user_start(message: Message, state: FSMContext, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.unban_user)
    text = """
<b>✅ Разблокировать пользователя</b>

Введите @username или ID пользователя:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb())


@router.message(AdminStates.unban_user)
async def unban_user_process(message: Message, state: FSMContext, bot: Bot):
    if message.text == "❌ Отмена":
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Операция отменена", reply_markup=admin_settings_kb())
        return

    query = message.text.strip()
    user = None
    if query.startswith("@"):
        user = await db.get_user_by_username(query)
    elif query.isdigit():
        user = await db.get_user(int(query))
    else:
        user = await db.get_user_by_username(query)

    if not user:
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не найден", reply_markup=cancel_kb())
        return

    if not user.get('is_banned'):
        await send_message_with_banner(bot, message.chat.id, "❌ Пользователь не заблокирован", reply_markup=admin_settings_kb())
        await state.clear()
        return

    await db.unban_user(user['user_id'])
    await state.clear()

    # Уведомляем пользователя
    try:
        await bot.send_message(user['user_id'], "✅ <b>Вы были разблокированы!</b>\n\nТеперь вы можете пользоваться ботом.", parse_mode="HTML")
    except:
        pass

    # Clear ban notification cache so admin can re-notify if needed
    try:
        banned_notified.discard(user['user_id'])
    except:
        pass

    text = f"""
<b>✅ Пользователь разблокирован!</b>

Пользователь: @{user['username'] or user['user_id']}
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_settings_kb())


@router.message(F.text == "📋 Список заблокированных")
async def show_banned_users(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return
    
    banned = await db.get_banned_users()
    
    if not banned:
        text = "<b>📋 Заблокированные пользователи</b>\n\nСписок пуст."
    else:
        text = f"<b>📋 Заблокированные пользователи</b>\n\nВсего: {len(banned)}\n\n"
        for u in banned[:20]:
            text += f"• @{u['username'] or u['user_id']}"
            if u.get('ban_reason'):
                text += f" - {u['ban_reason'][:30]}"
            text += "\n"
    
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=admin_settings_kb())


# ===== Страница апелляций в админ-панели =====
@router.message(F.text == "📣 Апелляции")
async def admin_appeals_list(message: Message, bot: Bot):
    if not is_admin(message.from_user.id):
        return

    appeals = await db.get_pending_appeals()
    if not appeals:
        await send_message_with_banner(bot, message.chat.id, "✅ Нет открытых апелляций", reply_markup=admin_menu_kb())
        return

    text = f"<b>📣 Апелляции</b>\n\nВсего открытых: {len(appeals)}\n\nВыберите апелляцию для просмотра:\n"
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=f"#{a['id']} — {a['user_id']}", callback_data=f"admin_view_appeal_{a['id']}")] for a in appeals[:20]])
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=kb)


@router.callback_query(F.data.startswith("admin_view_appeal_"))
async def admin_view_appeal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return

    appeal_id = int(callback.data.replace("admin_view_appeal_", ""))
    appeal = await db.get_appeal(appeal_id)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    user = await db.get_user(appeal['user_id'])
    text = f"<b>📣 Апелляция #{appeal['id']}</b>\n\nПользователь: @{user.get('username') if user else appeal['user_id']}\nID: <code>{appeal['user_id']}</code>\nСтатус: {appeal['status']}\nДата: {appeal.get('created_at')}\n\nСообщение:\n{appeal.get('message') or ''}"

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Одобрить", callback_data=f"admin_accept_appeal_{appeal['id']}"),
        InlineKeyboardButton(text="❌ Отклонить", callback_data=f"admin_reject_appeal_{appeal['id']}")
    ], [InlineKeyboardButton(text="Назад", callback_data="back_admin_panel")]
    ])

    # Add delete-attachment button if attachment exists
    if appeal.get('attachment_file_id'):
        kb.inline_keyboard.insert(0, [InlineKeyboardButton(text="Удалить фото", callback_data=f"admin_delete_appeal_attach_{appeal['id']}")])

    # If there is an attachment, send photo first then the text with keyboard
    if appeal.get('attachment_file_id'):
        try:
            await bot.send_photo(callback.message.chat.id, appeal['attachment_file_id'])
        except:
            pass
        try:
            await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=kb)
        except:
            # fallback to plain send_message
            await bot.send_message(callback.message.chat.id, text)
    else:
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=kb)

    await callback.answer()


@router.callback_query(F.data.startswith("admin_accept_appeal_"))
async def admin_process_accept(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    appeal_id = int(callback.data.replace("admin_accept_appeal_", ""))
    appeal = await db.get_appeal(appeal_id)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    await db.process_appeal(appeal_id, callback.from_user.id, 'accepted', admin_note='Одобрено админом')
    await db.unban_user(appeal['user_id'])
    try:
        await bot.send_message(appeal['user_id'], "✅ Ваша апелляция одобрена. Вы разблокированы.")
    except:
        pass
    await callback.answer("Апелляция одобрена — пользователь разблокирован", show_alert=True)


@router.callback_query(F.data.startswith("admin_reject_appeal_"))
async def admin_process_reject(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return
    appeal_id = int(callback.data.replace("admin_reject_appeal_", ""))
    appeal = await db.get_appeal(appeal_id)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    await db.process_appeal(appeal_id, callback.from_user.id, 'rejected', admin_note='Отклонено админом')
    try:
        await bot.send_message(appeal['user_id'], "❌ Ваша апелляция отклонена. Вы остаетесь заблокированными.")
    except:
        pass
    await callback.answer("Апелляция отклонена", show_alert=True)


@router.callback_query(F.data.startswith("admin_delete_appeal_attach_"))
async def admin_delete_appeal_attach(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return

    appeal_id = int(callback.data.replace("admin_delete_appeal_attach_", ""))
    appeal = await db.get_appeal(appeal_id)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    # Clear attachment in DB
    await db.clear_appeal_attachment(appeal_id)

    try:
        await callback.answer("Фото удалено из апелляции", show_alert=True)
    except:
        pass

    # Refresh view
    await admin_view_appeal(callback, bot)


# ===== Апелляции от пользователей =====
@router.callback_query(F.data.startswith("appeal_accept_"))
async def admin_accept_appeal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return

    user_id = int(callback.data.replace("appeal_accept_", ""))
    # Find latest pending appeal for this user
    appeals = await db.get_pending_appeals()
    appeal = next((a for a in appeals if a['user_id'] == user_id), None)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    await db.process_appeal(appeal['id'], callback.from_user.id, 'accepted', admin_note='Одобрено админом')
    # Unban user
    await db.unban_user(user_id)

    # Notify user
    try:
        await bot.send_message(user_id, "✅ Ваша апелляция рассмотрена: вы разблокированы.", parse_mode="HTML")
    except:
        pass

    await callback.answer("Апелляция одобрена, пользователь разблокирован", show_alert=True)


@router.callback_query(F.data.startswith("appeal_reject_"))
async def admin_reject_appeal(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        return

    user_id = int(callback.data.replace("appeal_reject_", ""))
    appeals = await db.get_pending_appeals()
    appeal = next((a for a in appeals if a['user_id'] == user_id), None)
    if not appeal:
        await callback.answer("Апелляция не найдена", show_alert=True)
        return

    await db.process_appeal(appeal['id'], callback.from_user.id, 'rejected', admin_note='Отклонено админом')

    # Notify user
    try:
        await bot.send_message(user_id, "❌ Ваша апелляция отклонена. Вы остаетесь заблокированными.", parse_mode="HTML")
    except:
        pass

    await callback.answer("Апелляция отклонена", show_alert=True)
