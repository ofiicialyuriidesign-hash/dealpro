from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

import database as db
from config import ADMIN_IDS
from keyboards import support_kb, tickets_list_kb, ticket_actions_kb, cancel_kb, main_menu_kb
from states import SupportStates
from utils import send_message_with_banner
from locales import get_text

router = Router()


@router.message(F.text.in_(["📞 Поддержка", "📞 Support"]))
async def show_support(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    tickets = await db.get_user_tickets(message.from_user.id)
    has_open = any(t['status'] == 'open' for t in tickets)
    text = get_text('support_title', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=support_kb(has_open, lang))


@router.callback_query(F.data == "back_support")
async def back_support_callback(callback: CallbackQuery, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    tickets = await db.get_user_tickets(callback.from_user.id)
    has_open = any(t['status'] == 'open' for t in tickets)
    text = get_text('support_title', lang)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=support_kb(has_open, lang))
    await callback.answer()


@router.message(F.text.in_(["📝 Создать тикет", "📝 Create ticket"]))
async def create_ticket_start(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.set_state(SupportStates.entering_subject)
    await state.update_data(lang=lang)
    text = get_text('support_create_ticket', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(SupportStates.entering_subject)
async def process_ticket_subject(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    subject = message.text.strip()
    if len(subject) < 3:
        await send_message_with_banner(bot, message.chat.id, get_text('support_subject_short', lang), reply_markup=cancel_kb(lang))
        return

    await state.update_data(subject=subject)
    await state.set_state(SupportStates.entering_message)
    text = get_text('support_enter_message', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(SupportStates.entering_message)
async def process_ticket_message(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    ticket_message = message.text.strip()
    if len(ticket_message) < 10:
        await send_message_with_banner(bot, message.chat.id, get_text('support_message_short', lang), reply_markup=cancel_kb(lang))
        return

    subject = data['subject']
    await state.clear()

    ticket_id = await db.create_ticket(message.from_user.id, subject)
    await db.add_ticket_message(ticket_id, message.from_user.id, ticket_message)

    for admin_id in ADMIN_IDS:
        try:
            admin_text = f"<b>🎫 Новый тикет #{ticket_id}</b>\n\n<b>От:</b> @{message.from_user.username or 'user'} ({message.from_user.full_name})\n<b>Тема:</b> {subject}\n\n<b>Сообщение:</b>\n{ticket_message}"
            await send_message_with_banner(bot, admin_id, admin_text)
        except:
            pass

    text = get_text('support_ticket_created', lang, id=ticket_id, subject=subject)
    tickets = await db.get_user_tickets(message.from_user.id)
    has_open = any(t['status'] == 'open' for t in tickets)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=support_kb(has_open, lang))


@router.message(F.text.in_(["📋 Мои тикеты", "📋 My tickets"]))
async def show_my_tickets(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    tickets = await db.get_user_tickets(message.from_user.id)

    if not tickets:
        text = get_text('support_no_tickets', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=support_kb(False, lang))
    else:
        text = get_text('support_my_tickets', lang, count=len(tickets))
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=tickets_list_kb(tickets))


@router.callback_query(F.data == "back_my_tickets")
async def back_my_tickets_callback(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    tickets = await db.get_user_tickets(callback.from_user.id)

    if not tickets:
        text = get_text('support_no_tickets', lang)
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=support_kb(False, lang))
    else:
        text = get_text('support_my_tickets', lang, count=len(tickets))
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=tickets_list_kb(tickets))
    await callback.answer()


@router.callback_query(F.data.startswith("view_ticket_"))
async def view_ticket(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    ticket_id = int(callback.data.replace("view_ticket_", ""))
    ticket = await db.get_ticket(ticket_id)

    if not ticket:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    messages = await db.get_ticket_messages(ticket_id)
    status_text = get_text('support_status_open', lang) if ticket['status'] == 'open' else get_text('support_status_closed', lang)

    text = get_text('support_ticket_view', lang, id=ticket_id, subject=ticket['subject'], status=status_text, created=ticket['created_at'])
    for msg in messages:
        sender = get_text('support_from_admin', lang) if msg['is_admin'] else get_text('support_from_you', lang)
        text += f"\n{sender}:\n{msg['message']}\n"

    is_admin = callback.from_user.id in ADMIN_IDS
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=ticket_actions_kb(ticket_id, is_admin))
    await callback.answer()


@router.callback_query(F.data.startswith("reply_ticket_"))
async def reply_ticket_start(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    ticket_id = int(callback.data.replace("reply_ticket_", ""))
    await state.update_data(ticket_id=ticket_id, lang=lang)
    await state.set_state(SupportStates.replying_ticket)
    text = get_text('support_reply', lang)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=cancel_kb(lang))
    await callback.answer()


@router.message(SupportStates.replying_ticket)
async def process_ticket_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        tickets = await db.get_user_tickets(message.from_user.id)
        has_open = any(t['status'] == 'open' for t in tickets)
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=support_kb(has_open, lang))
        return

    reply_text = message.text.strip()
    ticket_id = data['ticket_id']

    is_admin = message.from_user.id in ADMIN_IDS
    await db.add_ticket_message(ticket_id, message.from_user.id, reply_text, is_admin)

    ticket = await db.get_ticket(ticket_id)

    if is_admin:
        try:
            notify_text = f"<b>💬 Новый ответ в тикете #{ticket_id}</b>\n\n<b>От:</b> Поддержка\n\n{reply_text}"
            await send_message_with_banner(bot, ticket['user_id'], notify_text)
        except:
            pass
    else:
        for admin_id in ADMIN_IDS:
            try:
                notify_text = f"<b>💬 Новый ответ в тикете #{ticket_id}</b>\n\n<b>От:</b> @{message.from_user.username or 'user'}\n\n{reply_text}"
                await send_message_with_banner(bot, admin_id, notify_text)
            except:
                pass

    await state.clear()
    text = get_text('support_reply_sent', lang, id=ticket_id)
    tickets = await db.get_user_tickets(message.from_user.id)
    has_open = any(t['status'] == 'open' for t in tickets)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=support_kb(has_open, lang))
