from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message, InlineQuery, InlineQueryResultArticle, InputTextMessageContent
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from config import ADMIN_IDS
from keyboards import (
    payment_type_kb, role_select_kb, cancel_kb, deal_created_kb,
    my_deals_kb, deal_view_kb, main_menu_kb, profile_kb,
    deal_actions_reply_kb, join_deal_reply_kb, my_deals_reply_kb, select_deal_to_close_kb, review_rating_kb
)
from states import DealViewStates
from utils import send_message_with_banner, get_payment_type_text, get_deal_status_text
from locales import get_text

router = Router()


class DealStates(StatesGroup):
    selecting_payment = State()
    selecting_role = State()
    entering_amount = State()
    entering_description = State()


@router.message(F.text.in_(["📝 Создать сделку", "📝 Create deal"]))
async def create_deal_start(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.set_state(DealStates.selecting_payment)
    await state.update_data(lang=lang)
    text = get_text('deal_create_title', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=payment_type_kb(lang))


PAYMENT_MAP_RU = {
    "💳 На карту [РУ]": "card_ru", "💳 На карту [УК]": "card_ua",
    "💳 На карту [КЗ]": "card_kz", "💳 На карту [РБ]": "card_by",
    "💎 На кошелёк [USDT]": "usdt", "🪙 На кошелёк [TON]": "ton", "⭐ Звезды": "stars"
}
PAYMENT_MAP_EN = {
    "💳 Card [RU]": "card_ru", "💳 Card [UA]": "card_ua",
    "💳 Card [KZ]": "card_kz", "💳 Card [BY]": "card_by",
    "💎 Wallet [USDT]": "usdt", "🪙 Wallet [TON]": "ton", "⭐ Stars": "stars"
}
ALL_PAYMENT_BUTTONS = list(PAYMENT_MAP_RU.keys()) + list(PAYMENT_MAP_EN.keys())


@router.message(F.text.in_(ALL_PAYMENT_BUTTONS), DealStates.selecting_payment)
async def select_payment_type(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    payment_map = {**PAYMENT_MAP_RU, **PAYMENT_MAP_EN}
    payment_type = payment_map.get(message.text, "card_ru")
    await state.update_data(payment_type=payment_type)
    await state.set_state(DealStates.selecting_role)
    text = get_text('deal_select_role', lang, method=get_payment_type_text(payment_type, lang))
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=role_select_kb(lang))


@router.message(F.text.in_(["🛒 Я покупатель", "💰 Я продавец", "🛒 I am buyer", "💰 I am seller"]), DealStates.selecting_role)
async def select_role(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    role = "buyer" if message.text in ["🛒 Я покупатель", "🛒 I am buyer"] else "seller"
    await state.update_data(creator_role=role)
    await state.set_state(DealStates.entering_amount)
    role_text = get_text('role_buyer', lang) if role == "buyer" else get_text('role_seller', lang)
    text = get_text('deal_enter_amount', lang, role=role_text)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(DealStates.entering_amount)
async def process_amount(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')

    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    try:
        amount = float(message.text.replace(",", ".").replace(" ", ""))
        if amount <= 0:
            raise ValueError()
    except ValueError:
        await send_message_with_banner(bot, message.chat.id, get_text('invalid_amount', lang), reply_markup=cancel_kb(lang))
        return

    await state.update_data(amount=amount)
    await state.set_state(DealStates.entering_description)
    text = get_text('deal_enter_desc', lang, amount=amount)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(DealStates.entering_description)
async def process_description(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')

    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    description = message.text.strip()
    if len(description) < 3:
        await send_message_with_banner(bot, message.chat.id, get_text('desc_too_short', lang), reply_markup=cancel_kb(lang))
        return

    await state.clear()

    deal_id = await db.create_deal(
        creator_id=message.from_user.id,
        payment_type=data['payment_type'],
        amount=data['amount'],
        description=description,
        creator_role=data['creator_role']
    )

    bot_info = await bot.get_me()
    invite_link = f"https://t.me/{bot_info.username}?start=deal_{deal_id}"
    role_text = get_text('role_buyer', lang) if data['creator_role'] == "buyer" else get_text('role_seller', lang)

    text = get_text('deal_created', lang,
        id=deal_id,
        amount=data['amount'],
        method=get_payment_type_text(data['payment_type'], lang),
        desc=description,
        role=role_text,
        link=invite_link
    )
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deal_created_kb(deal_id, invite_link))


@router.callback_query(F.data.startswith("join_deal_"))
async def join_deal(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("join_deal_", ""))
    deal = await db.get_deal(deal_id)

    if not deal:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return
    if deal['status'] != 'pending':
        cant_join = "Cannot join this deal anymore" if lang == 'en' else "К этой сделке уже нельзя присоединиться"
        await callback.answer(cant_join, show_alert=True)
        return
    if deal['creator_id'] == callback.from_user.id:
        own_deal = "Cannot join your own deal" if lang == 'en' else "Нельзя присоединиться к своей сделке"
        await callback.answer(own_deal, show_alert=True)
        return

    await db.join_deal(deal_id, callback.from_user.id)

    try:
        creator = await db.get_user(deal['creator_id'])
        creator_lang = creator.get('language', 'ru') if creator else 'ru'
        await send_message_with_banner(bot, deal['creator_id'], get_text('deal_partner_joined', creator_lang, id=deal_id))
    except:
        pass

    for admin_id in ADMIN_IDS:
        try:
            await send_message_with_banner(bot, admin_id, f"<b>🆕 Новая сделка #{deal_id} ждет гаранта!</b>\nСумма: {deal['amount']}₽")
        except:
            pass

    text = get_text('deal_joined', lang, id=deal_id)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=main_menu_kb(lang))
    await callback.answer()


@router.message(F.text.in_(["📋 Мои сделки", "📋 My deals"]))
async def show_my_deals(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_user_deals(message.from_user.id)
    
    await state.set_state(DealViewStates.viewing_deals_list)
    await state.update_data(user_deals=deals, lang=lang)
    
    if not deals:
        text = get_text('deal_no_deals', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))
        await state.clear()
    else:
        text = get_text('deal_my_deals', lang, count=len(deals))
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))


@router.message(F.text.regexp(r'^[⏳👨‍💼🔄✋✅❌❓] (Сделка|Deal) #(\d+)'), DealViewStates.viewing_deals_list)
async def select_deal_from_list(message: Message, state: FSMContext, bot: Bot):
    import re
    match = re.search(r'#(\d+)', message.text)
    if not match:
        return
    
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = int(match.group(1))
    deal = await db.get_deal(deal_id)

    if not deal:
        await message.answer(get_text('deal_not_found', lang))
        return

    is_admin = message.from_user.id in ADMIN_IDS
    is_participant = deal['creator_id'] == message.from_user.id or deal['partner_id'] == message.from_user.id

    if not is_participant and not is_admin:
        await message.answer(get_text('no_access', lang))
        return

    await state.set_state(DealViewStates.viewing_deal)
    await state.update_data(current_deal_id=deal_id, lang=lang)

    creator = await db.get_user(deal['creator_id'])
    partner = await db.get_user(deal['partner_id']) if deal['partner_id'] else None

    text = get_text('deal_view', lang,
        id=deal['id'],
        amount=deal['amount'],
        method=get_payment_type_text(deal['payment_type'], lang),
        desc=deal['description'] or ('Not specified' if lang == 'en' else 'Не указано'),
        status=get_deal_status_text(deal['status'], lang)
    )

    if creator:
        rep = creator.get('reputation_positive', 0) - creator.get('reputation_negative', 0)
        dep = creator.get('deposit', 0)
        role = get_text('role_buyer', lang) if deal['creator_role'] == 'buyer' else get_text('role_seller', lang)
        rep_label = "Reputation" if lang == 'en' else "Репутация"
        dep_label = "Deposit" if lang == 'en' else "Депозит"
        text += f"\n• @{creator['username'] or 'user'} ({role})\n  📊 {rep_label}: {rep} | 💰 {dep_label}: {dep}$"

    if partner:
        rep = partner.get('reputation_positive', 0) - partner.get('reputation_negative', 0)
        dep = partner.get('deposit', 0)
        role = get_text('role_seller', lang) if deal['creator_role'] == 'buyer' else get_text('role_buyer', lang)
        rep_label = "Reputation" if lang == 'en' else "Репутация"
        dep_label = "Deposit" if lang == 'en' else "Депозит"
        text += f"\n\n• @{partner['username'] or 'user'} ({role})\n  📊 {rep_label}: {rep} | 💰 {dep_label}: {dep}$"

    if deal['admin_id']:
        garant = await db.get_user(deal['admin_id'])
        garant_label = "🛡 Escrow:" if lang == 'en' else "🛡 Гарант:"
        garant_name = f"@{garant['username']}" if garant and garant.get('username') else f"ID: {deal['admin_id']}"
        text += f"\n\n<b>{garant_label}</b> {garant_name}"

    is_deal_garant = deal.get('admin_id') == message.from_user.id
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deal_actions_reply_kb(deal, message.from_user.id, is_admin, is_deal_garant, lang))


@router.message(F.text.in_(["🗑 Закрыть сделку", "🗑 Close deal"]), DealViewStates.viewing_deals_list)
async def start_close_deal(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deals = await db.get_user_deals(message.from_user.id)
    closable_deals = [d for d in deals if d['status'] in ('pending', 'waiting_admin')]
    
    if not closable_deals:
        text = get_text('deal_no_closable', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))
        return
    
    await state.set_state(DealViewStates.closing_deal)
    await state.update_data(closable_deals=closable_deals, lang=lang)
    text = get_text('deal_close_title', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=select_deal_to_close_kb(closable_deals, lang))


@router.message(F.text.regexp(r'^❌ (Закрыть|Close) #(\d+)'), DealViewStates.closing_deal)
async def close_selected_deal(message: Message, state: FSMContext, bot: Bot):
    import re
    match = re.search(r'#(\d+)', message.text)
    if not match:
        return
    
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = int(match.group(1))
    deal = await db.get_deal(deal_id)
    
    if not deal:
        await message.answer(get_text('deal_not_found', lang))
        return
    
    is_creator = deal.get('creator_id') == message.from_user.id
    is_partner = deal.get('partner_id') == message.from_user.id
    
    if not is_creator and not is_partner:
        not_participant = "You are not a participant of this deal" if lang == 'en' else "Вы не участник этой сделки"
        await message.answer(f"❌ {not_participant}")
        return
    
    if deal['status'] not in ('pending', 'waiting_admin'):
        cant_close = "This deal cannot be closed" if lang == 'en' else "Эту сделку нельзя закрыть"
        await message.answer(f"❌ {cant_close}")
        return
    
    await db.cancel_deal(deal_id)
    
    other_id = deal['partner_id'] if is_creator else deal['creator_id']
    if other_id:
        try:
            other_user = await db.get_user(other_id)
            other_lang = other_user.get('language', 'ru') if other_user else 'ru'
            await send_message_with_banner(bot, other_id, get_text('deal_cancelled_by_user', other_lang, id=deal_id))
        except:
            pass
    
    deals = await db.get_user_deals(message.from_user.id)
    await state.set_state(DealViewStates.viewing_deals_list)
    await state.update_data(user_deals=deals, lang=lang)
    
    text = get_text('deal_closed', lang, id=deal_id) + f"\n\n{get_text('deal_my_deals', lang, count=len(deals))}"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))


@router.message(F.text.in_(["🔙 Назад", "🔙 Back"]), DealViewStates.closing_deal)
async def back_from_close_deal(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deals = await db.get_user_deals(message.from_user.id)
    await state.set_state(DealViewStates.viewing_deals_list)
    await state.update_data(user_deals=deals, lang=lang)
    text = get_text('deal_my_deals', lang, count=len(deals))
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))


@router.callback_query(F.data == "back_my_deals")
async def back_my_deals_callback(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_user_deals(callback.from_user.id)
    
    await state.set_state(DealViewStates.viewing_deals_list)
    await state.update_data(user_deals=deals, lang=lang)
    
    if not deals:
        text = get_text('deal_no_deals', lang)
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=profile_kb(lang))
        await state.clear()
    else:
        text = get_text('deal_my_deals', lang, count=len(deals))
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))
    await callback.answer()


@router.callback_query(F.data.startswith("view_deal_"))
async def view_deal(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("view_deal_", ""))
    deal = await db.get_deal(deal_id)

    if not deal:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    is_admin = callback.from_user.id in ADMIN_IDS
    is_participant = deal['creator_id'] == callback.from_user.id or deal['partner_id'] == callback.from_user.id

    if not is_participant and not is_admin:
        await callback.answer(get_text('no_access', lang), show_alert=True)
        return

    await state.set_state(DealViewStates.viewing_deal)
    await state.update_data(current_deal_id=deal_id, lang=lang)

    creator = await db.get_user(deal['creator_id'])
    partner = await db.get_user(deal['partner_id']) if deal['partner_id'] else None

    text = get_text('deal_view', lang,
        id=deal['id'],
        amount=deal['amount'],
        method=get_payment_type_text(deal['payment_type'], lang),
        desc=deal['description'] or ('Not specified' if lang == 'en' else 'Не указано'),
        status=get_deal_status_text(deal['status'], lang)
    )

    if creator:
        rep = creator.get('reputation_positive', 0) - creator.get('reputation_negative', 0)
        dep = creator.get('deposit', 0)
        role = get_text('role_buyer', lang) if deal['creator_role'] == 'buyer' else get_text('role_seller', lang)
        rep_label = "Reputation" if lang == 'en' else "Репутация"
        dep_label = "Deposit" if lang == 'en' else "Депозит"
        text += f"\n• @{creator['username'] or 'user'} ({role})\n  📊 {rep_label}: {rep} | 💰 {dep_label}: {dep}$"

    if partner:
        rep = partner.get('reputation_positive', 0) - partner.get('reputation_negative', 0)
        dep = partner.get('deposit', 0)
        role = get_text('role_seller', lang) if deal['creator_role'] == 'buyer' else get_text('role_buyer', lang)
        rep_label = "Reputation" if lang == 'en' else "Репутация"
        dep_label = "Deposit" if lang == 'en' else "Депозит"
        text += f"\n\n• @{partner['username'] or 'user'} ({role})\n  📊 {rep_label}: {rep} | 💰 {dep_label}: {dep}$"

    if deal['admin_id']:
        garant = await db.get_user(deal['admin_id'])
        garant_label = "🛡 Escrow:" if lang == 'en' else "🛡 Гарант:"
        garant_name = f"@{garant['username']}" if garant and garant.get('username') else f"ID: {deal['admin_id']}"
        text += f"\n\n<b>{garant_label}</b> {garant_name}"

    is_deal_garant = deal.get('admin_id') == callback.from_user.id
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=deal_actions_reply_kb(deal, callback.from_user.id, is_admin, is_deal_garant, lang))
    await callback.answer()


@router.message(F.text.in_(["👤 Профиль создателя", "👤 Creator profile"]), DealViewStates.viewing_deal)
async def deal_view_creator_profile(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    user = await db.get_user(deal['creator_id'])
    if not user:
        await message.answer(get_text('user_not_found', lang))
        return
    
    rep = user.get('reputation_positive', 0) - user.get('reputation_negative', 0)
    name_label = "Name" if lang == 'en' else "Имя"
    not_set = "not set" if lang == 'en' else "не указан"
    rep_label = "Reputation" if lang == 'en' else "Репутация"
    dep_label = "Deposit" if lang == 'en' else "Депозит"
    creator_label = "Creator profile" if lang == 'en' else "Профиль создателя"
    
    text = f"""
<b>👤 {creator_label}</b>

<b>{name_label}:</b> {user.get('full_name', 'N/A')}
<b>Username:</b> @{user.get('username') or not_set}
<b>📊 {rep_label}:</b> {rep} ({user.get('reputation_positive', 0)}+ / {user.get('reputation_negative', 0)}-)
<b>💰 {dep_label}:</b> {user.get('deposit', 0)}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deal_actions_reply_kb(deal, message.from_user.id, message.from_user.id in ADMIN_IDS, False, lang))


@router.message(F.text.in_(["👤 Профиль партнера", "👤 Partner profile"]), DealViewStates.viewing_deal)
async def deal_view_partner_profile(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal or not deal.get('partner_id'):
        no_partner = "Partner has not joined yet" if lang == 'en' else "Партнер еще не присоединился"
        await message.answer(no_partner)
        return
    
    user = await db.get_user(deal['partner_id'])
    if not user:
        await message.answer(get_text('user_not_found', lang))
        return
    
    rep = user.get('reputation_positive', 0) - user.get('reputation_negative', 0)
    name_label = "Name" if lang == 'en' else "Имя"
    not_set = "not set" if lang == 'en' else "не указан"
    rep_label = "Reputation" if lang == 'en' else "Репутация"
    dep_label = "Deposit" if lang == 'en' else "Депозит"
    partner_label = "Partner profile" if lang == 'en' else "Профиль партнера"
    
    text = f"""
<b>👤 {partner_label}</b>

<b>{name_label}:</b> {user.get('full_name', 'N/A')}
<b>Username:</b> @{user.get('username') or not_set}
<b>📊 {rep_label}:</b> {rep} ({user.get('reputation_positive', 0)}+ / {user.get('reputation_negative', 0)}-)
<b>💰 {dep_label}:</b> {user.get('deposit', 0)}$
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deal_actions_reply_kb(deal, message.from_user.id, message.from_user.id in ADMIN_IDS, False, lang))


@router.message(F.text.in_(["❌ Отменить сделку", "❌ Cancel deal"]), DealViewStates.viewing_deal)
async def deal_cancel_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    user_id = message.from_user.id
    is_admin = user_id in ADMIN_IDS
    is_garant = deal.get('admin_id') == user_id
    is_creator = deal.get('creator_id') == user_id
    is_partner = deal.get('partner_id') == user_id
    
    if deal['status'] == 'in_progress' and (is_admin or is_garant):
        await db.cancel_deal(deal_id)
        for uid in [deal['creator_id'], deal['partner_id']]:
            if uid and uid != user_id:
                try:
                    target_user = await db.get_user(uid)
                    target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                    await send_message_with_banner(bot, uid, get_text('deal_cancelled_by_garant', target_lang, id=deal_id))
                except:
                    pass
        await state.clear()
        text = get_text('deal_cancelled', lang, id=deal_id)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))
        return
    
    if deal['status'] in ('pending', 'waiting_admin') and (is_creator or is_partner):
        await db.cancel_deal(deal_id)
        other_id = deal['partner_id'] if is_creator else deal['creator_id']
        if other_id:
            try:
                other_user = await db.get_user(other_id)
                other_lang = other_user.get('language', 'ru') if other_user else 'ru'
                await send_message_with_banner(bot, other_id, get_text('deal_cancelled_by_user', other_lang, id=deal_id))
            except:
                pass
        await state.clear()
        text = get_text('deal_cancelled', lang, id=deal_id)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))
        return
    
    cant_cancel = "You cannot cancel this deal" if lang == 'en' else "Вы не можете отменить эту сделку"
    await message.answer(f"❌ {cant_cancel}")


@router.message(F.text.in_(["✅ Завершить сделку", "✅ Complete deal"]), DealViewStates.viewing_deal)
async def deal_complete_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    user_id = message.from_user.id
    is_admin = user_id in ADMIN_IDS
    is_garant = deal.get('admin_id') == user_id
    
    if deal['status'] != 'in_progress':
        not_in_progress = "Deal is not in progress" if lang == 'en' else "Сделка не в процессе"
        await message.answer(f"❌ {not_in_progress}")
        return
    
    if not is_admin and not is_garant:
        only_garant = "Only escrow can complete the deal" if lang == 'en' else "Только гарант может завершить сделку"
        await message.answer(f"❌ {only_garant}")
        return
    
    await db.complete_deal(deal_id)
    
    for uid in [deal['creator_id'], deal['partner_id']]:
        if uid:
            try:
                target_user = await db.get_user(uid)
                target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                await send_message_with_banner(bot, uid, get_text('deal_completed', target_lang, id=deal_id))
            except:
                pass
    
    await state.clear()
    completed_label = "Deal" if lang == 'en' else "Сделка"
    completed_text = "completed" if lang == 'en' else "завершена"
    text = f"<b>✅ {completed_label} #{deal_id} {completed_text}!</b>"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))


@router.message(F.text.in_(["💬 Написать участникам", "💬 Message participants"]), DealViewStates.viewing_deal)
async def deal_message_start_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    user_id = message.from_user.id
    is_admin = user_id in ADMIN_IDS
    is_garant = deal.get('admin_id') == user_id
    is_creator = deal.get('creator_id') == user_id
    is_partner = deal.get('partner_id') == user_id
    
    if not (is_admin or is_garant or is_creator or is_partner):
        not_participant = "You are not a participant of this deal" if lang == 'en' else "Вы не участник этой сделки"
        await message.answer(f"❌ {not_participant}")
        return
    
    await state.set_state(DealViewStates.messaging_participants)
    await state.update_data(current_deal_id=deal_id, lang=lang)
    text = get_text('deal_enter_message', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(DealViewStates.messaging_participants)
async def deal_send_message_to_participants(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        deal_id = data.get('current_deal_id')
        deal = await db.get_deal(deal_id) if deal_id else None
        if deal:
            await state.set_state(DealViewStates.viewing_deal)
            await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=deal_actions_reply_kb(deal, message.from_user.id, message.from_user.id in ADMIN_IDS, False, lang))
        else:
            await state.clear()
            await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return
    
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return
    
    sender = await db.get_user(message.from_user.id)
    sender_name = f"@{sender['username']}" if sender and sender.get('username') else ("Participant" if lang == 'en' else "Участник")
    
    user_id = message.from_user.id
    is_garant = deal.get('admin_id') == user_id
    if is_garant:
        garant_label = "🛡 Escrow" if lang == 'en' else "🛡 Гарант"
        sender_name = f"{garant_label} {sender_name}"
    
    recipients = set()
    if deal.get('creator_id'):
        recipients.add(deal['creator_id'])
    if deal.get('partner_id'):
        recipients.add(deal['partner_id'])
    if deal.get('admin_id'):
        recipients.add(deal['admin_id'])
    recipients.discard(message.from_user.id)
    
    sent_count = 0
    for uid in recipients:
        try:
            target_user = await db.get_user(uid)
            target_lang = target_user.get('language', 'ru') if target_user else 'ru'
            msg_text = get_text('deal_message', target_lang, id=deal_id, sender=sender_name, text=message.text)
            await send_message_with_banner(bot, uid, msg_text)
            sent_count += 1
        except:
            pass
    
    await state.set_state(DealViewStates.viewing_deal)
    await state.update_data(current_deal_id=deal_id, lang=lang)
    text = get_text('deal_message_sent', lang, count=sent_count)
    is_admin = message.from_user.id in ADMIN_IDS
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deal_actions_reply_kb(deal, message.from_user.id, is_admin, is_garant, lang))


@router.message(F.text.in_(["⭐ Оставить отзыв", "⭐ Leave review"]), DealViewStates.viewing_deal)
async def deal_leave_review_reply(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('current_deal_id')
    if not deal_id:
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=profile_kb(lang))
        return
    
    deal = await db.get_deal(deal_id)
    if not deal or deal['status'] != 'completed':
        await message.answer(get_text('review_only_completed', lang))
        return
    
    if await db.check_review_exists(deal_id, message.from_user.id):
        await message.answer(get_text('review_already_left', lang))
        return
    
    select_type = "Select review type:" if lang == 'en' else "Выберите тип отзыва:"
    text = f"<b>⭐ {'Leave review' if lang == 'en' else 'Оставить отзыв'}</b>\n\n{select_type}"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=review_rating_kb(deal_id))


@router.message(F.text.in_(["🔙 К сделкам", "🔙 To deals"]), DealViewStates.viewing_deal)
async def back_to_deals_reply(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_user_deals(message.from_user.id)
    
    await state.set_state(DealViewStates.viewing_deals_list)
    await state.update_data(user_deals=deals, lang=lang)
    
    if not deals:
        text = get_text('deal_no_deals', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))
        await state.clear()
    else:
        text = get_text('deal_my_deals', lang, count=len(deals))
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=my_deals_reply_kb(deals, lang))


@router.message(F.text.in_(["🏠 В меню", "🏠 Menu"]), DealViewStates.viewing_deal)
async def back_to_menu_from_deal(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.clear()
    from locales import get_text as gt
    text = gt('welcome', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))


@router.inline_query(F.query.startswith("deal_"))
async def inline_share_deal(query: InlineQuery, bot: Bot):
    try:
        deal_id = int(query.query.replace("deal_", ""))
        deal = await db.get_deal(deal_id)
        if deal:
            bot_info = await bot.get_me()
            link = f"https://t.me/{bot_info.username}?start=deal_{deal_id}"
            result = InlineQueryResultArticle(
                id=str(deal_id),
                title=f"Сделка #{deal_id} - {deal['amount']}₽",
                description=deal['description'] or "Без описания",
                input_message_content=InputTextMessageContent(
                    message_text=f"🤝 Приглашение в сделку #{deal_id}\n\nСумма: {deal['amount']}₽\nОписание: {deal['description']}\n\nПрисоединиться: {link}"
                )
            )
            await query.answer([result], cache_time=1)
            return
    except:
        pass
    await query.answer([], cache_time=1)
