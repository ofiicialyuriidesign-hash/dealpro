from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

import database as db
from keyboards import review_rating_kb, cancel_kb, main_menu_kb
from utils import send_message_with_banner
from locales import get_text

router = Router()


class ReviewStates(StatesGroup):
    entering_comment = State()


@router.callback_query(F.data.startswith("leave_review_"))
async def leave_review_start(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("leave_review_", ""))
    deal = await db.get_deal(deal_id)

    if not deal:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    if deal['status'] != 'completed':
        await callback.answer(get_text('review_only_completed', lang), show_alert=True)
        return

    has_review = await db.check_review_exists(deal_id, callback.from_user.id)
    if has_review:
        await callback.answer(get_text('review_already_left', lang), show_alert=True)
        return

    to_user_id = deal['partner_id'] if deal['creator_id'] == callback.from_user.id else deal['creator_id']
    to_user = await db.get_user(to_user_id)

    text = get_text('review_title', lang, id=deal_id, username=to_user['username'] or 'user')
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=review_rating_kb(deal_id))
    await callback.answer()


@router.callback_query(F.data.startswith("review_pos_"))
async def review_positive(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("review_pos_", ""))
    deal = await db.get_deal(deal_id)

    to_user_id = deal['partner_id'] if deal['creator_id'] == callback.from_user.id else deal['creator_id']

    await state.update_data(deal_id=deal_id, to_user_id=to_user_id, is_positive=True, lang=lang)
    await state.set_state(ReviewStates.entering_comment)

    text = get_text('review_positive', lang)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=cancel_kb(lang))
    await callback.answer()


@router.callback_query(F.data.startswith("review_neg_"))
async def review_negative(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("review_neg_", ""))
    deal = await db.get_deal(deal_id)

    to_user_id = deal['partner_id'] if deal['creator_id'] == callback.from_user.id else deal['creator_id']

    await state.update_data(deal_id=deal_id, to_user_id=to_user_id, is_positive=False, lang=lang)
    await state.set_state(ReviewStates.entering_comment)

    text = get_text('review_negative', lang)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=cancel_kb(lang))
    await callback.answer()


@router.message(ReviewStates.entering_comment)
async def process_review_comment(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    comment = message.text.strip() if message.text.strip() != "-" else None
    is_positive = data['is_positive']

    rating = 5 if is_positive else 1
    await db.create_review(
        deal_id=data['deal_id'],
        from_user_id=message.from_user.id,
        to_user_id=data['to_user_id'],
        rating=rating,
        comment=comment,
        is_positive=is_positive
    )

    await state.clear()

    emoji = "👍" if is_positive else "👎"
    review_type = get_text('review_type_positive', lang) if is_positive else get_text('review_type_negative', lang)

    try:
        to_user = await db.get_user(data['to_user_id'])
        to_lang = to_user.get('language', 'ru') if to_user else 'ru'
        notify_text = get_text('review_received', to_lang, emoji=emoji, type=review_type.lower(), id=data['deal_id'])
        if comment:
            comment_label = "Comment" if to_lang == 'en' else "Комментарий"
            notify_text += f"\n{comment_label}: {comment}"
        await send_message_with_banner(bot, data['to_user_id'], notify_text)
    except:
        pass

    text = get_text('review_saved', lang, emoji=emoji, type=review_type)
    if comment:
        comment_label = "Comment" if lang == 'en' else "Комментарий"
        text += f"\n{comment_label}: {comment}"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))
