from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

import database as db
from config import DEFAULT_MIN_WITHDRAWAL
from cryptobot import create_invoice, check_invoice_paid, create_transfer
from keyboards import (
    profile_kb, deposit_menu_kb, check_payment_kb, cancel_kb, 
    main_menu_kb, confirm_withdrawal_kb, withdraw_wallet_kb
)
from states import DepositStates, WithdrawStates
from utils import send_message_with_banner

router = Router()


@router.message(F.text.in_(["👤 Профиль", "👤 Profile"]))
async def show_profile(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    stats = await db.get_user_stats(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    if not user:
        await send_message_with_banner(bot, message.chat.id, "Error" if lang == 'en' else "Ошибка")
        return

    rep_pos = stats.get('reputation_positive', 0)
    rep_neg = stats.get('reputation_negative', 0)
    rep_total = rep_pos - rep_neg
    deposit = stats.get('deposit', 0)

    if lang == 'en':
        text = f"""
<b>👤 Your profile</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Name:</b> {user['full_name']}
<b>Username:</b> @{user['username'] or 'not set'}

<b>📊 Reputation:</b>
👍 {rep_pos} | 👎 {rep_neg} | Total: {rep_total}

<b>💰 Deposit:</b> {deposit}$

<b>📋 Deals:</b> {stats.get('deals_count', 0)}
<b>✅ Successful:</b> {stats.get('successful_deals', 0)}
"""
    else:
        text = f"""
<b>👤 Ваш профиль</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Имя:</b> {user['full_name']}
<b>Username:</b> @{user['username'] or 'не указан'}

<b>📊 Репутация:</b>
👍 {rep_pos} | 👎 {rep_neg} | Итого: {rep_total}

<b>💰 Депозит:</b> {deposit}$

<b>📋 Сделок:</b> {stats.get('deals_count', 0)}
<b>✅ Успешных:</b> {stats.get('successful_deals', 0)}
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))


@router.callback_query(F.data == "back_profile")
async def back_profile_callback(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    if not user:
        await callback.answer("Error", show_alert=True)
        return

    await render_profile(bot, callback.message.chat.id, user, lang)
    await callback.answer()



@router.message(F.text.in_(["💰 Пополнить депозит", "💰 Top up deposit"]))
async def deposit_menu(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deposit = user.get('deposit', 0) if user else 0
    min_deposit = await db.get_setting('min_deposit', '100')

    if lang == 'en':
        text = f"""
<b>💰 Deposit top up</b>

<b>Current deposit:</b> {deposit}$
<b>Minimum amount:</b> {min_deposit}$

Select top up method:
"""
    else:
        text = f"""
<b>💰 Пополнение депозита</b>

<b>Текущий депозит:</b> {deposit}$
<b>Минимальная сумма:</b> {min_deposit}$

Выберите способ пополнения:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=deposit_menu_kb(lang))


@router.message(F.text == "💳 Пополнить через CryptoBot")
async def deposit_crypto(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    min_deposit = await db.get_setting('min_deposit', '100')
    await state.set_state(DepositStates.waiting_amount)
    await state.update_data(lang=lang)

    if lang == 'en':
        text = f"""
<b>💳 Top up via CryptoBot</b>

Enter amount in USDT (minimum {min_deposit}$):
"""
    else:
        text = f"""
<b>💳 Пополнение через CryptoBot</b>

Введите сумму пополнения в USDT (минимум {min_deposit}$):
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(DepositStates.waiting_amount)
async def process_deposit_amount(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')

    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Operation cancelled" if lang == 'en' else "Операция отменена", reply_markup=main_menu_kb(lang))
        return

    try:
        amount = float(message.text.replace(",", ".").replace(" ", ""))
    except ValueError:
        await send_message_with_banner(bot, message.chat.id, "❌ Enter valid amount:" if lang == 'en' else "❌ Введите корректную сумму:", reply_markup=cancel_kb(lang))
        return

    min_deposit = float(await db.get_setting('min_deposit', '100'))

    if amount < min_deposit:
        await send_message_with_banner(bot, message.chat.id, f"❌ Minimum: {min_deposit}$" if lang == 'en' else f"❌ Минимальная сумма: {min_deposit}$", reply_markup=cancel_kb(lang))
        return

    await state.clear()
    invoice = await create_invoice(amount, message.from_user.id)

    if not invoice:
        text = "❌ Error creating invoice. Contact support." if lang == 'en' else "❌ Ошибка создания счета. Обратитесь в поддержку."
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))
        return

    await db.create_payment(message.from_user.id, amount, str(invoice['invoice_id']))

    if lang == 'en':
        text = f"""
<b>💳 Invoice created!</b>

<b>Amount:</b> {amount} USDT
<b>Payment link:</b>
{invoice.get('pay_url', 'Link unavailable')}

After payment click "Check payment".
"""
    else:
        text = f"""
<b>💳 Счет на оплату создан!</b>

<b>Сумма:</b> {amount} USDT
<b>Ссылка для оплаты:</b>
{invoice.get('pay_url', 'Ссылка недоступна')}

После оплаты нажмите кнопку "Проверить оплату".
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=check_payment_kb(str(invoice['invoice_id'])))


@router.callback_query(F.data.startswith("check_pay_"))
async def check_payment(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    invoice_id = callback.data.replace("check_pay_", "")
    is_paid = await check_invoice_paid(invoice_id)

    if is_paid:
        payment = await db.complete_payment(invoice_id)
        if payment:
            text = f"<b>✅ {'Payment received!' if lang == 'en' else 'Оплата получена!'}</b>\n\n{'Deposit topped up by' if lang == 'en' else 'Депозит пополнен на'} {payment['amount']}$"
            await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=profile_kb(lang))
        else:
            await callback.answer("Payment already processed" if lang == 'en' else "Платеж уже обработан", show_alert=True)
    else:
        await callback.answer("Payment not received yet" if lang == 'en' else "Оплата еще не получена", show_alert=True)


@router.message(F.text.in_(["📊 Статистика", "📊 Statistics"]))
async def show_my_stats(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    stats = await db.get_user_stats(message.from_user.id)
    deals = await db.get_user_deals(message.from_user.id)

    completed = len([d for d in deals if d['status'] == 'completed'])
    cancelled = len([d for d in deals if d['status'] == 'cancelled'])
    active = len([d for d in deals if d['status'] in ('pending', 'waiting_admin', 'in_progress')])
    rep_pos = stats.get('reputation_positive', 0)
    rep_neg = stats.get('reputation_negative', 0)
    success_rate = round(completed / len(deals) * 100, 1) if deals else 0

    if lang == 'en':
        text = f"""
<b>📊 Detailed statistics</b>

<b>Deals:</b>
• Total: {len(deals)}
• Active: {active}
• Completed: {completed}
• Cancelled: {cancelled}

<b>Reputation:</b>
• Positive: {rep_pos}
• Negative: {rep_neg}
• Total: {rep_pos - rep_neg}

<b>Success rate:</b> {success_rate}%
"""
    else:
        text = f"""
<b>📊 Детальная статистика</b>

<b>Сделки:</b>
• Всего: {len(deals)}
• Активных: {active}
• Завершенных: {completed}
• Отмененных: {cancelled}

<b>Репутация:</b>
• Положительных: {rep_pos}
• Отрицательных: {rep_neg}
• Итого: {rep_pos - rep_neg}

<b>Процент успеха:</b> {success_rate}%
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))


@router.message(F.text.in_(["🔙 Назад", "🔙 Back"]))
async def go_back(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    current_state = await state.get_state()

    if current_state == DepositStates.waiting_amount:
        await state.clear()
        deposit = user.get('deposit', 0) if user else 0
        min_deposit = await db.get_setting('min_deposit', '100')
        text = f"<b>💰 {'Deposit' if lang == 'en' else 'Депозит'}</b>\n\n{'Current:' if lang == 'en' else 'Текущий:'} {deposit}$\n{'Minimum:' if lang == 'en' else 'Минимум:'} {min_deposit}$"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=deposit_menu_kb(lang))
        return

    # ✅ ВОТ ТУТ БЫЛ ТВОЙ “КРИВОЙ” ПРОФИЛЬ — заменяем
    await state.clear()
    if not user:
        await send_message_with_banner(bot, message.chat.id, "Error", reply_markup=main_menu_kb(lang))
        return

    await render_profile(bot, message.chat.id, user, lang)



@router.message(F.text.in_(["💸 Вывести средства", "💸 Withdraw"]))
async def withdraw_menu(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    
    if not user:
        await send_message_with_banner(bot, message.chat.id, "Error" if lang == 'en' else "Ошибка", reply_markup=main_menu_kb(lang))
        return
    
    deposit = user.get('deposit', 0)
    
    if deposit <= 0:
        text = f"<b>💸 {'Withdraw' if lang == 'en' else 'Вывод средств'}</b>\n\n❌ {'Insufficient funds' if lang == 'en' else 'Недостаточно средств'}"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=profile_kb(lang))
        return

    await state.set_state(WithdrawStates.waiting_amount)
    await state.update_data(lang=lang)

    if lang == 'en':
        text = f"""
<b>💸 Withdraw funds</b>

<b>Available:</b> {deposit}$
<b>Minimum:</b> {DEFAULT_MIN_WITHDRAWAL} USDT

Enter amount to withdraw:
"""
    else:
        text = f"""
<b>💸 Вывод средств</b>

<b>Доступно:</b> {deposit}$
<b>Минимум:</b> {DEFAULT_MIN_WITHDRAWAL} USDT

Введите сумму для вывода:
"""
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(WithdrawStates.waiting_amount)
async def process_withdraw_amount(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')

    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Cancelled" if lang == 'en' else "Отменено", reply_markup=profile_kb(lang))
        return
    
    try:
        amount = float(message.text.replace(",", ".").replace(" ", ""))
    except ValueError:
        await send_message_with_banner(bot, message.chat.id, "❌ Enter valid amount" if lang == 'en' else "❌ Введите корректную сумму", reply_markup=cancel_kb(lang))
        return
    
    if amount < DEFAULT_MIN_WITHDRAWAL:
        await send_message_with_banner(bot, message.chat.id, f"❌ Minimum: {DEFAULT_MIN_WITHDRAWAL} USDT", reply_markup=cancel_kb(lang))
        return
    
    user = await db.get_user(message.from_user.id)
    deposit = user.get('deposit', 0)
    
    if amount > deposit:
        await send_message_with_banner(bot, message.chat.id, f"❌ {'Insufficient funds. Balance:' if lang == 'en' else 'Недостаточно средств. Баланс:'} {deposit}$", reply_markup=cancel_kb(lang))
        return
    
    await state.update_data(amount=amount)
    saved_wallet = user.get('withdrawal_wallet')
    
    text = f"<b>💸 {'Withdraw' if lang == 'en' else 'Вывод'}</b>\n\n{'Amount:' if lang == 'en' else 'Сумма:'} {amount} USDT\n\n{'Enter wallet address:' if lang == 'en' else 'Введите адрес кошелька:'}"
    
    if saved_wallet:
        text += f"\n{'Saved wallet:' if lang == 'en' else 'Сохранённый:'} <code>{saved_wallet}</code>"
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=withdraw_wallet_kb(saved_wallet))
    else:
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))
        
    await state.set_state(WithdrawStates.waiting_wallet)


@router.message(WithdrawStates.waiting_wallet)
async def process_withdraw_wallet(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')

    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, "Cancelled" if lang == 'en' else "Отменено", reply_markup=profile_kb(lang))
        return
    
    user = await db.get_user(message.from_user.id)
    saved_wallet = user.get('withdrawal_wallet')
    wallet_address = message.text.strip()
    
    if message.text.startswith("Использовать: ") and saved_wallet:
        wallet_address = saved_wallet
    elif message.text == "✏️ Ввести другой кошелек":
        await send_message_with_banner(bot, message.chat.id, "Enter wallet:" if lang == 'en' else "Введите кошелек:", reply_markup=cancel_kb(lang))
        return
    
    if len(wallet_address) < 10:
        await send_message_with_banner(bot, message.chat.id, "❌ Invalid address" if lang == 'en' else "❌ Неверный адрес", reply_markup=cancel_kb(lang))
        return

    await db.update_user_withdrawal_wallet(message.from_user.id, wallet_address)
    amount = data.get('amount')
    withdrawal_id = await db.create_withdrawal(message.from_user.id, amount, wallet_address)
    
    await state.update_data(withdrawal_id=withdrawal_id, wallet=wallet_address)
    await state.set_state(WithdrawStates.confirming)
    
    text = f"<b>💸 {'Confirm withdrawal' if lang == 'en' else 'Подтверждение'}</b>\n\n{'Amount:' if lang == 'en' else 'Сумма:'} {amount} USDT\n{'Wallet:' if lang == 'en' else 'Кошелек:'} <code>{wallet_address}</code>\n\n{'Confirm?' if lang == 'en' else 'Подтвердить?'}"
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=confirm_withdrawal_kb(withdrawal_id))


@router.callback_query(F.data.startswith("confirm_withdraw_"))
async def confirm_withdrawal(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    withdrawal_id = int(callback.data.replace("confirm_withdraw_", ""))
    withdrawal = await db.get_withdrawal(withdrawal_id)
    
    if not withdrawal or withdrawal['status'] != 'pending':
        await callback.answer("Error" if lang == 'en' else "Ошибка", show_alert=True)
        await state.clear()
        return

    text = f"<b>✅ {'Withdrawal request created!' if lang == 'en' else 'Заявка создана!'}</b>\n\nID: #{withdrawal_id}\n{'Amount:' if lang == 'en' else 'Сумма:'} {withdrawal['amount']} USDT"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=profile_kb(lang))
    await callback.answer("✅")
    await state.clear()


@router.callback_query(F.data == "cancel_withdraw")
async def cancel_withdrawal_callback(callback: CallbackQuery, state: FSMContext, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    data = await state.get_data()
    withdrawal_id = data.get('withdrawal_id')
    
    if withdrawal_id:
        await db.cancel_withdrawal(withdrawal_id)
    
    await state.clear()
    await send_message_with_banner(bot, callback.message.chat.id, "❌ Cancelled" if lang == 'en' else "❌ Отменено", reply_markup=profile_kb(lang))
    await callback.answer()

async def render_profile(bot: Bot, chat_id: int, user: dict, lang: str):
    stats = await db.get_user_stats(user["user_id"])

    rep_pos = stats.get('reputation_positive', 0)
    rep_neg = stats.get('reputation_negative', 0)
    rep_total = rep_pos - rep_neg
    deposit = stats.get('deposit', 0)

    deals_total = stats.get('deals_total', stats.get('deals', 0))
    deals_success = stats.get('deals_successful', stats.get('successful_deals', 0))

    if lang == 'en':
        text = f"""
<b>👤 Your profile</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Name:</b> {user.get('full_name') or '—'}
<b>Username:</b> @{user.get('username') or 'not set'}

<b>📊 Reputation:</b>
👍 {rep_pos} | 👎 {rep_neg} | Total: {rep_total}

<b>💰 Deposit:</b> {deposit}$

<b>📦 Deals:</b> {deals_total}
<b>✅ Successful:</b> {deals_success}
"""
    else:
        text = f"""
<b>👤 Ваш профиль</b>

<b>ID:</b> <code>{user['user_id']}</code>
<b>Имя:</b> {user.get('full_name') or '—'}
<b>Username:</b> @{user.get('username') or 'не указан'}

<b>📊 Репутация:</b>
👍 {rep_pos} | 👎 {rep_neg} | Итого: {rep_total}

<b>💰 Депозит:</b> {deposit}$

<b>📦 Сделок:</b> {deals_total}
<b>✅ Успешных:</b> {deals_success}
"""
    await send_message_with_banner(bot, chat_id, text, reply_markup=profile_kb(lang))
