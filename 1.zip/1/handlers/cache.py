# Simple in-memory cache for handlers
# Tracks user_ids that have already been notified about their ban during this process lifetime
banned_notified = set()
