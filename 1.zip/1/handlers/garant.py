from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.utils.keyboard import InlineKeyboardBuilder

import database as db
from keyboards import main_menu_kb, cancel_kb, garant_deal_actions_reply_kb
from states import GarantStates
from utils import send_message_with_banner, format_deal_info
from locales import get_text

router = Router()


def garant_pending_deals_kb(deals: list, lang: str = 'ru'):
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        deal_label = "Deal" if lang == 'en' else "Сделка"
        builder.row(InlineKeyboardButton(
            text=f"📝 {deal_label} #{deal['id']} - {deal['amount']}₽",
            callback_data=f"garant_view_deal_{deal['id']}"
        ))
    menu_label = "🏠 Menu" if lang == 'en' else "🏠 В меню"
    builder.row(InlineKeyboardButton(text=menu_label, callback_data="back_main_menu"))
    return builder.as_markup()


def garant_take_deal_kb(deal_id: int, lang: str = 'ru'):
    builder = InlineKeyboardBuilder()
    take_label = "✅ Take deal as escrow" if lang == 'en' else "✅ Взять сделку как гарант"
    back_label = "🔙 Back to list" if lang == 'en' else "🔙 Назад к списку"
    builder.row(InlineKeyboardButton(text=take_label, callback_data=f"garant_take_deal_{deal_id}"))
    builder.row(InlineKeyboardButton(text=back_label, callback_data="garant_back_to_deals"))
    return builder.as_markup()


def garant_my_deals_kb(deals: list, lang: str = 'ru'):
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        status_emoji = {'in_progress': '🔄', 'waiting_confirm': '✋'}.get(deal['status'], '❓')
        deal_label = "Deal" if lang == 'en' else "Сделка"
        builder.row(InlineKeyboardButton(
            text=f"{status_emoji} {deal_label} #{deal['id']} - {deal['amount']}₽",
            callback_data=f"garant_manage_deal_{deal['id']}"
        ))
    menu_label = "🏠 Menu" if lang == 'en' else "🏠 В меню"
    builder.row(InlineKeyboardButton(text=menu_label, callback_data="back_main_menu"))
    return builder.as_markup()


async def is_garant(user_id: int) -> bool:
    user = await db.get_user(user_id)
    return user and user.get('is_garant', 0) == 1


@router.message(Command("garant_open"))
async def cmd_garant_open(message: Message, bot: Bot):
    if not await is_garant(message.from_user.id):
        await message.answer("❌ У вас нет роли гаранта.")
        return

    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_pending_deals()
    
    if not deals:
        text = get_text('garant_no_deals', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))
    else:
        text = get_text('garant_panel', lang, count=len(deals))
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=garant_pending_deals_kb(deals, lang))


@router.callback_query(F.data == "garant_back_to_deals")
async def garant_back_to_deals(callback: CallbackQuery, bot: Bot):
    if not await is_garant(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_pending_deals()
    
    if not deals:
        text = get_text('garant_no_deals', lang)
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=main_menu_kb(lang))
    else:
        text = get_text('garant_panel', lang, count=len(deals))
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_pending_deals_kb(deals, lang))
    await callback.answer()


@router.callback_query(F.data.startswith("garant_view_deal_"))
async def garant_view_deal(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await is_garant(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("garant_view_deal_", ""))
    deal = await db.get_deal(deal_id)

    if not deal:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    creator = await db.get_user(deal['creator_id'])
    partner = await db.get_user(deal['partner_id']) if deal['partner_id'] else None

    participants_label = "Participants" if lang == 'en' else "Участники"
    creator_label = "creator" if lang == 'en' else "создатель"
    partner_label = "partner" if lang == 'en' else "партнер"
    rep_label = "Reputation" if lang == 'en' else "Репутация"
    dep_label = "Deposit" if lang == 'en' else "Депозит"

    text = f"{format_deal_info(deal, lang)}\n\n<b>👥 {participants_label}:</b>\n"
    if creator:
        rep = creator.get('reputation_positive', 0) - creator.get('reputation_negative', 0)
        dep = creator.get('deposit', 0)
        text += f"\n• @{creator['username'] or 'user'} ({creator_label})\n  {rep_label}: {rep} | {dep_label}: {dep}$"
    if partner:
        rep = partner.get('reputation_positive', 0) - partner.get('reputation_negative', 0)
        dep = partner.get('deposit', 0)
        text += f"\n\n• @{partner['username'] or 'user'} ({partner_label})\n  {rep_label}: {rep} | {dep_label}: {dep}$"

    if deal.get('admin_id') == callback.from_user.id:
        await state.set_state(GarantStates.viewing_deal)
        await state.update_data(garant_deal_id=deal_id, lang=lang)
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_deal_actions_reply_kb(lang))
    else:
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_take_deal_kb(deal_id, lang))
    await callback.answer()


@router.callback_query(F.data.startswith("garant_take_deal_"))
async def garant_take_deal(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await is_garant(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("garant_take_deal_", ""))
    deal = await db.get_deal(deal_id)

    if not deal:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    if deal.get('admin_id'):
        await callback.answer(get_text('garant_already_taken', lang), show_alert=True)
        return

    await db.assign_admin_to_deal(deal_id, callback.from_user.id)

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                target_user = await db.get_user(user_id)
                target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                await send_message_with_banner(bot, user_id, get_text('garant_connected', target_lang, id=deal_id))
            except:
                pass

    await state.set_state(GarantStates.viewing_deal)
    await state.update_data(garant_deal_id=deal_id, lang=lang)

    text = get_text('garant_taken', lang, id=deal_id)
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_deal_actions_reply_kb(lang))
    await callback.answer()


@router.callback_query(F.data == "garant_my_deals")
async def garant_my_deals(callback: CallbackQuery, bot: Bot):
    if not await is_garant(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deals = await db.get_admin_deals(callback.from_user.id)
    
    if not deals:
        text = get_text('garant_no_active', lang)
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=main_menu_kb(lang))
    else:
        text = get_text('garant_my_deals', lang, count=len(deals))
        await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_my_deals_kb(deals, lang))
    await callback.answer()


@router.callback_query(F.data.startswith("garant_manage_deal_"))
async def garant_manage_deal(callback: CallbackQuery, state: FSMContext, bot: Bot):
    if not await is_garant(callback.from_user.id):
        await callback.answer("Нет доступа", show_alert=True)
        return

    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    deal_id = int(callback.data.replace("garant_manage_deal_", ""))
    deal = await db.get_deal(deal_id)

    if not deal or deal.get('admin_id') != callback.from_user.id:
        await callback.answer(get_text('deal_not_found', lang), show_alert=True)
        return

    await state.set_state(GarantStates.viewing_deal)
    await state.update_data(garant_deal_id=deal_id, lang=lang)

    creator = await db.get_user(deal['creator_id'])
    partner = await db.get_user(deal['partner_id']) if deal['partner_id'] else None

    participants_label = "Participants" if lang == 'en' else "Участники"
    creator_label = "creator" if lang == 'en' else "создатель"
    partner_label = "partner" if lang == 'en' else "партнер"

    text = f"{format_deal_info(deal, lang)}\n\n<b>👥 {participants_label}:</b>\n"
    if creator:
        text += f"• @{creator['username'] or 'user'} ({creator_label})\n"
    if partner:
        text += f"• @{partner['username'] or 'user'} ({partner_label})"

    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=garant_deal_actions_reply_kb(lang))
    await callback.answer()


@router.message(F.text.in_(["✅ Завершить сделку", "✅ Complete deal"]), GarantStates.viewing_deal)
async def garant_complete_deal_reply(message: Message, state: FSMContext, bot: Bot):
    if not await is_garant(message.from_user.id):
        await message.answer("❌ У вас нет роли гаранта.")
        return

    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('garant_deal_id')
    
    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    deal = await db.get_deal(deal_id)
    if not deal or deal.get('admin_id') != message.from_user.id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    await db.complete_deal(deal_id)

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            referral = await db.get_referral_by_referred(user_id)
            if referral and referral['status'] == 'pending':
                await db.activate_referral(user_id)
                referrer_stats = await db.get_referral_stats(referral['referrer_id'])
                level_data = db.REFERRAL_LEVELS.get(referrer_stats['level'], db.REFERRAL_LEVELS['bronze'])
                bonus = deal['amount'] * level_data['bonus_percent'] / 100 * 0.05
                await db.add_referral_bonus(referral['referrer_id'], bonus)
                await db.update_referral_level(referral['referrer_id'])
                try:
                    await bot.send_message(referral['referrer_id'], f"🎉 Ваш реферал совершил первую сделку!\nБонус: +{bonus:.2f}$")
                except:
                    pass

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                target_user = await db.get_user(user_id)
                target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                await send_message_with_banner(bot, user_id, get_text('deal_completed', target_lang, id=deal_id))
            except:
                pass

    await state.clear()
    text = get_text('deal_cancelled', lang, id=deal_id).replace('отменена', 'завершена').replace('cancelled', 'completed')
    await send_message_with_banner(bot, message.chat.id, f"<b>✅ {'Deal' if lang == 'en' else 'Сделка'} #{deal_id} {'completed' if lang == 'en' else 'завершена'}!</b>", reply_markup=main_menu_kb(lang))


@router.message(F.text.in_(["❌ Отменить сделку", "❌ Cancel deal"]), GarantStates.viewing_deal)
async def garant_cancel_deal_reply(message: Message, state: FSMContext, bot: Bot):
    if not await is_garant(message.from_user.id):
        await message.answer("❌ У вас нет роли гаранта.")
        return

    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('garant_deal_id')
    
    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    deal = await db.get_deal(deal_id)
    if not deal or deal.get('admin_id') != message.from_user.id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    await db.cancel_deal(deal_id)

    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                target_user = await db.get_user(user_id)
                target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                await send_message_with_banner(bot, user_id, get_text('deal_cancelled_by_garant', target_lang, id=deal_id))
            except:
                pass

    await state.clear()
    text = get_text('deal_cancelled', lang, id=deal_id)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))


@router.message(F.text.in_(["💬 Написать участникам", "💬 Message participants"]), GarantStates.viewing_deal)
async def garant_message_start_reply(message: Message, state: FSMContext, bot: Bot):
    if not await is_garant(message.from_user.id):
        await message.answer("❌ У вас нет роли гаранта.")
        return

    data = await state.get_data()
    lang = data.get('lang', 'ru')
    deal_id = data.get('garant_deal_id')
    
    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    await state.set_state(GarantStates.messaging_deal)
    await state.update_data(garant_deal_id=deal_id, lang=lang)

    text = get_text('deal_enter_message', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(GarantStates.messaging_deal)
async def garant_send_message(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        deal_id = data.get('garant_deal_id')
        if deal_id:
            await state.set_state(GarantStates.viewing_deal)
            await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=garant_deal_actions_reply_kb(lang))
        else:
            await state.clear()
            await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    deal_id = data.get('garant_deal_id')
    if not deal_id:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    deal = await db.get_deal(deal_id)
    if not deal:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('deal_not_found', lang), reply_markup=main_menu_kb(lang))
        return

    sender = await db.get_user(message.from_user.id)
    garant_label = "🛡 Escrow" if lang == 'en' else "🛡 Гарант"
    sender_name = f"{garant_label} @{sender['username']}" if sender and sender.get('username') else garant_label

    sent_count = 0
    for user_id in [deal['creator_id'], deal['partner_id']]:
        if user_id:
            try:
                target_user = await db.get_user(user_id)
                target_lang = target_user.get('language', 'ru') if target_user else 'ru'
                msg_text = get_text('deal_message', target_lang, id=deal_id, sender=sender_name, text=message.text)
                await send_message_with_banner(bot, user_id, msg_text)
                sent_count += 1
            except:
                pass

    await state.set_state(GarantStates.viewing_deal)
    await state.update_data(garant_deal_id=deal_id, lang=lang)

    text = get_text('deal_message_sent', lang, count=sent_count)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=garant_deal_actions_reply_kb(lang))


@router.message(F.text.in_(["🔙 К моим сделкам", "🔙 To my deals"]), GarantStates.viewing_deal)
async def garant_back_to_my_deals_reply(message: Message, state: FSMContext, bot: Bot):
    if not await is_garant(message.from_user.id):
        await state.clear()
        await message.answer("❌ У вас нет роли гаранта.")
        return

    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.clear()
    deals = await db.get_admin_deals(message.from_user.id)
    
    if not deals:
        text = get_text('garant_no_active', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=main_menu_kb(lang))
    else:
        text = get_text('garant_my_deals', lang, count=len(deals))
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=garant_my_deals_kb(deals, lang))
