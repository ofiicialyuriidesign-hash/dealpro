from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

import database as db
from keyboards import profile_kb, referral_menu_kb, referral_list_kb
from utils import send_message_with_banner
from locales import get_text

router = Router()


def get_level_emoji(level: str) -> str:
    return {'bronze': '🥉', 'silver': '🥈', 'gold': '🥇', 'vip': '👑'}.get(level, '🥉')


def get_level_name(level: str, lang: str = 'ru') -> str:
    names = {
        'ru': {'bronze': 'Бронза', 'silver': 'Серебро', 'gold': 'Золото', 'vip': 'VIP'},
        'en': {'bronze': 'Bronze', 'silver': 'Silver', 'gold': 'Gold', 'vip': 'VIP'}
    }
    return names.get(lang, names['ru']).get(level, 'Bronze' if lang == 'en' else 'Бронза')


def get_next_level_info(level: str, active_refs: int, lang: str = 'ru') -> str:
    levels_order = ['bronze', 'silver', 'gold', 'vip']
    current_idx = levels_order.index(level) if level in levels_order else 0

    if current_idx >= len(levels_order) - 1:
        return get_text('referral_max_level', lang)

    next_level = levels_order[current_idx + 1]
    next_data = db.REFERRAL_LEVELS[next_level]
    refs_needed = next_data['min_refs'] - active_refs

    return get_text('referral_next_level', lang, emoji=get_level_emoji(next_level), name=get_level_name(next_level, lang), refs=refs_needed)


@router.message(F.text.in_(["👥 Рефералы", "👥 Referrals"]))
async def show_referral_menu(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    if not user:
        await send_message_with_banner(bot, message.chat.id, get_text('error', lang))
        return

    stats = await db.get_referral_stats(message.from_user.id)
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start=ref_{message.from_user.id}"

    level = stats['level']
    level_data = db.REFERRAL_LEVELS.get(level, db.REFERRAL_LEVELS['bronze'])

    text = get_text('referral_title', lang,
        level_emoji=get_level_emoji(level),
        level_name=get_level_name(level, lang),
        bonus=level_data['bonus_percent'],
        total=stats['total'],
        active=stats['active'],
        earned=f"{stats['bonus']:.2f}",
        next_level=get_next_level_info(level, stats['active'], lang),
        link=ref_link
    )
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_menu_kb(lang))


@router.message(F.text.in_(["📋 Мои рефералы", "📋 My referrals"]))
async def show_my_referrals(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    referrals = await db.get_user_referrals(message.from_user.id)

    if not referrals:
        text = get_text('referral_empty', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_menu_kb(lang))
        return

    text = get_text('referral_my', lang, count=len(referrals))
    deals_label = "deals" if lang == 'en' else "сделок"

    for i, ref in enumerate(referrals[:15], 1):
        status_emoji = "✅" if ref['status'] == 'active' else "⏳"
        username = ref.get('username') or ('User' if lang == 'en' else 'Пользователь')
        deals = ref.get('successful_deals', 0)
        text += f"{i}. {status_emoji} @{username} - {deals_label}: {deals}\n"

    if len(referrals) > 15:
        more_label = "and more" if lang == 'en' else "и еще"
        text += f"\n<i>...{more_label} {len(referrals) - 15}</i>"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_list_kb(lang))


@router.message(F.text.in_(["🏆 Топ рефереров", "🏆 Top referrers"]))
async def show_referral_leaderboard(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    leaders = await db.get_referral_leaderboard(10)

    if not leaders:
        text = get_text('referral_top_empty', lang)
        await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_menu_kb(lang))
        return

    text = get_text('referral_top', lang)
    active_label = "Active" if lang == 'en' else "Активных"
    bonus_label = "Bonus" if lang == 'en' else "Бонус"

    medals = ['🥇', '🥈', '🥉']
    for i, leader in enumerate(leaders, 1):
        medal = medals[i-1] if i <= 3 else f"{i}."
        username = leader.get('username') or ('User' if lang == 'en' else 'Пользователь')
        level_emoji = get_level_emoji(leader.get('referral_level', 'bronze'))
        active = leader.get('active_refs', 0)
        bonus = leader.get('referral_bonus', 0)

        text += f"{medal} {level_emoji} @{username}\n    {active_label}: {active} | {bonus_label}: {bonus:.2f}$\n\n"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_menu_kb(lang))


@router.message(F.text.in_(["📖 Правила", "📖 Rules"]))
async def show_referral_rules(message: Message, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    text = get_text('referral_rules', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=referral_menu_kb(lang))


@router.callback_query(F.data == "back_referral_menu")
async def back_to_referral_menu(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    stats = await db.get_referral_stats(callback.from_user.id)
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start=ref_{callback.from_user.id}"

    level = stats['level']
    level_data = db.REFERRAL_LEVELS.get(level, db.REFERRAL_LEVELS['bronze'])

    text = get_text('referral_title', lang,
        level_emoji=get_level_emoji(level),
        level_name=get_level_name(level, lang),
        bonus=level_data['bonus_percent'],
        total=stats['total'],
        active=stats['active'],
        earned=f"{stats['bonus']:.2f}",
        next_level=get_next_level_info(level, stats['active'], lang),
        link=ref_link
    )
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=referral_menu_kb(lang))
    await callback.answer()


@router.callback_query(F.data == "copy_ref_link")
async def copy_referral_link(callback: CallbackQuery, bot: Bot):
    await callback.answer("Ссылка скопирована!", show_alert=False)


@router.callback_query(F.data == "share_ref_link")
async def share_referral_link(callback: CallbackQuery, bot: Bot):
    user = await db.get_user(callback.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start=ref_{callback.from_user.id}"

    from urllib.parse import quote
    share_text = "Join DealPro - reliable escrow service for secure deals!" if lang == 'en' else "Присоединяйся к DealPro - надежному гарант-сервису для безопасных сделок!"
    share_url = f"https://t.me/share/url?url={quote(ref_link)}&text={quote(share_text)}"

    share_label = "Share link" if lang == 'en' else "Поделиться ссылкой"
    your_link = "Your referral link" if lang == 'en' else "Ваша реферальная ссылка"
    click_label = "Click the link below to share" if lang == 'en' else "Нажмите на ссылку ниже, чтобы поделиться"

    text = f"<b>📤 {share_label}</b>\n\n{your_link}:\n<code>{ref_link}</code>\n\n{click_label}:\n{share_url}"
    await send_message_with_banner(bot, callback.message.chat.id, text, reply_markup=referral_menu_kb(lang))
    await callback.answer()
