from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

import database as db
from keyboards import requisites_kb, cancel_kb, main_menu_kb
from states import RequisitesStates
from utils import send_message_with_banner
from locales import get_text

router = Router()


@router.message(F.text.in_(["📁 Управление реквизитами", "📁 Manage requisites"]))
async def show_requisites(message: Message, state: FSMContext, bot: Bot):
    await state.clear()
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'

    card = user.get('card_number') if user else None
    ton = user.get('ton_address') if user else None

    card_display = card if card else ("Not set" if lang == 'en' else "Не указан")
    ton_display = ton if ton else ("Not set" if lang == 'en' else "Не указан")

    text = get_text('requisites_title', lang)
    text += f"\n\n💳 {'Card number' if lang == 'en' else 'Номер карты'}: <code>{card_display}</code>"
    text += f"\n🪙 {'TON address' if lang == 'en' else 'Адрес TON'}: <code>{ton_display}</code>"
    text += f"\n\n<b>{'Select action:' if lang == 'en' else 'Выберите действие:'}</b>"

    await send_message_with_banner(bot, message.chat.id, text, reply_markup=requisites_kb(card, ton, lang))


@router.message(F.text.in_(["💳 Добавить номер карты", "✏️ Изменить номер карты", "💳 Add card number", "✏️ Edit card number"]))
async def add_card_start(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.set_state(RequisitesStates.waiting_card)
    await state.update_data(lang=lang)
    text = get_text('requisites_enter_card', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(RequisitesStates.waiting_card)
async def process_card(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    card = message.text.replace(" ", "").replace("-", "")

    if not card.isdigit() or len(card) != 16:
        await send_message_with_banner(bot, message.chat.id, get_text('requisites_invalid_card', lang), reply_markup=cancel_kb(lang))
        return

    await db.update_user_card(message.from_user.id, card)
    await state.clear()

    formatted_card = " ".join([card[i:i+4] for i in range(0, 16, 4)])
    text = get_text('requisites_card_saved', lang) + f"\n\n💳 {'Your card' if lang == 'en' else 'Ваша карта'}: <code>{formatted_card}</code>"
    
    user = await db.get_user(message.from_user.id)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=requisites_kb(card, user.get('ton_address'), lang))


@router.message(F.text.in_(["🪙 Добавить адрес TON", "✏️ Изменить адрес TON", "🪙 Add TON address", "✏️ Edit TON address"]))
async def add_ton_start(message: Message, state: FSMContext, bot: Bot):
    user = await db.get_user(message.from_user.id)
    lang = user.get('language', 'ru') if user else 'ru'
    await state.set_state(RequisitesStates.waiting_ton)
    await state.update_data(lang=lang)
    text = get_text('requisites_enter_ton', lang)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=cancel_kb(lang))


@router.message(RequisitesStates.waiting_ton)
async def process_ton(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get('lang', 'ru')
    
    if message.text in ["❌ Отмена", "❌ Cancel"]:
        await state.clear()
        await send_message_with_banner(bot, message.chat.id, get_text('operation_cancelled', lang), reply_markup=main_menu_kb(lang))
        return

    ton_address = message.text.strip()

    if len(ton_address) < 40 or len(ton_address) > 60:
        invalid_text = "❌ Invalid TON address format. Try again:" if lang == 'en' else "❌ Неверный формат TON адреса. Попробуйте снова:"
        await send_message_with_banner(bot, message.chat.id, invalid_text, reply_markup=cancel_kb(lang))
        return

    await db.update_user_ton(message.from_user.id, ton_address)
    await state.clear()

    text = get_text('requisites_ton_saved', lang) + f"\n\n🪙 {'Your address' if lang == 'en' else 'Ваш адрес'}: <code>{ton_address}</code>"
    
    user = await db.get_user(message.from_user.id)
    await send_message_with_banner(bot, message.chat.id, text, reply_markup=requisites_kb(user.get('card_number'), ton_address, lang))
