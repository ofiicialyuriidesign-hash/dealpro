"""
Telegram WebApp initData validation.
Validates the hash sent by Telegram Mini App to authenticate users.
"""
import hashlib
import hmac
import json
import time
from urllib.parse import unquote, parse_qs
from typing import Optional, Dict, Any


def validate_init_data(init_data: str, bot_token: str, max_age: int = 86400) -> Optional[Dict[str, Any]]:
    """
    Validate Telegram WebApp initData string.
    Returns parsed user data if valid, None otherwise.
    """
    try:
        parsed = parse_qs(init_data, keep_blank_values=True)
        
        # Extract hash
        received_hash = parsed.get("hash", [None])[0]
        if not received_hash:
            return None
        
        # Build data-check-string
        data_pairs = []
        for key, values in parsed.items():
            if key == "hash":
                continue
            data_pairs.append(f"{key}={values[0]}")
        
        data_pairs.sort()
        data_check_string = "\n".join(data_pairs)
        
        # Calculate secret key
        secret_key = hmac.new(
            b"WebAppData",
            bot_token.encode(),
            hashlib.sha256
        ).digest()
        
        # Calculate hash
        calculated_hash = hmac.new(
            secret_key,
            data_check_string.encode(),
            hashlib.sha256
        ).hexdigest()
        
        # Compare hashes
        if not hmac.compare_digest(calculated_hash, received_hash):
            return None
        
        # Check auth_date freshness
        auth_date = parsed.get("auth_date", [None])[0]
        if auth_date:
            auth_timestamp = int(auth_date)
            if time.time() - auth_timestamp > max_age:
                return None
        
        # Parse user data
        user_data_str = parsed.get("user", [None])[0]
        if user_data_str:
            user_data = json.loads(unquote(user_data_str))
            return {
                "user": user_data,
                "auth_date": auth_date,
                "query_id": parsed.get("query_id", [None])[0],
                "start_param": parsed.get("start_param", [None])[0],
            }
        
        return None
        
    except Exception as e:
        print(f"Auth validation error: {e}")
        return None


def parse_init_data_unsafe(init_data: str) -> Optional[Dict[str, Any]]:
    """
    Parse initData without validation (for development/testing).
    """
    try:
        parsed = parse_qs(init_data, keep_blank_values=True)
        user_data_str = parsed.get("user", [None])[0]
        if user_data_str:
            user_data = json.loads(unquote(user_data_str))
            return {
                "user": user_data,
                "auth_date": parsed.get("auth_date", [None])[0],
                "query_id": parsed.get("query_id", [None])[0],
                "start_param": parsed.get("start_param", [None])[0],
            }
        return None
    except Exception:
        return None
