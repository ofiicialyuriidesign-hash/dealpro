"""
FastAPI server for Telegram Mini App.
Serves the webapp frontend and provides REST API endpoints.
"""
import os
import sys
import hashlib
import hmac
import json
import time
import aiohttp
from urllib.parse import unquote, parse_qs
from typing import Optional, Dict, Any
from datetime import datetime

from fastapi import Header
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Add parent directory to path for database import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import BOT_TOKEN, ADMIN_IDS, GARANT_FEE, BOT_USERNAME
import database as db
from api.auth import validate_init_data, parse_init_data_unsafe


app = FastAPI(title="DealPro Mini App API")


# ============ BOT MESSAGE HELPER ============

async def send_bot_message(chat_id: int, text: str, reply_markup: dict = None):
    """Send a message via Telegram Bot API directly."""
    if not BOT_TOKEN:
        return
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if reply_markup:
        data["reply_markup"] = json.dumps(reply_markup)
    try:
        async with aiohttp.ClientSession() as session:
            await session.post(url, json=data)
    except Exception:
        pass


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============ AUTH DEPENDENCY ============

DEV_MODE = os.getenv("DEV_MODE", "false").lower() == "true"


async def get_current_user(request: Request) -> Dict[str, Any]:
    """Extract and validate user from Telegram initData."""
    init_data = request.headers.get("X-Telegram-Init-Data", "")
    
    if not init_data and DEV_MODE:
        # Dev mode without initData — use real data from DB (admin account)
        test_user_id = ADMIN_IDS[0] if ADMIN_IDS else 12345
        user = await db.get_user(test_user_id)
        if not user:
            # User hasn't pressed /start yet, create minimal entry
            await db.create_user(user_id=test_user_id, username="admin", full_name="Admin")
            user = await db.get_user(test_user_id)
        if user:
            user["is_admin"] = test_user_id in ADMIN_IDS
            user["start_param"] = None
            return user
        raise HTTPException(status_code=500, detail="Dev user not found")

    if not init_data:
        raise HTTPException(status_code=401, detail="Missing initData")
    
    if DEV_MODE:
        result = parse_init_data_unsafe(init_data)
    else:
        result = validate_init_data(init_data, BOT_TOKEN)
    
    if not result or not result.get("user"):
        raise HTTPException(status_code=401, detail="Invalid initData")
    
    tg_user = result["user"]
    user_id = tg_user["id"]
    username = tg_user.get("username", "")
    full_name = f"{tg_user.get('first_name', '')} {tg_user.get('last_name', '')}".strip()
    photo_url = tg_user.get("photo_url", "")
    
    # Ensure user exists in DB
    await db.create_user(user_id=user_id, username=username, full_name=full_name)
    # Always sync profile with latest Telegram data
    await db.update_user_info(user_id=user_id, username=username, full_name=full_name)
    
    user = await db.get_user(user_id)
    if not user:
        raise HTTPException(status_code=500, detail="User creation failed")
    
    user["is_admin"] = user_id in ADMIN_IDS
    user["start_param"] = result.get("start_param")
    user["photo_url"] = photo_url
    # Update last active timestamp
    await db.update_last_active(user_id)
    return user
PHP_ADMIN_API_KEY = os.getenv("PHP_ADMIN_API_KEY", "")

async def require_php_admin(x_api_key: str = Header(default="")):
    if not PHP_ADMIN_API_KEY:
        raise HTTPException(status_code=500, detail="PHP admin API key is not configured")
    if x_api_key != PHP_ADMIN_API_KEY:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return True


async def get_php_bridge_user(telegram_id: int) -> Dict[str, Any]:
    user = await db.get_user_by_telegram_id(telegram_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user["is_admin"] = telegram_id in ADMIN_IDS
    return user


async def build_profile_payload(user: Dict[str, Any]) -> Dict[str, Any]:
    stats = await db.get_user_stats(user["user_id"])
    referral_stats = await db.get_referral_stats(user["user_id"])

    return {
        "user_id": user["user_id"],
        "telegram_id": user["user_id"],
        "username": user.get("username"),
        "full_name": user.get("full_name"),
        "deposit": user.get("deposit", 0),
        "reputation_positive": user.get("reputation_positive", 0),
        "reputation_negative": user.get("reputation_negative", 0),
        "is_garant": bool(user.get("is_garant", 0)),
        "is_arbitrator": bool(user.get("is_arbitrator", 0)),
        "is_admin": user.get("is_admin", False),
        "is_banned": bool(user.get("is_banned", 0)),
        "language": user.get("language", "ru"),
        "card_number": user.get("card_number"),
        "ton_address": user.get("ton_address"),
        "withdrawal_wallet": user.get("withdrawal_wallet"),
        "deals_count": stats.get("deals_count", 0),
        "successful_deals": stats.get("successful_deals", 0),
        "review_count": stats.get("review_count", 0),
        "referral_level": referral_stats.get("level", "bronze"),
        "referral_bonus": referral_stats.get("bonus", 0),
        "referral_total": referral_stats.get("total", 0),
        "referral_active": referral_stats.get("active", 0),
        "created_at": user.get("created_at"),
        "photo_url": user.get("photo_url", ""),
        "verification_level": user.get("verification_level", "none"),
        "last_active": user.get("last_active"),
        "has_pin": bool(user.get("pin_hash")),
        "trust_status": user.get("trust_status", "clean"),
    }


async def build_stats_payload(user: Dict[str, Any]) -> Dict[str, Any]:
    deals = await db.get_user_deals(user["user_id"])
    stats = await db.get_user_stats(user["user_id"])

    completed = len([d for d in deals if d["status"] == "completed"])
    cancelled = len([d for d in deals if d["status"] == "cancelled"])
    active = len([d for d in deals if d["status"] in ("pending", "waiting_admin", "in_progress")])
    disputes = len([d for d in deals if d["status"] == "dispute"])
    success_rate = round(completed / len(deals) * 100, 1) if deals else 0

    return {
        "total_deals": len(deals),
        "active": active,
        "completed": completed,
        "cancelled": cancelled,
        "disputes": disputes,
        "rep_positive": stats.get("reputation_positive", 0),
        "rep_negative": stats.get("reputation_negative", 0),
        "success_rate": success_rate,
        "deposit": stats.get("deposit", 0),
    }


async def build_verification_payload(user: Dict[str, Any]) -> Dict[str, Any]:
    verification = await db.get_user_verification(user["user_id"])
    stats = await db.get_user_stats(user["user_id"])
    deals = await db.get_user_deals(user["user_id"])
    turnover = sum(d.get("amount", 0) for d in deals if d.get("status") == "completed")
    disputes = sum(1 for d in deals if d.get("status") == "cancelled")

    return {
        "level": verification["level"],
        "pending": verification["pending"],
        "stats": {
            "successful_deals": stats.get("successful_deals", 0),
            "turnover": turnover,
            "disputes": disputes,
            "deposit": user.get("deposit", 0),
        }
    }


async def build_deal_payload(deal: Dict[str, Any], viewer_user_id: Optional[int] = None) -> Dict[str, Any]:
    creator = await db.get_user(deal["creator_id"])
    partner = await db.get_user(deal["partner_id"]) if deal.get("partner_id") else None
    garant = await db.get_user(deal["admin_id"]) if deal.get("admin_id") else None

    is_creator = viewer_user_id is not None and deal["creator_id"] == viewer_user_id
    is_participant = viewer_user_id is not None and (
        deal["creator_id"] == viewer_user_id or deal.get("partner_id") == viewer_user_id
    )

    return {
        **deal,
        "deal_number": deal.get("deal_code"),
        "number": deal.get("deal_code"),
        "title": deal.get("description"),
        "creator_username": creator.get("username") if creator else None,
        "creator_name": creator.get("full_name") if creator else None,
        "creator_rep": (creator.get("reputation_positive", 0) - creator.get("reputation_negative", 0)) if creator else 0,
        "creator_deposit": creator.get("deposit", 0) if creator else 0,
        "partner_username": partner.get("username") if partner else None,
        "partner_name": partner.get("full_name") if partner else None,
        "partner_rep": (partner.get("reputation_positive", 0) - partner.get("reputation_negative", 0)) if partner else 0,
        "partner_deposit": partner.get("deposit", 0) if partner else 0,
        "garant_username": garant.get("username") if garant else None,
        "admin_username": garant.get("username") if garant else None,
        "is_creator": is_creator,
        "is_participant": is_participant,
        "can_cancel": deal["status"] in ("pending", "waiting_admin") and is_participant,
        "can_review": deal["status"] == "completed" and is_participant,
    }

# ============ PYDANTIC MODELS ============

class CreateDealRequest(BaseModel):
    payment_type: str
    amount: float
    description: str
    creator_role: str  # 'buyer' or 'seller'

class UpdateRequisitesRequest(BaseModel):
    card_number: Optional[str] = None
    ton_address: Optional[str] = None

class CreateTicketRequest(BaseModel):
    subject: str
    message: str

class TicketReplyRequest(BaseModel):
    message: str

class ReviewRequest(BaseModel):
    is_positive: bool
    comment: Optional[str] = None

class WithdrawRequest(BaseModel):
    amount: float
    wallet_address: str

class DepositRequest(BaseModel):
    amount: float

class MessageDealRequest(BaseModel):
    text: str

class AdminBoostDeposit(BaseModel):
    user_id: int
    amount: float

class AdminBoostReputation(BaseModel):
    user_id: int
    positive: int
    negative: int

class AdminBoostDeals(BaseModel):
    user_id: int
    amount: int

class AdminBoostReviews(BaseModel):
    user_id: int
    count: int
    is_positive: bool = True

class AdminBanUser(BaseModel):
    user_id: int
    reason: Optional[str] = None

class AdminUnbanUser(BaseModel):
    user_id: int

class AdminSetGarant(BaseModel):
    user_id: int
    is_garant: bool

class AdminSettingUpdate(BaseModel):
    key: str
    value: str


# ============ INITIALIZATION ============

@app.on_event("startup")
async def startup():
    # DB init handled by main.py run_all()
    pass


# ============ STATIC FILES ============

WEBAPP_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "webapp")

@app.get("/")
async def serve_index():
    return FileResponse(os.path.join(WEBAPP_DIR, "index.html"))

# Mount static files after API routes
# Will be added at the end of this file


# ============ PHP BRIDGE ENDPOINTS ============

@app.get("/api/php-admin/stats")
async def php_admin_stats(_: bool = Depends(require_php_admin)):
    return await db.get_all_stats()


@app.get("/api/php-admin/users")
async def php_admin_users(_: bool = Depends(require_php_admin)):
    return await db.get_all_users(limit=200)


@app.get("/api/php-admin/deals")
async def php_admin_deals(_: bool = Depends(require_php_admin)):
    deals = await db.get_all_deals(limit=500)
    return [await build_deal_payload(deal) for deal in deals]


@app.get("/api/php/users/{telegram_id}/dashboard")
async def php_user_dashboard(telegram_id: int, _: bool = Depends(require_php_admin)):
    user = await get_php_bridge_user(telegram_id)
    deals = await db.get_user_deals(user["user_id"])
    tickets = await db.get_user_tickets(user["user_id"])

    enriched_deals = [await build_deal_payload(deal, viewer_user_id=user["user_id"]) for deal in deals]
    profile = await build_profile_payload(user)
    stats = await build_stats_payload(user)
    verification = await build_verification_payload(user)

    return {
        "user": profile,
        "stats": stats,
        "verification": verification,
        "deals": enriched_deals,
        "tickets": tickets,
        "tickets_open": len([ticket for ticket in tickets if ticket.get("status") == "open"]),
    }


# ============ PROFILE / USER ENDPOINTS ============

@app.get("/api/me")
async def get_me(user: dict = Depends(get_current_user)):
    """Get current user profile with stats."""
    payload = await build_profile_payload(user)
    payload["start_param"] = user.get("start_param")
    payload["bot_username"] = BOT_USERNAME
    return payload


@app.post("/api/pin")
async def set_pin(request: Request, user: dict = Depends(get_current_user)):
    """Set or update user PIN."""
    body = await request.json()
    pin = body.get("pin", "").strip()
    if not pin:
        # Remove PIN
        await db.set_user_pin(user["user_id"], None)
        return {"ok": True}
    if len(pin) != 4 or not pin.isdigit():
        raise HTTPException(400, "PIN must be 4 digits")
    import hashlib
    pin_hash = hashlib.sha256(pin.encode()).hexdigest()
    await db.set_user_pin(user["user_id"], pin_hash)
    return {"ok": True}


@app.post("/api/pin/verify")
async def verify_pin(request: Request, user: dict = Depends(get_current_user)):
    """Verify user PIN."""
    body = await request.json()
    pin = body.get("pin", "").strip()
    if not pin or len(pin) != 4:
        raise HTTPException(400, "Invalid PIN")
    import hashlib
    pin_hash = hashlib.sha256(pin.encode()).hexdigest()
    if user.get("pin_hash") != pin_hash:
        raise HTTPException(403, "Wrong PIN")
    return {"ok": True}


@app.post("/api/language")
async def set_language(request: Request, user: dict = Depends(get_current_user)):
    body = await request.json()
    lang = body.get("language", "ru")
    if lang not in ("ru", "en", "uk"):
        raise HTTPException(400, "Invalid language")
    await db.set_user_language(user["user_id"], lang)
    return {"ok": True}


@app.get("/api/stats")
async def get_my_stats(user: dict = Depends(get_current_user)):
    """Get detailed user statistics."""
    return await build_stats_payload(user)


# ============ DEALS ENDPOINTS ============

@app.get("/api/deals")
async def get_deals(user: dict = Depends(get_current_user)):
    """Get all user deals."""
    deals = await db.get_user_deals(user["user_id"])
    return [await build_deal_payload(deal, viewer_user_id=user["user_id"]) for deal in deals]


@app.get("/api/deals/by-code/{code}")
async def get_deal_by_code(code: str, user: dict = Depends(get_current_user)):
    """Get deal by its code (e.g. DP-FSRJHE)."""
    deal = await db.get_deal_by_code(code)
    if not deal:
        raise HTTPException(404, "Deal not found")
    return {"id": deal["id"], "deal_code": deal.get("deal_code"), "status": deal["status"]}


@app.get("/api/deals/{deal_id}")
async def get_deal(deal_id: int, user: dict = Depends(get_current_user)):
    """Get single deal details."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    
    is_participant = deal["creator_id"] == user["user_id"] or deal.get("partner_id") == user["user_id"]
    is_admin = user.get("is_admin", False)
    is_deal_garant = deal.get("admin_id") == user["user_id"]
    
    if not is_participant and not is_admin and not is_deal_garant:
        raise HTTPException(403, "No access")
    
    creator = await db.get_user(deal["creator_id"])
    partner = await db.get_user(deal["partner_id"]) if deal.get("partner_id") else None
    garant = await db.get_user(deal["admin_id"]) if deal.get("admin_id") else None
    
    has_review = await db.check_review_exists(deal_id, user["user_id"]) if deal["status"] == "completed" else False
    
    return {
        **deal,
        "creator_username": creator.get("username") if creator else None,
        "creator_name": creator.get("full_name") if creator else None,
        "creator_rep": (creator.get("reputation_positive", 0) - creator.get("reputation_negative", 0)) if creator else 0,
        "creator_deposit": creator.get("deposit", 0) if creator else 0,
        "partner_username": partner.get("username") if partner else None,
        "partner_name": partner.get("full_name") if partner else None,
        "partner_rep": (partner.get("reputation_positive", 0) - partner.get("reputation_negative", 0)) if partner else 0,
        "partner_deposit": partner.get("deposit", 0) if partner else 0,
        "garant_username": garant.get("username") if garant else None,
        "is_creator": deal["creator_id"] == user["user_id"],
        "is_participant": is_participant,
        "is_deal_garant": is_deal_garant,
        "can_cancel": deal["status"] in ("pending", "waiting_admin") and is_participant,
        "can_complete": deal["status"] == "in_progress" and (is_admin or is_deal_garant),
        "can_review": deal["status"] == "completed" and not has_review and is_participant,
        "has_review": has_review,
    }


@app.post("/api/deals")
async def create_deal(req: CreateDealRequest, user: dict = Depends(get_current_user)):
    """Create a new deal."""
    if req.amount <= 0:
        raise HTTPException(400, "Invalid amount")
    if len(req.description) < 3:
        raise HTTPException(400, "Description too short")
    if req.creator_role not in ("buyer", "seller"):
        raise HTTPException(400, "Invalid role")
    if req.payment_type not in ("card_ru", "card_ua", "card_kz", "card_by", "usdt", "ton", "stars"):
        raise HTTPException(400, "Invalid payment type")
    
    deal_id = await db.create_deal(
        creator_id=user["user_id"],
        payment_type=req.payment_type,
        amount=req.amount,
        description=req.description,
        creator_role=req.creator_role,
    )
    deal = await db.get_deal(deal_id)
    deal_code = deal.get("deal_code", f"deal_{deal_id}") if deal else f"deal_{deal_id}"

    # Send deal link via bot message
    if BOT_USERNAME:
        pay_labels = {"card_ru": "Карта РУ", "card_ua": "Карта УК", "card_kz": "Карта КЗ",
                       "card_by": "Карта РБ", "usdt": "USDT", "ton": "TON", "stars": "Stars"}
        role_label = "Покупатель" if req.creator_role == "buyer" else "Продавец"
        link = f"https://t.me/{BOT_USERNAME}?start={deal_code}"
        text = (
            f"<b>Сделка {deal_code} создана</b>\n\n"
            f"Сумма: <b>{req.amount}</b>\n"
            f"Оплата: {pay_labels.get(req.payment_type, req.payment_type)}\n"
            f"Роль: {role_label}\n\n"
            f"Ссылка для партнёра:\n<code>{link}</code>"
        )
        from urllib.parse import quote
        share_url = f"https://t.me/share/url?url={quote(link)}&text={quote(chr(10) + 'Пора переходить к сделке — DEALPRO SERVICE уже страхует весь процесс.')}"
        markup = {"inline_keyboard": [[{"text": "🔐 Отправить защищённую ссылку", "url": share_url}]]}
        await send_bot_message(user["user_id"], text, markup)

    return {"deal_id": deal_id, "deal_code": deal_code, "ok": True}


@app.post("/api/deals/{deal_id}/join")
async def join_deal(deal_id: int, user: dict = Depends(get_current_user)):
    """Join an existing deal."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    if deal["status"] != "pending":
        raise HTTPException(400, "Cannot join this deal")
    if deal["creator_id"] == user["user_id"]:
        raise HTTPException(400, "Cannot join own deal")
    
    await db.join_deal(deal_id, user["user_id"])
    return {"ok": True}


@app.post("/api/deals/{deal_id}/cancel")
async def cancel_deal(deal_id: int, user: dict = Depends(get_current_user)):
    """Cancel a deal."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    
    is_participant = deal["creator_id"] == user["user_id"] or deal.get("partner_id") == user["user_id"]
    is_admin = user.get("is_admin", False)
    is_deal_garant = deal.get("admin_id") == user["user_id"]
    
    if not is_participant and not is_admin and not is_deal_garant:
        raise HTTPException(403, "No access")
    
    if deal["status"] not in ("pending", "waiting_admin", "in_progress"):
        raise HTTPException(400, "Cannot cancel this deal")
    
    await db.cancel_deal(deal_id)
    return {"ok": True}


@app.post("/api/deals/{deal_id}/complete")
async def complete_deal(deal_id: int, user: dict = Depends(get_current_user)):
    """Complete deal (admin/garant only)."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    
    is_admin = user.get("is_admin", False)
    is_deal_garant = deal.get("admin_id") == user["user_id"]
    
    if not is_admin and not is_deal_garant:
        raise HTTPException(403, "Only garant or admin can complete deals")
    
    if deal["status"] != "in_progress":
        raise HTTPException(400, "Deal is not in progress")
    
    await db.complete_deal(deal_id)
    
    # Handle referral bonuses
    for uid in [deal["creator_id"], deal.get("partner_id")]:
        if uid:
            referral = await db.get_referral_by_referred(uid)
            if referral and referral["status"] == "pending":
                await db.activate_referral(uid)
                referrer_stats = await db.get_referral_stats(referral["referrer_id"])
                level_data = db.REFERRAL_LEVELS.get(referrer_stats["level"], db.REFERRAL_LEVELS["bronze"])
                bonus = deal["amount"] * level_data["bonus_percent"] / 100 * 0.05
                await db.add_referral_bonus(referral["referrer_id"], bonus)
                await db.update_referral_level(referral["referrer_id"])
    
    return {"ok": True}


@app.post("/api/deals/{deal_id}/review")
async def leave_review(deal_id: int, req: ReviewRequest, user: dict = Depends(get_current_user)):
    """Leave a review for a deal."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    if deal["status"] != "completed":
        raise HTTPException(400, "Deal not completed")
    
    has_review = await db.check_review_exists(deal_id, user["user_id"])
    if has_review:
        raise HTTPException(400, "Review already exists")
    
    to_user_id = deal["partner_id"] if deal["creator_id"] == user["user_id"] else deal["creator_id"]
    
    rating = 5 if req.is_positive else 1
    comment = req.comment if req.comment and req.comment.strip() != "-" else None
    
    await db.create_review(
        deal_id=deal_id,
        from_user_id=user["user_id"],
        to_user_id=to_user_id,
        rating=rating,
        comment=comment,
        is_positive=req.is_positive,
    )
    
    return {"ok": True}


# ============ GARANT ENDPOINTS ============

@app.get("/api/garant/pending")
async def garant_pending_deals(user: dict = Depends(get_current_user)):
    """Get deals waiting for garant."""
    if not user.get("is_garant") and not user.get("is_admin"):
        raise HTTPException(403, "Not a garant")
    deals = await db.get_pending_deals()
    result = []
    for deal in deals:
        creator = await db.get_user(deal["creator_id"])
        partner = await db.get_user(deal["partner_id"]) if deal.get("partner_id") else None
        result.append({
            **deal,
            "creator_username": creator.get("username") if creator else None,
            "creator_rep": (creator.get("reputation_positive", 0) - creator.get("reputation_negative", 0)) if creator else 0,
            "creator_deposit": creator.get("deposit", 0) if creator else 0,
            "partner_username": partner.get("username") if partner else None,
            "partner_rep": (partner.get("reputation_positive", 0) - partner.get("reputation_negative", 0)) if partner else 0,
            "partner_deposit": partner.get("deposit", 0) if partner else 0,
        })
    return result


@app.get("/api/garant/my")
async def garant_my_deals(user: dict = Depends(get_current_user)):
    """Get garant's active deals."""
    if not user.get("is_garant") and not user.get("is_admin"):
        raise HTTPException(403, "Not a garant")
    deals = await db.get_admin_deals(user["user_id"])
    return deals


@app.post("/api/garant/take/{deal_id}")
async def garant_take_deal(deal_id: int, user: dict = Depends(get_current_user)):
    """Take a deal as garant."""
    if not user.get("is_garant") and not user.get("is_admin"):
        raise HTTPException(403, "Not a garant")
    
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    if deal.get("admin_id"):
        raise HTTPException(400, "Deal already taken")
    
    await db.assign_admin_to_deal(deal_id, user["user_id"])
    return {"ok": True}


# ============ REQUISITES ENDPOINTS ============

@app.post("/api/requisites")
async def update_requisites(req: UpdateRequisitesRequest, user: dict = Depends(get_current_user)):
    """Update user requisites."""
    if req.card_number is not None:
        card = req.card_number.replace(" ", "").replace("-", "")
        if card and (not card.isdigit() or len(card) != 16):
            raise HTTPException(400, "Проверьте правильность номера карты")
        await db.update_user_card(user["user_id"], card if card else None)
    
    if req.ton_address is not None:
        if req.ton_address and (len(req.ton_address) < 40 or len(req.ton_address) > 60):
            raise HTTPException(400, "Некорректный TON адрес. Адрес должен содержать от 40 до 60 символов")
        await db.update_user_ton(user["user_id"], req.ton_address if req.ton_address else None)
    
    return {"ok": True}


# ============ USERS ENDPOINTS ============

@app.get("/api/users/garants")
async def get_garants(user: dict = Depends(get_current_user)):
    """Get list of garants."""
    garants = await db.get_garants()
    return [{
        "user_id": g["user_id"],
        "username": g.get("username"),
        "full_name": g.get("full_name"),
        "reputation_positive": g.get("reputation_positive", 0),
        "reputation_negative": g.get("reputation_negative", 0),
        "reputation": g.get("reputation_positive", 0) - g.get("reputation_negative", 0),
        "deposit": g.get("deposit", 0),
        "deals_count": g.get("deals_count", 0),
    } for g in garants]


@app.get("/api/users/top")
async def get_top_reputation(user: dict = Depends(get_current_user)):
    """Get top reputation users."""
    users = await db.get_top_reputation(10)
    return [{
        "user_id": u["user_id"],
        "username": u.get("username"),
        "full_name": u.get("full_name"),
        "reputation_positive": u.get("reputation_positive", 0),
        "reputation_negative": u.get("reputation_negative", 0),
        "reputation": u.get("reputation_positive", 0) - u.get("reputation_negative", 0),
        "deposit": u.get("deposit", 0),
        "deals_count": u.get("deals_count", 0),
    } for u in users]


@app.get("/api/users/search/{query}")
async def search_user(query: str, user: dict = Depends(get_current_user)):
    """Search for a user by username or ID."""
    query = query.strip().replace("@", "")
    found = None
    if query.isdigit():
        found = await db.get_user(int(query))
    if not found:
        found = await db.get_user_by_username(query)
    
    if not found:
        return []
    
    reviews = await db.get_user_reviews(found["user_id"], "all")
    
    return [{
        "user_id": found["user_id"],
        "username": found.get("username"),
        "full_name": found.get("full_name"),
        "reputation_positive": found.get("reputation_positive", 0),
        "reputation_negative": found.get("reputation_negative", 0),
        "deposit": found.get("deposit", 0),
        "is_garant": bool(found.get("is_garant", 0)),
        "is_arbitrator": bool(found.get("is_arbitrator", 0)),
        "is_banned": bool(found.get("is_banned", 0)),
        "ban_reason": found.get("ban_reason"),
        "deals_count": found.get("deals_count", 0),
        "successful_deals": found.get("successful_deals", 0),
        "reviews_count": len(reviews),
    }]


@app.get("/api/users/trust/{query}")
async def get_user_trust(query: str, user: dict = Depends(get_current_user)):
    """Get trust info for a user by ID or username."""
    result = await db.get_user_trust(query)
    if not result:
        raise HTTPException(404, "User not found")
    return result


@app.get("/api/users/{user_id}/reviews")
async def get_user_reviews(user_id: int, filter: str = "all", user: dict = Depends(get_current_user)):
    """Get reviews for a user."""
    target = await db.get_user(user_id)
    if not target:
        raise HTTPException(404, "User not found")
    
    reviews = await db.get_user_reviews(user_id, filter)
    return [{
        "id": r["id"],
        "is_positive": bool(r.get("is_positive", 1)),
        "comment": r.get("comment"),
        "author": r.get("fake_username") or r.get("username") or r.get("full_name") or "Аноним",
        "created_at": r.get("created_at"),
        "deal_id": r.get("deal_id"),
    } for r in reviews[:50]]


@app.get("/api/users/{user_id}/profile")
async def get_user_profile(user_id: int, user: dict = Depends(get_current_user)):
    """Get user profile."""
    target = await db.get_user(user_id)
    if not target:
        raise HTTPException(404, "User not found")
    
    return {
        "user_id": target["user_id"],
        "username": target.get("username"),
        "full_name": target.get("full_name"),
        "reputation_positive": target.get("reputation_positive", 0),
        "reputation_negative": target.get("reputation_negative", 0),
        "deposit": target.get("deposit", 0),
        "is_garant": bool(target.get("is_garant", 0)),
        "is_arbitrator": bool(target.get("is_arbitrator", 0)),
        "is_banned": bool(target.get("is_banned", 0)),
        "deals_count": target.get("deals_count", 0),
        "successful_deals": target.get("successful_deals", 0),
        "verification_level": target.get("verification_level", "none"),
        "last_active": target.get("last_active"),
        "created_at": target.get("created_at"),
        "trust_status": target.get("trust_status", "clean"),
    }


# ============ SUPPORT ENDPOINTS ============

@app.get("/api/tickets")
async def get_tickets(user: dict = Depends(get_current_user)):
    """Get user tickets."""
    tickets = await db.get_user_tickets(user["user_id"])
    return tickets


@app.post("/api/tickets")
async def create_ticket(req: CreateTicketRequest, user: dict = Depends(get_current_user)):
    """Create a support ticket."""
    if len(req.subject) < 3:
        raise HTTPException(400, "Subject too short")
    if len(req.message) < 10:
        raise HTTPException(400, "Message too short")
    
    ticket_id = await db.create_ticket(user["user_id"], req.subject)
    await db.add_ticket_message(ticket_id, user["user_id"], req.message)
    return {"ticket_id": ticket_id, "ok": True}


@app.get("/api/tickets/{ticket_id}")
async def get_ticket(ticket_id: int, user: dict = Depends(get_current_user)):
    """Get ticket details with messages."""
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(404, "Ticket not found")
    
    is_admin = user.get("is_admin", False)
    if ticket["user_id"] != user["user_id"] and not is_admin:
        raise HTTPException(403, "No access")
    
    messages = await db.get_ticket_messages(ticket_id)
    return {
        **ticket,
        "messages": [{
            "id": m["id"],
            "message": m["message"],
            "is_admin": bool(m["is_admin"]),
            "created_at": m["created_at"],
        } for m in messages],
    }


@app.post("/api/tickets/{ticket_id}/reply")
async def reply_ticket(ticket_id: int, req: TicketReplyRequest, user: dict = Depends(get_current_user)):
    """Reply to a ticket."""
    ticket = await db.get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(404, "Ticket not found")
    
    is_admin = user.get("is_admin", False)
    if ticket["user_id"] != user["user_id"] and not is_admin:
        raise HTTPException(403, "No access")
    
    await db.add_ticket_message(ticket_id, user["user_id"], req.message, is_admin)
    return {"ok": True}


# ============ REFERRAL ENDPOINTS ============

@app.get("/api/referrals")
async def get_referrals(user: dict = Depends(get_current_user)):
    """Get referral info."""
    stats = await db.get_referral_stats(user["user_id"])
    referrals = await db.get_user_referrals(user["user_id"])
    level_data = db.REFERRAL_LEVELS.get(stats["level"], db.REFERRAL_LEVELS["bronze"])
    
    return {
        "level": stats["level"],
        "bonus_percent": level_data["bonus_percent"],
        "total": stats["total"],
        "active": stats["active"],
        "bonus_earned": stats["bonus"],
        "referrals": [{
            "username": r.get("username"),
            "full_name": r.get("full_name"),
            "status": r.get("status"),
            "successful_deals": r.get("successful_deals", 0),
        } for r in referrals[:20]],
    }


@app.get("/api/referrals/leaderboard")
async def get_referral_leaderboard(user: dict = Depends(get_current_user)):
    """Get referral leaderboard."""
    leaders = await db.get_referral_leaderboard(10)
    return [{
        "username": l.get("username"),
        "full_name": l.get("full_name"),
        "level": l.get("referral_level", "bronze"),
        "active_refs": l.get("active_refs", 0),
        "bonus": l.get("referral_bonus", 0),
    } for l in leaders]


# ============ DEPOSIT / WITHDRAW ENDPOINTS ============

@app.post("/api/deposit")
async def create_deposit(req: DepositRequest, user: dict = Depends(get_current_user)):
    """Create deposit invoice via CryptoBot."""
    from cryptobot import create_invoice
    
    min_deposit = float(await db.get_setting("min_deposit", "100"))
    if req.amount < min_deposit:
        raise HTTPException(400, f"Minimum deposit: {min_deposit}$")
    
    invoice = await create_invoice(req.amount, user["user_id"])
    if not invoice:
        raise HTTPException(500, "Failed to create invoice")
    
    await db.create_payment(user["user_id"], req.amount, str(invoice["invoice_id"]))
    
    return {
        "invoice_id": str(invoice["invoice_id"]),
        "pay_url": invoice.get("pay_url"),
        "amount": req.amount,
    }


@app.post("/api/deposit/check/{invoice_id}")
async def check_deposit(invoice_id: str, user: dict = Depends(get_current_user)):
    """Check if deposit payment was received."""
    from cryptobot import check_invoice_paid
    
    is_paid = await check_invoice_paid(invoice_id)
    if is_paid:
        payment = await db.complete_payment(invoice_id)
        if payment:
            return {"paid": True, "amount": payment["amount"]}
        return {"paid": True, "already_processed": True}
    return {"paid": False}


@app.post("/api/withdraw")
async def create_withdrawal(req: WithdrawRequest, user: dict = Depends(get_current_user)):
    """Create withdrawal request."""
    if req.amount <= 0:
        raise HTTPException(400, "Invalid amount")
    
    deposit = user.get("deposit", 0)
    if deposit < req.amount:
        raise HTTPException(400, "Insufficient funds")
    
    min_withdrawal = float(await db.get_setting("min_withdrawal", "10"))
    if req.amount < min_withdrawal:
        raise HTTPException(400, f"Minimum withdrawal: {min_withdrawal}$")
    
    w_id = await db.create_withdrawal(user["user_id"], req.amount, req.wallet_address)
    await db.update_user_withdrawal_wallet(user["user_id"], req.wallet_address)
    
    return {"withdrawal_id": w_id, "ok": True}


# ============ ADMIN ENDPOINTS ============
async def get_all_deals(limit: int = 500):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM deals ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]
@app.get("/api/php-admin/stats")
async def php_admin_stats(_: bool = Depends(require_php_admin)):
    return await db.get_all_stats()


@app.get("/api/php-admin/users")
async def php_admin_users(_: bool = Depends(require_php_admin)):
    return await db.get_all_users(limit=200)


@app.get("/api/php-admin/deals")
async def php_admin_deals(_: bool = Depends(require_php_admin)):
    deals = await db.get_all_deals(limit=500)
    result = []

    for deal in deals:
        creator = await db.get_user(deal["creator_id"])
        partner = await db.get_user(deal["partner_id"]) if deal.get("partner_id") else None
        admin_user = await db.get_user(deal["admin_id"]) if deal.get("admin_id") else None

        result.append({
            **deal,
            "creator_username": creator.get("username") if creator else None,
            "partner_username": partner.get("username") if partner else None,
            "admin_username": admin_user.get("username") if admin_user else None,
        })

    return result
    
@app.get("/api/admin/stats")
async def admin_stats(user: dict = Depends(get_current_user)):
    """Get admin statistics."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    stats = await db.get_all_stats()
    return stats


@app.get("/api/admin/users")
async def admin_get_users(user: dict = Depends(get_current_user)):
    """Get all users (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    users = await db.get_all_users(limit=200)
    return users


@app.get("/api/admin/pending-deals")
async def admin_pending_deals(user: dict = Depends(get_current_user)):
    """Get all pending deals for admin."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    deals = await db.get_pending_deals()
    result = []
    for deal in deals:
        creator = await db.get_user(deal["creator_id"])
        partner = await db.get_user(deal["partner_id"]) if deal.get("partner_id") else None
        result.append({
            **deal,
            "creator_username": creator.get("username") if creator else None,
            "partner_username": partner.get("username") if partner else None,
        })
    return result


@app.get("/api/admin/waiting-partner")
async def admin_waiting_partner(user: dict = Depends(get_current_user)):
    """Get deals waiting for partner."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    deals = await db.get_deals_waiting_partner()
    result = []
    for deal in deals:
        creator = await db.get_user(deal["creator_id"])
        result.append({
            **deal,
            "creator_username": creator.get("username") if creator else None,
        })
    return result


@app.get("/api/admin/my-deals")
async def admin_my_deals(user: dict = Depends(get_current_user)):
    """Get admin's active deals as garant."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    deals = await db.get_admin_deals(user["user_id"])
    return deals


@app.get("/api/admin/tickets")
async def admin_tickets(user: dict = Depends(get_current_user)):
    """Get all open tickets."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    tickets = await db.get_open_tickets()
    return tickets


@app.post("/api/admin/tickets/{ticket_id}/close")
async def admin_close_ticket(ticket_id: int, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.close_ticket(ticket_id)
    return {"ok": True}


@app.get("/api/admin/withdrawals")
async def admin_withdrawals(user: dict = Depends(get_current_user)):
    """Get pending withdrawals."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    return await db.get_pending_withdrawals()


@app.post("/api/admin/withdrawals/{w_id}/confirm")
async def admin_confirm_withdrawal(w_id: int, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    result = await db.complete_withdrawal(w_id, transfer_id="manual_admin")
    if not result:
        raise HTTPException(400, "Withdrawal not found or already processed")
    return {"ok": True}


@app.post("/api/admin/withdrawals/{w_id}/reject")
async def admin_reject_withdrawal(w_id: int, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.cancel_withdrawal(w_id)
    return {"ok": True}


@app.post("/api/admin/boost/deposit")
async def admin_boost_deposit(req: AdminBoostDeposit, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.update_user_deposit(req.user_id, req.amount)
    return {"ok": True}


@app.post("/api/admin/boost/reputation")
async def admin_boost_reputation(req: AdminBoostReputation, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    target = await db.get_user(req.user_id)
    if not target:
        raise HTTPException(404, "User not found")
    new_pos = target.get("reputation_positive", 0) + req.positive
    new_neg = target.get("reputation_negative", 0) + req.negative
    await db.set_user_reputation(req.user_id, new_pos, new_neg)
    return {"ok": True}


@app.post("/api/admin/boost/deals")
async def admin_boost_deals(req: AdminBoostDeals, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.update_user_deals(req.user_id, req.amount)
    return {"ok": True}


@app.post("/api/admin/boost/reviews")
async def admin_boost_reviews(req: AdminBoostReviews, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.add_fake_reviews(req.user_id, req.count if req.is_positive else 0, 0 if req.is_positive else req.count)
    return {"ok": True}


@app.post("/api/admin/boost/reviews/clear")
async def admin_clear_reviews(request: Request, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    await db.clear_fake_reviews(body["user_id"])
    return {"ok": True}


@app.post("/api/admin/ban")
async def admin_ban(req: AdminBanUser, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.ban_user(req.user_id, req.reason)
    return {"ok": True}


@app.post("/api/admin/unban")
async def admin_unban(req: AdminUnbanUser, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.unban_user(req.user_id)
    return {"ok": True}


@app.post("/api/admin/garant")
async def admin_set_garant(req: AdminSetGarant, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.set_user_garant(req.user_id, req.is_garant)
    return {"ok": True}


@app.post("/api/admin/settings")
async def admin_update_setting(req: AdminSettingUpdate, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.set_setting(req.key, req.value)
    return {"ok": True}


@app.get("/api/admin/settings/{key}")
async def admin_get_setting(key: str, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    value = await db.get_setting(key)
    return {"key": key, "value": value}


@app.get("/api/admin/banned-users")
async def admin_banned_users(user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    users = await db.get_banned_users()
    return [{
        "user_id": u["user_id"],
        "username": u.get("username"),
        "full_name": u.get("full_name"),
        "ban_reason": u.get("ban_reason"),
    } for u in users]


@app.get("/api/admin/appeals")
async def admin_appeals(user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    return await db.get_pending_appeals()


@app.post("/api/admin/appeals/{appeal_id}/process")
async def admin_process_appeal(appeal_id: int, request: Request, user: dict = Depends(get_current_user)):
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    status = body.get("status", "rejected")
    note = body.get("note", "")
    await db.process_appeal(appeal_id, user["user_id"], status, note)
    if status == "approved":
        appeal = await db.get_appeal(appeal_id)
        if appeal:
            await db.unban_user(appeal["user_id"])
    return {"ok": True}


# ============ VERIFICATION ENDPOINTS ============

@app.get("/api/verification")
async def get_verification(user: dict = Depends(get_current_user)):
    """Get user's verification status."""
    return await build_verification_payload(user)


@app.post("/api/verification/apply")
async def apply_verification(request: Request, user: dict = Depends(get_current_user)):
    """Submit a verification application."""
    body = await request.json()
    level = body.get("level", "basic")
    if level not in ("basic", "trusted", "premium"):
        raise HTTPException(400, "Invalid level")
    result = await db.create_verification_request(user["user_id"], level, "apply")
    if result is None:
        raise HTTPException(400, "У вас уже есть активная заявка")
    # Notify admins
    for admin_id in ADMIN_IDS:
        await send_bot_message(
            admin_id,
            f"🔔 <b>Новая заявка на верификацию</b>\n\n"
            f"👤 @{user.get('username', 'N/A')} (ID: {user['user_id']})\n"
            f"📋 Уровень: <b>{level.upper()} SELLER</b>\n"
            f"📝 Тип: Заявка\n\n"
            f"Проверьте в панели администратора."
        )
    return {"ok": True, "id": result}


@app.post("/api/verification/purchase")
async def purchase_verification(request: Request, user: dict = Depends(get_current_user)):
    """Submit a verification purchase request — pay from deposit."""
    body = await request.json()
    level = body.get("level", "basic")
    currency = body.get("currency", "DEPOSIT")
    price = body.get("price", 0)
    if level not in ("basic", "trusted", "premium"):
        raise HTTPException(400, "Invalid level")
    prices = {"basic": 50, "trusted": 100, "premium": 200}
    expected_price = prices.get(level, 50)
    if price != expected_price:
        raise HTTPException(400, "Invalid price")
    deposit = user.get("deposit", 0)
    if deposit < expected_price:
        raise HTTPException(400, "Недостаточно средств на депозите")
    await db.update_user_deposit(user["user_id"], -expected_price)
    result = await db.create_verification_request(user["user_id"], level, "purchase", currency)
    if result is None:
        await db.update_user_deposit(user["user_id"], expected_price)
        raise HTTPException(400, "У вас уже есть активная заявка")
    # Notify admins
    for admin_id in ADMIN_IDS:
        await send_bot_message(
            admin_id,
            f"💰 <b>Покупка верификации</b>\n\n"
            f"👤 @{user.get('username', 'N/A')} (ID: {user['user_id']})\n"
            f"📋 Уровень: <b>{level.upper()} SELLER</b>\n"
            f"💳 Валюта: {currency}\n\n"
            f"Проверьте в панели администратора."
        )
    return {"ok": True, "id": result}


@app.get("/api/admin/verifications")
async def admin_verifications(user: dict = Depends(get_current_user)):
    """Get pending verification requests (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    return await db.get_pending_verification_requests()


@app.post("/api/admin/verifications/{req_id}/process")
async def admin_process_verification(req_id: int, request: Request, user: dict = Depends(get_current_user)):
    """Process a verification request (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    status = body.get("status", "rejected")
    note = body.get("note", "")
    result = await db.process_verification_request(req_id, user["user_id"], status, note)
    if not result:
        raise HTTPException(404, "Request not found")
    return {"ok": True}


# ============ DEAL CHAT ENDPOINTS ============

@app.get("/api/deals/{deal_id}/messages")
async def get_deal_messages(deal_id: int, user: dict = Depends(get_current_user)):
    """Get deal chat messages."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    is_participant = deal["creator_id"] == user["user_id"] or deal.get("partner_id") == user["user_id"]
    is_admin = user.get("is_admin", False)
    is_deal_garant = deal.get("admin_id") == user["user_id"]
    if not is_participant and not is_admin and not is_deal_garant:
        raise HTTPException(403, "No access")
    messages = await db.get_deal_messages(deal_id)
    # Mark as read
    if messages:
        last_id = max(m["id"] for m in messages)
        await db.mark_chat_read(user["user_id"], deal_id, last_id)
    # Determine role for each sender
    creator_id = deal["creator_id"]
    partner_id = deal.get("partner_id")
    garant_id = deal.get("admin_id")
    creator_role = deal.get("creator_role", "buyer")  # buyer or seller
    def get_role(sender_id):
        if sender_id == garant_id:
            return "garant"
        if sender_id == creator_id:
            return creator_role
        if sender_id == partner_id:
            return "seller" if creator_role == "buyer" else "buyer"
        return "admin"
    return [{
        "id": m["id"],
        "sender_id": m["sender_id"],
        "username": m.get("username"),
        "full_name": m.get("full_name"),
        "message": m["message"],
        "image_url": m.get("image_url"),
        "created_at": m["created_at"],
        "is_me": m["sender_id"] == user["user_id"],
        "role": get_role(m["sender_id"]),
    } for m in messages]


@app.post("/api/deals/{deal_id}/messages")
async def send_deal_message(deal_id: int, request: Request, user: dict = Depends(get_current_user)):
    """Send a message in deal chat."""
    deal = await db.get_deal(deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    is_participant = deal["creator_id"] == user["user_id"] or deal.get("partner_id") == user["user_id"]
    is_admin = user.get("is_admin", False)
    is_deal_garant = deal.get("admin_id") == user["user_id"]
    if not is_participant and not is_admin and not is_deal_garant:
        raise HTTPException(403, "No access")
    body = await request.json()
    message = body.get("message", "").strip()
    image_url = body.get("image_url", None)
    if not message and not image_url:
        raise HTTPException(400, "Empty message")
    if message and len(message) > 1000:
        raise HTTPException(400, "Message too long")
    if image_url and len(image_url) > 2 * 1024 * 1024:  # 2MB limit
        raise HTTPException(400, "Image too large")
    if not message and image_url:
        message = "[photo]"
    msg_id = await db.add_deal_message(deal_id, user["user_id"], message, image_url)
    return {"ok": True, "id": msg_id}


@app.get("/api/chat/unread-count")
async def get_unread_count(user: dict = Depends(get_current_user)):
    """Get total unread chat messages count."""
    count = await db.get_unread_count(user["user_id"])
    return {"count": count}


# ============ NEWS ENDPOINTS ============

@app.get("/api/news")
async def get_news(user: dict = Depends(get_current_user)):
    """Get active news for home page."""
    return await db.get_active_news()


@app.get("/api/admin/news")
async def admin_get_news(user: dict = Depends(get_current_user)):
    """Get all news (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    return await db.get_all_news()


@app.post("/api/admin/news")
async def admin_create_news(request: Request, user: dict = Depends(get_current_user)):
    """Create a news item (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    title = body.get("title", "").strip()
    content = body.get("content", "").strip()
    emoji = body.get("emoji", "📢").strip()
    if not title or not content:
        raise HTTPException(400, "Title and content required")
    news_id = await db.create_news(title, content, emoji, body.get("image_url"), user["user_id"])
    return {"ok": True, "id": news_id}


@app.post("/api/admin/news/{news_id}/update")
async def admin_update_news(news_id: int, request: Request, user: dict = Depends(get_current_user)):
    """Update a news item (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    title = body.get("title", "").strip()
    content = body.get("content", "").strip()
    emoji = body.get("emoji", "📢").strip()
    if not title or not content:
        raise HTTPException(400, "Title and content required")
    await db.update_news(news_id, title, content, emoji, body.get("image_url"))
    return {"ok": True}


@app.post("/api/admin/news/{news_id}/toggle")
async def admin_toggle_news(news_id: int, user: dict = Depends(get_current_user)):
    """Toggle news active state (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.toggle_news(news_id)
    return {"ok": True}


@app.post("/api/admin/news/{news_id}/delete")
async def admin_delete_news(news_id: int, user: dict = Depends(get_current_user)):
    """Delete a news item (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    await db.delete_news(news_id)
    return {"ok": True}


# ============ DISPUTES ============

@app.post("/api/deals/{deal_id}/dispute")
async def create_dispute(deal_id: int, request: Request, user: dict = Depends(get_current_user)):
    """Open a dispute for a deal."""
    body = await request.json()
    details = body.get("details", "")
    photo_url = body.get("photo_url")
    if not details or len(details) < 3:
        raise HTTPException(400, "Details too short")
    dispute_id = await db.create_dispute(deal_id, user["user_id"], details, photo_url)
    return {"ok": True, "dispute_id": dispute_id}


@app.get("/api/admin/disputes")
async def admin_disputes(user: dict = Depends(get_current_user)):
    """Get all disputes (admin or arbitrator)."""
    if user["user_id"] not in ADMIN_IDS and not user.get("is_arbitrator"):
        raise HTTPException(403, "Admin or Arbitrator only")
    disputes = await db.get_disputes()
    return disputes


@app.post("/api/admin/disputes/{dispute_id}/resolve")
async def admin_resolve_dispute(dispute_id: int, request: Request, user: dict = Depends(get_current_user)):
    """Resolve a dispute (admin or arbitrator)."""
    if user["user_id"] not in ADMIN_IDS and not user.get("is_arbitrator"):
        raise HTTPException(403, "Admin or Arbitrator only")
    body = await request.json()
    status = body.get("status", "resolved")
    await db.update_dispute_status(dispute_id, status)
    return {"ok": True}


@app.post("/api/admin/set-arbitrator")
async def set_arbitrator(request: Request, user: dict = Depends(get_current_user)):
    """Set/remove arbitrator role (admin only)."""
    if user["user_id"] not in ADMIN_IDS:
        raise HTTPException(403, "Admin only")
    body = await request.json()
    user_id = body.get("user_id")
    is_arbitrator = body.get("is_arbitrator", True)
    if not user_id:
        raise HTTPException(400, "user_id required")
    await db.set_user_arbitrator(int(user_id), is_arbitrator)
    return {"ok": True}


# ============ COMPLAINTS ============

@app.post("/api/complaints")
async def create_complaint(request: Request, user: dict = Depends(get_current_user)):
    """Submit a complaint about a user."""
    body = await request.json()
    reported_user = body.get("reported_user", "")
    subject = body.get("subject", "")
    details = body.get("details", "")
    photo_url = body.get("photo_url")
    if not reported_user:
        raise HTTPException(400, "reported_user required")
    if not subject:
        raise HTTPException(400, "subject required")
    complaint_id = await db.create_complaint(user["user_id"], reported_user, subject, details, photo_url)
    return {"ok": True, "complaint_id": complaint_id}


@app.get("/api/admin/complaints")
async def admin_get_complaints(user: dict = Depends(get_current_user)):
    """Get all complaints (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    complaints = await db.get_complaints()
    return complaints


# ============ TRUST STATUS ============

@app.post("/api/admin/trust-status")
async def admin_set_trust_status(request: Request, user: dict = Depends(get_current_user)):
    """Set user trust status (admin only)."""
    if not user.get("is_admin"):
        raise HTTPException(403, "Admin only")
    body = await request.json()
    uid = body.get("user_id")
    status = body.get("trust_status", "clean")
    if status not in ("clean", "verified", "has_complaints", "blocked_fraud"):
        raise HTTPException(400, "Invalid status")
    if not uid:
        raise HTTPException(400, "user_id required")
    await db.set_trust_status(uid, status)
    return {"ok": True}


# Mount static files
if os.path.exists(WEBAPP_DIR):
    app.mount("/", StaticFiles(directory=WEBAPP_DIR, html=True), name="webapp")
