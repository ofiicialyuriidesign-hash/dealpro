from aiogram.fsm.state import State, StatesGroup


class CaptchaStates(StatesGroup):
    waiting_captcha = State()


class LanguageStates(StatesGroup):
    selecting = State()


class RequisitesStates(StatesGroup):
    waiting_card = State()
    waiting_ton = State()


class DepositStates(StatesGroup):
    waiting_amount = State()


class WithdrawStates(StatesGroup):
    """Состояния для вывода средств"""
    waiting_amount = State()
    waiting_wallet = State()
    confirming = State()


class DealStates(StatesGroup):
    selecting_payment = State()
    selecting_role = State()
    entering_amount = State()
    entering_description = State()
    confirming = State()


class DealViewStates(StatesGroup):
    """Состояния для просмотра и действий в сделке"""
    viewing_deal = State()
    messaging_participants = State()
    joining_deal = State()
    viewing_deals_list = State()
    closing_deal = State()


class ReviewViewStates(StatesGroup):
    """Состояния для просмотра отзывов"""
    viewing_reviews = State()


class GarantStates(StatesGroup):
    """Состояния для гаранта"""
    viewing_deal = State()
    messaging_deal = State()


class SupportStates(StatesGroup):
    entering_subject = State()
    entering_message = State()
    replying_ticket = State()


class ReviewStates(StatesGroup):
    entering_comment = State()


class AdminStates(StatesGroup):
    messaging_deal_users = State()
    replying_ticket = State()
    boost_fake_review_date = State()
    boost_fake_review_name = State()
    boost_fake_review_comment = State()
    boost_fake_review_confirm = State()

class AppealStates(StatesGroup):
    entering_appeal = State()
