﻿/**
 * DealPro Service — Mini App
 * Professional SPA with Lucide Icons + i18n
 */

// ===== GLOBALS =====
const tg = window.Telegram?.WebApp;
let currentUser = null;
let currentPage = 'home';
let currentParams = {};
let pageHistory = [];
let selectedRole = 'buyer';

// ===== i18n =====
const L = {
ru: {
    home:'Главная', deals:'Сделки', profile:'Профиль', users:'Юзеры', more:'Ещё',
    dealpro:'DEALPRO SERVICE', hero_sub:'Безопасные сделки с гарант-сервисом',
    deals_count:'Сделок', reputation:'Репутация', deposit_label:'Депозит', successful:'Успешных',
    quick_actions:'Быстрые действия', create_deal:'Создать сделку', new_safe_deal:'Новая безопасная сделка',
    my_deals:'Мои сделки', history_active:'История и активные', requisites:'Реквизиты',
    payment_methods:'Способы оплаты', garants:'Гаранты', verified_agents:'Проверенные агенты',
    no_deals:'Нет сделок', create_first:'Создайте первую сделку',
    deal:'Сделка', status:'Статус', amount:'Сумма', payment:'Оплата', description:'Описание',
    date:'Дата', fee:'Комиссия', total:'Итого', participants:'Участники', partner:'Партнёр',
    garant:'Гарант', partner_link:'Ссылка для партнёра', share:'Поделиться', cancel:'Отменить',
    complete:'Завершить', review:'Отзыв', you:'Вы', user_label:'Пользователь',
    new_deal:'Новая сделка', pay_method:'Способ оплаты', amount_rub:'Сумма ($)',
    describe_deal:'Опишите сделку подробно...', your_role:'Ваша роль',
    buyer:'Покупатель', seller:'Продавец',
    leave_review:'Оставить отзыв', positive:'Положительный', negative:'Отрицательный',
    comment:'Комментарий', your_comment:'Ваш комментарий...', send:'Отправить',
    top_deposit:'Пополнить депозит', add_funds:'Внести средства',
    withdraw:'Вывод средств', to_wallet:'На кошелёк', statistics:'Статистика',
    detailed_info:'Подробная информация', my_reputation:'Моя репутация',
    reviews_about:'Отзывы обо мне', language:'Язык',
    current_deposit:'Текущий депозит', deposit_amount:'Сумма пополнения ($)',
    min_100:'Минимум: 20$ • Оплата через CryptoBot (USDT)', top_up:'Пополнить',
    available:'Доступно к выводу', withdraw_amount:'Сумма вывода ($)',
    wallet_address:'Адрес кошелька (USDT TRC-20)', withdraw_btn:'Вывести',
    total_deals:'Всего сделок', active:'Активных', completed_deals:'Завершённых',
    cancelled:'Отменённых', success_rate:'Успешность', positive_rev:'Положительные',
    negative_rev:'Отрицательные', no_reviews:'Нет отзывов', reviews_after:'Отзывы появятся после сделок',
    card_number:'Номер карты', ton_wallet:'TON кошелёк', save:'Сохранить',
    top_rep:'Топ репутации', best_users:'Лучшие пользователи', search:'Поиск',
    search_by:'Найти по username или ID', username_or_id:'Username или ID',
    enter_query:'Введите запрос...', not_found:'Не найдено', no_garants:'Нет гарантов',
    empty:'Пусто', all_reviews:'Все отзывы пользователя',
    support:'Поддержка', ask_help:'Обратиться за помощью', referrals:'Рефералы',
    invite_earn:'Приглашайте и зарабатывайте', garant_panel:'Панель гаранта',
    manage_deals:'Управление сделками', admin_panel:'Админ-панель', manage_service:'Управление сервисом',
    new_ticket:'Новый тикет', no_tickets:'Нет тикетов', create_request:'Создайте обращение',
    subject:'Тема', describe_problem:'Кратко опишите проблему', message:'Сообщение',
    describe_more:'Опишите подробнее...', ticket:'Тикет', opened:'Открыт', closed:'Закрыт',
    write_msg:'Написать...', close_ticket:'Закрыть тикет',
    ref_link:'Реферальная ссылка', bonus_per_deal:'бонус с каждой сделки', invited:'Приглашено',
    active_refs:'Активных', leaders:'Лидеры', leaders_table:'Таблица лидеров',
    ref_count:'рефералов', waiting_garant:'Ожидают гаранта', no_waiting:'Нет ожидающих сделок',
    take:'Взять', my_garant_deals:'Мои сделки', no_active:'Нет активных сделок',
    users_label:'Юзеров', deals_label:'Сделок', active_label:'Активных',
    manage_deals_full:'Управление сделками', tickets:'Тикеты', support_req:'Запросы поддержки',
    disputes:'Споры', dispute_requests:'Открытые споры', no_disputes:'Нет споров',
    withdrawals:'Выводы', withdrawal_req:'Заявки на вывод',
    boost:'Буст', boost_params:'Накрутка параметров', settings:'Настройки', bot_settings:'Параметры бота',
    user_id:'User ID', parameters:'Параметры', add_funds_boost:'Начислить средства',
    change_rep:'Изменить репутацию', boost_deals:'Накрутить количество',
    add_reviews:'Добавить отзывы', clear_reviews:'Очистить отзывы', delete_all_reviews:'Удалить все отзывы',
    moderation:'Модерация', ban_user:'Заблокировать', ban_desc:'Бан пользователя',
    unban_user:'Разблокировать', unban_desc:'Снять бан', garant_toggle:'Назначить / снять',
    no_open_tickets:'Нет открытых тикетов', from_label:'От', approve:'Одобрить', reject:'Отклонить',
    no_requests:'Нет заявок', min_deposit:'Минимальный депозит ($)', min_withdrawal:'Минимальный вывод ($)',
    waiting_assign:'Ожидают назначения', waiting_partner:'Ждут партнёра',
    assign:'Назначить', no_deals_section:'Нет сделок', my:'Мои',
    loading_error:'Ошибка загрузки', retry:'Повторить', page_not_found:'Страница не найдена',
    cancel_deal_q:'Отменить сделку?', complete_deal_q:'Завершить сделку?',
    deal_created:'Сделка создана!', joined:'Вы присоединились!', deal_cancelled:'Сделка отменена',
    deal_completed:'Сделка завершена!', review_sent:'Отзыв отправлен!', saved:'Сохранено!',
    copied:'Ссылка скопирована', ticket_created:'Тикет создан!', ticket_closed:'Тикет закрыт',
    garant_assigned:'Вы назначены гарантом!', lang_changed:'Язык изменён',
    enter_amount:'Укажите сумму', desc_min:'Описание мин. 3 символа', enter_query_err:'Введите запрос',
    enter_subj:'Укажите тему', enter_msg:'Напишите сообщение', enter_wallet:'Укажите кошелёк',
    min_100_err:'Минимум 20$', pay_crypto:'Оплатите через CryptoBot', deposit_ok:'Депозит зачислен!',
    request_created:'Заявка создана', enter_uid:'Введите User ID',
    deposit_added:'Депозит начислен', rep_changed:'Репутация изменена',
    deals_added:'Сделки добавлены', reviews_added:'Отзывы добавлены',
    reviews_deleted:'Отзывы удалены', banned:'Забанен', unbanned:'Разбанен',
    garant_set:'Гарант назначен', garant_removed:'Гарант снят',
    arbitrator:'Арбитр', arbitration:'Арбитраж', resolve_disputes:'Решение споров',
    arbitrator_toggle:'Назначить/снять арбитра', arbitrator_set:'Арбитр назначен', arbitrator_removed:'Арбитр снят',
    dispute_resolved:'Спор решён', total:'Всего', open:'Открытые', resolved:'Решённые',
    approved:'Одобрено', rejected:'Отклонено',
    select_lang:'Выберите язык', bronze:'Бронза', silver:'Серебро', gold:'Золото', vip:'VIP',
    deal_share_text:'Пора переходить к сделке — DEALPRO SERVICE уже страхует весь процесс.', you_role:'Вы —',
    verification:'Верификация', get_verified:'Подтвердите аккаунт',
    your_stats:'Ваша статистика', success_deals:'Успешных сделок', total_turnover:'Общий оборот',
    disputes_count:'Споров', deposit_balance:'Баланс депозита',
    verif_status:'Статус', not_verified:'Не верифицирован', verified_badge:'Верифицирован',
    what_gives:'Что даёт верификация', trust_buyers:'Повышенное доверие покупателей',
    badge_near_nick:'Значок рядом с ником', less_fee:'Меньше комиссия',
    fast_payouts:'Быстрые выплаты', fake_protect:'Защита от фейковых жалоб',
    big_deals:'Доступ к крупным сделкам',
    protection_sys:'Система защиты', protect_1:'Все сделки проходят через гаранта',
    protect_2:'Деньги холдируются до подтверждения', protect_3:'Логи хранятся 12 месяцев',
    protect_4:'Арбитраж до 24 часов',
    available_statuses:'Доступные статусы',
    basic_desc:'Подтверждение личности', basic_tg:'Проверка Telegram (аккаунт 3+ мес.)',
    basic_deposit:'Страховой депозит: 1 000 $', basic_limit:'Лимит сделки: до 30 000 $',
    trusted_desc:'Всё из BASIC', trusted_video:'Видео-верификация',
    trusted_deals:'5+ успешных сделок', trusted_deposit:'Депозит: 5 000 $',
    trusted_priority:'Приоритет в каталоге',
    premium_desc:'Всё из TRUSTED', premium_deals:'20+ успешных сделок',
    premium_turnover:'Оборот от 300 000 $', premium_deposit:'Депозит: 20 000 $',
    premium_manager:'Персональный менеджер', premium_support:'Приоритетная поддержка',
    apply_btn:'Подать заявку', purchase_btn:'Приобрести', fee_label:'Комиссия',
    pending_request:'Заявка на рассмотрении',
    purchase_verif:'Покупка верификации', select_currency:'Выберите валюту оплаты',
    deposit_payment:'Оплата со счёта депозита', deposit_payment_hint:'Сумма будет списана с вашего баланса после подтверждения.',
    pay_from_deposit:'Оплатить с депозита', price:'Стоимость', your_deposit:'Ваш депозит', not_enough_deposit:'Недостаточно средств на депозите',
    confirm_purchase:'Подтвердить покупку', purchase_sent:'Заявка на покупку отправлена!',
    apply_sent:'Заявка отправлена!', verifications:'Верификации', verif_requests:'Заявки верификации',
    level_label:'Уровень', type_label:'Тип', currency_label:'Валюта',
    current_level:'Текущий уровень',
    deal_chat:'Чат сделки', write_msg_deal:'Напишите сообщение...', no_messages:'Сообщений пока нет',
    chat_hint:'Общайтесь с участниками сделки',
    news:'Новости', no_news:'Нет новостей', manage_news:'Управление новостями',
    add_news:'Добавить новость', edit_news:'Редактировать', news_title:'Заголовок',
    news_content:'Текст новости', news_emoji:'Эмодзи', news_saved:'Новость сохранена!',
    news_deleted:'Новость удалена', news_image:'Ссылка на картинку', read_more:'Читать далее',
    author:'Автор', published:'Опубликовано',
    service_users:'Пользователи', all_users:'Все пользователи',
    online:'В сети', offline:'Оффлайн', away:'Отошёл', was_online:'Был в сети',
    set_pin:'Установить PIN', change_pin:'Изменить PIN', remove_pin:'Убрать PIN',
    enter_pin:'Введите код-пароль для\nподтверждения операции',
    pin_set:'PIN установлен!', pin_removed:'PIN убран!', wrong_pin:'Неверный PIN',
    pin_code:'PIN-код', pin_security:'Защита приложения',
    amount_label:'Сумма',
    reglament:'РЕГЛАМЕНТ РАБОТЫ ГАРАНТ-СЕРВИСА',
    online_now:'Онлайн сейчас',
    check_user:'Проверить пользователя',
    check_user_desc:'Поиск и жалобы',
    report_user:'Пожаловаться',
    report_desc:'Жалоба на пользователя',
    find_user_check:'Найти пользователя',
    find_user_check_desc:'Проверить по ID или username',
    report_subject:'Тема жалобы',
    report_details:'Опишите проблему подробно...',
    report_photo:'Прикрепить фото (URL)',
    report_sent:'Жалоба отправлена!',
    user_verified:'Проверенный пользователь',
    user_has_complaints:'Имеются жалобы',
    user_blocked_fraud:'Заблокирован за мошенничество',
    user_clean:'Нарушений нет',
    trust_status:'Статус доверия',
    set_trust_status:'Статус пользователя',
    dispute:'Спор',
    dispute_title:'Открыть спор',
    dispute_desc:'Опишите проблему с данной сделкой. Администратор рассмотрит ваш запрос.',
    dispute_details:'Подробное описание спора...',
    dispute_sent:'Спор открыт!',
    open_app:'ОТКРЫТЬ ПРИЛОЖЕНИЕ',
    complaints:'Жалобы',
    view_complaints:'Просмотр жалоб',
    from:'От',
    or:'или',
    view_profile:'Просмотр профиля',
    no_data:'Нет данных',
    channel:'Официальный канал',
},
en: {
    home:'Home', deals:'Deals', profile:'Profile', users:'Users', more:'More',
    dealpro:'DEALPRO SERVICE', hero_sub:'Secure escrow deals',
    online_now:'Online now',
    check_user:'Check user',
    check_user_desc:'Search and reports',
    report_user:'Report',
    report_desc:'Report a user',
    find_user_check:'Find user',
    find_user_check_desc:'Check by ID or username',
    report_subject:'Problem description',
    report_details:'Describe the problem in detail...',
    report_photo:'Attach photo (URL)',
    report_photo_hint:'Paste screenshot URL',
    report_sent:'Report sent!',
    user_verified:'Verified user',
    user_has_complaints:'Has complaints',
    user_blocked_fraud:'Blocked for fraud',
    user_clean:'No violations',
    trust_status:'Trust status',
    set_trust_status:'User status',
    dispute:'Dispute',
    dispute_title:'Open dispute',
    dispute_desc:'Describe the problem',
    dispute_details:'Detailed dispute description...',
    dispute_sent:'Dispute sent!',
    open_app:'OPEN APP',
    complaints:'Complaints',
    view_complaints:'View complaints',
    from:'From',
    or:'or',
    view_profile:'View profile',
    no_data:'No data',
    channel:'Official Channel',
    deals_count:'Deals', reputation:'Reputation', deposit_label:'Deposit', successful:'Successful',
    quick_actions:'Quick actions', create_deal:'Create deal', new_safe_deal:'New secure deal',
    my_deals:'My deals', history_active:'History & active', requisites:'Requisites',
    payment_methods:'Payment methods', garants:'Escrow agents', verified_agents:'Verified agents',
    no_deals:'No deals', create_first:'Create your first deal',
    deal:'Deal', status:'Status', amount:'Amount', payment:'Payment', description:'Description',
    date:'Date', fee:'Fee', total:'Total', participants:'Participants', partner:'Partner',
    garant:'Escrow', partner_link:'Link for partner', share:'Share', cancel:'Cancel',
    complete:'Complete', review:'Review', you:'You', user_label:'User',
    new_deal:'New deal', pay_method:'Payment method', amount_rub:'Amount ($)',
    describe_deal:'Describe the deal in detail...', your_role:'Your role',
    buyer:'Buyer', seller:'Seller',
    leave_review:'Leave review', positive:'Positive', negative:'Negative',
    comment:'Comment', your_comment:'Your comment...', send:'Send',
    top_deposit:'Top up deposit', add_funds:'Add funds',
    withdraw:'Withdraw', to_wallet:'To wallet', statistics:'Statistics',
    detailed_info:'Detailed information', my_reputation:'My reputation',
    reviews_about:'Reviews about me', language:'Language',
    current_deposit:'Current deposit', deposit_amount:'Deposit amount ($)',
    min_100:'Min: 20$ • Pay via CryptoBot (USDT)', top_up:'Top up',
    available:'Available for withdrawal', withdraw_amount:'Withdrawal amount ($)',
    wallet_address:'Wallet address (USDT TRC-20)', withdraw_btn:'Withdraw',
    total_deals:'Total deals', active:'Active', completed_deals:'Completed',
    cancelled:'Cancelled', success_rate:'Success rate', positive_rev:'Positive',
    negative_rev:'Negative', no_reviews:'No reviews', reviews_after:'Reviews appear after deals',
    card_number:'Card number', ton_wallet:'TON wallet', save:'Save',
    top_rep:'Top reputation', best_users:'Best users', search:'Search',
    search_by:'Search by username or ID', username_or_id:'Username or ID',
    enter_query:'Enter query...', not_found:'Not found', no_garants:'No escrow agents',
    empty:'Empty', all_reviews:'All user reviews',
    support:'Support', ask_help:'Get help', referrals:'Referrals',
    invite_earn:'Invite & earn', garant_panel:'Escrow panel',
    manage_deals:'Manage deals', admin_panel:'Admin panel', manage_service:'Manage service',
    new_ticket:'New ticket', no_tickets:'No tickets', create_request:'Create a request',
    subject:'Subject', describe_problem:'Briefly describe the problem', message:'Message',
    describe_more:'Describe in detail...', ticket:'Ticket', opened:'Open', closed:'Closed',
    write_msg:'Write...', close_ticket:'Close ticket',
    ref_link:'Referral link', bonus_per_deal:'bonus per deal', invited:'Invited',
    active_refs:'Active', leaders:'Leaders', leaders_table:'Leaderboard',
    ref_count:'referrals', waiting_garant:'Waiting for escrow', no_waiting:'No pending deals',
    take:'Take', my_garant_deals:'My deals', no_active:'No active deals',
    users_label:'Users', deals_label:'Deals', active_label:'Active',
    manage_deals_full:'Manage deals', tickets:'Tickets', support_req:'Support requests',
    disputes:'Disputes', dispute_requests:'Open disputes', no_disputes:'No disputes',
    withdrawals:'Withdrawals', withdrawal_req:'Withdrawal requests',
    boost:'Boost', boost_params:'Boost parameters', settings:'Settings', bot_settings:'Bot settings',
    user_id:'User ID', parameters:'Parameters', add_funds_boost:'Add funds',
    change_rep:'Change reputation', boost_deals:'Boost deals count',
    add_reviews:'Add reviews', clear_reviews:'Clear reviews', delete_all_reviews:'Delete all reviews',
    moderation:'Moderation', ban_user:'Ban', ban_desc:'Ban user',
    unban_user:'Unban', unban_desc:'Remove ban', garant_toggle:'Assign / remove',
    no_open_tickets:'No open tickets', from_label:'From', approve:'Approve', reject:'Reject',
    no_requests:'No requests', min_deposit:'Minimum deposit ($)', min_withdrawal:'Minimum withdrawal ($)',
    waiting_assign:'Waiting assignment', waiting_partner:'Waiting partner',
    assign:'Assign', no_deals_section:'No deals', my:'My',
    loading_error:'Loading error', retry:'Retry', page_not_found:'Page not found',
    cancel_deal_q:'Cancel deal?', complete_deal_q:'Complete deal?',
    deal_created:'Deal created!', joined:'You joined!', deal_cancelled:'Deal cancelled',
    deal_completed:'Deal completed!', review_sent:'Review sent!', saved:'Saved!',
    copied:'Link copied', ticket_created:'Ticket created!', ticket_closed:'Ticket closed',
    garant_assigned:'You are assigned as escrow!', lang_changed:'Language changed',
    enter_amount:'Enter amount', desc_min:'Description min 3 chars', enter_query_err:'Enter query',
    enter_subj:'Enter subject', enter_msg:'Write a message', enter_wallet:'Enter wallet',
    min_100_err:'Minimum 20$', pay_crypto:'Pay via CryptoBot', deposit_ok:'Deposit credited!',
    request_created:'Request created', enter_uid:'Enter User ID',
    deposit_added:'Deposit added', rep_changed:'Reputation changed',
    deals_added:'Deals added', reviews_added:'Reviews added',
    reviews_deleted:'Reviews deleted', banned:'Banned', unbanned:'Unbanned',
    garant_set:'Escrow assigned', garant_removed:'Escrow removed',
    arbitrator:'Arbitrator', arbitration:'Arbitration', resolve_disputes:'Resolve disputes',
    arbitrator_toggle:'Assign/remove arbitrator', arbitrator_set:'Arbitrator assigned', arbitrator_removed:'Arbitrator removed',
    dispute_resolved:'Dispute resolved', total:'Total', open:'Open', resolved:'Resolved',
    approved:'Approved', rejected:'Rejected',
    select_lang:'Select language', bronze:'Bronze', silver:'Silver', gold:'Gold', vip:'VIP',
    deal_share_text:'Time to make a deal — DEALPRO SERVICE secures the entire process.', you_role:'You —',
    verification:'Verification', get_verified:'Verify your account',
    your_stats:'Your Statistics', success_deals:'Successful deals', total_turnover:'Total turnover',
    disputes_count:'Disputes', deposit_balance:'Deposit balance',
    verif_status:'Status', not_verified:'Not verified', verified_badge:'Verified',
    what_gives:'Verification benefits', trust_buyers:'Increased buyer trust',
    badge_near_nick:'Badge next to nickname', less_fee:'Lower fees',
    fast_payouts:'Fast payouts', fake_protect:'Protection from fake complaints',
    big_deals:'Access to large deals',
    protection_sys:'Protection system', protect_1:'All deals go through escrow',
    protect_2:'Funds held until confirmation', protect_3:'Logs stored for 12 months',
    protect_4:'Arbitration within 24 hours',
    available_statuses:'Available statuses',
    basic_desc:'Identity verification', basic_tg:'Telegram check (3+ months account)',
    basic_deposit:'Insurance deposit: 1,000 $', basic_limit:'Deal limit: up to 30,000 $',
    trusted_desc:'Everything from BASIC', trusted_video:'Video verification',
    trusted_deals:'5+ successful deals', trusted_deposit:'Deposit: 5,000 $',
    trusted_priority:'Catalog priority',
    premium_desc:'Everything from TRUSTED', premium_deals:'20+ successful deals',
    premium_turnover:'Turnover from 300,000 $', premium_deposit:'Deposit: 20,000 $',
    premium_manager:'Personal manager', premium_support:'Priority support',
    apply_btn:'Apply', purchase_btn:'Purchase', fee_label:'Fee',
    pending_request:'Application under review',
    purchase_verif:'Purchase verification', select_currency:'Select payment currency',
    deposit_payment:'Payment from deposit', deposit_payment_hint:'The amount will be deducted from your balance after confirmation.',
    pay_from_deposit:'Pay from deposit', price:'Price', your_deposit:'Your deposit', not_enough_deposit:'Insufficient deposit funds',
    confirm_purchase:'Confirm purchase', purchase_sent:'Purchase request sent!',
    apply_sent:'Application sent!', verifications:'Verifications', verif_requests:'Verification requests',
    level_label:'Level', type_label:'Type', currency_label:'Currency',
    current_level:'Current level',
    deal_chat:'Deal Chat', write_msg_deal:'Write a message...', no_messages:'No messages yet',
    chat_hint:'Chat with deal participants',
    news:'News', no_news:'No news', manage_news:'Manage news',
    add_news:'Add news', edit_news:'Edit', news_title:'Title',
    news_content:'News text', news_emoji:'Emoji', news_saved:'News saved!',
    news_deleted:'News deleted', news_image:'Image URL', read_more:'Read more',
    author:'Author', published:'Published',
    service_users:'Users', all_users:'All users',
    online:'Online', offline:'Offline', away:'Away', was_online:'Was online',
    set_pin:'Set PIN', change_pin:'Change PIN', remove_pin:'Remove PIN',
    enter_pin:'Enter passcode to\nconfirm operation',
    pin_set:'PIN set!', pin_removed:'PIN removed!', wrong_pin:'Wrong PIN',
    pin_code:'PIN code', pin_security:'App protection',
    amount_label:'Amount',
    reglament:'ESCROW SERVICE REGULATIONS',
    channel:'Official Channel',
},
uk: {
    home:'Головна', deals:'Угоди', profile:'Профіль', users:'Користувачі', more:'Ще',
    dealpro:'DEALPRO SERVICE', hero_sub:'Безпечні угоди з гарант-сервісом',
    online_now:'Онлайн зараз', channel:'Офіційний канал',
    check_user:'Перевірити користувача', check_user_desc:'Пошук та скарги',
    report_user:'Поскаржитись', report_desc:'Скарга на користувача',
    find_user_check:'Знайти користувача', find_user_check_desc:'Перевірити за ID або username',
    report_subject:'Тема скарги', report_details:'Опишіть проблему докладно...',
    report_photo:'Прикріпити фото (URL)', report_sent:'Скаргу надіслано!',
    user_verified:'Перевірений користувач', user_has_complaints:'Є скарги',
    user_blocked_fraud:'Заблоковано за шахрайство', user_clean:'Порушень немає',
    trust_status:'Статус довіри', set_trust_status:'Статус користувача',
    dispute:'Спір', dispute_title:'Відкрити спір',
    dispute_desc:'Опишіть проблему з даною угодою. Адміністратор розгляне ваш запит.',
    dispute_details:'Детальний опис спору...', dispute_sent:'Спір відкрито!',
    open_app:'ВІДКРИТИ ДОДАТОК', complaints:'Скарги', view_complaints:'Перегляд скарг',
    from:'Від', or:'або', view_profile:'Перегляд профілю', no_data:'Немає даних',
    deals_count:'Угод', reputation:'Репутація', deposit_label:'Депозит', successful:'Успішних',
    quick_actions:'Швидкі дії', create_deal:'Створити угоду', new_safe_deal:'Нова безпечна угода',
    my_deals:'Мої угоди', history_active:'Історія та активні', requisites:'Реквізити',
    payment_methods:'Способи оплати', garants:'Гаранти', verified_agents:'Перевірені агенти',
    no_deals:'Немає угод', create_first:'Створіть першу угоду',
    deal:'Угода', status:'Статус', amount:'Сума', payment:'Оплата', description:'Опис',
    date:'Дата', fee:'Комісія', total:'Разом', participants:'Учасники', partner:'Партнер',
    garant:'Гарант', partner_link:'Посилання для партнера', share:'Поділитись', cancel:'Скасувати',
    complete:'Завершити', review:'Відгук', you:'Ви', user_label:'Користувач',
    new_deal:'Нова угода', pay_method:'Спосіб оплати', amount_rub:'Сума ($)',
    describe_deal:'Опишіть угоду докладно...', your_role:'Ваша роль',
    buyer:'Покупець', seller:'Продавець',
    leave_review:'Залишити відгук', positive:'Позитивний', negative:'Негативний',
    comment:'Коментар', your_comment:'Ваш коментар...', send:'Надіслати',
    top_deposit:'Поповнити депозит', add_funds:'Внести кошти',
    withdraw:'Вивід коштів', to_wallet:'На гаманець', statistics:'Статистика',
    detailed_info:'Детальна інформація', my_reputation:'Моя репутація',
    reviews_about:'Відгуки про мене', language:'Мова',
    current_deposit:'Поточний депозит', deposit_amount:'Сума поповнення ($)',
    min_100:'Мінімум: 20$ • Оплата через CryptoBot (USDT)', top_up:'Поповнити',
    available:'Доступно до виводу', withdraw_amount:'Сума виводу ($)',
    wallet_address:'Адреса гаманця (USDT TRC-20)', withdraw_btn:'Вивести',
    total_deals:'Всього угод', active:'Активних', completed_deals:'Завершених',
    cancelled:'Скасованих', success_rate:'Успішність', positive_rev:'Позитивні',
    negative_rev:'Негативні', no_reviews:'Немає відгуків', reviews_after:"Відгуки з'являться після угод",
    card_number:'Номер картки', ton_wallet:'TON гаманець', save:'Зберегти',
    top_rep:'Топ репутації', best_users:'Найкращі користувачі', search:'Пошук',
    search_by:'Знайти за username або ID', username_or_id:'Username або ID',
    enter_query:'Введіть запит...', not_found:'Не знайдено', no_garants:'Немає гарантів',
    empty:'Порожньо', all_reviews:'Всі відгуки користувача',
    support:'Підтримка', ask_help:'Звернутись за допомогою', referrals:'Реферали',
    invite_earn:'Запрошуйте та заробляйте', garant_panel:'Панель гаранта',
    manage_deals:'Управління угодами', admin_panel:'Адмін-панель', manage_service:'Управління сервісом',
    new_ticket:'Новий тікет', no_tickets:'Немає тікетів', create_request:'Створіть звернення',
    subject:'Тема', describe_problem:'Коротко опишіть проблему', message:'Повідомлення',
    describe_more:'Опишіть докладніше...', ticket:'Тікет', opened:'Відкритий', closed:'Закритий',
    write_msg:'Написати...', close_ticket:'Закрити тікет',
    ref_link:'Реферальне посилання', bonus_per_deal:'бонус з кожної угоди', invited:'Запрошено',
    active_refs:'Активних', leaders:'Лідери', leaders_table:'Таблиця лідерів',
    ref_count:'рефералів', waiting_garant:'Очікують гаранта', no_waiting:'Немає очікуючих угод',
    take:'Взяти', my_garant_deals:'Мої угоди', no_active:'Немає активних угод',
    users_label:'Користувачів', deals_label:'Угод', active_label:'Активних',
    manage_deals_full:'Управління угодами', tickets:'Тікети', support_req:'Запити підтримки',
    disputes:'Спори', dispute_requests:'Відкриті спори', no_disputes:'Немає спорів',
    withdrawals:'Виводи', withdrawal_req:'Заявки на вивід',
    boost:'Буст', boost_params:'Накрутка параметрів', settings:'Налаштування', bot_settings:'Параметри бота',
    user_id:'User ID', parameters:'Параметри', add_funds_boost:'Нарахувати кошти',
    change_rep:'Змінити репутацію', boost_deals:'Накрутити кількість',
    add_reviews:'Додати відгуки', clear_reviews:'Очистити відгуки', delete_all_reviews:'Видалити всі відгуки',
    moderation:'Модерація', ban_user:'Заблокувати', ban_desc:'Бан користувача',
    unban_user:'Розблокувати', unban_desc:'Зняти бан', garant_toggle:'Призначити / зняти',
    no_open_tickets:'Немає відкритих тікетів', from_label:'Від', approve:'Схвалити', reject:'Відхилити',
    no_requests:'Немає заявок', min_deposit:'Мінімальний депозит ($)', min_withdrawal:'Мінімальний вивід ($)',
    waiting_assign:'Очікують призначення', waiting_partner:'Чекають партнера',
    assign:'Призначити', no_deals_section:'Немає угод', my:'Мої',
    loading_error:'Помилка завантаження', retry:'Повторити', page_not_found:'Сторінку не знайдено',
    cancel_deal_q:'Скасувати угоду?', complete_deal_q:'Завершити угоду?',
    deal_created:'Угоду створено!', joined:'Ви приєднались!', deal_cancelled:'Угоду скасовано',
    deal_completed:'Угоду завершено!', review_sent:'Відгук надіслано!', saved:'Збережено!',
    copied:'Посилання скопійовано', ticket_created:'Тікет створено!', ticket_closed:'Тікет закрито',
    garant_assigned:'Вас призначено гарантом!', lang_changed:'Мову змінено',
    enter_amount:'Вкажіть суму', desc_min:'Опис мін. 3 символи', enter_query_err:'Введіть запит',
    enter_subj:'Вкажіть тему', enter_msg:'Напишіть повідомлення', enter_wallet:'Вкажіть гаманець',
    min_100_err:'Мінімум 20$', pay_crypto:'Оплатіть через CryptoBot', deposit_ok:'Депозит зараховано!',
    request_created:'Заявку створено', enter_uid:'Введіть User ID',
    deposit_added:'Депозит нараховано', rep_changed:'Репутацію змінено',
    deals_added:'Угоди додано', reviews_added:'Відгуки додано',
    reviews_deleted:'Відгуки видалено', banned:'Заблоковано', unbanned:'Розблоковано',
    garant_set:'Гаранта призначено', garant_removed:'Гаранта знято',
    arbitrator:'Арбітр', arbitration:'Арбітраж', resolve_disputes:'Вирішення спорів',
    arbitrator_toggle:'Призначити/зняти арбітра', arbitrator_set:'Арбітра призначено', arbitrator_removed:'Арбітра знято',
    dispute_resolved:'Спір вирішено', total:'Всього', open:'Відкриті', resolved:'Вирішені',
    approved:'Схвалено', rejected:'Відхилено',
    select_lang:'Виберіть мову', bronze:'Бронза', silver:'Срібло', gold:'Золото', vip:'VIP',
    deal_share_text:'Час переходити до угоди — DEALPRO SERVICE вже страхує весь процес.', you_role:'Ви —',
    verification:'Верифікація', get_verified:'Підтвердіть акаунт',
    your_stats:'Ваша статистика', success_deals:'Успішних угод', total_turnover:'Загальний оборот',
    disputes_count:'Спорів', deposit_balance:'Баланс депозиту',
    verif_status:'Статус', not_verified:'Не верифіковано', verified_badge:'Верифіковано',
    what_gives:'Що дає верифікація', trust_buyers:'Підвищена довіра покупців',
    badge_near_nick:'Значок поряд з ніком', less_fee:'Менша комісія',
    fast_payouts:'Швидкі виплати', fake_protect:'Захист від фейкових скарг',
    big_deals:'Доступ до великих угод',
    protection_sys:'Система захисту', protect_1:'Усі угоди проходять через гаранта',
    protect_2:'Гроші утримуються до підтвердження', protect_3:'Логи зберігаються 12 місяців',
    protect_4:'Арбітраж до 24 годин',
    available_statuses:'Доступні статуси',
    basic_desc:'Підтвердження особи', basic_tg:'Перевірка Telegram (акаунт 3+ міс.)',
    basic_deposit:'Страховий депозит: 1 000 $', basic_limit:'Ліміт угоди: до 30 000 $',
    trusted_desc:'Все з BASIC', trusted_video:'Відео-верифікація',
    trusted_deals:'5+ успішних угод', trusted_deposit:'Депозит: 5 000 $',
    trusted_priority:'Пріоритет у каталозі',
    premium_desc:'Все з TRUSTED', premium_deals:'20+ успішних угод',
    premium_turnover:'Оборот від 300 000 $', premium_deposit:'Депозит: 20 000 $',
    premium_manager:'Персональний менеджер', premium_support:'Пріоритетна підтримка',
    apply_btn:'Подати заявку', purchase_btn:'Придбати', fee_label:'Комісія',
    pending_request:'Заявка на розгляді',
    purchase_verif:'Купівля верифікації', select_currency:'Виберіть валюту оплати',
    deposit_payment:'Оплата з депозиту', deposit_payment_hint:'Сума буде списана з вашого балансу після підтвердження.',
    pay_from_deposit:'Оплатити з депозиту', price:'Вартість', your_deposit:'Ваш депозит', not_enough_deposit:'Недостатньо коштів на депозиті',
    confirm_purchase:'Підтвердити купівлю', purchase_sent:'Заявку на купівлю надіслано!',
    apply_sent:'Заявку надіслано!', verifications:'Верифікації', verif_requests:'Заявки верифікації',
    level_label:'Рівень', type_label:'Тип', currency_label:'Валюта', current_level:'Поточний рівень',
    deal_chat:'Чат угоди', write_msg_deal:'Напишіть повідомлення...', no_messages:'Повідомлень поки немає',
    chat_hint:'Спілкуйтесь з учасниками угоди',
    news:'Новини', no_news:'Немає новин', manage_news:'Управління новинами',
    add_news:'Додати новину', edit_news:'Редагувати', news_title:'Заголовок',
    news_content:'Текст новини', news_emoji:'Емодзі', news_saved:'Новину збережено!',
    news_deleted:'Новину видалено', news_image:'Посилання на картинку', read_more:'Читати далі',
    author:'Автор', published:'Опубліковано',
    service_users:'Користувачі', all_users:'Всі користувачі',
    online:'В мережі', offline:'Офлайн', away:'Відійшов', was_online:'Був в мережі',
    set_pin:'Встановити PIN', change_pin:'Змінити PIN', remove_pin:'Прибрати PIN',
    enter_pin:'Введіть код-пароль для\nпідтвердження операції',
    pin_set:'PIN встановлено!', pin_removed:'PIN прибрано!', wrong_pin:'Невірний PIN',
    pin_code:'PIN-код', pin_security:'Захист додатку',
    amount_label:'Сума', reglament:'РЕГЛАМЕНТ РОБОТИ ГАРАНТ-СЕРВІСУ',
}
};
function t(k) { return (L[currentUser?.language || 'ru'] || L.ru)[k] || k; }

// ===== HELPERS =====
function ic(n) { return `<i data-lucide="${n}"></i>`; }

function avatar(name, photoUrl, size = 72) {
    if (photoUrl) return `<img class="profile-avatar-img" src="${photoUrl}" style="width:${size}px;height:${size}px;border-radius:50%;object-fit:cover">`;
    const initial = (name || 'U')[0].toUpperCase();
    return `<div class="profile-avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size*0.38)}px">${initial}</div>`;
}

function smallAvatar(name, photoUrl) {
    if (photoUrl) return `<img src="${photoUrl}" style="width:36px;height:36px;border-radius:50%;object-fit:cover">`;
    return `<div class="participant-avatar">${(name || 'U')[0].toUpperCase()}</div>`;
}

function pageHeader(title, back) {
    const bb = back ? `<div class="back-btn" onclick="goBack()">${ic('arrow-left')}</div>` : '';
    return `<div class="page-header">${bb}<h1>${title}</h1></div>`;
}

function menuItem(icon, title, desc, onclick, color = '') {
    return `<div class="menu-item" onclick="${onclick}">
        <div class="menu-icon ${color}">${ic(icon)}</div>
        <div class="menu-body"><div class="menu-title">${title}</div>${desc ? `<div class="menu-desc">${desc}</div>` : ''}</div>
        <div class="menu-arrow">${ic('chevron-right')}</div></div>`;
}

function statCard(icon, value, label, color = '') {
    return `<div class="stat-card">
        <div class="stat-icon ${color}">${ic(icon)}</div>
        <div class="stat-value">${value}</div>
        <div class="stat-label">${label}</div></div>`;
}

function statusBadge(status) {
    const m = {
        pending: [t('status') === 'Status' ? 'Pending' : 'Ожидает', 'badge-pending', 'clock'],
        waiting_admin: [t('status') === 'Status' ? 'Waiting escrow' : 'Ждёт гаранта', 'badge-waiting', 'shield'],
        in_progress: [t('status') === 'Status' ? 'In progress' : 'В процессе', 'badge-progress', 'refresh-cw'],
        waiting_confirm: [t('status') === 'Status' ? 'Confirming' : 'Подтверждение', 'badge-confirm', 'alert-circle'],
        completed: [t('status') === 'Status' ? 'Completed' : 'Завершена', 'badge-completed', 'check-circle'],
        cancelled: [t('status') === 'Status' ? 'Cancelled' : 'Отменена', 'badge-cancelled', 'x-circle'],
    };
    const [text, cls, i] = m[status] || [status, '', 'help-circle'];
    return `<span class="status-badge ${cls}">${ic(i)} ${text}</span>`;
}

function payLabel(type) {
    const lang = currentUser?.language || 'ru';
    const m = lang === 'en'
        ? { card_ru:'Card RU', card_ua:'Card UA', card_kz:'Card KZ', card_by:'Card BY', usdt:'USDT', ton:'TON', stars:'Stars' }
        : lang === 'uk'
        ? { card_ru:'Картка РУ', card_ua:'Картка УА', card_kz:'Картка КЗ', card_by:'Картка РБ', usdt:'USDT', ton:'TON', stars:'Stars' }
        : { card_ru:'Карта РУ', card_ua:'Карта УК', card_kz:'Карта КЗ', card_by:'Карта РБ', usdt:'USDT', ton:'TON', stars:'Stars' };
    return m[type] || type;
}

function roleLabel(role) { return role === 'buyer' ? t('buyer') : t('seller'); }

function formatDate(d) {
    if (!d) return '—';
    const lang = currentUser?.language || 'ru';
    const loc = lang === 'en' ? 'en-US' : lang === 'uk' ? 'uk-UA' : 'ru-RU';
    return new Date(d).toLocaleDateString(loc, { day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' });
}

function onlineStatus(lastActive) {
    if (!lastActive) return { text: t('offline'), color: '#6b7280', dot: 'gray' };
    const diff = Date.now() - new Date(lastActive + 'Z').getTime();
    const mins = diff / 60000;
    if (mins < 3) return { text: t('online'), color: '#22c55e', dot: 'green' };
    if (mins < 15) return { text: t('away'), color: '#f59e0b', dot: 'yellow' };
    const timeStr = new Date(lastActive + 'Z').toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
    const dateStr = new Date(lastActive + 'Z').toLocaleDateString(currentUser?.language === 'en' ? 'en-US' : 'ru-RU', {day:'2-digit',month:'2-digit'});
    return { text: `${t('was_online')} ${dateStr} ${timeStr}`, color: '#6b7280', dot: 'gray' };
}

function currencySymbol(payType) {
    if (payType === 'card_ru') return '₽';
    if (payType === 'card_ua') return '₴';
    if (payType === 'card_kz') return '₸';
    if (payType === 'card_by') return 'Br';
    if (payType === 'usdt') return '$';
    if (payType === 'ton') return 'TON';
    if (payType === 'stars') return '⭐';
    return '$';
}

function dealLink(codeOrId) {
    const bot = currentUser?.bot_username;
    return bot ? `https://t.me/${bot}?start=${codeOrId}` : '';
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async () => {
    if (tg) {
        tg.ready();
        tg.expand();
        try { tg.enableClosingConfirmation(); } catch(e) {}
        if (tg.initData && tg.initData.length > 0) {
            api.setInitData(tg.initData);
        }
    }
    try {
        currentUser = await api.getMe();
        // Get photo from TG SDK if available
        if (!currentUser.photo_url && tg?.initDataUnsafe?.user?.photo_url) {
            currentUser.photo_url = tg.initDataUnsafe.user.photo_url;
        }
        hideLoading();
        // Show language selection on first open
        if (!localStorage.getItem('lang_selected')) {
            showLangSelect();
            return;
        }
        // Check if PIN lock is needed
        if (currentUser.has_pin && !sessionStorage.getItem('pin_verified')) {
            showPinLock();
            return;
        }
        showNav();
        _afterLangInit();
    } catch (e) {
        hideLoading();
        document.getElementById('app').innerHTML = `<div class="page">
            <div class="empty-state">
                <div class="empty-icon">${ic('alert-circle')}</div>
                <div class="empty-text">${t('loading_error')}</div>
                <div class="empty-hint">${e.message}</div>
                <button class="btn btn-primary mt-16" onclick="location.reload()">${ic('refresh-cw')} ${t('retry')}</button>
            </div></div>`;
        if (window.lucide) lucide.createIcons();
    }
});

function hideLoading() {
    const el = document.getElementById('loading');
    if (el) el.classList.add('hidden');
}

function _afterLangInit() {
    if (currentUser.start_param) {
        const sp = currentUser.start_param;
        if (sp.startsWith('deal_')) {
            const dealId = parseInt(sp.split('_')[1]);
            if (dealId) { navigateTo('deal-detail', { dealId }); return; }
        } else if (sp.startsWith('DP-')) {
            // deal code format — fetch deal by code and navigate
            api.get(`/api/deals/by-code/${sp}`).then(d => {
                if (d && d.id) navigateTo('deal-detail', { dealId: d.id });
                else navigateTo('home');
            }).catch(() => navigateTo('home'));
            return;
        }
    }
    navigateTo('home');
}

function showLangSelect() {
    const app = document.getElementById('app');
    app.innerHTML = `
    <div class="lang-select-screen">
        <div class="lang-select-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>
        </div>
        <div class="lang-select-title">DEALPRO SERVICE</div>
        <div class="lang-select-sub">Выберите язык / Оберіть мову / Select language</div>
        <div class="lang-select-btns">
            <button class="lang-btn" onclick="selectLang('ru')">🇷🇺 Русский</button>
            <button class="lang-btn" onclick="selectLang('uk')">🇺🇦 Українська</button>
            <button class="lang-btn" onclick="selectLang('en')">🇬🇧 English</button>
        </div>
    </div>`;
    if (window.lucide) lucide.createIcons();
}

async function selectLang(lang) {
    currentUser.language = lang;
    localStorage.setItem('lang_selected', lang);
    try { await api.setLanguage(lang); } catch(e) {}
    if (!document.getElementById('bottom-nav') || document.getElementById('bottom-nav').classList.contains('hidden')) {
        if (currentUser.has_pin && !sessionStorage.getItem('pin_verified')) {
            showPinLock();
            return;
        }
        showNav();
        _afterLangInit();
    } else {
        // Already in app — just update labels and go to home
        updateNavLabels();
        navigateTo('home');
    }
}

function showLangSelectPage() {
    pageHistory.push({ page: currentPage, params: currentParams });
    const app = document.getElementById('app');
    app.innerHTML = `
    <div class="lang-select-screen" style="min-height:auto;padding-top:60px">
        <div class="lang-select-logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/></svg>
        </div>
        <div class="lang-select-title">${t('select_lang') || 'Выберите язык'}</div>
        <div class="lang-select-btns">
            <button class="lang-btn ${currentUser.language==='ru'?'lang-btn-active':''}" onclick="selectLang('ru')">🇷🇺 Русский</button>
            <button class="lang-btn ${currentUser.language==='uk'?'lang-btn-active':''}" onclick="selectLang('uk')">🇺🇦 Українська</button>
            <button class="lang-btn ${currentUser.language==='en'?'lang-btn-active':''}" onclick="selectLang('en')">🇬🇧 English</button>
        </div>
    </div>`;
    if (window.lucide) lucide.createIcons();
}

function showNav() {
    const nav = document.getElementById('bottom-nav');
    if (!nav) return;
    nav.classList.remove('hidden');
    updateNavLabels();
    // Set real nav height for chat positioning
    requestAnimationFrame(() => {
        document.documentElement.style.setProperty('--real-nav-h', nav.offsetHeight + 'px');
    });
    nav.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            pageHistory = [];
            navigateTo(item.dataset.page);
        });
    });
    if (window.lucide) lucide.createIcons();
    startUnreadPoll();
}

function startUnreadPoll() {
    if (_unreadPollTimer) clearInterval(_unreadPollTimer);
    pollUnreadCount();
    _unreadPollTimer = setInterval(pollUnreadCount, 10000);
}

async function pollUnreadCount() {
    try {
        const { count } = await api.getUnreadCount();
        const navItem = document.querySelector('.nav-item[data-page="deals"]');
        if (!navItem) return;
        let badge = navItem.querySelector('.nav-badge');
        if (count > 0) {
            if (!badge) {
                badge = document.createElement('span');
                badge.className = 'nav-badge';
                navItem.style.position = 'relative';
                navItem.appendChild(badge);
            }
            badge.textContent = count > 99 ? '99+' : count;
            badge.classList.add('nav-badge-pulse');
            setTimeout(() => badge.classList.remove('nav-badge-pulse'), 600);
        } else if (badge) {
            badge.remove();
        }
    } catch(e) {}
}

function updateNavLabels() {
    const map = { home: t('home'), deals: t('deals'), profile: t('profile'), users: t('users'), more: t('more') };
    document.querySelectorAll('.nav-item').forEach(item => {
        const label = item.querySelector('.nav-label');
        if (label && map[item.dataset.page]) label.textContent = map[item.dataset.page];
    });
    const rl = document.getElementById('reglament-label');
    if (rl) rl.textContent = t('reglament');
}

// ===== NAVIGATION =====
const pages = {
    'home': renderHome, 'deals': renderDeals, 'deal-detail': renderDealDetail,
    'create-deal': renderCreateDeal, 'leave-review': renderLeaveReview,
    'profile': renderProfile, 'deposit': renderDeposit, 'withdraw': renderWithdraw,
    'statistics': renderStatistics, 'my-reputation': renderMyReputation, 'requisites': renderRequisites,
    'users': renderUsers, 'garants': renderGarants, 'top-reputation': renderTopReputation,
    'search-user': renderSearchUser, 'user-profile': renderUserProfile, 'user-reviews': renderUserReviews,
    'more': renderMore, 'support': renderSupport, 'create-ticket': renderCreateTicket,
    'ticket-detail': renderTicketDetail, 'referrals': renderReferrals, 'referral-leaders': renderReferralLeaders,
    'verification': renderVerification, 'purchase-verification': renderPurchaseVerification,
    'deal-chat': renderDealChat,
    'garant-panel': renderGarantPanel, 'arbitration': renderArbitration, 'admin': renderAdmin, 'admin-deals': renderAdminDeals,
    'admin-tickets': renderAdminTickets, 'admin-withdrawals': renderAdminWithdrawals,
    'admin-boost': renderAdminBoost, 'admin-settings': renderAdminSettings,
    'admin-verifications': renderAdminVerifications,
    'admin-news': renderAdminNews, 'admin-news-edit': renderAdminNewsEdit,
    'admin-users': renderAdminUsers,
    'news-detail': renderNewsDetail,
    'pin-settings': renderPinSettings,
    'dispute': renderDispute, 'check-user': renderCheckUser,
    'report-user': renderReportUser, 'find-user-check': renderFindUserCheck,
    'admin-disputes': renderAdminDisputes,
    'admin-complaints': renderAdminComplaints,
};

function navigateTo(page, params = {}) {
    if (currentPage && currentPage !== page) {
        pageHistory.push({ page: currentPage, params: currentParams });
    }
    currentPage = page;
    currentParams = params;
    updateNavActive();
    const fn = pages[page];
    if (fn) fn(params);
    else renderApp(`<div class="page"><div class="empty-state"><div class="empty-text">${t('page_not_found')}</div></div></div>`);
}

function goBack() {
    if (pageHistory.length > 0) {
        const prev = pageHistory.pop();
        currentPage = prev.page;
        updateNavActive();
        const fn = pages[prev.page];
        if (fn) fn(prev.params || {});
    } else {
        navigateTo('home');
    }
}

function updateNavActive() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === currentPage);
    });
}

function renderApp(html) {
    document.getElementById('app').innerHTML = html;
    if (window.lucide) lucide.createIcons();
    window.scrollTo(0, 0);
}

// ===== HOME =====
async function renderHome() {
    const u = currentUser;
    const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
    // Load news in background
    let newsHtml = '';
    try {
        const news = await api.getNews();
        if (news.length) {
            newsHtml = `<div class="section-label">${ic('megaphone')} ${t('news')}</div><div class="news-list stagger">`;
            for (const n of news) {
                newsHtml += `<div class="news-card" onclick="navigateTo('news-detail',{newsId:${n.id}})">
                    ${n.image_url ? `<img class="news-card-img" src="${n.image_url}" alt="">` : `<div class="news-emoji-icon">${ic('newspaper')}</div>`}
                    <div class="news-body"><div class="news-title">${n.title}</div><div class="news-text">${n.content.length > 80 ? n.content.substring(0,80)+'...' : n.content}</div>
                    <div class="news-meta">${formatDate(n.created_at)}</div></div>
                    <div class="news-arrow">${ic('chevron-right')}</div>
                </div>`;
            }
            newsHtml += `</div>`;
        }
    } catch(e) {}
    renderApp(`<div class="page">
        <div class="hero">
            <div class="hero-dots"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
            <div class="hero-icon">${ic('shield')}</div>
            <div class="hero-title">${t('dealpro')}</div>
            <div class="hero-subtitle">${t('hero_sub')}</div>
            <div class="hero-line"></div>
            <div class="hero-online">${ic('users')} <span class="online-counter" id="online-counter">${Math.floor(Math.random()*150)+200}</span> ${t('online_now')}</div>
        </div>
        ${newsHtml}
        <div class="section-label">${ic('zap')} ${t('quick_actions')}</div>
        <div class="menu-list stagger">
            ${menuItem('plus-circle', t('create_deal'), t('new_safe_deal'), "navigateTo('create-deal')")}
            ${menuItem('clipboard-list', t('my_deals'), t('history_active'), "navigateTo('deals')")}
            ${menuItem('folder', t('requisites'), t('payment_methods'), "navigateTo('requisites')", 'green')}
            ${menuItem('shield', t('garants'), t('verified_agents'), "navigateTo('garants')", 'purple')}
            ${menuItem('user-check', t('check_user'), t('check_user_desc'), "navigateTo('check-user')", 'yellow')}
        </div>
    </div>`);
}

// ===== DEALS =====
async function renderDeals() {
    renderApp(`<div class="page">${pageHeader(t('my_deals'))}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const deals = await api.getDeals();
        let h = `<div class="page">${pageHeader(t('my_deals'))}`;
        h += `<button class="btn btn-primary mb-16" onclick="navigateTo('create-deal')">${ic('plus')} ${t('create_deal')}</button>`;
        if (!deals.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('file-text')}</div><div class="empty-text">${t('no_deals')}</div><div class="empty-hint">${t('create_first')}</div></div>`;
        } else {
            for (const d of deals) {
                h += `<div class="card" onclick="navigateTo('deal-detail',{dealId:${d.id}})">
                    <div class="card-top"><span class="card-id">${t('deal')} #${d.id}</span>${statusBadge(d.status)}</div>
                    <div class="card-amount">${d.amount}${currencySymbol(d.payment_type)}</div>
                    <div class="card-row">${ic('credit-card')} ${payLabel(d.payment_type)}</div>
                    <div class="card-row">${ic('user')} ${d.is_creator ? t('you_role') + ' ' + roleLabel(d.creator_role) : t('you_role') + ' ' + t('partner')}</div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== DEAL DETAIL =====
async function renderDealDetail({ dealId }) {
    renderApp(`<div class="page">${pageHeader(t('deal'), true)}<div class="skeleton" style="height:300px"></div></div>`);
    try {
        const d = await api.getDeal(dealId);
        let h = `<div class="page">${pageHeader(t('deal') + ' #' + d.id, true)}`;

        h += `<div class="info-block">
            <div class="info-row"><span class="info-label">${ic('activity')} ${t('status')}</span><span class="info-value">${statusBadge(d.status)}</span></div>
            <div class="info-row"><span class="info-label">${ic('wallet')} ${t('amount')}</span><span class="info-value">${d.amount}${currencySymbol(d.payment_type)}</span></div>
            <div class="info-row"><span class="info-label">${ic('credit-card')} ${t('payment')}</span><span class="info-value">${payLabel(d.payment_type)}</span></div>
            <div class="info-row"><span class="info-label">${ic('align-left')} ${t('description')}</span><span class="info-value" style="max-width:55%;text-align:right">${d.description}</span></div>
            <div class="info-row"><span class="info-label">${ic('calendar')} ${t('date')}</span><span class="info-value">${formatDate(d.created_at)}</span></div>
        </div>`;

        if (d.fee) {
            h += `<div class="info-block">
                <div class="info-row"><span class="info-label">${ic('percent')} ${t('fee')}</span><span class="info-value">${d.fee}${currencySymbol(d.payment_type)}</span></div>
                <div class="info-row"><span class="info-label">${ic('calculator')} ${t('total')}</span><span class="info-value fw-600">${d.amount + d.fee}${currencySymbol(d.payment_type)}</span></div>
            </div>`;
        }

        h += `<div class="section-label mt-16">${t('participants')}</div>`;
        h += participantCard(d.creator_name, d.creator_username, roleLabel(d.creator_role), d.is_creator, d.creator_rep, d.creator_deposit, d.creator_id);
        if (d.partner_id) {
            h += participantCard(d.partner_name, d.partner_username, t('partner'), !d.is_creator, d.partner_rep, d.partner_deposit, d.partner_id);
        }
        if (d.garant_username) {
            h += `<div class="participant">
                <div class="participant-head">
                    <div class="participant-avatar" style="background:var(--purple-soft);color:var(--purple)">${ic('shield')}</div>
                    <div class="participant-info">
                        <div class="participant-name">@${d.garant_username}</div>
                        <div class="participant-role">${t('garant')}</div>
                    </div>
                </div>
            </div>`;
        }

        if (d.status === 'pending' && d.is_creator) {
            const dealCode = d.deal_code || d.id;
            const link = dealLink(dealCode);
            if (link) {
                h += `<div class="section-label mt-16">${ic('link')} ${t('partner_link')}</div>
                    <div class="copy-field">
                        <input class="form-input" id="deal-link" value="${link}" readonly>
                        <button class="copy-btn" onclick="copyDealLink()">${ic('copy')}</button>
                    </div>
                    <button class="btn btn-outline btn-sm mt-8" onclick="shareDealLink('${dealCode}')">${ic('share-2')} ${t('share')}</button>`;
            }
        }

        let actions = '';
        // Chat button for active deals with participants
        if (d.partner_id && d.status !== 'cancelled') {
            actions += `<button class="btn btn-outline" onclick="navigateTo('deal-chat',{dealId:${d.id}})">${ic('message-circle')} ${t('deal_chat')}</button>`;
        }
        // Dispute button for active deals
        if (d.partner_id && d.status !== 'cancelled' && d.status !== 'completed') {
            actions += `<button class="btn btn-outline" style="border-color:rgba(239,68,68,.3);color:var(--red)" onclick="navigateTo('dispute',{dealId:${d.id}})">${ic('alert-triangle')} ${t('dispute')}</button>`;
        }
        if (d.can_cancel) actions += `<button class="btn btn-danger" onclick="cancelDeal(${d.id})">${ic('x')} ${t('cancel')}</button>`;
        if (d.can_complete) actions += `<button class="btn btn-success" onclick="completeDeal(${d.id})">${ic('check')} ${t('complete')}</button>`;
        if (d.can_review && !d.has_review) actions += `<button class="btn btn-primary" onclick="navigateTo('leave-review',{dealId:${d.id}})">${ic('star')} ${t('review')}</button>`;
        if (actions) h += `<div class="btn-group mt-16" style="flex-wrap:wrap">${actions}</div>`;

        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

function participantCard(name, username, role, isYou, rep, deposit, userId) {
    const click = userId ? `onclick="navigateTo('user-profile',{userId:${userId}})"` : '';
    return `<div class="participant" ${click}>
        <div class="participant-head">
            ${smallAvatar(name, null)}
            <div class="participant-info">
                <div class="participant-name">${name || t('user_label')}${isYou ? ' (' + t('you') + ')' : ''}</div>
                <div class="participant-role">${role}${username ? ' • @' + username : ''}</div>
            </div>
        </div>
        <div class="participant-stats">
            <span>${ic('trending-up')} ${(rep||0) >= 0 ? '+' : ''}${rep||0}</span>
            <span>${ic('wallet')} ${deposit||0}$</span>
        </div>
    </div>`;
}

// ===== CREATE DEAL =====
async function renderCreateDeal() {
    selectedRole = 'buyer';
    renderApp(`<div class="page">${pageHeader(t('new_deal'), true)}
        <div class="form-group">
            <div class="form-label">${t('pay_method')}</div>
            <select id="pay-type" class="form-select" onchange="updateCurrencyLabel()">
                <option value="card_ru">${payLabel('card_ru')}</option>
                <option value="card_ua">${payLabel('card_ua')}</option>
                <option value="card_kz">${payLabel('card_kz')}</option>
                <option value="card_by">${payLabel('card_by')}</option>
                <option value="usdt">USDT</option>
                <option value="ton">TON</option>
                <option value="stars">Stars</option>
            </select>
        </div>
        <div class="form-group">
            <div class="form-label" id="amount-label">${t('amount_label')} (${currencySymbol('card_ru')})</div>
            <input id="deal-amount" class="form-input" type="number" inputmode="decimal" placeholder="500" min="1">
        </div>
        <div class="form-group">
            <div class="form-label">${t('description')}</div>
            <textarea id="deal-desc" class="form-textarea" placeholder="${t('describe_deal')}"></textarea>
        </div>
        <div class="form-group">
            <div class="form-label">${t('your_role')}</div>
            <div class="role-selector">
                <div class="role-option active" id="role-buyer" onclick="selectRole('buyer')">
                    <div class="icon" style="width:28px;height:28px">${ic('shopping-cart')}</div>
                    <div class="role-label">${t('buyer')}</div>
                </div>
                <div class="role-option" id="role-seller" onclick="selectRole('seller')">
                    <div class="icon" style="width:28px;height:28px">${ic('tag')}</div>
                    <div class="role-label">${t('seller')}</div>
                </div>
            </div>
        </div>
        <button class="btn btn-primary" onclick="submitCreateDeal()">${ic('plus')} ${t('create_deal')}</button>
    </div>`);
}

function selectRole(role) {
    selectedRole = role;
    document.getElementById('role-buyer').classList.toggle('active', role === 'buyer');
    document.getElementById('role-seller').classList.toggle('active', role === 'seller');
    if (window.lucide) lucide.createIcons();
}

function updateCurrencyLabel() {
    const payType = document.getElementById('pay-type')?.value || 'card_ru';
    const sym = currencySymbol(payType);
    const label = document.getElementById('amount-label');
    if (label) label.textContent = `${t('amount_label')} (${sym})`;
}

// ===== DEAL CHAT =====
let _chatPollTimer = null;
let _unreadPollTimer = null;
let _chatLastMsgId = 0;

function buildChatMessages(messages, dealId) {
    const roleColors = { buyer: 'var(--blue)', seller: 'var(--green)', garant: 'var(--purple)', admin: 'var(--yellow)' };
    const roleIcons = { buyer: 'shopping-cart', seller: 'package', garant: 'shield', admin: 'crown' };
    let h = '';
    for (const m of messages) {
        const isMe = m.is_me;
        const name = m.full_name || m.username || 'User';
        const role = m.role || 'buyer';
        const roleName = t(role) || role;
        const roleColor = roleColors[role] || 'var(--sub)';
        const roleIcon = roleIcons[role] || 'user';
        const time = m.created_at ? new Date(m.created_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '';
        const msgContent = m.image_url
            ? `<img src="${m.image_url}" class="chat-msg-img" onclick="this.requestFullscreen&&this.requestFullscreen()" alt="photo"><span class="chat-msg-time">${time}</span>`
            : `${escapeHtml(m.message)}<span class="chat-msg-time">${time}</span>`;
        h += `<div class="chat-msg ${isMe ? 'chat-msg-me' : 'chat-msg-other'}">
            <div class="chat-msg-header">
                <span class="chat-msg-name">${name}</span>
                <span class="chat-role-badge" style="--role-color:${roleColor}">${ic(roleIcon)} ${roleName}</span>
            </div>
            <div class="chat-msg-bubble">${msgContent}</div>
        </div>`;
    }
    return h;
}

async function renderDealChat({ dealId }) {
    stopChatPoll();
    renderApp(`<div class="page">${pageHeader(t('deal_chat') + ' #' + dealId, true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const messages = await api.getDealMessages(dealId);
        _chatLastMsgId = messages.length ? Math.max(...messages.map(m => m.id)) : 0;
        let h = `<div class="page page-chat">${pageHeader(t('deal_chat') + ' #' + dealId, true)}`;
        h += `<div class="chat-container" id="chat-container">`;
        if (!messages.length) {
            h += `<div class="chat-empty">${ic('message-circle')} ${t('no_messages')}<br><span class="text-muted fs-13">${t('chat_hint')}</span></div>`;
        } else {
            h += buildChatMessages(messages, dealId);
        }
        h += `</div>`;
        h += `<div class="chat-input-bar">
            <label class="chat-photo-btn" title="${t('photo') || 'Фото'}">
                ${ic('image')}
                <input type="file" id="chat-photo-input" accept="image/*" style="display:none" onchange="sendChatPhoto(${dealId},this)">
            </label>
            <input id="chat-input" placeholder="${t('write_msg_deal')}" autocomplete="off" onkeydown="if(event.key==='Enter')sendChatMsg(${dealId})">
            <button class="chat-send-btn" onclick="sendChatMsg(${dealId})">${ic('send')}</button>
        </div>`;
        h += `</div>`;
        renderApp(h);
        const container = document.getElementById('chat-container');
        if (container) container.scrollTop = container.scrollHeight;
        // Set real nav height for correct chat sizing
        const nav = document.getElementById('bottom-nav');
        if (nav) document.documentElement.style.setProperty('--real-nav-h', nav.offsetHeight + 'px');
        startChatPoll(dealId);
        pollUnreadCount();
    } catch (e) { toast(e.message, 'error'); }
}

function startChatPoll(dealId) {
    stopChatPoll();
    _chatPollTimer = setInterval(async () => {
        if (currentPage !== 'deal-chat') { stopChatPoll(); return; }
        try {
            const messages = await api.getDealMessages(dealId);
            const newMax = messages.length ? Math.max(...messages.map(m => m.id)) : 0;
            if (newMax > _chatLastMsgId) {
                _chatLastMsgId = newMax;
                const container = document.getElementById('chat-container');
                if (container) {
                    const wasAtBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 60;
                    container.innerHTML = messages.length ? buildChatMessages(messages, dealId) : `<div class="chat-empty">${ic('message-circle')} ${t('no_messages')}</div>`;
                    if (window.lucide) lucide.createIcons();
                    if (wasAtBottom) container.scrollTop = container.scrollHeight;
                }
            }
        } catch(e) {}
    }, 3000);
}

function stopChatPoll() {
    if (_chatPollTimer) { clearInterval(_chatPollTimer); _chatPollTimer = null; }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function sendChatMsg(dealId) {
    const input = document.getElementById('chat-input');
    if (!input) return;
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    try {
        await api.sendDealMessage(dealId, msg);
        // Immediately fetch and update
        const messages = await api.getDealMessages(dealId);
        _chatLastMsgId = messages.length ? Math.max(...messages.map(m => m.id)) : 0;
        const container = document.getElementById('chat-container');
        if (container) {
            container.innerHTML = buildChatMessages(messages, dealId);
            if (window.lucide) lucide.createIcons();
            container.scrollTop = container.scrollHeight;
        }
    } catch (e) { toast(e.message, 'error'); }
}

async function sendChatPhoto(dealId, input) {
    const file = input.files[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { toast('Макс. размер фото: 3 МБ', 'error'); return; }
    const reader = new FileReader();
    reader.onload = async (e) => {
        const image_url = e.target.result;
        input.value = '';
        try {
            await api.sendDealPhoto(dealId, image_url);
            const messages = await api.getDealMessages(dealId);
            _chatLastMsgId = messages.length ? Math.max(...messages.map(m => m.id)) : 0;
            const container = document.getElementById('chat-container');
            if (container) {
                container.innerHTML = buildChatMessages(messages, dealId);
                if (window.lucide) lucide.createIcons();
                container.scrollTop = container.scrollHeight;
            }
        } catch (e) { toast(e.message, 'error'); }
    };
    reader.readAsDataURL(file);
}

// ===== LEAVE REVIEW =====
async function renderLeaveReview({ dealId }) {
    window._reviewPositive = true;
    renderApp(`<div class="page">${pageHeader(t('leave_review'), true)}
        <div class="review-selector">
            <div class="review-option positive active" id="opt-pos" onclick="setReviewType(true)">
                <div class="icon" style="width:32px;height:32px">${ic('thumbs-up')}</div>
                <div>${t('positive')}</div>
            </div>
            <div class="review-option negative" id="opt-neg" onclick="setReviewType(false)">
                <div class="icon" style="width:32px;height:32px">${ic('thumbs-down')}</div>
                <div>${t('negative')}</div>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">${t('comment')}</div>
            <textarea id="review-text" class="form-textarea" placeholder="${t('your_comment')}"></textarea>
        </div>
        <button class="btn btn-primary" onclick="submitReview(${dealId})">${ic('send')} ${t('send')}</button>
    </div>`);
}

function setReviewType(positive) {
    window._reviewPositive = positive;
    document.getElementById('opt-pos').classList.toggle('active', positive);
    document.getElementById('opt-neg').classList.toggle('active', !positive);
    if (window.lucide) lucide.createIcons();
}

// ===== PROFILE =====
async function renderProfile() {
    const u = currentUser;
    const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
    let badges = '';
    const vl = u.verification_level;
    if (vl && vl !== 'none') badges += `<span class="profile-badge badge-verified">${ic('badge-check')} ${vl.toUpperCase()}</span>`;
    if (u.is_garant) badges += `<span class="profile-badge badge-garant">${ic('shield')} ${t('garant')}</span>`;
    if (u.is_arbitrator) badges += `<span class="profile-badge badge-arbitrator">${ic('scale')} ${t('arbitrator')}</span>`;
    if (u.is_admin) badges += `<span class="profile-badge badge-admin">${ic('crown')} Admin</span>`;

    renderApp(`<div class="page">
        <div class="profile-header">
            ${avatar(u.full_name || u.username, u.photo_url, 76)}
            <div class="profile-name">${u.full_name || t('user_label')}</div>
            <div class="profile-username">@${u.username || '—'}</div>
            <div class="online-status-row" style="justify-content:center"><span class="status-indicator-dot"></span> ${t('online')}</div>
            ${badges ? `<div class="profile-badges">${badges}</div>` : ''}
        </div>
        <div class="stat-grid stagger">
            ${statCard('file-text', u.deals_count || 0, t('deals_count'))}
            ${statCard('trending-up', (rep >= 0 ? '+' : '') + rep, t('reputation'), 'green')}
            ${statCard('wallet', (u.deposit || 0) + '$', t('deposit_label'), 'purple')}
            ${statCard('star', u.review_count || 0, t('review'), 'yellow')}
        </div>
        <div class="section-label">${ic('settings')} ${t('quick_actions')}</div>
        <div class="menu-list stagger">
            ${menuItem('badge-check', t('verification'), t('get_verified'), "navigateTo('verification')")}
            ${menuItem('lock', t('pin_code'), t('pin_security'), "navigateTo('pin-settings')")}
            ${menuItem('wallet', t('top_deposit'), t('add_funds'), "navigateTo('deposit')")}
            ${menuItem('arrow-up-right', t('withdraw'), t('to_wallet'), "navigateTo('withdraw')")}
            ${menuItem('bar-chart-3', t('statistics'), t('detailed_info'), "navigateTo('statistics')")}
            ${menuItem('star', t('my_reputation'), t('reviews_about'), "navigateTo('my-reputation')")}
            ${menuItem('folder', t('requisites'), t('payment_methods'), "navigateTo('requisites')")}
            ${menuItem('globe', t('language'), currentUser.language === 'en' ? 'English' : 'Русский', "showLanguageModal()")}
        </div>
    </div>`);
}

// ===== DEPOSIT =====
async function renderDeposit() {
    const u = currentUser;
    renderApp(`<div class="page">${pageHeader(t('top_deposit'), true)}
        <div class="balance-card">
            <div class="balance-label">${t('current_deposit')}</div>
            <div class="balance-value">${u.deposit || 0} <span class="balance-currency">$</span></div>
        </div>
        <div class="form-group">
            <div class="form-label">${t('deposit_amount')}</div>
            <input id="deposit-amount" class="form-input" type="number" inputmode="decimal" placeholder="500" min="100">
            <div class="form-hint">${t('min_100')}</div>
        </div>
        <button class="btn btn-primary" onclick="submitDeposit()">${ic('wallet')} ${t('top_up')}</button>
    </div>`);
}

// ===== WITHDRAW =====
async function renderWithdraw() {
    const u = currentUser;
    renderApp(`<div class="page">${pageHeader(t('withdraw'), true)}
        <div class="balance-card">
            <div class="balance-label">${t('available')}</div>
            <div class="balance-value">${u.deposit || 0} <span class="balance-currency">$</span></div>
        </div>
        <div class="form-group">
            <div class="form-label">${t('withdraw_amount')}</div>
            <input id="withdraw-amount" class="form-input" type="number" inputmode="decimal" placeholder="100" min="10">
        </div>
        <div class="form-group">
            <div class="form-label">${t('wallet_address')}</div>
            <input id="withdraw-wallet" class="form-input" type="text" placeholder="T..." value="${u.withdrawal_wallet || ''}">
        </div>
        <button class="btn btn-primary" onclick="submitWithdraw()">${ic('arrow-up-right')} ${t('withdraw_btn')}</button>
    </div>`);
}

// ===== STATISTICS =====
async function renderStatistics() {
    renderApp(`<div class="page">${pageHeader(t('statistics'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const s = await api.getStats();
        renderApp(`<div class="page">${pageHeader(t('statistics'), true)}
            <div class="stat-grid stagger">
                ${statCard('file-text', s.total_deals, t('total_deals'))}
                ${statCard('loader', s.active, t('active'), 'yellow')}
                ${statCard('check-circle', s.completed, t('completed_deals'), 'green')}
                ${statCard('x-circle', s.cancelled, t('cancelled'))}
            </div>
            <div class="info-block">
                <div class="info-row"><span class="info-label">${ic('percent')} ${t('success_rate')}</span><span class="info-value">${s.success_rate}%</span></div>
                <div class="info-row"><span class="info-label">${ic('thumbs-up')} ${t('positive_rev')}</span><span class="info-value text-green">+${s.rep_positive}</span></div>
                <div class="info-row"><span class="info-label">${ic('thumbs-down')} ${t('negative_rev')}</span><span class="info-value text-red">-${s.rep_negative}</span></div>
                <div class="info-row"><span class="info-label">${ic('wallet')} ${t('deposit_label')}</span><span class="info-value">${s.deposit}$</span></div>
            </div>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== MY REPUTATION =====
async function renderMyReputation() {
    renderApp(`<div class="page">${pageHeader(t('my_reputation'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const reviews = await api.getUserReviews(currentUser.user_id);
        let h = `<div class="page">${pageHeader(t('my_reputation'), true)}`;
        if (!reviews.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('star')}</div><div class="empty-text">${t('no_reviews')}</div><div class="empty-hint">${t('reviews_after')}</div></div>`;
        } else {
            for (const r of reviews) h += reviewCard(r);
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

function reviewCard(r) {
    return `<div class="review-card">
        <div class="review-head">
            <span class="review-author">${r.reviewer_name || t('user_label')}</span>
            <span class="review-type ${r.is_positive ? 'review-positive' : 'review-negative'}">${ic(r.is_positive ? 'thumbs-up' : 'thumbs-down')} ${r.is_positive ? '+' : '−'}</span>
        </div>
        ${r.comment ? `<div class="review-text">${r.comment}</div>` : ''}
        <div class="review-date">${formatDate(r.created_at)}</div>
    </div>`;
}

// ===== REQUISITES =====
async function renderRequisites() {
    // Refresh data from server to avoid stale values
    try { currentUser = await api.getMe(); } catch(e) {}
    const u = currentUser;
    renderApp(`<div class="page">${pageHeader(t('requisites'), true)}
        <div class="form-group">
            <div class="form-label">${ic('credit-card')} ${t('card_number')}</div>
            <input id="req-card" class="form-input" type="text" inputmode="numeric" placeholder="0000 0000 0000 0000" value="${u.card_number || ''}" autocomplete="off">
        </div>
        <div class="form-group">
            <div class="form-label">${ic('diamond')} ${t('ton_wallet')}</div>
            <input id="req-ton" class="form-input" type="text" placeholder="UQ..." value="${u.ton_address || ''}" autocomplete="off">
        </div>
        <button class="btn btn-primary" onclick="saveRequisites()">${ic('check')} ${t('save')}</button>
    </div>`);
}

// ===== USERS =====
async function renderUsers() {
    renderApp(`<div class="page">${pageHeader(t('users'))}
        <div class="hero" style="padding:24px 20px">
            <div class="hero-icon">${ic('users')}</div>
            <div class="hero-title" style="font-size:16px;letter-spacing:1px">${t('users')}</div>
            <div class="hero-subtitle">${t('search_by')}</div>
        </div>
        <div class="menu-list stagger">
            ${menuItem('shield', t('garants'), t('verified_agents'), "navigateTo('garants')")}
            ${menuItem('trophy', t('top_rep'), t('best_users'), "navigateTo('top-reputation')", 'yellow')}
            ${menuItem('search', t('search'), t('search_by'), "navigateTo('search-user')", 'green')}
        </div>
    </div>`);
}

// ===== GARANTS =====
async function renderGarants() {
    renderApp(`<div class="page">${pageHeader(t('garants'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.getGarants();
        let h = `<div class="page">${pageHeader(t('garants'), true)}`;
        if (!list.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('shield')}</div><div class="empty-text">${t('no_garants')}</div></div>`;
        } else {
            for (const u of list) {
                const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
                h += userListCard(u, rep);
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

function userListCard(u, rep, rank) {
    const rankHtml = rank !== undefined ? `<div class="leader-rank ${rank === 0 ? 'gold' : rank === 1 ? 'silver' : rank === 2 ? 'bronze' : ''}">${rank + 1}</div>` : '';
    const av = rank !== undefined ? rankHtml : smallAvatar(u.full_name, null);
    return `<div class="leader-card" onclick="navigateTo('user-profile',{userId:${u.user_id}})">
        ${av}
        <div class="leader-info">
            <div class="leader-name">${u.full_name || t('user_label')}</div>
            <div class="leader-sub">@${u.username || '—'}</div>
        </div>
        <div class="leader-value ${rep >= 0 ? 'text-green' : 'text-red'}">${rep >= 0 ? '+' : ''}${rep}</div>
    </div>`;
}

// ===== TOP REPUTATION =====
async function renderTopReputation() {
    renderApp(`<div class="page">${pageHeader(t('top_rep'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.getTopReputation();
        let h = `<div class="page">${pageHeader(t('top_rep'), true)}`;
        if (!list.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('trophy')}</div><div class="empty-text">${t('empty')}</div></div>`;
        } else {
            list.forEach((u, i) => {
                const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
                h += userListCard(u, rep, i);
            });
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== SEARCH USER =====
async function renderSearchUser() {
    renderApp(`<div class="page">${pageHeader(t('search'), true)}
        <div class="form-group">
            <div class="form-label">${t('username_or_id')}</div>
            <div class="copy-field">
                <input id="search-query" class="form-input" placeholder="${t('enter_query')}" autocomplete="off">
                <button class="copy-btn" onclick="doSearchUser()">${ic('search')}</button>
            </div>
        </div>
        <div id="search-results"></div>
    </div>`);
}

async function doSearchUser() {
    const q = document.getElementById('search-query')?.value?.trim();
    if (!q) return toast(t('enter_query_err'), 'error');
    try {
        const users = await api.searchUser(q);
        const el = document.getElementById('search-results');
        if (!el) return;
        if (!users.length) {
            el.innerHTML = `<div class="empty-state" style="padding:24px"><div class="empty-text">${t('not_found')}</div></div>`;
        } else {
            el.innerHTML = users.map(u => {
                const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
                return userListCard(u, rep);
            }).join('');
        }
        if (window.lucide) lucide.createIcons();
    } catch (e) { toast(e.message, 'error'); }
}

// ===== USER PROFILE =====
async function renderUserProfile({ userId }) {
    renderApp(`<div class="page">${pageHeader(t('profile'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const u = await api.getUserProfile(userId);
        const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
        let badges = '';
        const uvl = u.verification_level;
        if (uvl && uvl !== 'none') badges += `<span class="profile-badge badge-verified">${ic('badge-check')} ${uvl.toUpperCase()}</span>`;
        if (u.is_garant) badges += `<span class="profile-badge badge-garant">${ic('shield')} ${t('garant')}</span>`;
        const os = onlineStatus(u.last_active);

        renderApp(`<div class="page">${pageHeader(t('profile'), true)}
            <div class="profile-header">
                ${avatar(u.full_name, null, 76)}
                <div class="profile-name">${u.full_name || t('user_label')}</div>
                <div class="profile-username">@${u.username || '—'}</div>
                <div class="online-status-row" style="justify-content:center;--status-color:${os.color}"><span class="status-indicator-dot" style="background:${os.color}"></span> ${os.text}</div>
                ${u.trust_status && u.trust_status !== 'clean' ? `<div class="trust-badge trust-badge-${u.trust_status}">${ic(u.trust_status === 'verified' ? 'badge-check' : u.trust_status === 'has_complaints' ? 'alert-triangle' : 'ban')} ${u.trust_status === 'verified' ? t('user_verified') : u.trust_status === 'has_complaints' ? t('user_has_complaints') : t('user_blocked_fraud')}</div>` : ''}
                ${badges ? `<div class="profile-badges">${badges}</div>` : ''}
            </div>
            <div class="stat-grid stagger">
                ${statCard('file-text', u.deals_count || 0, t('deals_count'))}
                ${statCard('trending-up', (rep >= 0 ? '+' : '') + rep, t('reputation'), 'green')}
                ${statCard('wallet', (u.deposit || 0) + '$', t('deposit_label'), 'purple')}
                ${statCard('check-circle', u.successful_deals || 0, t('successful'), 'yellow')}
            </div>
            <div class="menu-list stagger">
                ${menuItem('star', t('review'), t('all_reviews'), "navigateTo('user-reviews',{userId:" + userId + "})", 'yellow')}
            </div>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== USER REVIEWS =====
async function renderUserReviews({ userId }) {
    renderApp(`<div class="page">${pageHeader(t('review'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const reviews = await api.getUserReviews(userId);
        let h = `<div class="page">${pageHeader(t('review'), true)}`;
        if (!reviews.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('star')}</div><div class="empty-text">${t('no_reviews')}</div></div>`;
        } else {
            for (const r of reviews) h += reviewCard(r);
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== MORE =====
async function renderMore() {
    let h = `<div class="page">${pageHeader(t('more'))}
        <div class="menu-list stagger">
            ${menuItem('headphones', t('support'), t('ask_help'), "navigateTo('support')")}
            ${menuItem('share-2', t('referrals'), t('invite_earn'), "navigateTo('referrals')", 'green')}
            <div class="menu-item" onclick="if(tg)tg.openTelegramLink('https://t.me/dealpro_channel');else window.open('https://t.me/dealpro_channel','_blank')">
                <div class="menu-icon blue">${ic('megaphone')}</div>
                <div class="menu-body"><div class="menu-title">${t('channel') || 'Наш канал'}</div><div class="menu-desc">@dealpro_channel</div></div>
                <div class="menu-arrow">${ic('chevron-right')}</div>
            </div>
            ${menuItem('globe', t('language'), t('select_lang') || 'Выберите язык', "showLangSelectPage()")}`;

    if (currentUser.is_garant) h += menuItem('shield', t('garant_panel'), t('manage_deals'), "navigateTo('garant-panel')", 'purple');
    if (currentUser.is_arbitrator) h += menuItem('scale', t('arbitration'), t('resolve_disputes'), "navigateTo('arbitration')", 'red');
    if (currentUser.is_admin) h += menuItem('crown', t('admin_panel'), t('manage_service'), "navigateTo('admin')", 'yellow');
    h += `</div></div>`;
    renderApp(h);
}

// ===== SUPPORT =====
async function renderSupport() {
    renderApp(`<div class="page">${pageHeader(t('support'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const tickets = await api.getTickets();
        let h = `<div class="page">${pageHeader(t('support'), true)}`;
        h += `<button class="btn btn-primary mb-16" onclick="navigateTo('create-ticket')">${ic('plus')} ${t('new_ticket')}</button>`;
        if (!tickets.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('headphones')}</div><div class="empty-text">${t('no_tickets')}</div><div class="empty-hint">${t('create_request')}</div></div>`;
        } else {
            for (const tk of tickets) {
                const open = tk.status === 'open';
                h += `<div class="card" onclick="navigateTo('ticket-detail',{ticketId:${tk.id}})">
                    <div class="card-top"><span class="card-id">${t('ticket')} #${tk.id}</span><span class="status-badge ${open ? 'badge-progress' : 'badge-cancelled'}">${ic(open ? 'circle' : 'check-circle')} ${open ? t('opened') : t('closed')}</span></div>
                    <div class="card-row">${tk.subject}</div>
                    <div class="card-row" style="font-size:12px;color:var(--muted)">${formatDate(tk.created_at)}</div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== CREATE TICKET =====
async function renderCreateTicket() {
    renderApp(`<div class="page">${pageHeader(t('new_ticket'), true)}
        <div class="form-group">
            <div class="form-label">${t('subject')}</div>
            <input id="ticket-subj" class="form-input" placeholder="${t('describe_problem')}" autocomplete="off">
        </div>
        <div class="form-group">
            <div class="form-label">${t('message')}</div>
            <textarea id="ticket-msg" class="form-textarea" placeholder="${t('describe_more')}"></textarea>
        </div>
        <button class="btn btn-primary" onclick="submitTicket()">${ic('send')} ${t('send')}</button>
    </div>`);
}

// ===== TICKET DETAIL =====
async function renderTicketDetail({ ticketId }) {
    renderApp(`<div class="page">${pageHeader(t('ticket'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const tk = await api.getTicket(ticketId);
        let h = `<div class="page">${pageHeader(t('ticket') + ' #' + tk.id, true)}`;
        const open = tk.status === 'open';
        h += `<div class="info-block">
            <div class="info-row"><span class="info-label">${t('subject')}</span><span class="info-value">${tk.subject}</span></div>
            <div class="info-row"><span class="info-label">${t('status')}</span><span class="info-value"><span class="status-badge ${open ? 'badge-progress' : 'badge-cancelled'}">${open ? t('opened') : t('closed')}</span></span></div>
        </div>`;

        h += `<div class="chat-messages">`;
        if (tk.messages) {
            for (const msg of tk.messages) {
                const isUser = msg.sender_id === currentUser.user_id;
                h += `<div class="chat-msg ${isUser ? 'user-msg' : 'admin-msg'}">
                    <div class="chat-msg-author">${isUser ? t('you') : t('support')}</div>
                    <div>${msg.message}</div>
                    <div class="chat-msg-time">${formatDate(msg.created_at)}</div>
                </div>`;
            }
        }
        h += `</div>`;

        if (open) {
            h += `<div class="chat-reply">
                <input id="ticket-reply" class="form-input" placeholder="${t('write_msg')}" autocomplete="off">
                <button class="btn btn-primary btn-sm" onclick="submitTicketReply(${tk.id})">${ic('send')}</button>
            </div>`;
        }
        if (currentUser.is_admin && open) {
            h += `<button class="btn btn-danger btn-sm mt-12" onclick="closeTicket(${tk.id})">${ic('x')} ${t('close_ticket')}</button>`;
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== REFERRALS =====
async function renderReferrals() {
    renderApp(`<div class="page">${pageHeader(t('referrals'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const r = await api.getReferrals();
        const bot = currentUser.bot_username;
        const link = bot ? `https://t.me/${bot}?start=ref_${currentUser.user_id}` : '—';
        const levelNames = { bronze: t('bronze'), silver: t('silver'), gold: t('gold'), vip: t('vip') };
        const levelColors = { bronze: '#cd7f32', silver: '#c0c0c0', gold: 'var(--yellow)', vip: 'var(--blue)' };
        const col = levelColors[r.level] || 'var(--blue)';
        const bonusPct = r.bonus_percent ?? r.bonus ?? 0;

        renderApp(`<div class="page">${pageHeader(t('referrals'), true)}
            <div class="ref-level-card">
                <div class="ref-level-icon" style="background:${col}20;color:${col}">${ic('award')}</div>
                <div class="ref-level-name">${levelNames[r.level] || r.level}</div>
                <div class="ref-level-bonus">${bonusPct}% ${t('bonus_per_deal')}</div>
            </div>
            <div class="stat-grid stagger">
                ${statCard('users', r.total || 0, t('invited'))}
                ${statCard('check-circle', r.active || 0, t('active_refs'), 'green')}
            </div>
            <div class="section-label">${ic('link')} ${t('ref_link')}</div>
            <div class="copy-field mb-16">
                <input class="form-input" id="ref-link" value="${link}" readonly>
                <button class="copy-btn" onclick="copyRefLink()">${ic('copy')}</button>
            </div>
            <div class="menu-list stagger">
                ${menuItem('trophy', t('leaders'), t('leaders_table'), "navigateTo('referral-leaders')", 'yellow')}
            </div>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== REFERRAL LEADERS =====
async function renderReferralLeaders() {
    renderApp(`<div class="page">${pageHeader(t('leaders'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.getReferralLeaderboard();
        let h = `<div class="page">${pageHeader(t('leaders'), true)}`;
        if (!list.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('trophy')}</div><div class="empty-text">${t('empty')}</div></div>`;
        } else {
            list.forEach((u, i) => {
                const rankCls = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
                h += `<div class="leader-card">
                    <div class="leader-rank ${rankCls}">${i + 1}</div>
                    <div class="leader-info">
                        <div class="leader-name">${u.full_name || t('user_label')}</div>
                        <div class="leader-sub">${u.active_refs || 0} ${t('ref_count')}</div>
                    </div>
                    <div class="leader-value">${u.active_refs || 0}</div>
                </div>`;
            });
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== VERIFICATION =====
async function renderVerification() {
    renderApp(`<div class="page">${pageHeader(t('verification'), true)}<div class="skeleton" style="height:300px"></div></div>`);
    try {
        const v = await api.getVerification();
        const s = v.stats;
        const isVerified = v.level && v.level !== 'none';
        const statusText = isVerified ? `${ic('badge-check')} ${t('verified_badge')} — ${v.level.toUpperCase()} SELLER` : `${ic('x-circle')} ${t('not_verified')}`;

        let h = `<div class="page">${pageHeader(t('verification'), true)}`;

        // User stats card
        h += `<div class="verif-stats-card">
            <div class="verif-stats-title">${ic('bar-chart-3')} ${t('your_stats')}</div>
            <div class="verif-stats-grid">
                <div class="verif-stat-row"><span class="verif-stat-label">${t('success_deals')}</span><span class="verif-stat-value">${s.successful_deals}</span></div>
                <div class="verif-stat-row"><span class="verif-stat-label">${t('total_turnover')}</span><span class="verif-stat-value">${s.turnover} $</span></div>
                <div class="verif-stat-row"><span class="verif-stat-label">${t('disputes_count')}</span><span class="verif-stat-value">${s.disputes}</span></div>
                <div class="verif-stat-row"><span class="verif-stat-label">${t('deposit_balance')}</span><span class="verif-stat-value">${s.deposit} $</span></div>
                <div class="verif-stat-row"><span class="verif-stat-label">${t('verif_status')}</span><span class="verif-stat-value">${statusText}</span></div>
            </div>
        </div>`;

        // Pending request notice
        if (v.pending) {
            h += `<div class="verif-pending">${ic('clock')} ${t('pending_request')} — ${v.pending.level.toUpperCase()} SELLER (${v.pending.type === 'purchase' ? t('purchase_btn') : t('apply_btn')})</div>`;
        }

        // Benefits
        h += `<div class="verif-section">
            <div class="verif-section-title">${ic('sparkles')} ${t('what_gives')}</div>
            <div class="verif-benefits">
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('trust_buyers')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('badge_near_nick')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('less_fee')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('fast_payouts')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('fake_protect')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('check-circle')}</span>${t('big_deals')}</div>
            </div>
        </div>`;

        // Protection system
        h += `<div class="verif-section">
            <div class="verif-section-title">${ic('shield')} ${t('protection_sys')}</div>
            <div class="verif-benefits">
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('shield-check')}</span>${t('protect_1')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('shield-check')}</span>${t('protect_2')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('shield-check')}</span>${t('protect_3')}</div>
                <div class="verif-benefit"><span class="verif-benefit-icon">${ic('shield-check')}</span>${t('protect_4')}</div>
            </div>
        </div>`;

        // Available statuses
        h += `<div class="verif-section">
            <div class="verif-section-title">${ic('award')} ${t('available_statuses')}</div>`;

        // BASIC SELLER
        h += verifTierCard('basic', 'BASIC SELLER', '5%', [
            t('basic_desc'), t('basic_tg'), t('basic_deposit'), t('basic_limit')
        ], v.level, v.pending);

        // TRUSTED SELLER
        h += verifTierCard('trusted', 'TRUSTED SELLER', '4%', [
            t('trusted_desc'), t('trusted_video'), t('trusted_deals'), t('trusted_deposit'), t('trusted_priority')
        ], v.level, v.pending);

        // PREMIUM SELLER
        h += verifTierCard('premium', 'PREMIUM SELLER', '3%', [
            t('premium_desc'), t('premium_deals'), t('premium_turnover'), t('premium_deposit'), t('premium_manager'), t('premium_support')
        ], v.level, v.pending);

        h += `</div></div>`;
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

function verifTierCard(level, title, fee, reqs, currentLevel, pendingReq) {
    const isActive = currentLevel === level;
    const hasPending = pendingReq && pendingReq.status === 'pending';
    let h = `<div class="verif-tier ${isActive ? 'verif-tier-active' : ''}">
        <div class="verif-tier-header">
            <div class="verif-tier-title">${title}</div>
            ${isActive ? `<span class="verif-tier-badge">${t('current_level')}</span>` : ''}
        </div>
        <div class="verif-tier-reqs">`;
    for (const r of reqs) {
        h += `<div class="verif-tier-req">${ic('check')} ${r}</div>`;
    }
    h += `</div>
        <div class="verif-tier-fee">${t('fee_label')}: <strong>${fee}</strong></div>`;
    if (!isActive && !hasPending) {
        h += `<div class="verif-tier-actions">
            <button class="btn btn-outline" onclick="submitVerifApply('${level}')">${ic('send')} ${t('apply_btn')}</button>
            <button class="btn btn-primary" onclick="navigateTo('purchase-verification',{level:'${level}'})">${ic('shopping-cart')} ${t('purchase_btn')}</button>
        </div>`;
    }
    h += `</div>`;
    return h;
}

async function submitVerifApply(level) {
    try {
        await api.applyVerification(level);
        toast(t('apply_sent'), 'success');
        renderVerification();
    } catch (e) { toast(e.message, 'error'); }
}

// ===== PURCHASE VERIFICATION =====
async function renderPurchaseVerification({ level }) {
    const levelName = level.toUpperCase() + ' SELLER';
    const prices = { basic: 50, trusted: 100, premium: 200 };
    const price = prices[level] || 50;
    const deposit = currentUser.deposit || 0;
    const canPay = deposit >= price;
    let h = `<div class="page">${pageHeader(t('purchase_verif'), true)}
        <div class="verif-purchase-card">
            <div class="verif-purchase-title">${ic('badge-check')} ${levelName}</div>
            <div class="verif-purchase-sub">${t('deposit_payment')}</div>
            <div class="info-block" style="margin:16px 0">
                <div class="info-row"><span class="info-label">${t('price')}</span><span class="info-value">${price}$</span></div>
                <div class="info-row"><span class="info-label">${t('your_deposit')}</span><span class="info-value ${canPay ? 'text-green' : 'text-red'}">${deposit}$</span></div>
            </div>
            <div class="info-card warn mb-16">
                <div class="info-card-icon">${ic('info')}</div>
                <div class="info-card-text">${t('deposit_payment_hint')}</div>
            </div>
            <button class="btn btn-primary" onclick="submitVerifPurchase('${level}', ${price})" ${!canPay ? 'disabled' : ''}>${ic('wallet')} ${t('pay_from_deposit')}</button>
        </div>
    </div>`;
    renderApp(h);
}

function selectVerifCurrency(el, currency) {
    document.querySelectorAll('.verif-currency-option').forEach(e => e.classList.remove('active'));
    el.classList.add('active');
    window._verifCurrency = currency;
    if (window.lucide) lucide.createIcons();
}

async function submitVerifPurchase(level, price) {
    try {
        await api.purchaseVerification(level, 'DEPOSIT', price);
        await loadUser();
        toast(t('purchase_sent'), 'success');
        navigateTo('verification');
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN VERIFICATIONS =====
async function renderAdminVerifications() {
    renderApp(`<div class="page">${pageHeader(t('verifications'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const reqs = await api.adminVerifications();
        let h = `<div class="page">${pageHeader(t('verifications'), true)}`;
        if (!reqs.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('badge-check')}</div><div class="empty-text">${t('no_requests')}</div></div>`;
        } else {
            for (const r of reqs) {
                h += `<div class="card">
                    <div class="card-top"><span class="card-id">@${r.username || 'N/A'}</span><span class="status-badge badge-pending">${ic('clock')} ${r.type === 'purchase' ? t('purchase_btn') : t('apply_btn')}</span></div>
                    <div class="card-row">${ic('award')} ${t('level_label')}: <strong>${r.level.toUpperCase()} SELLER</strong></div>
                    ${r.currency ? `<div class="card-row">${ic('credit-card')} ${t('currency_label')}: ${r.currency}</div>` : ''}
                    <div class="card-row">${ic('file-text')} ${t('deals_count')}: ${r.deals_count || 0} | ${t('successful')}: ${r.successful_deals || 0}</div>
                    <div class="card-row">${ic('wallet')} ${t('deposit_label')}: ${r.deposit || 0}$</div>
                    <div class="card-actions mt-8">
                        <button class="btn btn-primary btn-sm" onclick="adminProcessVerif(${r.id}, 'approved')">${ic('check')} ${t('approve')}</button>
                        <button class="btn btn-outline btn-sm" onclick="adminProcessVerif(${r.id}, 'rejected')">${ic('x')} ${t('reject')}</button>
                    </div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

async function adminProcessVerif(id, status) {
    try {
        await api.adminProcessVerification(id, { status });
        toast(status === 'approved' ? t('approved') : t('rejected'), 'success');
        renderAdminVerifications();
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN NEWS =====
async function renderAdminNews() {
    renderApp(`<div class="page">${pageHeader(t('news'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const news = await api.adminGetNews();
        let h = `<div class="page">${pageHeader(t('news'), true)}`;
        h += `<button class="btn btn-primary mb-16" onclick="navigateTo('admin-news-edit',{newsId:0})">${ic('plus')} ${t('add_news')}</button>`;
        if (!news.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('megaphone')}</div><div class="empty-text">${t('no_news')}</div></div>`;
        } else {
            for (const n of news) {
                h += `<div class="card">
                    <div class="card-top"><span class="card-id">${ic('newspaper')} ${n.title}</span><span class="status-badge ${n.is_active ? 'badge-completed' : 'badge-cancelled'}">${n.is_active ? ic('check') : ic('x')}</span></div>
                    <div class="card-row text-muted fs-13">${n.content.substring(0, 80)}${n.content.length > 80 ? '...' : ''}</div>
                    <div class="card-actions mt-8">
                        <button class="btn btn-outline btn-sm" onclick="navigateTo('admin-news-edit',{newsId:${n.id}})">${ic('edit')} ${t('edit_news')}</button>
                        <button class="btn btn-outline btn-sm" onclick="toggleNewsItem(${n.id})">${ic(n.is_active ? 'eye-off' : 'eye')}</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteNewsItem(${n.id})">${ic('trash-2')}</button>
                    </div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

async function renderAdminNewsEdit({ newsId }) {
    newsId = parseInt(newsId) || 0;
    let title = '', content = '', emoji = '', imageUrl = '';
    if (newsId > 0) {
        try {
            const news = await api.adminGetNews();
            const item = news.find(n => n.id === newsId);
            if (item) { title = item.title; content = item.content; emoji = item.emoji; imageUrl = item.image_url || ''; }
        } catch(e) {}
    }
    renderApp(`<div class="page">${pageHeader(newsId > 0 ? t('edit_news') : t('add_news'), true)}
        <div class="form-group">
            <div class="form-label">${t('news_emoji')}</div>
            <input id="news-emoji" class="form-input" value="${emoji}" maxlength="4" style="width:60px;text-align:center;font-size:24px">
        </div>
        <div class="form-group">
            <div class="form-label">${t('news_title')}</div>
            <input id="news-title" class="form-input" value="${title}" placeholder="${t('news_title')}">
        </div>
        <div class="form-group">
            <div class="form-label">${t('news_image')} (URL)</div>
            <input id="news-image" class="form-input" value="${imageUrl}" placeholder="https://...">
        </div>
        <div class="form-group">
            <div class="form-label">${t('news_content')}</div>
            <textarea id="news-content" class="form-textarea" placeholder="${t('news_content')}" rows="4">${content}</textarea>
        </div>
        <button class="btn btn-primary" onclick="saveNewsItem(${newsId})">${ic('save')} ${t('save')}</button>
    </div>`);
}

async function saveNewsItem(newsId) {
    newsId = parseInt(newsId) || 0;
    const title = document.getElementById('news-title')?.value?.trim();
    const content = document.getElementById('news-content')?.value?.trim();
    const emoji = document.getElementById('news-emoji')?.value?.trim() || '';
    const image_url = document.getElementById('news-image')?.value?.trim() || '';
    if (!title) return toast(t('enter_subj'), 'error');
    if (!content) return toast(t('enter_msg'), 'error');
    try {
        if (newsId > 0) {
            await api.adminUpdateNews(newsId, { title, content, emoji, image_url });
        } else {
            await api.adminCreateNews({ title, content, emoji, image_url });
        }
        toast(t('news_saved'), 'success');
        navigateTo('admin-news');
    } catch (e) { toast(e.message, 'error'); }
}

async function toggleNewsItem(id) {
    try {
        await api.adminToggleNews(id);
        renderAdminNews();
    } catch (e) { toast(e.message, 'error'); }
}

async function deleteNewsItem(id) {
    try {
        await api.adminDeleteNews(id);
        toast(t('news_deleted'), 'success');
        renderAdminNews();
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN USERS =====
async function renderAdminUsers() {
    renderApp(`<div class="page">${pageHeader(t('service_users'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const users = await api.adminGetUsers();
        let h = `<div class="page">${pageHeader(t('service_users'), true)}`;
        h += `<div class="section-label">${ic('users')} ${t('all_users')} (${users.length})</div>`;
        for (const u of users) {
            const rep = (u.reputation_positive || 0) - (u.reputation_negative || 0);
            const os = onlineStatus(u.last_active);
            h += `<div class="card" onclick="navigateTo('user-profile',{userId:${u.user_id}})">
                <div class="card-top">
                    <span class="card-id" style="display:flex;align-items:center;gap:6px">
                        <span class="status-dot-sm status-dot-${os.dot}"></span>
                        ${u.full_name || u.username || 'User #' + u.user_id}
                    </span>
                    ${u.is_banned ? '<span class="status-badge badge-cancelled">BAN</span>' : ''}
                    ${u.is_arbitrator ? `<span class="status-badge badge-arbitrator">${ic('scale')}</span>` : ''}
                    ${u.is_garant ? `<span class="status-badge badge-garant">${ic('shield')}</span>` : ''}
                </div>
                <div class="card-row">${ic('at-sign')} @${u.username || '—'} <span class="text-muted">• ID: ${u.user_id}</span></div>
                <div class="card-row">${ic('trending-up')} ${rep >= 0 ? '+' : ''}${rep} <span class="text-muted">•</span> ${ic('file-text')} ${u.deals_count || 0} <span class="text-muted">•</span> ${ic('wallet')} ${u.deposit || 0}$</div>
                <div class="card-row text-muted fs-12">${os.text} • ${t('date')}: ${formatDate(u.created_at)}</div>
            </div>`;
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== NEWS DETAIL =====
async function renderNewsDetail({ newsId }) {
    renderApp(`<div class="page">${pageHeader(t('news'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const allNews = await api.getNews();
        const n = allNews.find(x => x.id === parseInt(newsId));
        if (!n) return renderApp(`<div class="page">${pageHeader(t('news'), true)}<div class="empty-state"><div class="empty-text">${t('not_found')}</div></div></div>`);
        renderApp(`<div class="page">${pageHeader(t('news'), true)}
            ${n.image_url ? `<img class="news-detail-img" src="${n.image_url}" alt="">` : ''}
            <div class="news-detail-header">
                <span class="news-detail-emoji">${ic('newspaper')}</span>
                <h2 class="news-detail-title">${n.title}</h2>
            </div>
            <div class="news-detail-meta">
                ${ic('calendar')} ${formatDate(n.created_at)}
                ${n.author_name ? ` • ${ic('user')} ${n.author_name}` : ''}
            </div>
            <div class="news-detail-content">${n.content.replace(/\\n/g, '<br>')}</div>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== PIN SETTINGS =====
async function renderPinSettings() {
    const hasPin = currentUser.has_pin;
    renderApp(`<div class="page">${pageHeader(t('pin_code'), true)}
        <div class="pin-info-card">
            <div class="pin-info-icon">${ic('lock')}</div>
            <div class="pin-info-text">${t('pin_security')}</div>
            <div class="pin-info-status ${hasPin ? 'pin-on' : 'pin-off'}">${hasPin ? ic('check-circle') + ' ' + t('online') : ic('x-circle') + ' ' + t('offline')}</div>
        </div>
        ${hasPin ? `
            <button class="btn btn-primary mb-16" onclick="showPinSetup(true)">${ic('edit')} ${t('change_pin')}</button>
            <button class="btn btn-danger" onclick="removePin()">${ic('x')} ${t('remove_pin')}</button>
        ` : `
            <button class="btn btn-primary" onclick="showPinSetup(false)">${ic('lock')} ${t('set_pin')}</button>
        `}
    </div>`);
}

function showPinSetup(isChange) {
    window._pinDigits = '';
    renderApp(`<div class="pin-screen">
        <div class="pin-lock-icon"><div class="pin-icon-bg">${ic('lock')}</div></div>
        <div class="pin-dots" id="pin-dots">
            <div class="pin-dot"></div><div class="pin-dot"></div><div class="pin-dot"></div><div class="pin-dot"></div>
        </div>
        <div class="pin-label">${isChange ? t('enter_pin').split('\\n')[0] : t('set_pin')}</div>
        <div class="pin-pad">
            ${[1,2,3,4,5,6,7,8,9].map(n => `<div class="pin-key" onclick="pinInput(${n})">${n}</div>`).join('')}
            <div class="pin-key pin-key-empty"></div>
            <div class="pin-key" onclick="pinInput(0)">0</div>
            <div class="pin-key" onclick="pinBackspace()">${ic('delete')}</div>
        </div>
    </div>`);
    if (window.lucide) lucide.createIcons();
}

function showPinLock() {
    window._pinDigits = '';
    document.getElementById('app').innerHTML = `<div class="pin-screen">
        <div class="pin-lock-icon"><div class="pin-icon-bg">${ic('lock')}</div></div>
        <div class="pin-dots" id="pin-dots">
            <div class="pin-dot"></div><div class="pin-dot"></div><div class="pin-dot"></div><div class="pin-dot"></div>
        </div>
        <div class="pin-label">${t('enter_pin')}</div>
        <div class="pin-pad">
            ${[1,2,3,4,5,6,7,8,9].map(n => `<div class="pin-key" onclick="pinVerify(${n})">${n}</div>`).join('')}
            <div class="pin-key pin-key-empty"></div>
            <div class="pin-key" onclick="pinVerify(0)">0</div>
            <div class="pin-key" onclick="pinVerifyBackspace()">${ic('delete')}</div>
        </div>
    </div>`;
    if (window.lucide) lucide.createIcons();
}

function pinInput(n) {
    if (window._pinDigits.length >= 4) return;
    window._pinDigits += n;
    updatePinDots();
    if (window._pinDigits.length === 4) {
        setTimeout(async () => {
            try {
                await api.setPin({ pin: window._pinDigits });
                currentUser.has_pin = true;
                toast(t('pin_set'), 'success');
                navigateTo('pin-settings');
            } catch(e) { toast(e.message, 'error'); window._pinDigits = ''; updatePinDots(); }
        }, 200);
    }
}

function pinBackspace() {
    window._pinDigits = window._pinDigits.slice(0, -1);
    updatePinDots();
}

function pinVerify(n) {
    if (window._pinDigits.length >= 4) return;
    window._pinDigits += n;
    updatePinDots();
    if (window._pinDigits.length === 4) {
        setTimeout(async () => {
            try {
                await api.verifyPin({ pin: window._pinDigits });
                sessionStorage.setItem('pin_verified', '1');
                showNav();
                if (currentUser.start_param && currentUser.start_param.startsWith('deal_')) {
                    const dealId = parseInt(currentUser.start_param.split('_')[1]);
                    navigateTo('deal-detail', { dealId });
                } else {
                    navigateTo('home');
                }
            } catch(e) {
                toast(t('wrong_pin'), 'error');
                window._pinDigits = '';
                updatePinDots();
                document.getElementById('pin-dots')?.classList.add('pin-shake');
                setTimeout(() => document.getElementById('pin-dots')?.classList.remove('pin-shake'), 500);
            }
        }, 200);
    }
}

function pinVerifyBackspace() {
    window._pinDigits = window._pinDigits.slice(0, -1);
    updatePinDots();
}

function updatePinDots() {
    const dots = document.querySelectorAll('.pin-dot');
    dots.forEach((dot, i) => dot.classList.toggle('filled', i < window._pinDigits.length));
}

async function removePin() {
    try {
        await api.setPin({ pin: '' });
        currentUser.has_pin = false;
        sessionStorage.removeItem('pin_verified');
        toast(t('pin_removed'), 'success');
        renderPinSettings();
    } catch(e) { toast(e.message, 'error'); }
}

// ===== GARANT PANEL =====
async function renderGarantPanel() {
    renderApp(`<div class="page">${pageHeader(t('garant_panel'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const [pending, my] = await Promise.all([api.garantPendingDeals(), api.garantMyDeals()]);
        let h = `<div class="page">${pageHeader(t('garant_panel'), true)}`;
        h += `<div class="section-label">${t('waiting_garant')} (${pending.length})</div>`;
        if (!pending.length) {
            h += `<div class="empty-state" style="padding:20px"><div class="empty-text">${t('no_waiting')}</div></div>`;
        } else {
            for (const d of pending) {
                h += `<div class="card">
                    <div class="card-top"><span class="card-id">${t('deal')} #${d.id}</span>${statusBadge(d.status)}</div>
                    <div class="card-amount">${d.amount}${currencySymbol(d.payment_type)}</div>
                    <div class="btn-group"><button class="btn btn-primary btn-sm" onclick="takeDeal(${d.id})">${ic('shield')} ${t('take')}</button></div>
                </div>`;
            }
        }
        h += `<div class="section-label mt-16">${t('my_garant_deals')} (${my.length})</div>`;
        if (!my.length) {
            h += `<div class="empty-state" style="padding:20px"><div class="empty-text">${t('no_active')}</div></div>`;
        } else {
            for (const d of my) {
                h += `<div class="card" onclick="navigateTo('deal-detail',{dealId:${d.id}})">
                    <div class="card-top"><span class="card-id">${t('deal')} #${d.id}</span>${statusBadge(d.status)}</div>
                    <div class="card-amount">${d.amount}${currencySymbol(d.payment_type)}</div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN =====
// ===== ARBITRATION PANEL =====
async function renderArbitration() {
    renderApp(`<div class="page">${pageHeader(t('arbitration'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.adminGetDisputes();
        const open = list.filter(d => d.status === 'open');
        const resolved = list.filter(d => d.status !== 'open');
        let h = `<div class="page">${pageHeader(t('arbitration'), true)}
            <div class="admin-stat-row">
                <div class="admin-stat"><div class="admin-stat-value">${list.length}</div><div class="admin-stat-label">${t('total')}</div></div>
                <div class="admin-stat"><div class="admin-stat-value">${open.length}</div><div class="admin-stat-label">${t('open')}</div></div>
                <div class="admin-stat"><div class="admin-stat-value">${resolved.length}</div><div class="admin-stat-label">${t('resolved')}</div></div>
            </div>`;
        if (!open.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('check-circle')}</div><div class="empty-text">${t('no_disputes')}</div></div>`;
        } else {
            h += `<div class="section-label">${ic('alert-triangle')} ${t('open')} (${open.length})</div>`;
            for (const d of open) {
                h += `<div class="card" style="cursor:default">
                    <div class="card-top">
                        <span class="card-id">${t('deal')} #${d.deal_id}</span>
                        <span class="status-badge badge-cancelled">OPEN</span>
                    </div>
                    <div class="card-row">${ic('user')} ${d.full_name || d.username || 'ID: ' + d.user_id}</div>
                    <div style="font-size:14px;color:var(--text);margin:8px 0;line-height:1.5">${d.details || ''}</div>
                    ${d.photo_url ? `<img src="${d.photo_url}" style="max-width:100%;border-radius:var(--r-xs);margin-bottom:8px">` : ''}
                    <div class="card-row">${ic('clock')} ${formatDate(d.created_at)}</div>
                    <div class="btn-group">
                        <button class="btn btn-success btn-sm" onclick="resolveDispute(${d.id},'arbitration')">${ic('check')} ${t('resolved')}</button>
                    </div>
                </div>`;
            }
        }
        if (resolved.length) {
            h += `<div class="section-label mt-16">${ic('check-circle')} ${t('resolved')} (${resolved.length})</div>`;
            for (const d of resolved.slice(0, 10)) {
                h += `<div class="card" style="cursor:default;opacity:.7">
                    <div class="card-top">
                        <span class="card-id">${t('deal')} #${d.deal_id}</span>
                        <span class="status-badge badge-completed">RESOLVED</span>
                    </div>
                    <div class="card-row">${ic('user')} ${d.full_name || d.username || 'ID: ' + d.user_id}</div>
                    <div class="card-row">${ic('clock')} ${formatDate(d.created_at)}</div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

async function renderAdmin() {
    renderApp(`<div class="page">${pageHeader(t('admin_panel'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const s = await api.adminStats();
        renderApp(`<div class="page">${pageHeader(t('admin_panel'), true)}
            <div class="admin-stat-row">
                <div class="admin-stat"><div class="admin-stat-value">${s.total_users || 0}</div><div class="admin-stat-label">${t('users_label')}</div></div>
                <div class="admin-stat"><div class="admin-stat-value">${s.total_deals || 0}</div><div class="admin-stat-label">${t('deals_label')}</div></div>
                <div class="admin-stat"><div class="admin-stat-value">${s.active_deals || 0}</div><div class="admin-stat-label">${t('active_label')}</div></div>
            </div>
            <div class="menu-list">
                ${menuItem('file-text', t('deals'), t('manage_deals'), "navigateTo('admin-deals')")}
                ${menuItem('users', t('service_users'), t('all_users'), "navigateTo('admin-users')", 'purple')}
                ${menuItem('headphones', t('tickets'), t('support_req'), "navigateTo('admin-tickets')", 'yellow')}
                ${menuItem('badge-check', t('verifications'), t('verif_requests'), "navigateTo('admin-verifications')", 'green')}
                ${menuItem('megaphone', t('news'), t('manage_news'), "navigateTo('admin-news')", 'yellow')}
                ${menuItem('arrow-up-right', t('withdrawals'), t('withdrawal_req'), "navigateTo('admin-withdrawals')", 'green')}
                ${menuItem('alert-triangle', t('disputes'), t('dispute_requests'), "navigateTo('admin-disputes')", 'red')}
                ${menuItem('zap', t('boost'), t('boost_params'), "navigateTo('admin-boost')", 'purple')}
                ${menuItem('settings', t('settings'), t('bot_settings'), "navigateTo('admin-settings')")}
            </div>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN DEALS =====
async function renderAdminDeals() {
    renderApp(`<div class="page">${pageHeader(t('deals'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const [pending, waiting, my] = await Promise.all([
            api.adminPendingDeals(), api.adminWaitingPartner(), api.adminMyDeals()
        ]);
        let h = `<div class="page">${pageHeader(t('manage_deals_full'), true)}`;
        h += dealSection(t('waiting_assign'), pending, true);
        h += dealSection(t('waiting_partner'), waiting, false);
        h += dealSection(t('my'), my, false);
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

function dealSection(title, deals, showTake) {
    let h = `<div class="section-label mt-16">${title} (${deals.length})</div>`;
    if (!deals.length) return h + `<div class="empty-state" style="padding:16px"><div class="empty-text">${t('no_deals_section')}</div></div>`;
    for (const d of deals) {
        h += `<div class="card" onclick="navigateTo('deal-detail',{dealId:${d.id}})">
            <div class="card-top"><span class="card-id">${t('deal')} #${d.id}</span>${statusBadge(d.status)}</div>
            <div class="card-amount">${d.amount}${currencySymbol(d.payment_type)}</div>
            ${showTake ? `<div class="btn-group"><button class="btn btn-primary btn-sm" onclick="event.stopPropagation();takeDeal(${d.id})">${ic('shield')} ${t('assign')}</button></div>` : ''}
        </div>`;
    }
    return h;
}

// ===== ADMIN TICKETS =====
async function renderAdminTickets() {
    renderApp(`<div class="page">${pageHeader(t('tickets'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const tickets = await api.adminTickets();
        let h = `<div class="page">${pageHeader(t('tickets'), true)}`;
        if (!tickets.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('headphones')}</div><div class="empty-text">${t('no_open_tickets')}</div></div>`;
        } else {
            for (const tk of tickets) {
                h += `<div class="card" onclick="navigateTo('ticket-detail',{ticketId:${tk.id}})">
                    <div class="card-top"><span class="card-id">${t('ticket')} #${tk.id}</span><span class="status-badge badge-progress">${ic('circle')} ${t('opened')}</span></div>
                    <div class="card-row">${tk.subject}</div>
                    <div class="card-row" style="color:var(--muted);font-size:12px">${t('from_label')}: ${tk.username || tk.user_id}</div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN WITHDRAWALS =====
async function renderAdminWithdrawals() {
    renderApp(`<div class="page">${pageHeader(t('withdrawals'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const wds = await api.adminWithdrawals();
        let h = `<div class="page">${pageHeader(t('withdrawal_req'), true)}`;
        if (!wds.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('arrow-up-right')}</div><div class="empty-text">${t('no_requests')}</div></div>`;
        } else {
            for (const w of wds) {
                h += `<div class="card">
                    <div class="card-top"><span class="card-id">#${w.id}</span><span class="card-amount">${w.amount}$</span></div>
                    <div class="card-row">${ic('user')} ${w.username || w.user_id}</div>
                    <div class="card-row">${ic('wallet')} ${w.wallet_address}</div>
                    <div class="btn-group">
                        <button class="btn btn-success btn-sm" onclick="confirmWithdrawal(${w.id})">${ic('check')} ${t('approve')}</button>
                        <button class="btn btn-danger btn-sm" onclick="rejectWithdrawal(${w.id})">${ic('x')} ${t('reject')}</button>
                    </div>
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN BOOST =====
async function renderAdminBoost() {
    renderApp(`<div class="page">${pageHeader(t('boost'), true)}
        <div class="form-group">
            <div class="form-label">${t('user_id')}</div>
            <input id="boost-uid" class="form-input" type="number" inputmode="numeric" placeholder="123456789" autocomplete="off">
        </div>
        <div class="section-label mt-16">${t('parameters')}</div>
        <div class="menu-list">
            ${menuItem('wallet', t('deposit_label'), t('add_funds_boost'), 'showBoostDeposit()')}
            ${menuItem('trending-up', t('reputation'), t('change_rep'), 'showBoostReputation()', 'green')}
            ${menuItem('file-text', t('deals'), t('boost_deals'), 'showBoostDeals()', 'purple')}
            ${menuItem('star', t('review'), t('add_reviews'), 'showBoostReviews()', 'yellow')}
            ${menuItem('trash-2', t('clear_reviews'), t('delete_all_reviews'), 'clearUserReviews()', 'red')}
        </div>
        <div class="section-label mt-16">${t('moderation')}</div>
        <div class="menu-list">
            ${menuItem('ban', t('ban_user'), t('ban_desc'), 'banUser()', 'red')}
            ${menuItem('check-circle', t('unban_user'), t('unban_desc'), 'unbanUser()', 'green')}
            ${menuItem('shield', t('garant'), t('garant_toggle'), 'toggleGarant()')}
            ${menuItem('scale', t('arbitrator'), t('arbitrator_toggle'), 'toggleArbitrator()', 'purple')}
            ${menuItem('user-check', t('set_trust_status'), t('trust_status'), 'setTrustStatus()', 'yellow')}
        </div>
        <div class="section-label mt-16">${t('complaints')}</div>
        <div class="menu-list">
            ${menuItem('alert-circle', t('complaints'), t('view_complaints'), "navigateTo('admin-complaints')", 'red')}
        </div>
    </div>`);
}

// ===== ADMIN SETTINGS =====
async function renderAdminSettings() {
    renderApp(`<div class="page">${pageHeader(t('settings'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        let minDep = '100', minWd = '10';
        try { const r = await api.adminGetSetting('min_deposit'); minDep = r.value || '100'; } catch(e) {}
        try { const r = await api.adminGetSetting('min_withdrawal'); minWd = r.value || '10'; } catch(e) {}
        renderApp(`<div class="page">${pageHeader(t('settings'), true)}
            <div class="form-group">
                <div class="form-label">${t('min_deposit')}</div>
                <input id="set-min-dep" class="form-input" type="number" inputmode="decimal" value="${minDep}">
            </div>
            <div class="form-group">
                <div class="form-label">${t('min_withdrawal')}</div>
                <input id="set-min-wd" class="form-input" type="number" inputmode="decimal" value="${minWd}">
            </div>
            <button class="btn btn-primary" onclick="saveAdminSettings()">${ic('check')} ${t('save')}</button>
        </div>`);
    } catch (e) { toast(e.message, 'error'); }
}

// ===== DISPUTE =====
async function renderDispute({ dealId }) {
    renderApp(`<div class="page">${pageHeader(t('dispute_title'), true)}
        <div class="info-card warn mt-16">
            <div class="info-card-icon">${ic('alert-triangle')}</div>
            <div class="info-card-text">${t('dispute_desc')}</div>
        </div>
        <div class="form-group mt-16">
            <div class="form-label">${t('dispute_details')}</div>
            <textarea id="dispute-text" class="form-input" rows="5" placeholder="${t('dispute_details')}..." style="resize:vertical"></textarea>
        </div>
        <div class="form-group">
            <div class="form-label">${t('report_photo')} (URL)</div>
            <input id="dispute-photo" class="form-input" type="url" placeholder="https://..." autocomplete="off">
        </div>
        <button class="btn btn-danger mt-16" onclick="submitDispute(${dealId})">${ic('send')} ${t('send')}</button>
    </div>`);
}

// ===== CHECK USER =====
async function renderCheckUser() {
    renderApp(`<div class="page">${pageHeader(t('check_user'), true)}
        <div class="menu-list stagger mt-16">
            ${menuItem('alert-circle', t('report_user'), t('report_desc'), "navigateTo('report-user')", 'red')}
            ${menuItem('search', t('find_user_check'), t('find_user_check_desc'), "navigateTo('find-user-check')", 'blue')}
        </div>
    </div>`);
}

// ===== REPORT USER =====
async function renderReportUser() {
    renderApp(`<div class="page">${pageHeader(t('report_user'), true)}
        <div class="info-card warn mt-16">
            <div class="info-card-icon">${ic('alert-triangle')}</div>
            <div class="info-card-text">${t('report_desc')}</div>
        </div>
        <div class="form-group mt-16">
            <div class="form-label">${t('user_id')} / @username</div>
            <input id="report-uid" class="form-input" type="text" placeholder="123456789 ${t('or')} @username" autocomplete="off">
        </div>
        <div class="form-group">
            <div class="form-label">${t('report_subject')}</div>
            <input id="report-subject" class="form-input" type="text" placeholder="${t('report_subject')}..." autocomplete="off">
        </div>
        <div class="form-group">
            <div class="form-label">${t('report_details')}</div>
            <textarea id="report-details" class="form-input" rows="4" placeholder="${t('report_details')}..." style="resize:vertical"></textarea>
        </div>
        <div class="form-group">
            <div class="form-label">${t('report_photo')} (URL)</div>
            <input id="report-photo" class="form-input" type="url" placeholder="https://..." autocomplete="off">
        </div>
        <button class="btn btn-danger mt-16" onclick="submitReport()">${ic('send')} ${t('send')}</button>
    </div>`);
}

// ===== FIND USER CHECK =====
async function renderFindUserCheck() {
    renderApp(`<div class="page">${pageHeader(t('find_user_check'), true)}
        <div class="form-group">
            <div class="form-label">${t('username_or_id')}</div>
            <div class="copy-field">
                <input id="check-uid" class="form-input" type="text" placeholder="${t('enter_query')}" autocomplete="off">
                <button class="copy-btn" onclick="searchUserTrust()">${ic('search')}</button>
            </div>
        </div>
        <div id="trust-result"></div>
    </div>`);
}

// ===== ADMIN DISPUTES =====
async function renderAdminDisputes() {
    renderApp(`<div class="page">${pageHeader(t('disputes'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.adminGetDisputes();
        let h = `<div class="page">${pageHeader(t('disputes'), true)}`;
        if (!list.length) {
            h += `<div class="empty-state"><div class="empty-icon">${ic('check-circle')}</div><div class="empty-text">${t('no_disputes')}</div></div>`;
        } else {
            for (const d of list) {
                const isOpen = d.status === 'open';
                h += `<div class="card" style="cursor:default">
                    <div class="card-top">
                        <span class="card-id">${t('deal')} #${d.deal_id}</span>
                        ${isOpen ? '<span class="status-badge badge-cancelled">OPEN</span>' : '<span class="status-badge badge-completed">RESOLVED</span>'}
                    </div>
                    <div class="card-row">${ic('user')} ${d.full_name || d.username || 'ID: ' + d.user_id}</div>
                    <div style="font-size:14px;color:var(--text);margin:8px 0;line-height:1.5">${d.details || ''}</div>
                    ${d.photo_url ? `<img src="${d.photo_url}" style="max-width:100%;border-radius:var(--r-xs);margin-bottom:8px">` : ''}
                    <div class="card-row">${ic('clock')} ${formatDate(d.created_at)}</div>
                    ${isOpen ? `<div class="btn-group"><button class="btn btn-success btn-sm" onclick="resolveDispute(${d.id})">${ic('check')} Решено</button><button class="btn btn-ghost btn-sm" onclick="navigateTo('deal-detail',{dealId:${d.deal_id}})">${ic('eye')} Сделка</button></div>` : ''}
                </div>`;
            }
        }
        h += '</div>';
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

async function resolveDispute(id, from) {
    try {
        await api.adminResolveDispute(id, { status: 'resolved' });
        toast(t('dispute_resolved') || 'Спор решён', 'success');
        if (from === 'arbitration') renderArbitration();
        else renderAdminDisputes();
    } catch (e) { toast(e.message, 'error'); }
}

// ===== ADMIN COMPLAINTS =====
async function renderAdminComplaints() {
    renderApp(`<div class="page">${pageHeader(t('complaints'), true)}<div class="skeleton" style="height:200px"></div></div>`);
    try {
        const list = await api.adminGetComplaints();
        let h = `<div class="page">${pageHeader(t('complaints'), true)}`;
        if (!list.length) { h += `<div class="empty">${ic('check-circle')}<div>${t('no_data')}</div></div>`; }
        else {
            h += `<div class="menu-list stagger">`;
            for (const c of list) {
                const badge = c.status === 'new' ? 'red' : 'green';
                h += `<div class="menu-item">
                    <div class="menu-icon" style="color:var(--${badge})">${ic('alert-circle')}</div>
                    <div class="menu-body">
                        <div class="menu-title">${c.subject || t('report_user')}</div>
                        <div class="menu-desc">${t('from')}: ${c.reporter_id} → ${t('user_id')}: ${c.reported_user}<br>${c.details ? c.details.substring(0,80) : ''}</div>
                        <div class="menu-desc">${formatDate(c.created_at)}</div>
                    </div>
                </div>`;
            }
            h += `</div>`;
        }
        h += `</div>`;
        renderApp(h);
    } catch (e) { toast(e.message, 'error'); }
}

// ===================================================================
// ACTION FUNCTIONS
// ===================================================================

async function submitCreateDeal() {
    const type = document.getElementById('pay-type')?.value;
    const amount = parseFloat(document.getElementById('deal-amount')?.value);
    const desc = document.getElementById('deal-desc')?.value?.trim();
    if (!amount || amount <= 0) return toast(t('enter_amount'), 'error');
    if (!desc || desc.length < 3) return toast(t('desc_min'), 'error');
    try {
        const r = await api.createDeal({ payment_type: type, amount, description: desc, creator_role: selectedRole });
        toast(t('deal_created'), 'success');
        navigateTo('deal-detail', { dealId: r.deal_id });
    } catch (e) { toast(e.message, 'error'); }
}

async function cancelDeal(id) {
    if (!confirm(t('cancel_deal_q'))) return;
    try { await api.cancelDeal(id); toast(t('deal_cancelled'), 'success'); navigateTo('deals'); }
    catch (e) { toast(e.message, 'error'); }
}

async function completeDeal(id) {
    if (!confirm(t('complete_deal_q'))) return;
    try { await api.completeDeal(id); toast(t('deal_completed'), 'success'); navigateTo('deal-detail', { dealId: id }); }
    catch (e) { toast(e.message, 'error'); }
}

async function submitReview(dealId) {
    const comment = document.getElementById('review-text')?.value?.trim();
    try {
        await api.leaveReview(dealId, { is_positive: window._reviewPositive, comment: comment || null });
        toast(t('review_sent'), 'success');
        navigateTo('deal-detail', { dealId });
    } catch (e) { toast(e.message, 'error'); }
}

async function saveRequisites() {
    const card = document.getElementById('req-card')?.value?.trim();
    const ton = document.getElementById('req-ton')?.value?.trim();
    try {
        await api.updateRequisites({ card_number: card || null, ton_address: ton || null });
        currentUser.card_number = card;
        currentUser.ton_address = ton;
        toast(t('saved'), 'success');
    } catch (e) { toast(e.message, 'error'); }
}

async function submitDeposit() {
    const amount = parseFloat(document.getElementById('deposit-amount')?.value);
    if (!amount || amount < 100) return toast(t('min_100_err'), 'error');
    try {
        const r = await api.createDeposit(amount);
        if (r.pay_url) {
            if (tg) tg.openLink(r.pay_url);
            else window.open(r.pay_url, '_blank');
            toast(t('pay_crypto'), 'success');
            if (r.invoice_id) {
                let attempts = 0;
                const poll = setInterval(async () => {
                    attempts++;
                    try {
                        const check = await api.checkDeposit(r.invoice_id);
                        if (check.status === 'paid') {
                            clearInterval(poll);
                            currentUser.deposit = (currentUser.deposit || 0) + amount;
                            toast(t('deposit_ok'), 'success');
                            navigateTo('profile');
                        }
                    } catch(e) {}
                    if (attempts > 60) clearInterval(poll);
                }, 5000);
            }
        }
    } catch (e) { toast(e.message, 'error'); }
}

async function submitWithdraw() {
    const amount = parseFloat(document.getElementById('withdraw-amount')?.value);
    const wallet = document.getElementById('withdraw-wallet')?.value?.trim();
    if (!amount || amount <= 0) return toast(t('enter_amount'), 'error');
    if (!wallet) return toast(t('enter_wallet'), 'error');
    try {
        await api.createWithdrawal(amount, wallet);
        currentUser.withdrawal_wallet = wallet;
        toast(t('request_created'), 'success');
        navigateTo('profile');
    } catch (e) { toast(e.message, 'error'); }
}

async function submitTicket() {
    const subj = document.getElementById('ticket-subj')?.value?.trim();
    const msg = document.getElementById('ticket-msg')?.value?.trim();
    if (!subj) return toast(t('enter_subj'), 'error');
    if (!msg) return toast(t('enter_msg'), 'error');
    try { await api.createTicket({ subject: subj, message: msg }); toast(t('ticket_created'), 'success'); navigateTo('support'); }
    catch (e) { toast(e.message, 'error'); }
}

async function submitTicketReply(ticketId) {
    const msg = document.getElementById('ticket-reply')?.value?.trim();
    if (!msg) return;
    try { await api.replyTicket(ticketId, msg); navigateTo('ticket-detail', { ticketId }); }
    catch (e) { toast(e.message, 'error'); }
}

async function closeTicket(ticketId) {
    try { await api.adminCloseTicket(ticketId); toast(t('ticket_closed'), 'success'); navigateTo('ticket-detail', { ticketId }); }
    catch (e) { toast(e.message, 'error'); }
}

async function takeDeal(id) {
    try { await api.garantTakeDeal(id); toast(t('garant_assigned'), 'success'); navigateTo('deal-detail', { dealId: id }); }
    catch (e) { toast(e.message, 'error'); }
}

// ===== LANGUAGE MODAL =====
function showLanguageModal() {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `<div class="modal">
        <div class="modal-header">
            <div class="modal-title">${t('select_lang')}</div>
            <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">${ic('x')}</button>
        </div>
        <div class="menu-list">
            <div class="menu-item ${currentUser.language === 'ru' ? 'active' : ''}" onclick="applyLanguage('ru')">
                <div class="menu-icon" style="font-size:14px;color:var(--blue)">${ic('languages')}</div>
                <div class="menu-body"><div class="menu-title">Русский</div></div>
                ${currentUser.language === 'ru' ? ic('check') : ''}
            </div>
            <div class="menu-item ${currentUser.language === 'en' ? 'active' : ''}" onclick="applyLanguage('en')">
                <div class="menu-icon" style="font-size:14px;color:var(--green)">${ic('languages')}</div>
                <div class="menu-body"><div class="menu-title">English</div></div>
                ${currentUser.language === 'en' ? ic('check') : ''}
            </div>
        </div>
    </div>`;
    document.body.appendChild(overlay);
    if (window.lucide) lucide.createIcons();
}

async function applyLanguage(lang) {
    try {
        await api.setLanguage(lang);
        currentUser.language = lang;
        document.querySelector('.modal-overlay')?.remove();
        updateNavLabels();
        toast(t('lang_changed'), 'success');
        navigateTo('profile');
    } catch(e) { toast(e.message, 'error'); }
}

// ===== ADMIN ACTIONS =====
function getBoostUid() {
    const uid = parseInt(document.getElementById('boost-uid')?.value);
    if (!uid) { toast(t('enter_uid'), 'error'); return null; }
    return uid;
}
async function showBoostDeposit() {
    const uid = getBoostUid(); if (!uid) return;
    const amount = parseFloat(prompt(t('amount') + ':')); if (!amount) return;
    try { await api.adminBoostDeposit({ user_id: uid, amount }); toast(t('deposit_added'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function showBoostReputation() {
    const uid = getBoostUid(); if (!uid) return;
    const pos = parseInt(prompt(t('positive_rev') + ':') || '0');
    const neg = parseInt(prompt(t('negative_rev') + ':') || '0');
    try { await api.adminBoostReputation({ user_id: uid, positive: pos, negative: neg }); toast(t('rep_changed'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function showBoostDeals() {
    const uid = getBoostUid(); if (!uid) return;
    const amount = parseInt(prompt(t('amount') + ':')); if (!amount) return;
    try { await api.adminBoostDeals({ user_id: uid, amount }); toast(t('deals_added'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function showBoostReviews() {
    const uid = getBoostUid(); if (!uid) return;
    const count = parseInt(prompt(t('amount') + ':')); if (!count) return;
    const pos = confirm(t('positive') + '?');
    try { await api.adminBoostReviews({ user_id: uid, count, is_positive: pos }); toast(t('reviews_added'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function clearUserReviews() {
    const uid = getBoostUid(); if (!uid) return;
    if (!confirm(t('delete_all_reviews') + '?')) return;
    try { await api.adminClearReviews(uid); toast(t('reviews_deleted'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function banUser() {
    const uid = getBoostUid(); if (!uid) return;
    const reason = prompt(t('description') + ':');
    try { await api.adminBan({ user_id: uid, reason }); toast(t('banned'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function unbanUser() {
    const uid = getBoostUid(); if (!uid) return;
    try { await api.adminUnban({ user_id: uid }); toast(t('unbanned'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function toggleGarant() {
    const uid = getBoostUid(); if (!uid) return;
    const isGarant = confirm(t('garant_set') + '? (Cancel = ' + t('garant_removed') + ')');
    try { await api.adminSetGarant({ user_id: uid, is_garant: isGarant }); toast(isGarant ? t('garant_set') : t('garant_removed'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function toggleArbitrator() {
    const uid = getBoostUid(); if (!uid) return;
    const isArb = confirm(t('arbitrator_set') + '? (Cancel = ' + t('arbitrator_removed') + ')');
    try { await api.adminSetArbitrator({ user_id: uid, is_arbitrator: isArb }); toast(isArb ? t('arbitrator_set') : t('arbitrator_removed'), 'success'); } catch(e) { toast(e.message, 'error'); }
}
async function setTrustStatus() {
    const uid = getBoostUid(); if (!uid) return;
    showTrustModal(uid);
}
function showTrustModal(uid) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    overlay.innerHTML = `<div class="modal">
        <div class="modal-header">
            <div class="modal-title">${t('set_trust_status')}</div>
            <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">${ic('x')}</button>
        </div>
        <div class="menu-list">
            <div class="menu-item" onclick="applyTrustStatus(${uid},'clean')">
                <div class="menu-icon" style="color:var(--text-secondary)">${ic('user')}</div>
                <div class="menu-body"><div class="menu-title">${t('user_clean')}</div></div>
            </div>
            <div class="menu-item" onclick="applyTrustStatus(${uid},'verified')">
                <div class="menu-icon" style="color:var(--green)">${ic('check-circle')}</div>
                <div class="menu-body"><div class="menu-title">${t('user_verified')}</div></div>
            </div>
            <div class="menu-item" onclick="applyTrustStatus(${uid},'has_complaints')">
                <div class="menu-icon" style="color:var(--yellow)">${ic('alert-triangle')}</div>
                <div class="menu-body"><div class="menu-title">${t('user_has_complaints')}</div></div>
            </div>
            <div class="menu-item" onclick="applyTrustStatus(${uid},'blocked_fraud')">
                <div class="menu-icon" style="color:var(--red)">${ic('shield-off')}</div>
                <div class="menu-body"><div class="menu-title">${t('user_blocked_fraud')}</div></div>
            </div>
        </div>
    </div>`;
    document.body.appendChild(overlay);
    if (window.lucide) lucide.createIcons();
}
async function applyTrustStatus(uid, status) {
    try {
        await api.adminSetTrustStatus({ user_id: uid, trust_status: status });
        document.querySelector('.modal-overlay')?.remove();
        toast(t('saved'), 'success');
    } catch(e) { toast(e.message, 'error'); }
}
async function submitDispute(dealId) {
    const text = document.getElementById('dispute-text')?.value?.trim();
    const photo = document.getElementById('dispute-photo')?.value?.trim();
    if (!text || text.length < 3) return toast(t('desc_min'), 'error');
    try {
        await api.createDispute(dealId, { details: text, photo_url: photo || null });
        toast(t('dispute_sent'), 'success');
        navigateTo('deal-detail', { dealId });
    } catch (e) { toast(e.message, 'error'); }
}
async function submitReport() {
    const uid = document.getElementById('report-uid')?.value?.trim();
    const subject = document.getElementById('report-subject')?.value?.trim();
    const details = document.getElementById('report-details')?.value?.trim();
    const photo = document.getElementById('report-photo')?.value?.trim();
    if (!uid) return toast(t('enter_uid'), 'error');
    if (!subject) return toast(t('enter_subj'), 'error');
    if (!details || details.length < 10) return toast(t('desc_min'), 'error');
    try {
        await api.createComplaint({ reported_user: uid, subject, details, photo_url: photo || null });
        toast(t('report_sent'), 'success');
        navigateTo('check-user');
    } catch (e) { toast(e.message, 'error'); }
}
async function searchUserTrust() {
    const q = document.getElementById('check-uid')?.value?.trim();
    if (!q) return toast(t('enter_uid'), 'error');
    const container = document.getElementById('trust-result');
    if (!container) return;
    container.innerHTML = `<div class="skeleton" style="height:80px;margin-top:16px"></div>`;
    try {
        const u = await api.getUserTrust(q);
        let badgeClass = 'trust-clean', badgeText = t('user_clean'), badgeIcon = 'user';
        if (u.trust_status === 'verified') { badgeClass = 'trust-verified'; badgeText = t('user_verified'); badgeIcon = 'check-circle'; }
        else if (u.trust_status === 'has_complaints') { badgeClass = 'trust-complaints'; badgeText = t('user_has_complaints'); badgeIcon = 'alert-triangle'; }
        else if (u.trust_status === 'blocked_fraud') { badgeClass = 'trust-blocked'; badgeText = t('user_blocked_fraud'); badgeIcon = 'shield-off'; }
        container.innerHTML = `<div class="trust-result-card animate-fadeIn mt-16">
            <div class="trust-result-header">
                <div class="trust-result-avatar">${u.username ? u.username[0].toUpperCase() : '#'}</div>
                <div><div class="trust-result-name">${u.full_name || u.username || 'ID: '+u.user_id}</div>
                <div class="trust-result-id">ID: ${u.user_id}${u.username ? ' • @'+u.username : ''}</div></div>
            </div>
            <div class="trust-badge ${badgeClass}">${ic(badgeIcon)} ${badgeText}</div>
            <div class="trust-result-stats">
                <div class="trust-stat"><span class="trust-stat-val">${u.deals_count || 0}</span><span class="trust-stat-label">${t('deals')}</span></div>
                <div class="trust-stat"><span class="trust-stat-val">${u.reputation_positive || 0}</span><span class="trust-stat-label">👍</span></div>
                <div class="trust-stat"><span class="trust-stat-val">${u.reputation_negative || 0}</span><span class="trust-stat-label">👎</span></div>
            </div>
            <button class="btn btn-outline mt-16" onclick="navigateTo('user-profile',{userId:${u.user_id}})" style="width:100%">${ic('user')} ${t('view_profile')}</button>
        </div>`;
        if (window.lucide) lucide.createIcons();
    } catch(e) {
        container.innerHTML = `<div class="empty mt-16">${ic('user-x')}<div>${e.message}</div></div>`;
        if (window.lucide) lucide.createIcons();
    }
}
async function saveAdminSettings() {
    const minDep = document.getElementById('set-min-dep')?.value;
    const minWd = document.getElementById('set-min-wd')?.value;
    try {
        if (minDep) await api.adminUpdateSetting({ key: 'min_deposit', value: minDep });
        if (minWd) await api.adminUpdateSetting({ key: 'min_withdrawal', value: minWd });
        toast(t('saved'), 'success');
    } catch (e) { toast(e.message, 'error'); }
}
async function confirmWithdrawal(id) {
    try { await api.adminConfirmWithdrawal(id); toast(t('approved'), 'success'); navigateTo('admin-withdrawals'); } catch(e) { toast(e.message, 'error'); }
}
async function rejectWithdrawal(id) {
    try { await api.adminRejectWithdrawal(id); toast(t('rejected'), 'success'); navigateTo('admin-withdrawals'); } catch(e) { toast(e.message, 'error'); }
}

// ===================================================================
// UTILITIES
// ===================================================================

function toast(msg, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const el = document.createElement('div');
    const iconName = type === 'success' ? 'check-circle' : 'alert-circle';
    el.className = `toast toast-${type}`;
    el.innerHTML = `${ic(iconName)} <span>${msg}</span>`;
    container.appendChild(el);
    if (window.lucide) lucide.createIcons();
    setTimeout(() => {
        el.classList.add('toast-hide');
        setTimeout(() => el.remove(), 300);
    }, 3000);
}

function copyDealLink() {
    const input = document.getElementById('deal-link');
    if (input && input.value) {
        navigator.clipboard.writeText(input.value)
            .then(() => toast(t('copied'), 'success'))
            .catch(() => { input.select(); document.execCommand('copy'); toast(t('copied'), 'success'); });
    }
}

function shareDealLink(dealCodeOrId) {
    const link = dealLink(dealCodeOrId);
    if (link && tg) {
        tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent('\n' + t('deal_share_text'))}`);
    } else if (link) {
        navigator.clipboard.writeText(link).then(() => toast(t('copied'), 'success'));
    }
}

function copyRefLink() {
    const input = document.getElementById('ref-link');
    if (input && input.value) {
        navigator.clipboard.writeText(input.value)
            .then(() => toast(t('copied'), 'success'))
            .catch(() => { input.select(); document.execCommand('copy'); toast(t('copied'), 'success'); });
    }
}
