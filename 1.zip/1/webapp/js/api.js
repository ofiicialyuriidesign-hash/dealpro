/**
 * API Client for DealPro Mini App
 * Handles all communication with the FastAPI backend.
 */
class ApiClient {
    constructor() {
        this.baseUrl = '';
        this.initData = '';
    }

    setInitData(initData) {
        this.initData = initData;
    }

    async request(method, url, body = null) {
        const opts = {
            method,
            headers: {
                'Content-Type': 'application/json',
                'X-Telegram-Init-Data': this.initData,
            },
        };
        if (body) {
            opts.body = JSON.stringify(body);
        }
        try {
            const resp = await fetch(`${this.baseUrl}${url}`, opts);
            if (!resp.ok) {
                const err = await resp.json().catch(() => ({}));
                let detail = err.detail || `HTTP ${resp.status}`;
                if (Array.isArray(detail)) detail = detail.map(e => e.msg || e.message || JSON.stringify(e)).join('; ');
                else if (typeof detail === 'object') detail = detail.msg || detail.message || JSON.stringify(detail);
                throw new Error(String(detail));
            }
            return await resp.json();
        } catch (e) {
            console.error(`API Error [${method} ${url}]:`, e);
            throw e;
        }
    }

    get(url) { return this.request('GET', url); }
    post(url, body) { return this.request('POST', url, body); }

    // ---- Profile ----
    getMe() { return this.get('/api/me'); }
    setLanguage(lang) { return this.post('/api/language', { language: lang }); }
    getStats() { return this.get('/api/stats'); }

    // ---- Deals ----
    getDeals() { return this.get('/api/deals'); }
    getDeal(id) { return this.get(`/api/deals/${id}`); }
    createDeal(data) { return this.post('/api/deals', data); }
    joinDeal(id) { return this.post(`/api/deals/${id}/join`); }
    cancelDeal(id) { return this.post(`/api/deals/${id}/cancel`); }
    completeDeal(id) { return this.post(`/api/deals/${id}/complete`); }
    leaveReview(dealId, data) { return this.post(`/api/deals/${dealId}/review`, data); }
    getDealMessages(dealId) { return this.get(`/api/deals/${dealId}/messages`); }
    sendDealMessage(dealId, message) { return this.post(`/api/deals/${dealId}/messages`, { message }); }
    sendDealPhoto(dealId, image_url) { return this.post(`/api/deals/${dealId}/messages`, { message: '[photo]', image_url }); }

    // ---- News ----
    getNews() { return this.get('/api/news'); }

    // ---- Garant ----
    garantPendingDeals() { return this.get('/api/garant/pending'); }
    garantMyDeals() { return this.get('/api/garant/my'); }
    garantTakeDeal(id) { return this.post(`/api/garant/take/${id}`); }

    // ---- Requisites ----
    updateRequisites(data) { return this.post('/api/requisites', data); }

    // ---- Users ----
    getGarants() { return this.get('/api/users/garants'); }
    getTopReputation() { return this.get('/api/users/top'); }
    searchUser(query) { return this.get(`/api/users/search/${encodeURIComponent(query)}`); }
    getUserProfile(id) { return this.get(`/api/users/${id}/profile`); }
    getUserReviews(id, filter = 'all') { return this.get(`/api/users/${id}/reviews?filter=${filter}`); }

    // ---- Support ----
    getTickets() { return this.get('/api/tickets'); }
    createTicket(data) { return this.post('/api/tickets', data); }
    getTicket(id) { return this.get(`/api/tickets/${id}`); }
    replyTicket(id, msg) { return this.post(`/api/tickets/${id}/reply`, { message: msg }); }

    // ---- Referrals ----
    getReferrals() { return this.get('/api/referrals'); }
    getReferralLeaderboard() { return this.get('/api/referrals/leaderboard'); }

    // ---- Verification ----
    getVerification() { return this.get('/api/verification'); }
    applyVerification(level) { return this.post('/api/verification/apply', { level }); }
    purchaseVerification(level, currency, price) { return this.post('/api/verification/purchase', { level, currency, price }); }

    // ---- Deposit/Withdraw ----
    createDeposit(amount) { return this.post('/api/deposit', { amount }); }
    checkDeposit(invoiceId) { return this.post(`/api/deposit/check/${invoiceId}`); }
    createWithdrawal(amount, wallet) { return this.post('/api/withdraw', { amount, wallet_address: wallet }); }

    // ---- Admin ----
    adminStats() { return this.get('/api/admin/stats'); }
    adminPendingDeals() { return this.get('/api/admin/pending-deals'); }
    adminWaitingPartner() { return this.get('/api/admin/waiting-partner'); }
    adminMyDeals() { return this.get('/api/admin/my-deals'); }
    adminTickets() { return this.get('/api/admin/tickets'); }
    adminCloseTicket(id) { return this.post(`/api/admin/tickets/${id}/close`); }
    adminWithdrawals() { return this.get('/api/admin/withdrawals'); }
    adminConfirmWithdrawal(id) { return this.post(`/api/admin/withdrawals/${id}/confirm`); }
    adminRejectWithdrawal(id) { return this.post(`/api/admin/withdrawals/${id}/reject`); }
    adminBoostDeposit(data) { return this.post('/api/admin/boost/deposit', data); }
    adminBoostReputation(data) { return this.post('/api/admin/boost/reputation', data); }
    adminBoostDeals(data) { return this.post('/api/admin/boost/deals', data); }
    adminBoostReviews(data) { return this.post('/api/admin/boost/reviews', data); }
    adminClearReviews(userId) { return this.post('/api/admin/boost/reviews/clear', { user_id: userId }); }
    adminBan(data) { return this.post('/api/admin/ban', data); }
    adminUnban(data) { return this.post('/api/admin/unban', data); }
    adminSetGarant(data) { return this.post('/api/admin/garant', data); }
    adminUpdateSetting(data) { return this.post('/api/admin/settings', data); }
    adminGetSetting(key) { return this.get(`/api/admin/settings/${key}`); }
    adminBannedUsers() { return this.get('/api/admin/banned-users'); }
    adminAppeals() { return this.get('/api/admin/appeals'); }
    adminProcessAppeal(id, data) { return this.post(`/api/admin/appeals/${id}/process`, data); }

    // ---- Admin Verification ----
    adminVerifications() { return this.get('/api/admin/verifications'); }
    adminProcessVerification(id, data) { return this.post(`/api/admin/verifications/${id}/process`, data); }

    // ---- Chat ----
    getUnreadCount() { return this.get('/api/chat/unread-count'); }

    // ---- PIN ----
    setPin(data) { return this.post('/api/pin', data); }
    verifyPin(data) { return this.post('/api/pin/verify', data); }

    // ---- Disputes ----
    createDispute(dealId, data) { return this.post(`/api/deals/${dealId}/dispute`, data); }
    adminGetDisputes() { return this.get('/api/admin/disputes'); }
    adminResolveDispute(id, data) { return this.post(`/api/admin/disputes/${id}/resolve`, data); }
    adminSetArbitrator(data) { return this.post('/api/admin/set-arbitrator', data); }

    // ---- Complaints / Trust ----
    createComplaint(data) { return this.post('/api/complaints', data); }
    getUserTrust(query) { return this.get(`/api/users/trust/${encodeURIComponent(query)}`); }

    // ---- Admin Users ----
    adminGetUsers() { return this.get('/api/admin/users'); }
    adminSetTrustStatus(data) { return this.post('/api/admin/trust-status', data); }
    adminGetComplaints() { return this.get('/api/admin/complaints'); }

    // ---- Admin News ----
    adminGetNews() { return this.get('/api/admin/news'); }
    adminCreateNews(data) { return this.post('/api/admin/news', data); }
    adminUpdateNews(id, data) { return this.post(`/api/admin/news/${id}/update`, data); }
    adminToggleNews(id) { return this.post(`/api/admin/news/${id}/toggle`); }
    adminDeleteNews(id) { return this.post(`/api/admin/news/${id}/delete`); }
}

const api = new ApiClient();
