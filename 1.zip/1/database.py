import aiosqlite
import string
from datetime import datetime
from typing import Optional, List, Dict, Any

from config import DB_PATH


import random


def generate_deal_code() -> str:
    """Generate a unique deal code like DP-FSRJHE."""
    chars = string.ascii_uppercase + string.digits
    return "DP-" + "".join(random.choices(chars, k=6))

FAKE_USERNAMES = [
    "CryptoKing", "CryptoMaster", "CryptoWhale", "CryptoLion", "CryptoShark",
    "CryptoWolf", "CryptoEagle", "CryptoBoss", "CryptoHero", "CryptoGod",
    "CryptoPro", "CryptoMan", "CryptoFan", "CryptoTrader", "CryptoDealer",
    "BitKing", "BitMaster", "BitPro", "BitMan", "BitBoss",
    "BlockChain", "BlockMaster", "BlockPro", "Satoshi", "Nakamoto",
    "TopSeller", "ProTrader", "TradeKing", "TradeMaster", "TradeBoss",
    "FastTrade", "QuickTrade", "SafeTrade", "EliteTrader", "AlphaTrader",
    "BetaTrader", "OmegaTrader", "DeltaTrader", "SigmaTrader", "GammaTrader",
    "TraderOne", "TraderPro", "TraderX", "TraderZ", "TraderMax",
    "Seller", "BestSeller", "TopSell", "ProSell", "FastSell",
    "TrustDealer", "VIPDealer", "TopDealer", "BestDealer", "ProDealer",
    "SafeDealer", "TrueDealer", "RealDealer", "HonestDealer", "FastDealer",
    "MainDealer", "ChiefDealer", "PrimeDealer", "FirstDealer", "GoldDealer",
    "Garant", "GarantPro", "GarantTop", "GarantBest", "GarantVIP",
    "SafeGarant", "TrustGarant", "ProGarant", "MainGarant", "ChiefGarant",
    "Premium", "Diamond", "Platinum", "Gold", "Silver",
    "Bronze", "Elite", "VIP", "Pro", "Best",
    "Top", "First", "Prime", "Chief", "Main",
    "Ultra", "Mega", "Super", "Hyper", "Max",
    "Alex", "Max", "Ivan", "Denis", "Artem", "Kirill", "Vlad", "Dima", "Sasha", "Roma",
    "Nikita", "Andrey", "Pavel", "Sergey", "Oleg", "Kostya", "Vanya", "Petya", "Kolya", "Misha",
    "Tema", "Lesha", "Zhenya", "Vitya", "Tolya", "Grisha", "Fedya", "Serega", "Pasha", "Danila",
    "Egor", "Igor", "Timur", "Ruslan", "Vadim", "Anton", "Viktor", "Maksim", "Roman", "Dmitriy",
    "Alexey", "Ilya", "Gleb", "Mark", "Lev", "Matvey", "Yaroslav", "Bogdan", "Danil", "Stepan",
    "Masha", "Dasha", "Sasha", "Nastya", "Katya", "Anya", "Olya", "Lena", "Sveta", "Marina",
    "Alina", "Polina", "Karina", "Arina", "Vika", "Kristina", "Liza", "Sonya", "Mila", "Diana",
    "Shadow", "Phoenix", "Dragon", "Ghost", "Storm", "Thunder", "Flash", "Blaze", "Frost", "Venom",
    "Ninja", "Sniper", "Hunter", "Legend", "Champion", "Warrior", "Knight", "Paladin", "Mage", "Rogue",
    "Assassin", "Archer", "Tank", "Healer", "Support", "Carry", "Mid", "Jungle", "Top", "Bot",
    "Pro", "Noob", "Tryhard", "Casual", "Grinder", "Farmer", "Rusher", "Camper", "Pusher", "Feeder",
    "Ace", "Clutch", "Frag", "Headshot", "Combo", "Streak", "Rampage", "Dominate", "Unstoppable", "Godlike",
    "Dark", "Light", "Fire", "Ice", "Water", "Earth", "Wind", "Electric", "Poison", "Holy",
    "Demon", "Angel", "Devil", "Spirit", "Soul", "Mind", "Heart", "Power", "Force", "Energy",
    "Alpha", "Beta", "Omega", "Delta", "Sigma", "Gamma", "Epsilon", "Zeta", "Theta", "Lambda",
    "Neo", "Matrix", "Cyber", "Tech", "Digital", "Virtual", "Binary", "Quantum", "Atomic", "Nuclear",
    "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Business", "Money", "Cash", "Dollar", "Profit", "Success", "Winner", "Leader", "Expert", "Master",
    "Boss", "Chief", "Director", "Manager", "Founder", "Owner", "Investor", "Trader", "Broker", "Dealer",
    "Rich", "Wealthy", "Million", "Billion", "Fortune", "Luck", "Gold", "Silver", "Diamond", "Platinum",
    "Wolf", "Lion", "Tiger", "Bear", "Eagle", "Hawk", "Falcon", "Shark", "Snake", "Cobra",
    "Panther", "Jaguar", "Leopard", "Cheetah", "Fox", "Lynx", "Puma", "Rhino", "Bull", "Buffalo",
    "Raven", "Crow", "Owl", "Bat", "Spider", "Scorpion", "Viper", "Python", "Dragon", "Phoenix",
    "Black", "White", "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink", "Gray",
    "Dark", "Light", "Bright", "Deep", "Pale", "Neon", "Electric", "Royal", "Navy", "Sky",
    "Sky", "Cloud", "Rain", "Snow", "Sun", "Moon", "Star", "Night", "Day", "Dawn",
    "Dusk", "Storm", "Thunder", "Lightning", "Wind", "Wave", "Ocean", "Sea", "River", "Lake",
    "Mountain", "Hill", "Valley", "Forest", "Desert", "Island", "Beach", "Coast", "Shore", "Rock",
    "Free", "Fast", "Quick", "Swift", "Speed", "Flash", "Instant", "Rapid", "Turbo", "Nitro",
    "Power", "Force", "Energy", "Strength", "Might", "Glory", "Honor", "Pride", "Fame", "Legend",
    "Trust", "Faith", "Hope", "Love", "Peace", "Truth", "Justice", "Freedom", "Victory", "Triumph",
    "DealHunter", "DealMaker", "DealPro", "SafeDeals", "BestDeals",
    "SecureExchange", "FastExchange", "TrustExchange", "ProExchange", "TopExchange",
    "MoneyMaker", "CashFlow", "GoldRush", "DiamondHands", "SteelNerves",
    "IronWill", "StoneHeart", "ColdBlood", "HotShot", "BigBoss",
    "TheOne", "Number1", "FirstPlace", "TopDog", "BigDeal",
    "RealDeal", "TrueDeal", "BestDeal", "GoodDeal", "GreatDeal",
    "Prodavan", "Chestniy", "Nadezhda", "Uspeh", "Pobeda",
    "Zashita", "Doverie", "Proverka", "Kachestvo", "Garantiya",
    "Bezopasnost", "Nadezhnost", "Chestnost", "Poryadok", "Stabilnost",
    "Professiya", "Opyt", "Znanie", "Umeniye", "Masterstvo",
    "Luchshiy", "Perviy", "Glavniy", "Vedushiy", "Osnovnoy",
]

RARE_EMOJI_FOR_NICK = ["🔥", "⭐", "💎", "👑", "🏆", "💪", "🎯", "✨", "💫", "🌟"]

FAKE_COMMENTS_POSITIVE = [
    "+реп",
    "+реп, все четко",
    "+реп за сделку",
    "+реп продавцу",
    "+реп гаранту",
    "+реп, без проблем",
    "+реп, рекомендую",
    "+реп, купил получил",
    "+реп, все по факту",
    "+реп, можно работать",
    "+реп, быстро закрыли",
    "+реп, без вопросов",
    "+реп, все честно",
    "+реп, без обмана",
    "+реп, доволен",
    "+реп, норм продавец",
    "Купил NFT, все получил",
    "NFT получил, без вопросов",
    "Купил, все ок",
    "Покупка прошла нормально",
    "Сделка закрыта",
    "Сделка прошла успешно",
    "Все как договаривались",
    "Все по договору",
    "Условия выполнены",
    "Без сюрпризов",
    "Без подводных камней",
    "Все прозрачно",
    "Все честно",
    "Продал без проблем",
    "Продажа прошла быстро",
    "Обмен прошел успешно",
    "Обменяли быстро",
    "Сделка через гарант сервис",
    "Через гарант сервис, все ровно",
    "С гарантом спокойно",
    "Гарант отработал",
    "Гарант все проверил",
    "Через гарант сервис без рисков",
    "USDT получил",
    "Крипта пришла",
    "Оплата прошла",
    "Перевод подтвержден",
    "Деньги получил",
    "Деньги пришли",
    "Оплата без задержек",
    "Средства зачислены",
    "Все пришло",
    "Сумма полная",
    "Без недостачи",
    "Все деньги на месте",
    "Деньги получил сразу",
    "Оплата моментальная",
    "Пришло быстро",
    "Без задержек",
    "Все оперативно",
    "За пару минут",
    "За несколько минут",
    "Быстрее чем ожидал",
    "Скорость порадовала",
    "Продавец на связи",
    "Отвечает быстро",
    "Отвечает сразу",
    "Всегда на связи",
    "Без лишних вопросов",
    "Все по делу",
    "Адекватный человек",
    "Приятное общение",
    "Коммуникация норм",
    "Можно доверять",
    "Проверено лично",
    "Надежный человек",
    "Без обмана",
    "Честно отработал",
    "Не подвел",
    "Доверие оправдал",
    "Все честно и открыто",
    "Не первый раз работаем",
    "Уже несколько сделок",
    "Работаем дальше",
    "Буду обращаться еще",
    "Продолжим сотрудничество",
    "Еще поработаем",
    "Не последний раз",
    "Товар получил",
    "Все на месте",
    "Соответствует описанию",
    "Все как на фото",
    "Без брака",
    "Качество норм",
    "Все устроило",
    "Рекомендую",
    "Советую",
    "Можно брать",
    "Смело можно работать",
    "Рекомендую к работе",
    "Все прошло нормально",
    "Все прошло без проблем",
    "Все прошло гладко",
    "Все ок",
    "Нормально отработали",
    "Без косяков",
    "Без нервов",
    "Спасибо за сделку",
    "Спасибо",
    "Благодарю",
    "Спасибо, все ок",
    "Как договаривались",
    "Без лишних слов",
    "Все четко и быстро",
    "Закрыли сделку",
    "Еще одна сделка",
    "Все стабильно",
    "Работает как надо",
    "Покупал впервые, все прошло нормально",
    "Сначала сомневался, но зря",
    "Все прошло лучше чем ожидал",
    "Приятно удивлен",
    "Оставил хорошее впечатление",
    "Добавил в контакты",
    "Сохранил контакт",
    "Теперь знаю к кому обращаться",
    "Нашел надежного продавца",
    "Без задержек и проблем",
    "Все четко по срокам",
    "Закрыли быстро",
    "Не тянули время",
    "Работа аккуратная",
    "Все грамотно",
    "Подход адекватный",
    "Очередная успешная сделка",
    "Как обычно без проблем",
    "Стабильно хорошо",
]

FAKE_COMMENTS_NEGATIVE = [
    "Не рекомендую", "Не советую", "Не связывайтесь", "Обходите стороной",
    "Долго отвечал потом пропал", "Обещал одно сделал другое", "Были проблемы",
    "Кинул на деньги", "Мошенник не ведитесь", "Пропал после получения денег",
    "Не выполнил условия сделки", "Обманул с товаром", "Скам осторожно",
    "Развод чистой воды", "Лохотрон", "Кидала", "Разводила",
    "Не доверяйте", "Обманщик", "Врун", "Плохой продавец",
    "Ужасный сервис", "Отвратительно", "Кошмар", "Никогда больше",
    "Зря потратил время", "Зря потратил деньги", "Жалею что связался",
    "Худший опыт", "Негативный опыт", "Разочарован полностью",
]

RARE_EMOJI_FOR_COMMENT = ["👍", "🔥", "⭐", "💯", "✅", "👌", "🤝", "💪", "🎉", "❤️"]


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                card_number TEXT,
                ton_address TEXT,
                deposit REAL DEFAULT 0,
                reputation_positive INTEGER DEFAULT 0,
                reputation_negative INTEGER DEFAULT 0,
                is_garant INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                deals_count INTEGER DEFAULT 0,
                successful_deals INTEGER DEFAULT 0,
                referrer_id INTEGER,
                referral_bonus REAL DEFAULT 0,
                referral_level TEXT DEFAULT 'bronze',
                days_in_bot INTEGER DEFAULT 0,
                is_verified INTEGER DEFAULT 0,
                language TEXT DEFAULT 'ru',
                captcha_passed INTEGER DEFAULT 0
            )
        """)
        # Таблица рефералов
        await db.execute("""
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_id INTEGER NOT NULL,
                status TEXT DEFAULT 'pending',
                bonus_paid INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                activated_at TIMESTAMP,
                UNIQUE(referred_id)
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS deals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                creator_id INTEGER NOT NULL,
                partner_id INTEGER,
                admin_id INTEGER,
                payment_type TEXT NOT NULL,
                amount REAL NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                creator_role TEXT DEFAULT 'seller',
                creator_confirmed INTEGER DEFAULT 0,
                partner_confirmed INTEGER DEFAULT 0,
                admin_confirmed INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                deal_id INTEGER,
                from_user_id INTEGER,
                to_user_id INTEGER NOT NULL,
                rating INTEGER NOT NULL,
                is_positive INTEGER DEFAULT 1,
                comment TEXT,
                fake_username TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                status TEXT DEFAULT 'open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                is_admin INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                invoice_id TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                currency TEXT DEFAULT 'USDT',
                wallet_address TEXT,
                transfer_id TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP
            )
        """)
        await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('min_deposit', '100')")
        await db.commit()
        for col in ["ALTER TABLE users ADD COLUMN deposit REAL DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN reputation_positive INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN reputation_negative INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN is_garant INTEGER DEFAULT 0",
                    "ALTER TABLE reviews ADD COLUMN is_positive INTEGER DEFAULT 1",
                    "ALTER TABLE reviews ADD COLUMN fake_username TEXT",
                    "ALTER TABLE users ADD COLUMN referrer_id INTEGER",
                    "ALTER TABLE users ADD COLUMN referral_bonus REAL DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN referral_level TEXT DEFAULT 'bronze'",
                    "ALTER TABLE users ADD COLUMN days_in_bot INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN ban_reason TEXT",
                    "ALTER TABLE users ADD COLUMN withdrawal_wallet TEXT",
                    "ALTER TABLE withdrawals ADD COLUMN wallet_address TEXT",
                    "ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'ru'",
                    "ALTER TABLE users ADD COLUMN captcha_passed INTEGER DEFAULT 0",
                    "ALTER TABLE users ADD COLUMN is_arbitrator INTEGER DEFAULT 0"]:
            try:
                await db.execute(col)
            except:
                pass
        await db.commit()

        # Ensure appeals table has attachment column
        try:
            await db.execute("ALTER TABLE appeals ADD COLUMN attachment_file_id TEXT")
        except:
            pass

        # Create appeals table for ban/unban requests
        await db.execute("""
            CREATE TABLE IF NOT EXISTS appeals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                message TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                admin_id INTEGER,
                admin_note TEXT
            )
        """)

        # Verification requests table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS verification_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                level TEXT NOT NULL DEFAULT 'basic',
                type TEXT NOT NULL DEFAULT 'apply',
                currency TEXT,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processed_at TIMESTAMP,
                admin_id INTEGER,
                admin_note TEXT
            )
        """)

        # Add verification_level + last_active + pin columns
        for col in [
            "ALTER TABLE users ADD COLUMN verification_level TEXT DEFAULT 'none'",
            "ALTER TABLE users ADD COLUMN last_active TIMESTAMP",
            "ALTER TABLE users ADD COLUMN pin_hash TEXT",
        ]:
            try:
                await db.execute(col)
            except:
                pass

        # News table columns migration
        for col in [
            "ALTER TABLE news ADD COLUMN image_url TEXT",
            "ALTER TABLE news ADD COLUMN author_id INTEGER",
        ]:
            try:
                await db.execute(col)
            except:
                pass

        # Deal messages (chat)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS deal_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                deal_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Chat read status
        await db.execute("""
            CREATE TABLE IF NOT EXISTS chat_read_status (
                user_id INTEGER NOT NULL,
                deal_id INTEGER NOT NULL,
                last_read_id INTEGER DEFAULT 0,
                PRIMARY KEY (user_id, deal_id)
            )
        """)

        # News table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS news (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                emoji TEXT DEFAULT '📢',
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Complaints table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reporter_id INTEGER NOT NULL,
                reported_user TEXT NOT NULL,
                subject TEXT,
                details TEXT,
                photo_url TEXT,
                status TEXT DEFAULT 'new',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Disputes table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS disputes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                deal_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                details TEXT,
                photo_url TEXT,
                status TEXT DEFAULT 'open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Add trust_status column to users if missing
        try:
            await db.execute("ALTER TABLE users ADD COLUMN trust_status TEXT DEFAULT 'clean'")
        except Exception:
            pass

        # Add is_banned / ban_reason columns if missing
        try:
            await db.execute("ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN ban_reason TEXT")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN last_active TIMESTAMP")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN pin_hash TEXT")
        except Exception:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN withdrawal_wallet TEXT")
        except Exception:
            pass

        # Add image_url to news if missing
        try:
            await db.execute("ALTER TABLE news ADD COLUMN image_url TEXT")
        except Exception:
            pass

        # Add deal_code column to deals
        try:
            await db.execute("ALTER TABLE deals ADD COLUMN deal_code TEXT")
        except Exception:
            pass

        # Add image_url to deal_messages
        try:
            await db.execute("ALTER TABLE deal_messages ADD COLUMN image_url TEXT")
        except Exception:
            pass

        await db.commit()


async def get_setting(key: str, default: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = await cursor.fetchone()
        return row[0] if row else default


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
        await db.commit()


async def get_user(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_user_by_telegram_id(telegram_id: int):
    """Telegram ID in Mini App DB matches user_id, kept as a semantic alias for PHP bridge."""
    return await get_user(telegram_id)


async def get_user_by_username(username: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        username = username.replace("@", "").strip()
        cursor = await db.execute("SELECT * FROM users WHERE LOWER(username) = LOWER(?)", (username,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def create_user(user_id: int, username: str, full_name: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO users (user_id, username, full_name) VALUES (?, ?, ?)", (user_id, username, full_name))
        # Всегда обновляем username и full_name на случай если они изменились
        await db.execute("UPDATE users SET username = ?, full_name = ? WHERE user_id = ?", (username, full_name, user_id))
        await db.commit()


async def update_user_info(user_id: int, username: str, full_name: str):
    """Обновляет username и full_name пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET username = ?, full_name = ? WHERE user_id = ?", (username, full_name, user_id))
        await db.commit()


async def update_user_card(user_id: int, card_number: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET card_number = ? WHERE user_id = ?", (card_number, user_id))
        await db.commit()


async def update_user_ton(user_id: int, ton_address: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET ton_address = ? WHERE user_id = ?", (ton_address, user_id))
        await db.commit()


async def set_user_language(user_id: int, lang: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
        await db.commit()


async def get_user_language(user_id: int) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT language FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row and row[0] else 'ru'


async def set_captcha_passed(user_id: int, passed: bool = True):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET captcha_passed = ? WHERE user_id = ?", (1 if passed else 0, user_id))
        await db.commit()


async def is_captcha_passed(user_id: int) -> bool:
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT captcha_passed FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return bool(row[0]) if row else False


async def add_user_deals_count(user_id: int, count: int = 1):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET deals_count = deals_count + ?, successful_deals = successful_deals + ? WHERE user_id = ?", (count, count, user_id))
        await db.commit()


async def update_user_withdrawal_wallet(user_id: int, wallet: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET withdrawal_wallet = ? WHERE user_id = ?", (wallet, user_id))
        await db.commit()


async def update_user_deposit(user_id: int, amount: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET deposit = deposit + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()


async def set_user_deposit(user_id: int, amount: float):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET deposit = ? WHERE user_id = ?", (amount, user_id))
        await db.commit()


async def set_user_reputation(user_id: int, positive: int, negative: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET reputation_positive = ?, reputation_negative = ? WHERE user_id = ?", (positive, negative, user_id))
        await db.commit()


async def set_user_garant(user_id: int, is_garant: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET is_garant = ? WHERE user_id = ?", (1 if is_garant else 0, user_id))
        await db.commit()


async def set_user_arbitrator(user_id: int, is_arbitrator: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET is_arbitrator = ? WHERE user_id = ?", (1 if is_arbitrator else 0, user_id))
        await db.commit()


async def get_user_stats(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            return {}
        cursor = await db.execute("SELECT COUNT(*) as cnt FROM reviews WHERE to_user_id = ?", (user_id,))
        review_data = await cursor.fetchone()
        return {**dict(user), "review_count": review_data["cnt"] or 0}


async def get_garants():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE is_garant = 1 ORDER BY reputation_positive DESC")
        return [dict(row) for row in await cursor.fetchall()]


async def get_top_reputation(limit: int = 10):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users ORDER BY (reputation_positive - reputation_negative) DESC LIMIT ?", (limit,))
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_users():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT user_id FROM users")
        return [dict(row) for row in await cursor.fetchall()]


async def create_review(deal_id, from_user_id: int, to_user_id: int, rating: int, comment: str = None, is_positive: bool = True):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO reviews (deal_id, from_user_id, to_user_id, rating, comment, is_positive) VALUES (?, ?, ?, ?, ?, ?)",
                        (deal_id, from_user_id, to_user_id, rating, comment, 1 if is_positive else 0))
        if is_positive:
            await db.execute("UPDATE users SET reputation_positive = reputation_positive + 1 WHERE user_id = ?", (to_user_id,))
        else:
            await db.execute("UPDATE users SET reputation_negative = reputation_negative + 1 WHERE user_id = ?", (to_user_id,))
        await db.commit()


_COMMENT_OPENERS = [
    "Все прошло отлично.", "Сделка без проблем.", "Все как договаривались.",
    "Закрыли быстро.", "Без вопросов.", "Все четко.", "Все ровно.",
    "Без косяков.", "Все по факту.", "Сделка прошла гладко.",
    "Все нормально.", "Без задержек.", "Оперативно закрыли.",
    "Прошло без нервов.", "Условия выполнены.", "Все прозрачно.",
    "Без сюрпризов.", "Все как обещал.", "Выполнил все условия.",
    "Хорошая сделка.", "Без проблем закрыли.", "Все по договору.",
]
_COMMENT_MIDDLE = [
    "Деньги пришли вовремя.", "Оплата моментальная.", "Перевод без задержек.",
    "Отвечал быстро.", "Всегда на связи.", "Коммуникация четкая.",
    "USDT получил без задержек.", "Крипта пришла быстро.", "Карта пришла сразу.",
    "Товар соответствует описанию.", "Всё как на фото.", "Качество норм.",
    "Средства зачислены сразу.", "Сумма полная, без недостачи.",
    "Подтвердил быстро.", "Сделка через гарант сервис — спокойно.",
    "Гарант все проверил.", "Без лишних вопросов.", "Все по делу.",
    "Адекватный человек.", "Приятное общение.", "Можно доверять.",
]
_COMMENT_CLOSERS = [
    "Рекомендую.", "Буду обращаться еще.", "Работаем дальше.",
    "Добавил в контакты.", "Советую.", "Смело можно работать.",
    "Не последний раз.", "Вернусь снова.", "Проверено лично.",
    "Надежный продавец.", "Нашел надежного партнера.",
    "Теперь знаю к кому обращаться.", "Продолжим сотрудничество.",
    "Повторю.", "Рекомендую всем.", "Зачет.",
]
_COMMENT_AMOUNTS = [100, 200, 300, 500, 750, 1000, 1500, 2000, 2500, 3000,
                    4000, 5000, 7500, 8000, 10000, 12000, 15000, 20000, 25000, 50000]
_COMMENT_AMOUNT_TPLS = [
    "Сумма {a}₽.", "Сделка на {a}₽.", "{a} руб. получил.", "Перевод {a}₽.",
    "Сделка на {a} рублей.", "{a}₽ — все пришло.",
]


def _generate_unique_positive_comment() -> str:
    """Generate a varied positive review comment from randomized fragments."""
    style = random.randint(0, 3)

    if style == 0:
        # Single phrase from original pool
        comment = random.choice(FAKE_COMMENTS_POSITIVE)
    elif style == 1:
        # opener + closer
        comment = random.choice(_COMMENT_OPENERS) + " " + random.choice(_COMMENT_CLOSERS)
    elif style == 2:
        # opener + middle
        comment = random.choice(_COMMENT_OPENERS) + " " + random.choice(_COMMENT_MIDDLE)
    else:
        # opener + middle + closer (full sentence)
        comment = (random.choice(_COMMENT_OPENERS) + " " +
                   random.choice(_COMMENT_MIDDLE) + " " +
                   random.choice(_COMMENT_CLOSERS))

    # ~30% chance to append amount context
    if random.random() < 0.30:
        a = random.choice(_COMMENT_AMOUNTS)
        comment += " " + random.choice(_COMMENT_AMOUNT_TPLS).format(a=a)

    # ~20% chance to append emoji
    if random.random() < 0.20:
        comment += " " + random.choice(RARE_EMOJI_FOR_COMMENT)

    return comment.strip()


async def add_fake_review(to_user_id: int, is_positive: bool = True, _base_override: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        rating = 5 if is_positive else 1
        # Generate varied username
        name_part = random.choice(FAKE_USERNAMES)
        num_part = str(random.randint(10, 9999))
        fake_username = name_part + num_part
        if random.random() < 0.08:
            fake_username = fake_username + random.choice(RARE_EMOJI_FOR_NICK)
        # Generate varied comment
        if is_positive:
            comment = _generate_unique_positive_comment()
            # If a specific base was requested (batch mode), splice it in
            if _base_override:
                comment = _base_override
                if random.random() < 0.30:
                    a = random.choice(_COMMENT_AMOUNTS)
                    comment += " " + random.choice(_COMMENT_AMOUNT_TPLS).format(a=a)
                if random.random() < 0.20:
                    comment += " " + random.choice(RARE_EMOJI_FOR_COMMENT)
        else:
            neg_base = _base_override or random.choice(FAKE_COMMENTS_NEGATIVE)
            neg_details = ["", "", "", " Осторожно.", " Не советую.", " Предупреждаю всех.", " Берегитесь."]
            comment = neg_base + random.choice(neg_details)

        await db.execute(
            "INSERT INTO reviews (deal_id, from_user_id, to_user_id, rating, comment, is_positive, fake_username) VALUES (0, 0, ?, ?, ?, ?, ?)",
            (to_user_id, rating, comment, 1 if is_positive else 0, fake_username)
        )
        if is_positive:
            await db.execute("UPDATE users SET reputation_positive = reputation_positive + 1 WHERE user_id = ?", (to_user_id,))
        else:
            await db.execute("UPDATE users SET reputation_negative = reputation_negative + 1 WHERE user_id = ?", (to_user_id,))
        await db.commit()


async def add_fake_reviews(to_user_id: int, positive_count: int, negative_count: int = 0):
    # Shuffle base pools so comments in the same batch don't repeat
    pos_pool = FAKE_COMMENTS_POSITIVE[:]
    random.shuffle(pos_pool)
    neg_pool = FAKE_COMMENTS_NEGATIVE[:]
    random.shuffle(neg_pool)
    for i in range(positive_count):
        await add_fake_review(to_user_id, is_positive=True, _base_override=pos_pool[i % len(pos_pool)])
    for i in range(negative_count):
        await add_fake_review(to_user_id, is_positive=False, _base_override=neg_pool[i % len(neg_pool)])


async def clear_fake_reviews(to_user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM reviews WHERE to_user_id = ? AND (fake_username IS NOT NULL OR deal_id = 0)", (to_user_id,))
        await db.execute("UPDATE users SET reputation_positive = 0, reputation_negative = 0 WHERE user_id = ?", (to_user_id,))
        await db.commit()


async def get_user_reviews(user_id: int, filter_type: str = "all"):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        base = "SELECT r.*, u.username, u.full_name FROM reviews r LEFT JOIN users u ON r.from_user_id = u.user_id WHERE r.to_user_id = ?"
        if filter_type == "positive":
            cursor = await db.execute(base + " AND r.is_positive = 1 ORDER BY r.created_at DESC", (user_id,))
        elif filter_type == "negative":
            cursor = await db.execute(base + " AND r.is_positive = 0 ORDER BY r.created_at DESC", (user_id,))
        elif filter_type == "last_positive":
            cursor = await db.execute(base + " AND r.is_positive = 1 ORDER BY r.created_at DESC LIMIT 1", (user_id,))
        elif filter_type == "last_negative":
            cursor = await db.execute(base + " AND r.is_positive = 0 ORDER BY r.created_at DESC LIMIT 1", (user_id,))
        else:
            cursor = await db.execute(base + " ORDER BY r.created_at DESC", (user_id,))
        return [dict(row) for row in await cursor.fetchall()]


async def check_review_exists(deal_id: int, from_user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT id FROM reviews WHERE deal_id = ? AND from_user_id = ?", (deal_id, from_user_id))
        return await cursor.fetchone() is not None


async def create_deal(creator_id: int, payment_type: str, amount: float, description: str, creator_role: str):
    async with aiosqlite.connect(DB_PATH) as db:
        deal_code = generate_deal_code()
        # Ensure uniqueness
        for _ in range(10):
            cursor = await db.execute("SELECT id FROM deals WHERE deal_code = ?", (deal_code,))
            if not await cursor.fetchone():
                break
            deal_code = generate_deal_code()
        cursor = await db.execute(
            "INSERT INTO deals (creator_id, payment_type, amount, description, creator_role, deal_code) VALUES (?, ?, ?, ?, ?, ?)",
            (creator_id, payment_type, amount, description, creator_role, deal_code)
        )
        await db.commit()
        return cursor.lastrowid


async def get_deal(deal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE id = ?", (deal_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_deal_by_code(deal_code: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE deal_code = ?", (deal_code,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_user_deals(user_id: int, status: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        if status:
            cursor = await db.execute("SELECT * FROM deals WHERE (creator_id = ? OR partner_id = ?) AND status = ? ORDER BY created_at DESC", (user_id, user_id, status))
        else:
            cursor = await db.execute("SELECT * FROM deals WHERE creator_id = ? OR partner_id = ? ORDER BY created_at DESC", (user_id, user_id))
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_deals(limit: int = 500, offset: int = 0):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM deals ORDER BY datetime(created_at) DESC, id DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_pending_deals():
    """Получает сделки ожидающие гаранта (waiting_admin) для админ-панели"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE status = 'waiting_admin' AND admin_id IS NULL ORDER BY created_at ASC")
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_pending_deals():
    """Получает все незавершенные сделки (pending + waiting_admin) для админ-панели"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE status IN ('pending', 'waiting_admin') ORDER BY created_at ASC")
        return [dict(row) for row in await cursor.fetchall()]


async def get_admin_deals(admin_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE admin_id = ? AND status IN ('in_progress', 'waiting_confirm') ORDER BY created_at DESC", (admin_id,))
        return [dict(row) for row in await cursor.fetchall()]


async def assign_admin_to_deal(deal_id: int, admin_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE deals SET admin_id = ?, status = 'in_progress', updated_at = ? WHERE id = ?", (admin_id, datetime.now(), deal_id))
        await db.commit()


async def join_deal(deal_id: int, partner_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE deals SET partner_id = ?, status = 'waiting_admin', updated_at = ? WHERE id = ?", (partner_id, datetime.now(), deal_id))
        await db.commit()


async def complete_deal(deal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM deals WHERE id = ?", (deal_id,))
        deal = await cursor.fetchone()
        if deal:
            await db.execute("UPDATE deals SET status = 'completed', updated_at = ? WHERE id = ?", (datetime.now(), deal_id))
            await db.execute("UPDATE users SET deals_count = deals_count + 1, successful_deals = successful_deals + 1 WHERE user_id IN (?, ?)", (deal["creator_id"], deal["partner_id"]))
        await db.commit()


async def cancel_deal(deal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE deals SET status = 'cancelled', updated_at = ? WHERE id = ?", (datetime.now(), deal_id))
        await db.commit()


async def create_ticket(user_id: int, subject: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("INSERT INTO tickets (user_id, subject) VALUES (?, ?)", (user_id, subject))
        await db.commit()
        return cursor.lastrowid


async def get_ticket(ticket_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def get_user_tickets(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC", (user_id,))
        return [dict(row) for row in await cursor.fetchall()]


async def get_open_tickets():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT t.*, u.username, u.full_name FROM tickets t JOIN users u ON t.user_id = u.user_id WHERE t.status = 'open' ORDER BY t.created_at ASC")
        return [dict(row) for row in await cursor.fetchall()]


async def add_ticket_message(ticket_id: int, sender_id: int, message: str, is_admin: bool = False):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT INTO ticket_messages (ticket_id, sender_id, message, is_admin) VALUES (?, ?, ?, ?)", (ticket_id, sender_id, message, 1 if is_admin else 0))
        await db.commit()


async def get_ticket_messages(ticket_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC", (ticket_id,))
        return [dict(row) for row in await cursor.fetchall()]


async def close_ticket(ticket_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tickets SET status = 'closed' WHERE id = ?", (ticket_id,))
        await db.commit()


async def create_payment(user_id: int, amount: float, invoice_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("INSERT INTO payments (user_id, amount, invoice_id) VALUES (?, ?, ?)", (user_id, amount, invoice_id))
        await db.commit()
        return cursor.lastrowid


async def get_payment_by_invoice(invoice_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM payments WHERE invoice_id = ?", (invoice_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def complete_payment(invoice_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM payments WHERE invoice_id = ? AND status = 'pending'", (invoice_id,))
        payment = await cursor.fetchone()
        if payment:
            await db.execute("UPDATE payments SET status = 'completed' WHERE invoice_id = ?", (invoice_id,))
# ========== WITHDRAWALS ==========

async def create_withdrawal(user_id: int, amount: float, wallet_address: str, currency: str = "USDT"):
    """Создает запрос на вывод средств"""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO withdrawals (user_id, amount, currency, wallet_address, status) VALUES (?, ?, ?, ?, 'pending')",
            (user_id, amount, currency, wallet_address)
        )
        # Сразу списываем средства с баланса при создании заявки
        await db.execute("UPDATE users SET deposit = deposit - ? WHERE user_id = ?", (amount, user_id))
        await db.commit()
        return cursor.lastrowid


async def get_withdrawal(withdrawal_id: int):
    """Получает информацию о выводе"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def complete_withdrawal(withdrawal_id: int, transfer_id: str = None):
    """Завершает вывод средств (подтверждает)"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'", (withdrawal_id,))
        withdrawal = await cursor.fetchone()
        if withdrawal:
            await db.execute(
                "UPDATE withdrawals SET status = 'completed', transfer_id = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?",
                (transfer_id, withdrawal_id)
            )
            # Деньги уже списаны при создании, ничего делать не нужно
            await db.commit()
            return dict(withdrawal)
        return None


async def cancel_withdrawal(withdrawal_id: int):
    """Отменяет вывод средств и возвращает деньги"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM withdrawals WHERE id = ? AND status = 'pending'", (withdrawal_id,))
        withdrawal = await cursor.fetchone()
        if withdrawal:
            await db.execute("UPDATE withdrawals SET status = 'cancelled' WHERE id = ?", (withdrawal_id,))
            # Возвращаем деньги на баланс
            await db.execute("UPDATE users SET deposit = deposit + ? WHERE user_id = ?", (withdrawal['amount'], withdrawal['user_id']))
            await db.commit()


async def get_user_withdrawals(user_id: int):
    """Получает все выводы пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,)
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_pending_withdrawals():
    """Получает все ожидающие выводы"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT w.*, u.username, u.full_name FROM withdrawals w JOIN users u ON w.user_id = u.user_id WHERE w.status = 'pending' ORDER BY w.created_at ASC"
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_stats():
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT COUNT(*) FROM users")
        users_count = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT COUNT(*) FROM deals")
        deals_count = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT COUNT(*) FROM deals WHERE status = 'completed'")
        completed_deals = (await cursor.fetchone())[0]
        
        # Add fake stats
        cursor = await db.execute("SELECT value FROM settings WHERE key = 'fake_deals_count'")
        row = await cursor.fetchone()
        fake_deals = int(row[0]) if row else 0
        deals_count += fake_deals
        completed_deals += fake_deals

        cursor = await db.execute("SELECT COUNT(*) FROM deals WHERE status IN ('pending', 'waiting_admin', 'in_progress')")
        active_deals = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT COUNT(*) FROM deals WHERE status = 'pending'")
        pending_deals = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT COUNT(*) FROM deals WHERE status = 'waiting_admin' AND admin_id IS NULL")
        waiting_admin_deals = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT COUNT(*) FROM tickets WHERE status = 'open'")
        open_tickets = (await cursor.fetchone())[0]
        cursor = await db.execute("SELECT SUM(deposit) FROM users")
        total_deposit = (await cursor.fetchone())[0] or 0
        return {
            "users_count": users_count,
            "deals_count": deals_count,
            "completed_deals": completed_deals,
            "active_deals": active_deals,
            "pending_deals": pending_deals,
            "waiting_admin_deals": waiting_admin_deals,
            "open_tickets": open_tickets,
            "total_deposit": total_deposit
        }


async def add_fake_global_deals(amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("SELECT value FROM settings WHERE key = 'fake_deals_count'")
        row = await cursor.fetchone()
        current = int(row[0]) if row else 0
        
        new_val = current + amount
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('fake_deals_count', ?)", (str(new_val),))
        await db.commit()


# ========== REFERRAL SYSTEM ==========

REFERRAL_LEVELS = {
    'bronze': {'min_refs': 0, 'bonus_percent': 5, 'name': 'Бронза'},
    'silver': {'min_refs': 5, 'bonus_percent': 7, 'name': 'Серебро'},
    'gold': {'min_refs': 15, 'bonus_percent': 10, 'name': 'Золото'},
    'vip': {'min_refs': 50, 'bonus_percent': 15, 'name': 'VIP'}
}


async def create_referral(referrer_id: int, referred_id: int):
    """Создает запись о реферале"""
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "INSERT INTO referrals (referrer_id, referred_id) VALUES (?, ?)",
                (referrer_id, referred_id)
            )
            await db.execute(
                "UPDATE users SET referrer_id = ? WHERE user_id = ?",
                (referrer_id, referred_id)
            )
            await db.commit()
            return True
        except:
            return False


async def get_referral_by_referred(referred_id: int):
    """Получает реферал по ID приглашенного"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM referrals WHERE referred_id = ?",
            (referred_id,)
        )
        row = await cursor.fetchone()
        return dict(row) if row else None


async def activate_referral(referred_id: int):
    """Активирует реферала (после первой успешной сделки)"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE referrals SET status = 'active', activated_at = CURRENT_TIMESTAMP WHERE referred_id = ? AND status = 'pending'",
            (referred_id,)
        )
        await db.commit()


async def get_user_referrals(user_id: int):
    """Получает всех рефералов пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT r.*, u.username, u.full_name, u.successful_deals
            FROM referrals r
            LEFT JOIN users u ON r.referred_id = u.user_id
            WHERE r.referrer_id = ?
            ORDER BY r.created_at DESC
        """, (user_id,))
        return [dict(row) for row in await cursor.fetchall()]


async def get_referral_stats(user_id: int):
    """Получает статистику рефералов пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT COUNT(*) FROM referrals WHERE referrer_id = ?",
            (user_id,)
        )
        total = (await cursor.fetchone())[0]

        cursor = await db.execute(
            "SELECT COUNT(*) FROM referrals WHERE referrer_id = ? AND status = 'active'",
            (user_id,)
        )
        active = (await cursor.fetchone())[0]

        cursor = await db.execute(
            "SELECT referral_bonus, referral_level FROM users WHERE user_id = ?",
            (user_id,)
        )
        row = await cursor.fetchone()
        bonus = row[0] if row else 0
        level = row[1] if row else 'bronze'

        return {
            'total': total,
            'active': active,
            'bonus': bonus or 0,
            'level': level or 'bronze'
        }


async def add_referral_bonus(user_id: int, amount: float):
    """Добавляет бонус рефереру"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET referral_bonus = referral_bonus + ? WHERE user_id = ?",
            (amount, user_id)
        )
        await db.commit()


async def update_referral_level(user_id: int):
    """Обновляет уровень реферала на основе количества активных рефералов"""
    stats = await get_referral_stats(user_id)
    active_refs = stats['active']

    new_level = 'bronze'
    for level, data in sorted(REFERRAL_LEVELS.items(), key=lambda x: x[1]['min_refs'], reverse=True):
        if active_refs >= data['min_refs']:
            new_level = level
            break

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET referral_level = ? WHERE user_id = ?",
            (new_level, user_id)
        )
        await db.commit()


async def get_referral_leaderboard(limit: int = 10):
    """Получает топ рефереров"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("""
            SELECT u.user_id, u.username, u.full_name, u.referral_bonus, u.referral_level,
                   (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id = u.user_id AND r.status = 'active') as active_refs
            FROM users u
            WHERE (SELECT COUNT(*) FROM referrals r WHERE r.referrer_id = u.user_id) > 0
            ORDER BY active_refs DESC, u.referral_bonus DESC
            LIMIT ?
        """, (limit,))
        return [dict(row) for row in await cursor.fetchall()]


async def mark_referral_bonus_paid(referral_id: int):
    """Отмечает что бонус выплачен"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE referrals SET bonus_paid = 1 WHERE id = ?",
            (referral_id,)
        )
        await db.commit()


async def get_deals_waiting_partner():
    """Получает сделки ожидающие партнера (pending)"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM deals WHERE status = 'pending' ORDER BY created_at ASC"
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_garants():
    """Получает всех гарантов"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM users WHERE is_garant = 1 ORDER BY reputation_positive DESC"
        )
        return [dict(row) for row in await cursor.fetchall()]


async def ban_user(user_id: int, reason: str = None):
    """Блокирует пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_banned = 1, ban_reason = ? WHERE user_id = ?",
            (reason, user_id)
        )
        await db.commit()


async def unban_user(user_id: int):
    """Разблокирует пользователя"""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE users SET is_banned = 0, ban_reason = NULL WHERE user_id = ?",
            (user_id,)
        )
        await db.commit()


async def is_user_banned(user_id: int) -> bool:
    """Проверяет, заблокирован ли пользователь"""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "SELECT is_banned FROM users WHERE user_id = ?",
            (user_id,)
        )
        row = await cursor.fetchone()
        return row[0] == 1 if row else False


async def get_banned_users():
    """Получает список заблокированных пользователей"""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(
            "SELECT * FROM users WHERE is_banned = 1 ORDER BY user_id DESC"
        )
        return [dict(row) for row in await cursor.fetchall()]


async def create_appeal(user_id: int, message: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "INSERT INTO appeals (user_id, message, status) VALUES (?, ?, 'pending')",
            (user_id, message)
        )
        await db.commit()
        return cursor.lastrowid


async def get_pending_appeals():
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM appeals WHERE status = 'pending' ORDER BY created_at ASC")
        return [dict(row) for row in await cursor.fetchall()]


async def get_appeal(appeal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM appeals WHERE id = ?", (appeal_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def process_appeal(appeal_id: int, admin_id: int, status: str, admin_note: str = None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE appeals SET status = ?, processed_at = CURRENT_TIMESTAMP, admin_id = ?, admin_note = ? WHERE id = ?",
            (status, admin_id, admin_note, appeal_id)
        )
        await db.commit()


async def clear_appeal_attachment(appeal_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE appeals SET attachment_file_id = NULL WHERE id = ?", (appeal_id,))
        await db.commit()

async def update_user_deals(user_id: int, amount: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('UPDATE users SET deals_count = deals_count + ?, successful_deals = successful_deals + ? WHERE user_id = ?', (amount, amount, user_id))
        await db.commit()

async def add_custom_fake_review(
    to_user_id: int,
    fake_username: str,
    comment: str,
    created_at: str,
    is_positive: bool = True,
):
    """Добавляет кастомный "накрученный" отзыв для пользователя."""
    async with aiosqlite.connect(DB_PATH) as db:
        rating = 5 if is_positive else 1

        await db.execute(
            "INSERT INTO reviews (deal_id, from_user_id, to_user_id, rating, comment, is_positive, fake_username, created_at) "
            "VALUES (0, 0, ?, ?, ?, ?, ?, ?)",
            (to_user_id, rating, comment, 1 if is_positive else 0, fake_username, created_at)
        )

        if is_positive:
            await db.execute(
                "UPDATE users SET reputation_positive = reputation_positive + 1 WHERE user_id = ?",
                (to_user_id,)
            )
        else:
            await db.execute(
                "UPDATE users SET reputation_negative = reputation_negative + 1 WHERE user_id = ?",
                (to_user_id,)
            )

        await db.commit()


# ============ VERIFICATION ============

async def create_verification_request(user_id: int, level: str, req_type: str, currency: str = None):
    """Create a verification request (apply or purchase)."""
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "SELECT id FROM verification_requests WHERE user_id = ? AND status = 'pending'",
            (user_id,)
        )
        existing = await cursor.fetchone()
        if existing:
            return None
        cursor = await conn.execute(
            "INSERT INTO verification_requests (user_id, level, type, currency) VALUES (?, ?, ?, ?)",
            (user_id, level, req_type, currency)
        )
        await conn.commit()
        return cursor.lastrowid


async def get_pending_verification_requests():
    """Get all pending verification requests for admin."""
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("""
            SELECT vr.*, u.username, u.full_name, u.deals_count, u.successful_deals, u.deposit
            FROM verification_requests vr
            JOIN users u ON u.user_id = vr.user_id
            WHERE vr.status = 'pending'
            ORDER BY vr.created_at ASC
        """)
        return [dict(row) for row in await cursor.fetchall()]


async def process_verification_request(request_id: int, admin_id: int, status: str, note: str = None):
    """Process a verification request (approve/reject)."""
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("SELECT * FROM verification_requests WHERE id = ?", (request_id,))
        req = await cursor.fetchone()
        if not req:
            return False
        req = dict(req)
        await conn.execute(
            "UPDATE verification_requests SET status = ?, processed_at = CURRENT_TIMESTAMP, admin_id = ?, admin_note = ? WHERE id = ?",
            (status, admin_id, note, request_id)
        )
        if status == 'approved':
            await conn.execute(
                "UPDATE users SET verification_level = ?, is_verified = 1 WHERE user_id = ?",
                (req['level'], req['user_id'])
            )
        await conn.commit()
        return True


async def get_user_verification(user_id: int):
    """Get user's verification level and pending request if any."""
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("SELECT verification_level FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        level = dict(row).get('verification_level', 'none') if row else 'none'
        cursor = await conn.execute(
            "SELECT * FROM verification_requests WHERE user_id = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1",
            (user_id,)
        )
        pending = await cursor.fetchone()
        return {
            'level': level or 'none',
            'pending': dict(pending) if pending else None
        }


# ============ DEAL MESSAGES (CHAT) ============

async def add_deal_message(deal_id: int, sender_id: int, message: str, image_url: str = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "INSERT INTO deal_messages (deal_id, sender_id, message, image_url) VALUES (?, ?, ?, ?)",
            (deal_id, sender_id, message, image_url)
        )
        await conn.commit()
        return cursor.lastrowid


async def mark_chat_read(user_id: int, deal_id: int, last_msg_id: int):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "INSERT INTO chat_read_status (user_id, deal_id, last_read_id) VALUES (?, ?, ?) "
            "ON CONFLICT(user_id, deal_id) DO UPDATE SET last_read_id = MAX(last_read_id, excluded.last_read_id)",
            (user_id, deal_id, last_msg_id)
        )
        await conn.commit()


async def get_unread_count(user_id: int):
    """Get total unread messages count across all deals for a user."""
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "SELECT COALESCE(SUM(cnt), 0) FROM ("
            "  SELECT COUNT(*) as cnt FROM deal_messages dm "
            "  INNER JOIN deals d ON d.id = dm.deal_id "
            "  LEFT JOIN chat_read_status crs ON crs.user_id = ? AND crs.deal_id = dm.deal_id "
            "  WHERE (d.creator_id = ? OR d.partner_id = ? OR d.admin_id = ?) "
            "  AND dm.sender_id != ? "
            "  AND dm.id > COALESCE(crs.last_read_id, 0)"
            ")",
            (user_id, user_id, user_id, user_id, user_id)
        )
        row = await cursor.fetchone()
        return row[0] if row else 0


async def get_deal_messages(deal_id: int, limit: int = 100):
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute(
            "SELECT dm.*, u.username, u.full_name FROM deal_messages dm "
            "LEFT JOIN users u ON u.user_id = dm.sender_id "
            "WHERE dm.deal_id = ? ORDER BY dm.created_at ASC LIMIT ?",
            (deal_id, limit)
        )
        return [dict(row) for row in await cursor.fetchall()]


# ============ NEWS ============

async def update_last_active(user_id: int):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "UPDATE users SET last_active = CURRENT_TIMESTAMP WHERE user_id = ?",
            (user_id,)
        )
        await conn.commit()


async def set_user_pin(user_id: int, pin_hash: str):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "UPDATE users SET pin_hash = ? WHERE user_id = ?",
            (pin_hash, user_id)
        )
        await conn.commit()


async def get_all_users(limit: int = 100, offset: int = 0):
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute(
            "SELECT user_id, username, full_name, deposit, reputation_positive, reputation_negative, "
            "deals_count, successful_deals, is_garant, is_banned, verification_level, last_active, created_at "
            "FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_active_news(limit: int = 5):
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute(
            "SELECT n.*, u.username as author_username, u.full_name as author_name "
            "FROM news n LEFT JOIN users u ON u.user_id = n.author_id "
            "WHERE n.is_active = 1 ORDER BY n.created_at DESC LIMIT ?",
            (limit,)
        )
        return [dict(row) for row in await cursor.fetchall()]


async def get_all_news():
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("SELECT * FROM news ORDER BY created_at DESC")
        return [dict(row) for row in await cursor.fetchall()]


async def create_news(title: str, content: str, emoji: str = '📢', image_url: str = None, author_id: int = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "INSERT INTO news (title, content, emoji, image_url, author_id) VALUES (?, ?, ?, ?, ?)",
            (title, content, emoji, image_url, author_id)
        )
        await conn.commit()
        return cursor.lastrowid


async def update_news(news_id: int, title: str, content: str, emoji: str, image_url: str = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "UPDATE news SET title = ?, content = ?, emoji = ?, image_url = ? WHERE id = ?",
            (title, content, emoji, image_url, news_id)
        )
        await conn.commit()


async def toggle_news(news_id: int):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "UPDATE news SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?",
            (news_id,)
        )
        await conn.commit()


async def delete_news(news_id: int):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute("DELETE FROM news WHERE id = ?", (news_id,))
        await conn.commit()


# ===== COMPLAINTS =====
async def create_complaint(reporter_id: int, reported_user: str, subject: str, details: str, photo_url: str = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "INSERT INTO complaints (reporter_id, reported_user, subject, details, photo_url) VALUES (?, ?, ?, ?, ?)",
            (reporter_id, reported_user, subject, details, photo_url)
        )
        await conn.commit()
        return cursor.lastrowid


async def get_complaints():
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        cursor = await conn.execute("SELECT * FROM complaints ORDER BY created_at DESC")
        return [dict(row) for row in await cursor.fetchall()]


# ===== DISPUTES =====
async def create_dispute(deal_id: int, user_id: int, details: str, photo_url: str = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        cursor = await conn.execute(
            "INSERT INTO disputes (deal_id, user_id, details, photo_url) VALUES (?, ?, ?, ?)",
            (deal_id, user_id, details, photo_url)
        )
        await conn.commit()
        return cursor.lastrowid


async def get_disputes(status: str = None):
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        if status:
            rows = await conn.execute_fetchall(
                "SELECT d.*, u.username, u.full_name FROM disputes d LEFT JOIN users u ON d.user_id = u.user_id WHERE d.status = ? ORDER BY d.created_at DESC", (status,)
            )
        else:
            rows = await conn.execute_fetchall(
                "SELECT d.*, u.username, u.full_name FROM disputes d LEFT JOIN users u ON d.user_id = u.user_id ORDER BY d.created_at DESC"
            )
        return [dict(r) for r in rows]


async def update_dispute_status(dispute_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute("UPDATE disputes SET status = ? WHERE id = ?", (status, dispute_id))
        await conn.commit()


# ===== TRUST STATUS =====
async def set_trust_status(user_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as conn:
        await conn.execute(
            "UPDATE users SET trust_status = ? WHERE user_id = ?",
            (status, user_id)
        )
        await conn.commit()


async def get_user_trust(query: str):
    """Get user trust info by user_id or @username"""
    async with aiosqlite.connect(DB_PATH) as conn:
        conn.row_factory = aiosqlite.Row
        q = query.lstrip('@')
        # Try as user_id first
        try:
            uid = int(q)
            cursor = await conn.execute(
                "SELECT user_id, username, full_name, deals_count, successful_deals, "
                "reputation_positive, reputation_negative, trust_status FROM users WHERE user_id = ?",
                (uid,)
            )
        except ValueError:
            cursor = await conn.execute(
                "SELECT user_id, username, full_name, deals_count, successful_deals, "
                "reputation_positive, reputation_negative, trust_status FROM users WHERE LOWER(username) = LOWER(?)",
                (q,)
            )
        row = await cursor.fetchone()
        return dict(row) if row else None
