import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x]

CRYPTOBOT_TOKEN = os.getenv("CRYPTOBOT_TOKEN", "")

BANNER_PATH = "images/banner.png"

GARANT_FEE = 5

DEFAULT_MIN_DEPOSIT = 100
DEFAULT_MIN_WITHDRAWAL = 10

# Data storage (Railway Volume or local)
DATA_DIR = os.getenv("DATA_DIR", ".")
DB_PATH = os.path.join(DATA_DIR, "garant_bot.db")

# Mini App
WEBAPP_URL = os.getenv("WEBAPP_URL", "")  # e.g. https://yourdomain.com
WEBAPP_PORT = int(os.getenv("WEBAPP_PORT", "8080"))
BOT_USERNAME = os.getenv("BOT_USERNAME", "")
