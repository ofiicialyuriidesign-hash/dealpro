from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton,
    WebAppInfo
)
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from config import WEBAPP_URL


def language_select_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🇷🇺 Русский", callback_data="set_lang_ru"),
        InlineKeyboardButton(text="🇺🇦 Українська", callback_data="set_lang_uk"),
        InlineKeyboardButton(text="🇬🇧 English", callback_data="set_lang_en")
    )
    return builder.as_markup()


def captcha_kb(correct_icon: str, all_icons: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for i in range(0, len(all_icons), 5):
        row_icons = all_icons[i:i+5]
        builder.row(*[InlineKeyboardButton(text=icon, callback_data=f"captcha_{icon}") for icon in row_icons])
    return builder.as_markup()


def main_menu_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="📁 Manage requisites"))
        builder.row(KeyboardButton(text="📝 Create deal"))
        builder.row(KeyboardButton(text="👥 Users"))
        builder.row(KeyboardButton(text="📞 Support"), KeyboardButton(text="👤 Profile"))
        builder.row(KeyboardButton(text="🌐 Language"))
    else:
        builder.row(KeyboardButton(text="📁 Управление реквизитами"))
        builder.row(KeyboardButton(text="📝 Создать сделку"))
        builder.row(KeyboardButton(text="👥 Пользователи"))
        builder.row(KeyboardButton(text="📞 Поддержка"), KeyboardButton(text="👤 Профиль"))
        builder.row(KeyboardButton(text="🌐 Язык"))
    return builder.as_markup(resize_keyboard=True)


def users_menu_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="🛡 Escrow agents"))
        builder.row(KeyboardButton(text="🏆 Top reputation"))
        builder.row(KeyboardButton(text="🔍 Find user"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        builder.row(KeyboardButton(text="🛡 Гаранты"))
        builder.row(KeyboardButton(text="🏆 Топ репутации"))
        builder.row(KeyboardButton(text="🔍 Найти пользователя"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def requisites_menu_kb(card: str = None, ton: str = None, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        card_text = "✏️ Edit card number" if card else "💳 Add card number"
        ton_text = "✏️ Edit TON address" if ton else "🪙 Add TON address"
        menu_text = "🏠 Return to menu"
    else:
        card_text = "✏️ Изменить номер карты" if card else "💳 Добавить номер карты"
        ton_text = "✏️ Изменить адрес TON" if ton else "🪙 Добавить адрес TON"
        menu_text = "🏠 Вернуться в меню"
    builder.row(KeyboardButton(text=card_text))
    builder.row(KeyboardButton(text=ton_text))
    builder.row(KeyboardButton(text=menu_text))
    return builder.as_markup(resize_keyboard=True)


def payment_type_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="💳 Card [RU]"), KeyboardButton(text="💳 Card [UA]"))
        builder.row(KeyboardButton(text="💳 Card [KZ]"), KeyboardButton(text="💳 Card [BY]"))
        builder.row(KeyboardButton(text="💎 Wallet [USDT]"), KeyboardButton(text="🪙 Wallet [TON]"))
        builder.row(KeyboardButton(text="⭐ Stars"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        builder.row(KeyboardButton(text="💳 На карту [РУ]"), KeyboardButton(text="💳 На карту [УК]"))
        builder.row(KeyboardButton(text="💳 На карту [КЗ]"), KeyboardButton(text="💳 На карту [РБ]"))
        builder.row(KeyboardButton(text="💎 На кошелёк [USDT]"), KeyboardButton(text="🪙 На кошелёк [TON]"))
        builder.row(KeyboardButton(text="⭐ Звезды"))
        builder.row(KeyboardButton(text="🏠 Вернуться в меню"))
    return builder.as_markup(resize_keyboard=True)


def role_select_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="🛒 I am buyer"))
        builder.row(KeyboardButton(text="💰 I am seller"))
        builder.row(KeyboardButton(text="🔙 Back"))
    else:
        builder.row(KeyboardButton(text="🛒 Я покупатель"))
        builder.row(KeyboardButton(text="💰 Я продавец"))
        builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)


def back_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="🔙 Back" if lang == 'en' else "🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)


def cancel_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="❌ Cancel" if lang == 'en' else "❌ Отмена"))
    return builder.as_markup(resize_keyboard=True)


def support_kb(has_open_ticket: bool = False, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        if has_open_ticket:
            builder.row(KeyboardButton(text="📋 My tickets"))
        builder.row(KeyboardButton(text="📝 Create ticket"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        if has_open_ticket:
            builder.row(KeyboardButton(text="📋 Мои тикеты"))
        builder.row(KeyboardButton(text="📝 Создать тикет"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def profile_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="📋 My deals"))
        builder.row(KeyboardButton(text="💰 Top up deposit"), KeyboardButton(text="💸 Withdraw"))
        builder.row(KeyboardButton(text="⭐ My reputation"))
        builder.row(KeyboardButton(text="👥 Referrals"))
        builder.row(KeyboardButton(text="📊 Statistics"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        builder.row(KeyboardButton(text="📋 Мои сделки"))
        builder.row(KeyboardButton(text="💰 Пополнить депозит"), KeyboardButton(text="💸 Вывести средства"))
        builder.row(KeyboardButton(text="⭐ Моя репутация"))
        builder.row(KeyboardButton(text="👥 Рефералы"))
        builder.row(KeyboardButton(text="📊 Статистика"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def referral_menu_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="📋 My referrals"))
        builder.row(KeyboardButton(text="🏆 Top referrers"))
        builder.row(KeyboardButton(text="📖 Rules"))
        builder.row(KeyboardButton(text="👤 Profile"))
    else:
        builder.row(KeyboardButton(text="📋 Мои рефералы"))
        builder.row(KeyboardButton(text="🏆 Топ рефереров"))
        builder.row(KeyboardButton(text="📖 Правила"))
        builder.row(KeyboardButton(text="👤 Профиль"))
    return builder.as_markup(resize_keyboard=True)


def referral_list_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="👥 Referrals"))
        builder.row(KeyboardButton(text="👤 Profile"))
    else:
        builder.row(KeyboardButton(text="👥 Рефералы"))
        builder.row(KeyboardButton(text="👤 Профиль"))
    return builder.as_markup(resize_keyboard=True)


def deposit_menu_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="💳 Пополнить через CryptoBot"))
    builder.row(KeyboardButton(text="🔙 Назад" if lang == 'ru' else "🔙 Back"))
    return builder.as_markup(resize_keyboard=True)


def reputation_filter_reply_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="📋 ALL"))
        builder.row(KeyboardButton(text="👍 Positive"), KeyboardButton(text="👎 Negative"))
        builder.row(KeyboardButton(text="✅ Last positive"), KeyboardButton(text="❌ Last negative"))
        builder.row(KeyboardButton(text="🔙 Back"))
    else:
        builder.row(KeyboardButton(text="📋 ВСЕ"))
        builder.row(KeyboardButton(text="👍 Положительные"), KeyboardButton(text="👎 Отрицательные"))
        builder.row(KeyboardButton(text="✅ Последний положит."), KeyboardButton(text="❌ Последний отрицат."))
        builder.row(KeyboardButton(text="🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)


def deal_actions_reply_kb(deal: dict, user_id: int, is_admin: bool = False, is_garant: bool = False, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        if deal.get('creator_id'):
            builder.row(KeyboardButton(text="👤 Creator profile"))
        if deal.get('partner_id'):
            builder.row(KeyboardButton(text="👤 Partner profile"))
        if deal['status'] == 'in_progress':
            if is_admin or is_garant:
                builder.row(KeyboardButton(text="✅ Complete deal"))
                builder.row(KeyboardButton(text="❌ Cancel deal"))
            builder.row(KeyboardButton(text="💬 Message participants"))
        if deal['status'] in ('pending', 'waiting_admin'):
            is_creator = deal.get('creator_id') == user_id
            is_partner = deal.get('partner_id') == user_id
            if (is_creator or is_partner) and not is_admin:
                builder.row(KeyboardButton(text="❌ Cancel deal"))
        if deal['status'] == 'completed':
            builder.row(KeyboardButton(text="⭐ Leave review"))
        builder.row(KeyboardButton(text="🔙 To deals"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        if deal.get('creator_id'):
            builder.row(KeyboardButton(text="👤 Профиль создателя"))
        if deal.get('partner_id'):
            builder.row(KeyboardButton(text="👤 Профиль партнера"))
        if deal['status'] == 'in_progress':
            if is_admin or is_garant:
                builder.row(KeyboardButton(text="✅ Завершить сделку"))
                builder.row(KeyboardButton(text="❌ Отменить сделку"))
            builder.row(KeyboardButton(text="💬 Написать участникам"))
        if deal['status'] in ('pending', 'waiting_admin'):
            is_creator = deal.get('creator_id') == user_id
            is_partner = deal.get('partner_id') == user_id
            if (is_creator or is_partner) and not is_admin:
                builder.row(KeyboardButton(text="❌ Отменить сделку"))
        if deal['status'] == 'completed':
            builder.row(KeyboardButton(text="⭐ Оставить отзыв"))
        builder.row(KeyboardButton(text="🔙 К сделкам"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def join_deal_reply_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="✅ Join deal"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    elif lang == 'uk':
        builder.row(KeyboardButton(text="✅ Приєднатися до угоди"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    else:
        builder.row(KeyboardButton(text="✅ Присоединиться к сделке"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def garant_deal_actions_reply_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if lang == 'en':
        builder.row(KeyboardButton(text="✅ Complete deal"))
        builder.row(KeyboardButton(text="❌ Cancel deal"))
        builder.row(KeyboardButton(text="💬 Message participants"))
        builder.row(KeyboardButton(text="🔙 To my deals"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        builder.row(KeyboardButton(text="✅ Завершить сделку"))
        builder.row(KeyboardButton(text="❌ Отменить сделку"))
        builder.row(KeyboardButton(text="💬 Написать участникам"))
        builder.row(KeyboardButton(text="🔙 К моим сделкам"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def my_deals_reply_kb(deals: list, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    for deal in deals[:10]:
        status_emoji = {'pending': '⏳', 'waiting_admin': '👨‍💼', 'in_progress': '🔄',
                       'waiting_confirm': '✋', 'completed': '✅', 'cancelled': '❌'}.get(deal['status'], '❓')
        if lang == 'en':
            builder.row(KeyboardButton(text=f"{status_emoji} Deal #{deal['id']} - {deal['amount']}₽"))
        else:
            builder.row(KeyboardButton(text=f"{status_emoji} Сделка #{deal['id']} - {deal['amount']}₽"))
    if lang == 'en':
        builder.row(KeyboardButton(text="🗑 Close deal"))
        builder.row(KeyboardButton(text="🏠 Menu"))
    else:
        builder.row(KeyboardButton(text="🗑 Закрыть сделку"))
        builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def select_deal_to_close_kb(deals: list, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    closable_deals = [d for d in deals if d['status'] in ('pending', 'waiting_admin')]
    for deal in closable_deals[:10]:
        if lang == 'en':
            builder.row(KeyboardButton(text=f"❌ Close #{deal['id']} - {deal['amount']}₽"))
        else:
            builder.row(KeyboardButton(text=f"❌ Закрыть #{deal['id']} - {deal['amount']}₽"))
    builder.row(KeyboardButton(text="🔙 Back" if lang == 'en' else "🔙 Назад"))
    return builder.as_markup(resize_keyboard=True)


def admin_menu_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="📊 Статистика"))
    builder.row(KeyboardButton(text="💸 Выводы"))
    builder.row(KeyboardButton(text="📣 Рассылка"), KeyboardButton(text="📣 Апелляции"))
    builder.row(KeyboardButton(text="🔄 Ожидающие сделки"))
    builder.row(KeyboardButton(text="⏳ Ожидают партнера"))
    builder.row(KeyboardButton(text="📋 Мои активные сделки"))
    builder.row(KeyboardButton(text="🎫 Открытые тикеты"))
    builder.row(KeyboardButton(text="🛡 Выдать гаранта"))
    builder.row(KeyboardButton(text="⚙️ Настройки"))
    builder.row(KeyboardButton(text="🔧 Накрутка"))
    builder.row(KeyboardButton(text="🏠 В меню"))
    return builder.as_markup(resize_keyboard=True)


def admin_settings_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="💰 Мин. сумма депозита"))
    builder.row(KeyboardButton(text="🚫 Заблокировать пользователя"))
    builder.row(KeyboardButton(text="✅ Разблокировать пользователя"))
    builder.row(KeyboardButton(text="📋 Список заблокированных"))
    builder.row(KeyboardButton(text="🖼 Управление баннером"))
    builder.row(KeyboardButton(text="👁Пользователи сервиса"))
    builder.row(KeyboardButton(text="🔙 Админ панель"))
    return builder.as_markup(resize_keyboard=True)


def admin_banner_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="📤 Загрузить баннер"))
    builder.row(KeyboardButton(text="🗑 Удалить баннер"))
    builder.row(KeyboardButton(text="🔙 Настройки"))
    return builder.as_markup(resize_keyboard=True)


def admin_boost_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="💬 Накрутить отзывы"))
    builder.row(KeyboardButton(text="💰 Накрутить депозит"))
    builder.row(KeyboardButton(text="⭐ Накрутить репутацию"))
    builder.row(KeyboardButton(text="📦 Накрутить сделки"))
    builder.row(KeyboardButton(text="🗑 Очистить отзывы"))
    builder.row(KeyboardButton(text="🛡 Назначить гарантом"))
    builder.row(KeyboardButton(text="🔙 Админ панель"))
    return builder.as_markup(resize_keyboard=True)


def broadcast_attach_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="➡️ Пропустить"))
    builder.row(KeyboardButton(text="❌ Отмена"))
    return builder.as_markup(resize_keyboard=True)


def broadcast_confirm_kb() -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.row(KeyboardButton(text="✅ Да"), KeyboardButton(text="❌ Нет"))
    return builder.as_markup(resize_keyboard=True)


def withdraw_wallet_kb(saved_wallet: str = None, lang: str = 'ru') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    if saved_wallet:
        if lang == 'en':
            builder.row(KeyboardButton(text=f"Use: {saved_wallet}"))
            builder.row(KeyboardButton(text="✏️ Enter another wallet"))
        else:
            builder.row(KeyboardButton(text=f"Использовать: {saved_wallet}"))
            builder.row(KeyboardButton(text="✏️ Ввести другой кошелек"))
    builder.row(KeyboardButton(text="❌ Cancel" if lang == 'en' else "❌ Отмена"))
    return builder.as_markup(resize_keyboard=True)


def reputation_filter_kb(user_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="📋 ВСЕ", callback_data=f"rep_all_{user_id}"))
    builder.row(
        InlineKeyboardButton(text="👍 Положительные", callback_data=f"rep_positive_{user_id}"),
        InlineKeyboardButton(text="👎 Отрицательные", callback_data=f"rep_negative_{user_id}")
    )
    builder.row(
        InlineKeyboardButton(text="✅ Последний положител.", callback_data=f"rep_last_positive_{user_id}"),
        InlineKeyboardButton(text="❌ Последний отрицател.", callback_data=f"rep_last_negative_{user_id}")
    )
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data="back_users_menu"))
    return builder.as_markup()


def user_profile_kb(user_id: int, back_callback: str = "back_users_menu") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="⭐ Посмотреть репутацию", callback_data=f"view_reputation_{user_id}"))
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data=back_callback))
    return builder.as_markup()


def deal_created_kb(deal_id: int, invite_link: str = None, bot_username: str = None) -> InlineKeyboardMarkup:
    from urllib.parse import quote
    builder = InlineKeyboardBuilder()
    if invite_link:
        share_text = f"🤝 Приглашение в сделку #{deal_id}"
        share_url = f"https://t.me/share/url?url={quote(invite_link)}&text={quote(share_text)}"
        builder.row(InlineKeyboardButton(text="📤 Поделиться ссылкой", url=share_url))
    builder.row(InlineKeyboardButton(text="🏠 В меню", callback_data="back_main_menu"))
    return builder.as_markup()


def join_deal_kb(deal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Присоединиться к сделке", callback_data=f"join_deal_{deal_id}"))
    return builder.as_markup()


def my_deals_kb(deals: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        status_emoji = {'pending': '⏳', 'waiting_admin': '👨‍💼', 'in_progress': '🔄',
                       'waiting_confirm': '✋', 'completed': '✅', 'cancelled': '❌'}.get(deal['status'], '❓')
        builder.row(InlineKeyboardButton(
            text=f"{status_emoji} Сделка #{deal['id']} - {deal['amount']}₽",
            callback_data=f"view_deal_{deal['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🏠 В меню", callback_data="back_main_menu"))
    return builder.as_markup()


def deal_view_kb(deal: dict, user_id: int, is_admin: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if deal.get('creator_id'):
        builder.row(InlineKeyboardButton(text="👤 Профиль создателя", callback_data=f"deal_user_{deal['creator_id']}_{deal['id']}"))
    if deal.get('partner_id'):
        builder.row(InlineKeyboardButton(text="👤 Профиль партнера", callback_data=f"deal_user_{deal['partner_id']}_{deal['id']}"))
    if deal['status'] == 'in_progress':
        if is_admin:
            builder.row(InlineKeyboardButton(text="✅ Завершить сделку", callback_data=f"admin_complete_{deal['id']}"))
            builder.row(InlineKeyboardButton(text="❌ Отменить сделку", callback_data=f"admin_cancel_{deal['id']}"))
            builder.row(InlineKeyboardButton(text="💬 Написать участникам", callback_data=f"admin_message_{deal['id']}"))
        else:
            builder.row(InlineKeyboardButton(text="💬 Написать участникам", callback_data=f"user_message_{deal['id']}"))
    if deal['status'] in ('pending', 'waiting_admin'):
        is_creator = deal.get('creator_id') == user_id
        is_partner = deal.get('partner_id') == user_id
        if (is_creator or is_partner) and not is_admin:
            builder.row(InlineKeyboardButton(text="❌ Отменить сделку", callback_data=f"user_cancel_deal_{deal['id']}"))
    if deal['status'] == 'completed':
        builder.row(InlineKeyboardButton(text="⭐ Оставить отзыв", callback_data=f"leave_review_{deal['id']}"))
    builder.row(InlineKeyboardButton(text="🔙 К сделкам", callback_data="back_my_deals"))
    builder.row(InlineKeyboardButton(text="🏠 В меню", callback_data="back_main_menu"))
    return builder.as_markup()


def tickets_list_kb(tickets: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for ticket in tickets[:10]:
        status_emoji = "🟢" if ticket['status'] == 'open' else "🔴"
        builder.row(InlineKeyboardButton(
            text=f"{status_emoji} #{ticket['id']}: {ticket['subject'][:20]}...",
            callback_data=f"view_ticket_{ticket['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data="back_support"))
    return builder.as_markup()


def ticket_actions_kb(ticket_id: int, is_admin: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="💬 Ответить", callback_data=f"reply_ticket_{ticket_id}"))
    if is_admin:
        builder.row(InlineKeyboardButton(text="✅ Закрыть тикет", callback_data=f"close_ticket_{ticket_id}"))
    builder.row(InlineKeyboardButton(text="🔙 К тикетам", callback_data="back_my_tickets"))
    return builder.as_markup()


def check_payment_kb(invoice_id: str) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🔄 Проверить оплату", callback_data=f"check_pay_{invoice_id}"))
    builder.row(InlineKeyboardButton(text="🔙 Отмена", callback_data="back_profile"))
    return builder.as_markup()


def confirm_withdrawal_kb(withdrawal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Подтвердить вывод", callback_data=f"confirm_withdraw_{withdrawal_id}"))
    builder.row(InlineKeyboardButton(text="❌ Отменить", callback_data="cancel_withdraw"))
    return builder.as_markup()


def admin_withdrawals_kb(withdrawals: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for w in withdrawals[:10]:
        builder.row(InlineKeyboardButton(
            text=f"💸 #{w['id']} | {w['amount']} USDT | @{w['username']}",
            callback_data=f"admin_view_withdraw_{w['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Админ панель", callback_data="back_admin_panel"))
    return builder.as_markup()


def admin_withdrawal_action_kb(withdrawal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Подтвердить (Отправлено)", callback_data=f"admin_confirm_withdraw_{withdrawal_id}"))
    builder.row(InlineKeyboardButton(text="❌ Отклонить (Вернуть)", callback_data=f"admin_reject_withdraw_{withdrawal_id}"))
    builder.row(InlineKeyboardButton(text="🔙 К списку", callback_data="admin_withdrawals"))
    return builder.as_markup()


def review_rating_kb(deal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="👍 Положительный", callback_data=f"review_pos_{deal_id}"),
        InlineKeyboardButton(text="👎 Отрицательный", callback_data=f"review_neg_{deal_id}")
    )
    builder.row(InlineKeyboardButton(text="❌ Отмена", callback_data=f"view_deal_{deal_id}"))
    return builder.as_markup()


def admin_pending_deals_kb(deals: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        builder.row(InlineKeyboardButton(
            text=f"📝 Сделка #{deal['id']} - {deal['amount']}₽",
            callback_data=f"admin_view_deal_{deal['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Админ панель", callback_data="back_admin_panel"))
    return builder.as_markup()


def admin_my_active_deals_kb(deals: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        status_emoji = {'in_progress': '🔄', 'waiting_confirm': '✋'}.get(deal['status'], '❓')
        builder.row(InlineKeyboardButton(
            text=f"{status_emoji} Сделка #{deal['id']} - {deal['amount']}₽",
            callback_data=f"garant_manage_deal_{deal['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Админ панель", callback_data="back_admin_panel"))
    return builder.as_markup()


def admin_take_deal_kb(deal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Взять сделку", callback_data=f"admin_take_deal_{deal_id}"))
    builder.row(InlineKeyboardButton(text="🔙 Назад", callback_data="back_admin_pending_deals"))
    return builder.as_markup()


def admin_deal_actions_kb(deal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ Завершить сделку", callback_data=f"admin_complete_{deal_id}"))
    builder.row(InlineKeyboardButton(text="❌ Отменить сделку", callback_data=f"admin_cancel_{deal_id}"))
    builder.row(InlineKeyboardButton(text="💬 Написать участникам", callback_data=f"admin_message_{deal_id}"))
    builder.row(InlineKeyboardButton(text="🔙 К моим сделкам", callback_data="back_admin_my_deals"))
    return builder.as_markup()


def admin_open_tickets_kb(tickets: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for ticket in tickets[:10]:
        builder.row(InlineKeyboardButton(
            text=f"🎫 #{ticket['id']} от @{ticket['username'] or 'user'}: {ticket['subject'][:15]}...",
            callback_data=f"admin_ticket_{ticket['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Админ панель", callback_data="back_admin_panel"))
    return builder.as_markup()


def admin_waiting_partner_deals_kb(deals: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for deal in deals[:10]:
        builder.row(InlineKeyboardButton(
            text=f"⏳ Сделка #{deal['id']} - {deal['amount']}₽",
            callback_data=f"admin_view_pending_{deal['id']}"
        ))
    builder.row(InlineKeyboardButton(text="🔙 Админ панель", callback_data="back_admin_panel"))
    return builder.as_markup()


def admin_pending_deal_actions_kb(deal_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="❌ Закрыть сделку", callback_data=f"admin_close_pending_{deal_id}"))
    builder.row(InlineKeyboardButton(text="🔙 К списку", callback_data="back_waiting_partner"))
    return builder.as_markup()


def requisites_kb(card: str = None, ton: str = None, lang: str = 'ru') -> ReplyKeyboardMarkup:
    return requisites_menu_kb(card, ton, lang)


def webapp_inline_kb(lang: str = 'ru') -> ReplyKeyboardMarkup:
    """Reply keyboard with one big Mini App button."""
    builder = ReplyKeyboardBuilder()
    if WEBAPP_URL:
        builder.row(KeyboardButton(text="DEALPRO SERVICE", web_app=WebAppInfo(url=WEBAPP_URL)))
    return builder.as_markup(resize_keyboard=True)
