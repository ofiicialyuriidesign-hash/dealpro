import asyncio
import logging
import os
import sys
from datetime import datetime

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.session.aiohttp import AiohttpSession

from config import BOT_TOKEN, WEBAPP_PORT
from database import init_db
from handlers import setup_routers


async def run_api_server():
    """Start the FastAPI Mini App server."""
    import uvicorn
    from api.server import app as fastapi_app

    # PORT env var is set by Railway/Render/Heroku automatically
    port = int(os.getenv("PORT", str(WEBAPP_PORT)))
    config = uvicorn.Config(
        fastapi_app,
        host="0.0.0.0",
        port=port,
        log_level="info",
    )
    server = uvicorn.Server(config)
    await server.serve()


async def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stdout
    )

    def print_banner():
        banner_lines = [
            "============================================================",
            "                    DEALPROSERVICE                          ",
            "============================================================"
        ]

        use_colors = False
        try:
            import colorama
            colorama.init()
            use_colors = True
        except Exception:
            use_colors = False

        # ANSI color codes
        RED = "\033[31m" if use_colors else ""
        YELLOW = "\033[33m" if use_colors else ""
        GREEN = "\033[32m" if use_colors else ""
        BOLD = "\033[1m" if use_colors else ""
        RESET = "\033[0m" if use_colors else ""

        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

        # Print banner with colors
        print()
        print(f"{YELLOW}{BOLD}=============================================={RESET}")
        for i, line in enumerate(banner_lines):
            color = GREEN if i % 2 == 0 else YELLOW
            print(f"{color}{BOLD}{line}{RESET}")
        print(f"{YELLOW}{BOLD}        DEALPRO SERVICE — bot startup         {RESET}")
        print(f"{RED}Started: {now}{RESET}")
        print(f"{YELLOW}{BOLD}=============================================={RESET}\n")

    print_banner()
    logging.info("dealproservice started")

    # Increase connection timeout
    session = AiohttpSession()
    
    bot = Bot(
        token=BOT_TOKEN,
        session=session,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )

    dp = Dispatcher(storage=MemoryStorage())

    router = setup_routers()
    dp.include_router(router)

    logging.info("Бот запущен!")

    try:
        while True:
            try:
                await dp.start_polling(bot)
            except Exception as e:
                logging.error(f"Polling error: {e}. Retrying in 5 seconds...")
                await asyncio.sleep(5)
    finally:
        await bot.session.close()


async def run_all():
    """Run both the bot and the API server concurrently."""
    await init_db()
    await asyncio.gather(
        main(),
        run_api_server(),
    )


if __name__ == "__main__":
    asyncio.run(run_all())
