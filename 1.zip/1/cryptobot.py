import aiohttp
from typing import Optional, Dict, Any
from config import CRYPTOBOT_TOKEN

CRYPTOBOT_API = "https://pay.crypt.bot/api"


async def create_invoice(amount: float, user_id: int, currency: str = "USDT") -> Optional[Dict[str, Any]]:
    if not CRYPTOBOT_TOKEN:
        return None

    headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}
    payload = {
        "asset": currency,
        "amount": str(amount),
        "description": f"Пополнение депозита (ID: {user_id})",
        "hidden_message": "Спасибо за пополнение депозита!",
        "paid_btn_name": "callback",
        "paid_btn_url": "https://t.me/your_bot",
        "payload": str(user_id),
        "allow_comments": False,
        "allow_anonymous": False
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{CRYPTOBOT_API}/createInvoice", headers=headers, json=payload) as resp:
                data = await resp.json()
                if data.get("ok"):
                    return data.get("result")
    except Exception as e:
        print(f"CryptoBot error: {e}")

    return None


async def get_invoice(invoice_id: str) -> Optional[Dict[str, Any]]:
    if not CRYPTOBOT_TOKEN:
        return None

    headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{CRYPTOBOT_API}/getInvoices",
                headers=headers,
                params={"invoice_ids": invoice_id}
            ) as resp:
                data = await resp.json()
                if data.get("ok") and data.get("result", {}).get("items"):
                    return data["result"]["items"][0]
    except Exception as e:
        print(f"CryptoBot error: {e}")

    return None


async def check_invoice_paid(invoice_id: str) -> bool:
    invoice = await get_invoice(invoice_id)
    if invoice:
        return invoice.get("status") == "paid"
    return False


async def get_balance() -> Optional[Dict[str, Any]]:
    if not CRYPTOBOT_TOKEN:
        return None

    headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{CRYPTOBOT_API}/getBalance", headers=headers) as resp:
                data = await resp.json()
                if data.get("ok"):
                    return data.get("result")
    except Exception as e:
        print(f"CryptoBot error: {e}")

    return None


async def create_transfer(user_id: int, amount: float, currency: str = "USDT", comment: str = None) -> Optional[Dict[str, Any]]:
    """
    Создает перевод пользователю через CryptoBot
    
    Args:
        user_id: Telegram ID пользователя
        amount: Сумма перевода
        currency: Валюта (по умолчанию USDT)
        comment: Комментарий к переводу
    
    Returns:
        Данные о переводе или None в случае ошибки
    """
    if not CRYPTOBOT_TOKEN:
        return None

    headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}
    payload = {
        "user_id": user_id,
        "asset": currency,
        "amount": str(amount),
        "spend_id": f"withdraw_{user_id}_{int(amount * 100)}",  # Уникальный ID для избежания дублирования
        "comment": comment or f"Вывод средств (ID: {user_id})",
        "disable_send_notification": False
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{CRYPTOBOT_API}/transfer", headers=headers, json=payload) as resp:
                data = await resp.json()
                if data.get("ok"):
                    return data.get("result")
                else:
                    print(f"CryptoBot transfer error: {data}")
    except Exception as e:
        print(f"CryptoBot transfer error: {e}")

    return None


async def get_transfer(transfer_id: int) -> Optional[Dict[str, Any]]:
    """
    Получает информацию о переводе
    
    Args:
        transfer_id: ID перевода
    
    Returns:
        Данные о переводе или None
    """
    if not CRYPTOBOT_TOKEN:
        return None

    headers = {"Crypto-Pay-API-Token": CRYPTOBOT_TOKEN}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{CRYPTOBOT_API}/getTransfers",
                headers=headers,
                params={"transfer_id": transfer_id}
            ) as resp:
                data = await resp.json()
                if data.get("ok") and data.get("result", {}).get("items"):
                    return data["result"]["items"][0]
    except Exception as e:
        print(f"CryptoBot error: {e}")

    return None
