import crypto from 'node:crypto'
import cors from 'cors'
import express from 'express'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const rootDir = join(__dirname, '..')
const dataPath = join(__dirname, 'data.json')
const distDir = join(rootDir, 'dist')

loadEnv(join(rootDir, '.env'))

const app = express()
const host = process.env.HOST || '127.0.0.1'
const port = Number(process.env.PORT || 4300)
const botToken = process.env.BOT_TOKEN || ''
const miniAppUrl = process.env.MINIAPP_URL || `http://${host}:${port}`
const cryptoPayToken = process.env.CRYPTO_PAY_TOKEN || ''
const adminIds = String(process.env.ADMIN_IDS || '')
  .split(',')
  .map((item) => item.trim())
  .filter(Boolean)
const cryptoPayBaseUrl = process.env.CRYPTO_PAY_TESTNET === 'true'
  ? 'https://testnet-pay.crypt.bot/api'
  : 'https://pay.crypt.bot/api'

const emptyState = { users: [], tasks: [], deposits: [], applications: [], notifications: [], messages: [], ratings: [], withdrawals: [] }

function loadEnv(path) {
  try {
    for (const line of readFileSync(path, 'utf8').split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)=(.*)$/)
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2]
    }
  } catch {
    // .env is optional for local UI work.
  }
}

function readState() {
  if (!existsSync(dataPath)) return structuredClone(emptyState)
  return { ...structuredClone(emptyState), ...JSON.parse(readFileSync(dataPath, 'utf8')) }
}

function writeState(state) {
  writeFileSync(dataPath, JSON.stringify(state, null, 2), 'utf8')
}

function nextId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`
}

function normalizeAmount(value) {
  return Math.round(Number(value || 0) * 100) / 100
}

function findUser(state, id) {
  return state.users.find((item) => item.id === id)
}

function isAdminUser(user) {
  return Boolean(user && adminIds.includes(String(user.telegramId)))
}

function userPublic(user) {
  if (!user) return null
  return {
    id: user.id,
    telegramId: user.telegramId,
    username: user.username,
    photoUrl: user.photoUrl,
    name: user.name,
    role: user.role,
    rating: Number(user.rating || 0),
    completedTasks: Number(user.completedTasks || 0),
    turnover: Number(user.turnover || 0),
    level: performerLevel(user),
    badges: performerBadges(user),
  }
}

function performerLevel(user) {
  const completed = Number(user.completedTasks || 0)
  const rating = Number(user.rating || 0)
  const turnover = Number(user.turnover || 0)
  if (rating >= 4.9 && completed >= 100 && turnover >= 250000) return 'Elite'
  if (rating >= 4.8 && completed >= 40 && turnover >= 90000) return 'Pro'
  if (rating >= 4.6 && completed >= 10) return 'Проверенный'
  return 'Новичок'
}

function performerBadges(user) {
  const badges = []
  const completed = Number(user.completedTasks || 0)
  if (Number(user.responseMinutes || 999) <= 15) badges.push('Быстро отвечает')
  if (Number(user.completedTasks || 0) >= 100) badges.push('100 заказов')
  if (completed >= 3 && Number(user.rating || 0) >= 4.8) badges.push('Надежный')
  if ((user.skills || []).some((skill) => String(skill).toLowerCase().includes('smm'))) badges.push('SMM эксперт')
  return badges
}

function createNotification(state, userId, type, title, text, meta = {}) {
  if (!userId) return
  state.notifications.unshift({
    id: nextId('ntf'),
    userId,
    type,
    title,
    text,
    meta,
    read: false,
    createdAt: new Date().toISOString(),
  })
}

function bestPerformers(state, task) {
  return state.users
    .filter((user) => user.role === 'worker' || user.role === 'performer')
    .map((user) => {
      const skills = user.skills || []
      const skillMatch = skills.some((skill) => String(skill).toLowerCase() === String(task.category).toLowerCase())
      const score = Number(user.rating || 0) * 20
        + Number(user.completedTasks || 0) * 0.7
        + Number(user.turnover || 0) / 5000
        + (skillMatch ? 35 : 0)
        + (user.proUntil ? 10 : 0)
      return {
        id: user.id,
        name: user.name,
        level: performerLevel(user),
        badges: performerBadges(user),
        rating: Number(user.rating || 0),
        completedTasks: Number(user.completedTasks || 0),
        score: Math.round(score),
      }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
}

function publicState(telegramId = 'browser') {
  const state = readState()
  const user = state.users.find((item) => item.telegramId === telegramId) || null
  const userId = user?.id
  const openTasks = state.tasks.filter((task) => task.status === 'open')
  const locked = state.tasks
    .filter((task) => task.status === 'open')
    .reduce((sum, task) => sum + Number(task.budget || 0), 0)

  const tasks = state.tasks.map((task) => ({
    ...task,
    owner: userPublic(findUser(state, task.ownerId)),
    worker: userPublic(findUser(state, task.workerId)),
    appliedByMe: state.applications.some((item) => item.taskId === task.id && item.userId === userId),
    applications: state.applications
      .filter((item) => item.taskId === task.id)
      .map((item) => ({ ...item, user: userPublic(findUser(state, item.userId)) })),
    unreadMessages: state.messages.filter((item) => item.taskId === task.id && item.toUserId === userId && !item.read).length,
  }))
  const myApplications = state.applications
    .filter((appItem) => appItem.userId === userId || state.tasks.some((task) => task.id === appItem.taskId && task.ownerId === userId))
    .map((appItem) => ({
      ...appItem,
      task: state.tasks.find((task) => task.id === appItem.taskId) || null,
      user: userPublic(findUser(state, appItem.userId)),
    }))
  const myMessages = state.messages
    .filter((item) => item.fromUserId === userId || item.toUserId === userId)
    .slice(-100)

  return {
    user: user ? { ...user, isAdmin: isAdminUser(user), level: performerLevel(user), badges: performerBadges(user) } : null,
    tasks,
    myOrders: tasks.filter((task) => task.ownerId === userId),
    myWork: tasks.filter((task) => task.workerId === userId || myApplications.some((item) => item.taskId === task.id && item.userId === userId)),
    deposits: state.deposits.filter((deposit) => deposit.userId === userId).slice(0, 10),
    applications: myApplications,
    messages: myMessages,
    withdrawals: state.withdrawals.filter((item) => item.userId === userId).slice(0, 10),
    notifications: state.notifications.filter((item) => item.userId === userId).slice(0, 20),
    admin: isAdminUser(user)
      ? {
        users: state.users.map((item) => ({ ...item, isAdmin: isAdminUser(item), level: performerLevel(item), badges: performerBadges(item) })),
        tasks: state.tasks,
        deposits: state.deposits,
        withdrawals: state.withdrawals,
        applications: state.applications,
        messages: state.messages.slice(-50),
      }
      : null,
    stats: {
      openTasks: openTasks.length,
      locked,
      responses: state.tasks.reduce((sum, task) => sum + Number(task.responses || 0), 0),
    },
  }
}

function upsertUser(body = {}) {
  const state = readState()
  const telegramId = String(body.telegramId || body.id || 'browser')
  const existing = state.users.find((user) => user.telegramId === telegramId)
  const completedTasks = Number(existing?.completedTasks ?? 0)
  const user = {
    id: existing?.id || nextId('u'),
    telegramId,
    chatId: body.chatId || existing?.chatId || null,
    name: body.name || existing?.name || 'Пользователь',
    username: body.username || existing?.username || '',
    photoUrl: body.photoUrl || existing?.photoUrl || '',
    role: body.role || existing?.role || 'customer',
    balance: Number(existing?.balance ?? 0),
    rating: completedTasks > 0 ? Number(existing?.rating ?? 0) : 0,
    completedTasks,
    turnover: Number(existing?.turnover ?? 0),
    responseMinutes: Number(existing?.responseMinutes ?? 30),
    skills: existing?.skills || body.skills || [],
    proUntil: existing?.proUntil || null,
  }

  state.users = existing
    ? state.users.map((item) => (item.telegramId === telegramId ? user : item))
    : [user, ...state.users]
  writeState(state)
  return user
}

async function telegramRequest(method, payload) {
  if (!botToken) return { skipped: true }
  const response = await fetch(`https://api.telegram.org/bot${botToken}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!response.ok) throw new Error(`Telegram ${method}: ${response.status}`)
  return response.json()
}

async function cryptoPayRequest(method, payload = {}) {
  if (!cryptoPayToken) {
    const error = new Error('Укажите CRYPTO_PAY_TOKEN в .env')
    error.status = 503
    throw error
  }

  const response = await fetch(`${cryptoPayBaseUrl}/${method}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Crypto-Pay-API-Token': cryptoPayToken,
    },
    body: JSON.stringify(payload),
  })
  const json = await response.json().catch(() => null)
  if (!response.ok || !json?.ok) {
    const error = new Error(json?.error || `Crypto Pay error: ${response.status}`)
    error.status = response.status
    throw error
  }
  return json.result
}

function invoiceUrl(invoice) {
  return invoice.mini_app_invoice_url || invoice.bot_invoice_url || invoice.web_app_invoice_url || invoice.pay_url
}

function applyPaidInvoice(invoice) {
  const state = readState()
  const deposit = state.deposits.find((item) => String(item.invoiceId) === String(invoice.invoice_id))
  if (!deposit) return { changed: false, reason: 'deposit_not_found' }
  if (deposit.status === 'paid') return { changed: false, reason: 'already_paid' }
  if (invoice.status !== 'paid') {
    deposit.status = invoice.status || deposit.status
    writeState(state)
    return { changed: false, reason: 'not_paid' }
  }

  const user = findUser(state, deposit.userId)
  if (!user) return { changed: false, reason: 'user_not_found' }

  user.balance += Number(deposit.amount)
  deposit.status = 'paid'
  deposit.paidAt = invoice.paid_at || new Date().toISOString()
  deposit.paidAsset = invoice.paid_asset || invoice.asset || null
  deposit.paidAmount = invoice.paid_amount || invoice.amount || null
  writeState(state)
  return { changed: true, user }
}

function verifyCryptoPaySignature(req) {
  if (!cryptoPayToken) return false
  const signature = req.get('crypto-pay-api-signature')
  if (!signature || !req.rawBody) return false
  const secret = crypto.createHash('sha256').update(cryptoPayToken).digest()
  const hmac = crypto.createHmac('sha256', secret).update(req.rawBody).digest('hex')
  if (hmac.length !== signature.length) return false
  return crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(signature))
}

async function notifyAll(text) {
  const state = readState()
  const users = state.users.filter((user) => user.chatId)
  for (const user of users) {
    await telegramRequest('sendMessage', { chat_id: user.chatId, text }).catch(() => null)
  }
}

async function sendStart(chatId) {
  return telegramRequest('sendMessage', {
    chat_id: chatId,
    text: 'TaskPay: безопасная биржа заданий внутри Telegram. Пополните баланс через CryptoBot, создайте задачу и получайте отклики исполнителей.',
    reply_markup: {
      inline_keyboard: [[{ text: 'Открыть TaskPay', web_app: { url: miniAppUrl } }]],
    },
  })
}

async function startBotPolling() {
  if (!botToken) return
  let offset = 0
  await telegramRequest('deleteWebhook', { drop_pending_updates: false }).catch(() => null)
  await telegramRequest('setChatMenuButton', {
    menu_button: { type: 'web_app', text: 'TaskPay', web_app: { url: miniAppUrl } },
  }).catch(() => null)

  async function poll() {
    try {
      const result = await telegramRequest('getUpdates', {
        offset,
        timeout: 25,
        allowed_updates: ['message'],
      })
      for (const update of result.result || []) {
        offset = update.update_id + 1
        const message = update.message
        if (message?.chat?.id && String(message.text || '').startsWith('/start')) {
          upsertUser({
            telegramId: message.from?.id,
            chatId: message.chat.id,
            username: message.from?.username || '',
            name: [message.from?.first_name, message.from?.last_name].filter(Boolean).join(' '),
          })
          await sendStart(message.chat.id)
        }
      }
    } catch (error) {
      console.warn(error.message)
      await new Promise((resolve) => setTimeout(resolve, 2500))
    } finally {
      setTimeout(poll, 500)
    }
  }

  poll()
}

app.use(cors())
app.use(express.json({
  limit: '1mb',
  verify: (req, _res, buf) => {
    req.rawBody = buf
  },
}))

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'taskpay-miniapp', cryptoPay: Boolean(cryptoPayToken) })
})

app.post('/api/session', (req, res) => {
  const user = upsertUser(req.body)
  res.json(publicState(user.telegramId))
})

app.get('/api/bootstrap', (req, res) => {
  res.json(publicState(String(req.query.telegramId || 'browser')))
})

app.post('/api/deposits', async (req, res) => {
  try {
    const state = readState()
    const user = findUser(state, req.body.userId)
    const amount = normalizeAmount(req.body.amount)
    if (!user || amount < 1) return res.status(422).json({ error: 'Минимальная сумма пополнения 1 ₽' })

    const depositId = nextId('dep')
    const invoice = await cryptoPayRequest('createInvoice', {
      currency_type: 'fiat',
      fiat: 'RUB',
      accepted_assets: req.body.acceptedAssets || 'USDT,TON,BTC,ETH,LTC,BNB,TRX,USDC',
      amount: String(amount),
      description: `Пополнение TaskPay на ${amount} ₽`,
      payload: JSON.stringify({ depositId, userId: user.id }),
      paid_btn_name: 'callback',
      paid_btn_url: miniAppUrl,
      allow_comments: false,
      allow_anonymous: false,
      expires_in: 1800,
    })

    state.deposits.unshift({
      id: depositId,
      userId: user.id,
      amount,
      method: 'cryptobot',
      status: invoice.status || 'active',
      invoiceId: invoice.invoice_id,
      invoiceHash: invoice.hash,
      paymentUrl: invoiceUrl(invoice),
      createdAt: new Date().toISOString(),
      expiresAt: invoice.expiration_date || null,
    })
    writeState(state)
    res.status(201).json({ ...publicState(user.telegramId), paymentUrl: invoiceUrl(invoice), invoiceId: invoice.invoice_id })
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message })
  }
})

app.post('/api/deposits/:id/check', async (req, res) => {
  try {
    const state = readState()
    const deposit = state.deposits.find((item) => item.id === req.params.id)
    const user = findUser(state, req.body.userId)
    if (!deposit || !user || deposit.userId !== user.id) return res.status(404).json({ error: 'Счет на оплату не найден' })

    const invoices = await cryptoPayRequest('getInvoices', { invoice_ids: String(deposit.invoiceId), count: 1 })
    const invoice = Array.isArray(invoices) ? invoices[0] : invoices?.items?.[0]
    if (invoice) applyPaidInvoice(invoice)
    res.json(publicState(user.telegramId))
  } catch (error) {
    res.status(error.status || 500).json({ error: error.message })
  }
})

app.post('/api/crypto-pay/webhook', (req, res) => {
  if (!verifyCryptoPaySignature(req)) {
    res.status(401).json({ ok: false })
    return
  }
  if (req.body?.update_type === 'invoice_paid') {
    applyPaidInvoice(req.body.payload)
  }
  res.json({ ok: true })
})

app.post('/api/notifications/:id/read', (req, res) => {
  const state = readState()
  const user = findUser(state, req.body.userId)
  const notification = state.notifications.find((item) => item.id === req.params.id)
  if (!user || !notification || notification.userId !== user.id) return res.status(404).json({ error: 'Уведомление не найдено' })
  notification.read = true
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/subscriptions/pro', (req, res) => {
  const state = readState()
  const user = findUser(state, req.body.userId)
  const days = Number(req.body.days || 30)
  const price = days >= 30 ? 500 : 250
  if (!user) return res.status(404).json({ error: 'Пользователь не найден' })
  if (user.proUntil && new Date(user.proUntil).getTime() > Date.now()) return res.status(409).json({ error: 'PRO уже активен' })
  if (user.balance < price) return res.status(402).json({ error: 'Недостаточно средств для PRO' })

  user.balance -= price
  user.proUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString()
  createNotification(state, user.id, 'pro', 'PRO активирован', 'Задачи получают приоритет и выделение в ленте.')
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/tasks', async (req, res) => {
  const state = readState()
  const user = findUser(state, req.body.userId)
  const budget = normalizeAmount(req.body.budget)
  const title = String(req.body.title || '').trim()
  if (!user || !title || budget < 1) return res.status(422).json({ error: 'Заполните название и бюджет от 1 ₽' })
  if (user.balance < budget) return res.status(402).json({ error: 'Недостаточно средств на балансе' })

  user.balance -= budget
  const task = {
    id: nextId('task'),
    ownerId: user.id,
    title,
    description: String(req.body.description || '').trim(),
    category: req.body.category || 'Другое',
    budget,
    deadline: req.body.deadline || 'Сегодня',
    status: 'open',
    statusLabel: 'Открыто',
    priority: Boolean(user.proUntil),
    responses: 0,
    recommendedPerformers: [],
    createdAt: new Date().toISOString(),
  }
  task.recommendedPerformers = bestPerformers(state, task)
  state.tasks.unshift(task)
  createNotification(state, user.id, 'task_created', 'Задание опубликовано', `Статус: открыто. Рекомендовано исполнителей: ${task.recommendedPerformers.length}.`, { taskId: task.id })
  for (const performer of task.recommendedPerformers) {
    createNotification(state, performer.id, 'new_task', 'Подходящее задание', `${task.title}: ${task.budget} ₽`, { taskId: task.id })
  }
  writeState(state)
  await notifyAll(`Новое задание: ${task.title}. Бюджет ${task.budget} ₽.`)
  res.status(201).json(publicState(user.telegramId))
})

app.post('/api/tasks/:id/apply', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  if (!task || !user) return res.status(404).json({ error: 'Задание не найдено' })
  if (task.ownerId === user.id) return res.status(422).json({ error: 'Нельзя откликнуться на свое задание' })
  if (state.applications.some((item) => item.taskId === task.id && item.userId === user.id)) {
    return res.status(409).json({ error: 'Вы уже откликнулись на это задание' })
  }

  task.responses += 1
  state.applications.unshift({
    id: nextId('app'),
    taskId: task.id,
    userId: user.id,
    message: String(req.body.message || 'Готов выполнить').trim(),
    status: 'new',
    createdAt: new Date().toISOString(),
  })
  createNotification(state, task.ownerId, 'new_response', 'Новый отклик', `${user.name} откликнулся на задание: ${task.title}`, { taskId: task.id })
  writeState(state)
  res.status(201).json(publicState(user.telegramId))
})

app.post('/api/applications/:id/accept', (req, res) => {
  const state = readState()
  const owner = findUser(state, req.body.userId)
  const application = state.applications.find((item) => item.id === req.params.id)
  const task = state.tasks.find((item) => item.id === application?.taskId)
  if (!owner || !application || !task || task.ownerId !== owner.id) return res.status(404).json({ error: 'Отклик не найден' })

  application.status = 'accepted'
  for (const item of state.applications.filter((appItem) => appItem.taskId === task.id && appItem.id !== application.id)) {
    item.status = 'rejected'
  }
  task.status = 'in_work'
  task.statusLabel = 'В работе'
  task.workerId = application.userId
  createNotification(state, application.userId, 'order_accepted', 'Заказ принят', `Вас выбрали исполнителем: ${task.title}`, { taskId: task.id })
  createNotification(state, owner.id, 'message', 'Системное сообщение', 'Исполнитель получил уведомление о начале работы.', { taskId: task.id })
  state.messages.push({
    id: nextId('msg'),
    taskId: task.id,
    fromUserId: owner.id,
    toUserId: application.userId,
    text: 'Вы выбраны исполнителем. Можно начинать работу.',
    read: false,
    createdAt: new Date().toISOString(),
  })
  writeState(state)
  res.json(publicState(owner.telegramId))
})

app.post('/api/tasks/:id/messages', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  const text = String(req.body.text || '').trim()
  if (!task || !user || !text) return res.status(422).json({ error: 'Сообщение не отправлено' })
  if (![task.ownerId, task.workerId].includes(user.id)) return res.status(403).json({ error: 'Чат доступен только участникам заказа' })
  const toUserId = user.id === task.ownerId ? task.workerId : task.ownerId
  if (!toUserId) return res.status(422).json({ error: 'Исполнитель еще не выбран' })

  state.messages.push({
    id: nextId('msg'),
    taskId: task.id,
    fromUserId: user.id,
    toUserId,
    text,
    read: false,
    createdAt: new Date().toISOString(),
  })
  createNotification(state, toUserId, 'message', 'Новое сообщение', `${user.name}: ${text.slice(0, 80)}`, { taskId: task.id })
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/tasks/:id/messages/read', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  if (!task || !user || ![task.ownerId, task.workerId].includes(user.id)) return res.status(404).json({ error: 'Чат не найден' })
  for (const message of state.messages.filter((item) => item.taskId === task.id && item.toUserId === user.id)) {
    message.read = true
  }
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/tasks/:id/review', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  if (!task || !user || task.workerId !== user.id) return res.status(404).json({ error: 'Задание не найдено' })

  task.status = 'review'
  task.statusLabel = 'На проверке'
  createNotification(state, task.ownerId, 'message', 'Пришел отчет', `Исполнитель отправил задание на проверку: ${task.title}`, { taskId: task.id })
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/tasks/:id/complete', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  if (!task || !user || task.ownerId !== user.id) return res.status(404).json({ error: 'Задание не найдено' })

  task.status = 'done'
  task.statusLabel = 'Завершено'
  task.completedAt = new Date().toISOString()
  task.rating = Math.min(5, Math.max(1, Number(req.body.rating || 5)))
  const worker = findUser(state, task.workerId)
  if (worker) {
    worker.balance += Number(task.budget || 0)
    worker.completedTasks = Number(worker.completedTasks || 0) + 1
    worker.turnover = Number(worker.turnover || 0) + Number(task.budget || 0)
    const previousCompleted = Math.max(0, Number(worker.completedTasks || 1) - 1)
    const previousRating = previousCompleted > 0 ? Number(worker.rating || 0) : 0
    worker.rating = Number(((previousRating * previousCompleted + task.rating) / Math.max(1, Number(worker.completedTasks || 1))).toFixed(2))
    state.ratings.unshift({
      id: nextId('rate'),
      taskId: task.id,
      fromUserId: user.id,
      toUserId: worker.id,
      rating: task.rating,
      text: String(req.body.review || '').trim(),
      createdAt: new Date().toISOString(),
    })
    createNotification(state, worker.id, 'task_done', 'Заказ завершен', `Оплата начислена: ${task.budget} ₽`, { taskId: task.id })
    createNotification(state, worker.id, 'withdrawal', 'Вывод средств', 'Средства доступны к выводу из профиля.', { taskId: task.id })
  }
  createNotification(state, user.id, 'task_done', 'Заказ завершен', `Задание закрыто: ${task.title}`, { taskId: task.id })
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.post('/api/withdrawals', (req, res) => {
  const state = readState()
  const user = findUser(state, req.body.userId)
  const amount = normalizeAmount(req.body.amount)
  const wallet = String(req.body.wallet || '').trim()
  if (!user || amount < 1 || !wallet) return res.status(422).json({ error: 'Укажите сумму от 1 ₽ и кошелек' })
  if (user.balance < amount) return res.status(402).json({ error: 'Недостаточно средств' })

  user.balance -= amount
  const withdrawal = {
    id: nextId('wd'),
    userId: user.id,
    amount,
    wallet,
    status: 'pending',
    createdAt: new Date().toISOString(),
  }
  state.withdrawals.unshift(withdrawal)
  createNotification(state, user.id, 'withdrawal', 'Заявка на вывод создана', `Сумма: ${amount} ₽`, { withdrawalId: withdrawal.id })
  writeState(state)
  res.status(201).json(publicState(user.telegramId))
})

function requireAdminState(req, res) {
  const state = readState()
  const user = findUser(state, req.body.userId || req.query.userId)
  if (!isAdminUser(user)) {
    res.status(403).json({ error: 'Нет доступа к админ-панели' })
    return null
  }
  return { state, user }
}

app.post('/api/admin/users/:id/balance', (req, res) => {
  const context = requireAdminState(req, res)
  if (!context) return
  const target = findUser(context.state, req.params.id)
  const amount = normalizeAmount(req.body.amount)
  if (!target || !amount) return res.status(422).json({ error: 'Пользователь или сумма не найдены' })
  target.balance += amount
  createNotification(context.state, target.id, 'admin', 'Баланс изменен', `Админ изменил баланс на ${amount} ₽.`)
  writeState(context.state)
  res.json(publicState(context.user.telegramId))
})

app.post('/api/admin/tasks/:id/status', (req, res) => {
  const context = requireAdminState(req, res)
  if (!context) return
  const task = context.state.tasks.find((item) => item.id === req.params.id)
  if (!task) return res.status(404).json({ error: 'Задание не найдено' })
  task.status = req.body.status || task.status
  task.statusLabel = req.body.statusLabel || task.statusLabel
  createNotification(context.state, task.ownerId, 'admin', 'Статус изменен админом', `${task.title}: ${task.statusLabel || task.status}`)
  writeState(context.state)
  res.json(publicState(context.user.telegramId))
})

app.post('/api/admin/withdrawals/:id/status', (req, res) => {
  const context = requireAdminState(req, res)
  if (!context) return
  const withdrawal = context.state.withdrawals.find((item) => item.id === req.params.id)
  if (!withdrawal) return res.status(404).json({ error: 'Заявка не найдена' })
  withdrawal.status = req.body.status || withdrawal.status
  withdrawal.updatedAt = new Date().toISOString()
  createNotification(context.state, withdrawal.userId, 'withdrawal', 'Статус вывода обновлен', `Заявка ${withdrawal.status}.`, { withdrawalId: withdrawal.id })
  writeState(context.state)
  res.json(publicState(context.user.telegramId))
})

app.post('/api/tasks/:id/cancel', (req, res) => {
  const state = readState()
  const task = state.tasks.find((item) => item.id === req.params.id)
  const user = findUser(state, req.body.userId)
  if (!task || !user || task.ownerId !== user.id) return res.status(404).json({ error: 'Задание не найдено' })

  if (task.status !== 'done') {
    task.status = 'canceled'
    task.statusLabel = 'Отменено'
    user.balance += Number(task.budget || 0)
    createNotification(state, user.id, 'task_canceled', 'Задание отменено', `Бюджет возвращен на баланс: ${task.budget} ₽`, { taskId: task.id })
  }
  writeState(state)
  res.json(publicState(user.telegramId))
})

app.use(express.static(distDir))
app.get(/.*/, (_req, res) => {
  res.sendFile(join(distDir, 'index.html'))
})

app.listen(port, host, () => {
  console.log(`TaskPay Mini App: http://${host}:${port}`)
  startBotPolling().catch((error) => console.warn(error.message))
})
