# TaskPay Mini App

Telegram бот + Mini App для заданий за деньги: пользователь пополняет баланс, публикует задание, задание появляется в общей ленте, исполнители отправляют отклики.

## Что внутри

- React/Vite Mini App с мобильным UX под Telegram.
- Express API с JSON-хранилищем `server/data.json`.
- Telegram bot polling: `/start`, кнопка открытия Mini App и меню бота.
- Пополнение баланса через CryptoBot/Crypto Pay invoices.
- Создание заданий, отклики, принятие исполнителя, проверка и завершение.
- Уведомления: новый отклик, приняли заказ, сообщение, завершение, вывод средств.
- Статусы заданий: открыто, в работе, на проверке, завершено, отменено.
- Уровни исполнителей, бейджи, PRO-подписка и автоподбор исполнителей.

## Запуск локально

```bash
npm install
npm run dev:full
```

Mini App откроется на `http://127.0.0.1:5173`, API на `http://127.0.0.1:4300`.

## Подключение Telegram

1. Создайте бота через BotFather.
2. Скопируйте `.env.example` в `.env`.
3. Укажите `BOT_TOKEN`, `CRYPTO_PAY_TOKEN` и публичный HTTPS адрес Mini App в `MINIAPP_URL`.
4. Запустите `npm run api`.
5. В Telegram отправьте боту `/start`.

Для локальной проверки Mini App в Telegram нужен HTTPS-туннель, например ngrok или Cloudflare Tunnel.

## CryptoBot / Crypto Pay

1. Откройте `@CryptoBot`.
2. Перейдите в Crypto Pay и создайте приложение.
3. Вставьте токен приложения в `CRYPTO_PAY_TOKEN`.
4. Для тестнета используйте `@CryptoTestnetBot` и `CRYPTO_PAY_TESTNET=true`.
5. Webhook URL для продакшена: `https://your-domain.example/api/crypto-pay/webhook`.

## Важно для продакшена

Для продакшена нужна нормальная база данных вместо JSON, админка модерации, KYC/AML-правила для выплат и отдельный процесс вывода средств.
