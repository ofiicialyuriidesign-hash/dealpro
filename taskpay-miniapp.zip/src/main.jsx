import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  BadgeCheck,
  Banknote,
  Bell,
  BriefcaseBusiness,
  CheckCircle2,
  ChevronRight,
  Clock3,
  ExternalLink,
  ArrowLeft,
  Home,
  Layers3,
  ListChecks,
  MessageSquare,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  Settings,
  UserRound,
  WalletCards,
} from 'lucide-react'
import './styles.css'

const tg = window.Telegram?.WebApp
const api = {
  async get(path) {
    const response = await fetch(path)
    const json = await parseApiResponse(response)
    if (!response.ok) throw new Error(json.error || 'Ошибка загрузки')
    return json
  },
  async post(path, body) {
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const json = await parseApiResponse(response)
    if (!response.ok) throw new Error(json.error || 'Ошибка запроса')
    return json
  },
}

async function parseApiResponse(response) {
  const contentType = response.headers.get('content-type') || ''
  if (contentType.includes('application/json')) return response.json()
  const text = await response.text()
  if (text.trim().startsWith('<!DOCTYPE') || text.trim().startsWith('<html')) {
    throw new Error('API не отвечает. Запустите npm run dev:full или отдельно npm run api.')
  }
  throw new Error(text || 'API вернул неизвестный ответ')
}

const initialForm = {
  title: '',
  description: '',
  category: 'SMM',
  budget: 2500,
  deadline: 'Сегодня',
}

function money(value) {
  return new Intl.NumberFormat('ru-RU').format(Number(value || 0)) + ' ₽'
}

function getTelegramUser() {
  const user = tg?.initDataUnsafe?.user
  return {
    telegramId: user?.id ? String(user.id) : 'browser',
    username: user?.username || '',
    photoUrl: user?.photo_url || '',
    name: [user?.first_name, user?.last_name].filter(Boolean).join(' ') || 'Пользователь',
  }
}

function openPayment(url) {
  if (!url) return
  if (tg?.openTelegramLink && url.includes('t.me')) tg.openTelegramLink(url)
  else if (tg?.openLink) tg.openLink(url)
  else window.open(url, '_blank', 'noopener,noreferrer')
}

function App() {
  const [tab, setTabState] = useState('home')
  const [tabHistory, setTabHistory] = useState([])
  const [state, setState] = useState(null)
  const [form, setForm] = useState(initialForm)
  const [deposit, setDeposit] = useState(3000)
  const [withdrawalAmount, setWithdrawalAmount] = useState(1000)
  const [withdrawalWallet, setWithdrawalWallet] = useState('')
  const [activeInvoice, setActiveInvoice] = useState(null)
  const [showNotifications, setShowNotifications] = useState(false)
  const [categoryFilter, setCategoryFilter] = useState('Все')
  const [selectedTaskId, setSelectedTaskId] = useState('')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(true)

  const me = state?.user
  const tasks = state?.tasks || []
  const deposits = state?.deposits || []
  const notifications = state?.notifications || []
  const messages = state?.messages || []
  const unreadCount = notifications.filter((item) => !item.read).length
  const myTasks = useMemo(() => tasks.filter((task) => task.ownerId === me?.id), [tasks, me])
  const selectedTask = tasks.find((task) => task.id === selectedTaskId)
  const isProActive = Boolean(me?.proUntil && new Date(me.proUntil).getTime() > Date.now())
  const filteredTasks = useMemo(() => (
    categoryFilter === 'Все' ? tasks : tasks.filter((task) => task.category === categoryFilter)
  ), [tasks, categoryFilter])
  const myOrders = state?.myOrders || myTasks
  const myWork = state?.myWork || []
  const pageTitle = {
    home: 'ГЛАВНАЯ СТРАНИЦА',
    tasks: 'ЗАДАНИЯ',
    detail: 'КАРТОЧКА ЗАДАНИЯ',
    chat: 'ЧАТ ЗАКАЗА',
    orders: 'МОИ ЗАКАЗЫ',
    work: 'МОИ ОТКЛИКИ',
    create: 'СОЗДАТЬ ЗАДАНИЕ',
    wallet: 'ПОПОЛНЕНИЕ БАЛАНСА',
    withdraw: 'ВЫВОД БАЛАНСА',
    profile: 'ПРОФИЛЬ',
    admin: 'АДМИН ПАНЕЛЬ',
  }[tab]

  useEffect(() => {
    tg?.ready()
    tg?.expand()
    api.post('/api/session', getTelegramUser())
      .then(setState)
      .catch(() => api.get('/api/bootstrap').then(setState))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!notice) return undefined
    const timer = window.setTimeout(() => setNotice(''), 2200)
    return () => window.clearTimeout(timer)
  }, [notice])

  useEffect(() => {
    if (!me?.telegramId) return undefined
    const timer = window.setInterval(() => {
      api.get(`/api/bootstrap?telegramId=${encodeURIComponent(me.telegramId)}`)
        .then(setState)
        .catch(() => {})
    }, 3000)
    return () => window.clearInterval(timer)
  }, [me?.telegramId])

  async function run(action, successText) {
    try {
      setNotice('')
      const fresh = await action()
      setState(fresh)
      if (successText) {
        setNotice(successText)
        tg?.HapticFeedback?.notificationOccurred('success')
      }
      return fresh
    } catch (error) {
      setNotice(error.message)
      tg?.HapticFeedback?.notificationOccurred('error')
      return null
    }
  }

  function goTo(nextTab) {
    if (!nextTab || nextTab === tab) return
    setShowNotifications(false)
    setTabHistory((history) => [...history.slice(-8), tab])
    setTabState(nextTab)
  }

  function goBack() {
    setShowNotifications(false)
    setTabHistory((history) => {
      const previous = history.at(-1) || 'home'
      setTabState(previous)
      return history.slice(0, -1)
    })
  }

  async function createDeposit() {
    const fresh = await run(
      () => api.post('/api/deposits', { userId: me.id, amount: deposit }),
      'Счет CryptoBot создан. Откройте оплату и вернитесь проверить статус.',
    )
    if (fresh?.paymentUrl) {
      setActiveInvoice({ depositId: fresh.deposits[0]?.id, url: fresh.paymentUrl })
      openPayment(fresh.paymentUrl)
    }
  }

  async function checkDeposit(id) {
    await run(
      () => api.post(`/api/deposits/${id}/check`, { userId: me.id }),
      'Статус оплаты обновлен.',
    )
  }

  async function createWithdrawal() {
    await run(
      () => api.post('/api/withdrawals', { userId: me.id, amount: withdrawalAmount, wallet: withdrawalWallet }),
      'Заявка на вывод создана.',
    )
  }

  function createTask(event) {
    event.preventDefault()
    run(
      () => api.post('/api/tasks', { ...form, userId: me.id }),
      'Задание опубликовано. Бюджет зарезервирован на балансе.',
    ).then((fresh) => {
      if (fresh) setForm(initialForm)
    })
  }

  if (loading || !state || !me) {
    return <SkeletonScreen />
  }

  return (
    <main className="app">
      <header className="topbar">
        {tab === 'home' ? (
          <span className="header-spacer" />
        ) : (
          <button className="icon-button header-back" title="Назад" onClick={goBack}>
            <ArrowLeft size={20} />
          </button>
        )}
        <div className="topbar-title">
          <h1>{pageTitle}</h1>
          <span className="header-note">Задания, оплата и исполнители в одном месте</span>
        </div>
        <div className="notify-wrap">
          <button className="icon-button notify-button" title="Уведомления" onClick={() => setShowNotifications(!showNotifications)}>
            <Bell size={20} />
            {unreadCount > 0 && <span>{unreadCount}</span>}
          </button>
          {showNotifications && <Notifications items={notifications} me={me} run={run} />}
        </div>
      </header>

      {notice && <div className="notice">{notice}</div>}

      {tab === 'home' && (
        <section className="view">
          <section className="balance-panel">
            <div>
              <p>Баланс</p>
              <strong>{money(me.balance)}</strong>
            </div>
            <button onClick={() => goTo('wallet')}>
              <Plus size={18} />
              Пополнить
            </button>
          </section>

          <div className="quick-grid">
            <button onClick={() => goTo('create')}>
              <BriefcaseBusiness size={22} />
              Создать задание
            </button>
            <button onClick={() => goTo('tasks')}>
              <Search size={22} />
              Найти работу
            </button>
          </div>

          <section className="stats-row">
            <Stat icon={<ListChecks />} label="Открыто" value={state.stats.openTasks} />
            <Stat icon={<Banknote />} label="В заданиях" value={money(state.stats.locked)} />
            <Stat icon={<Send />} label="Отклики" value={state.stats.responses} />
          </section>

          <SectionTitle title="Новые задания" action="Все" onClick={() => goTo('tasks')} />
          <TaskList tasks={tasks.slice(0, 3)} me={me} run={run} onOpen={(task) => { setSelectedTaskId(task.id); goTo('detail') }} emptyText="Пока нет активных заданий." emptyAction={() => goTo('create')} />
        </section>
      )}

      {tab === 'tasks' && (
        <section className="view">
          <div className="searchbar">
            <Search size={18} />
            <span>Активные задания</span>
          </div>
          <CategoryFilters value={categoryFilter} onChange={setCategoryFilter} />
          <TaskList tasks={filteredTasks} me={me} run={run} onOpen={(task) => { setSelectedTaskId(task.id); goTo('detail') }} emptyText="Лента пустая. Новые задания появятся сразу после публикации заказчиками." emptyAction={() => goTo('create')} />
        </section>
      )}

      {tab === 'detail' && selectedTask && (
        <TaskDetail task={selectedTask} me={me} onOpenChat={() => goTo('chat')} />
      )}

      {tab === 'chat' && selectedTask && (
        <ChatPage task={selectedTask} me={me} messages={messages} run={run} />
      )}

      {tab === 'orders' && (
        <MyOrders orders={myOrders} me={me} run={run} onOpenChat={(task) => { setSelectedTaskId(task.id); goTo('chat') }} />
      )}

      {tab === 'work' && (
        <MyWork work={myWork} me={me} run={run} onOpenChat={(task) => { setSelectedTaskId(task.id); goTo('chat') }} />
      )}

      {tab === 'create' && (
        <section className="view">
          <form className="sheet" onSubmit={createTask}>
            <div className="sheet-head">
              <Layers3 size={22} />
              <h2>Новое задание</h2>
            </div>
            <label>
              Название
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Например: собрать базу каналов" />
            </label>
            <label>
              Описание
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Что нужно сделать, формат результата, требования" />
            </label>
            <div className="two-cols">
              <label>
                Категория
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                  <option>SMM</option>
                  <option>Дизайн</option>
                  <option>Тексты</option>
                  <option>Монтаж</option>
                  <option>Telegram</option>
                  <option>AI</option>
                  <option>Парсинг</option>
                  <option>Разработка</option>
                  <option>Реклама</option>
                  <option>Другое</option>
                </select>
              </label>
              <label>
                Срок
                <select value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })}>
                  <option>Сегодня</option>
                  <option>До завтра</option>
                  <option>3 дня</option>
                  <option>Неделя</option>
                </select>
              </label>
            </div>
            <label>
              Бюджет, ₽
              <input type="number" min="1" value={form.budget} onChange={(e) => setForm({ ...form, budget: Number(e.target.value) })} />
            </label>
            <button className="primary" type="submit">
              <ShieldCheck size={19} />
              Опубликовать
            </button>
          </form>
        </section>
      )}

      {tab === 'wallet' && (
        <section className="view">
          <section className="wallet-card">
            <WalletCards size={30} />
            <p>Доступно</p>
            <strong>{money(me.balance)}</strong>
            <span>Пополнение проходит через CryptoBot. Баланс начисляется после подтверждения оплаты.</span>
          </section>
          <div className="sheet">
            <div className="sheet-head">
              <Banknote size={22} />
              <h2>Пополнение</h2>
            </div>
            <div className="amounts">
              {[1000, 3000, 5000, 10000].map((value) => (
                <button className={deposit === value ? 'selected' : ''} key={value} onClick={() => setDeposit(value)}>
                  {money(value)}
                </button>
              ))}
            </div>
            <label>
              Своя сумма
              <input type="number" min="1" value={deposit} onChange={(e) => setDeposit(Number(e.target.value))} />
            </label>
            <button className="primary" onClick={createDeposit}>
              <ExternalLink size={19} />
              Создать счет CryptoBot
            </button>
            {activeInvoice?.url && (
              <button className="ghost-action" onClick={() => openPayment(activeInvoice.url)}>
                <ExternalLink size={18} />
                Открыть оплату еще раз
              </button>
            )}
          </div>

          <section className="history">
            <SectionTitle title="История счетов" action="Обновить" onClick={() => deposits[0] && checkDeposit(deposits[0].id)} />
            {deposits.length === 0 ? (
              <EmptyState text="Счетов еще нет. Создайте оплату через CryptoBot." />
            ) : deposits.map((item) => (
              <article className="deposit-row" key={item.id}>
                <div>
                  <strong>{money(item.amount)}</strong>
                  <span>{item.status === 'paid' ? 'Оплачен' : 'Ожидает оплаты'}</span>
                </div>
                <button onClick={() => checkDeposit(item.id)} title="Проверить оплату">
                  <RefreshCw size={17} />
                </button>
              </article>
            ))}
          </section>

        </section>
      )}

      {tab === 'withdraw' && (
        <section className="view">
          <section className="wallet-card">
            <WalletCards size={30} />
            <p>Доступно к выводу</p>
            <strong>{money(me.balance)}</strong>
            <span>Создайте заявку на вывод. Администратор проверит ее и обновит статус.</span>
          </section>

          <div className="sheet">
            <div className="sheet-head">
              <WalletCards size={22} />
              <h2>Вывод средств</h2>
            </div>
            <label>
              Сумма, ₽
              <input type="number" min="1" value={withdrawalAmount} onChange={(event) => setWithdrawalAmount(Number(event.target.value))} />
            </label>
            <label>
              Кошелек или реквизиты
              <input value={withdrawalWallet} onChange={(event) => setWithdrawalWallet(event.target.value)} placeholder="USDT TRC20 / TON / карта" />
            </label>
            <button className="primary" onClick={createWithdrawal}>
              Создать заявку
            </button>
          </div>

          <section className="history">
            <SectionTitle title="История выводов" action="" onClick={() => {}} />
            {(state.withdrawals || []).length === 0 ? (
              <EmptyState text="Заявок на вывод пока нет." />
            ) : state.withdrawals.map((item) => (
              <article className="deposit-row" key={item.id}>
                <div>
                  <strong>{money(item.amount)}</strong>
                  <span>{item.status} · {item.wallet}</span>
                </div>
              </article>
            ))}
          </section>
        </section>
      )}

      {tab === 'profile' && (
        <section className="view">
          <section className="profile-hero">
            <div className="profile-hero-content">
              <Avatar user={me} />
              <div className="profile-main">
                <h2>{me.name}</h2>
                <p>{me.username ? `@${me.username}` : `ID ${me.telegramId}`}</p>
                <div className="profile-badges">
                  <span>{levelFor(me)}</span>
                  {(badgesFor(me).length ? badgesFor(me) : ['Без бейджей']).map((badge) => <span key={badge}>{badge}</span>)}
                </div>
              </div>
              <div className="profile-balance">
                <span>Баланс</span>
                <strong>{money(me.balance)}</strong>
              </div>
            </div>
          </section>

          <div className="profile-stats">
            <ProfileMetric icon={<BadgeCheck />} label="Задания" value={myTasks.length} />
            <ProfileMetric icon={<CheckCircle2 />} label="Завершено" value={tasks.filter((task) => task.status === 'done').length} />
            <ProfileMetric icon={<Star />} label="Рейтинг" value={Number(me.completedTasks ? me.rating : 0).toFixed(1)} />
          </div>

          <div className="profile-actions">
            <button onClick={() => goTo('orders')}>
              <BriefcaseBusiness size={19} />
              Мои заказы
            </button>
            <button onClick={() => goTo('work')}>
              <MessageSquare size={19} />
              Мои отклики
            </button>
            <button onClick={() => goTo('wallet')}>
              <WalletCards size={19} />
              Пополнение баланса
            </button>
            <button onClick={() => goTo('withdraw')}>
              <Banknote size={19} />
              Вывод баланса
            </button>
          </div>

          <div className="pro-card">
            <div className="pro-card-top">
              <div>
                <span className="pro-label">TASKPAY PRO</span>
                <h2>Больше видимости для заказов</h2>
                <div className="pro-price">
                  <strong>500 ₽</strong>
                  <span>30 дней</span>
                </div>
                <p>Поднимайте задания выше и получайте больше откликов от исполнителей.</p>
              </div>
            </div>
            <div className="pro-benefits">
              <span><CheckCircle2 size={15} /> Поднятие задач</span>
              <span><CheckCircle2 size={15} /> Выделение в ленте</span>
              <span><CheckCircle2 size={15} /> Больше откликов</span>
              <span><CheckCircle2 size={15} /> Приоритет показа</span>
            </div>
            <button className="primary" disabled={isProActive} onClick={() => run(() => api.post('/api/subscriptions/pro', { userId: me.id, days: 30 }), 'PRO активирован на 30 дней.')}>
              <Sparkles size={19} />
              {isProActive ? 'PRO активен' : 'Активировать PRO'}
            </button>
          </div>
        </section>
      )}

      {tab === 'admin' && me.isAdmin && (
        <AdminPanel admin={state.admin} me={me} run={run} />
      )}

      <nav className="nav" style={{ gridTemplateColumns: `repeat(${me.isAdmin ? 5 : 4}, 1fr)` }}>
        <NavButton active={tab === 'home'} icon={<Home />} label="Главная" onClick={() => goTo('home')} />
        <NavButton active={tab === 'tasks'} icon={<ListChecks />} label="Задания" onClick={() => goTo('tasks')} />
        <NavButton active={tab === 'create'} icon={<Plus />} label="Создать" onClick={() => goTo('create')} />
        <NavButton active={tab === 'profile'} icon={<UserRound />} label="Профиль" onClick={() => goTo('profile')} />
        {me.isAdmin && <NavButton active={tab === 'admin'} icon={<Settings />} label="Админ" onClick={() => goTo('admin')} />}
      </nav>
    </main>
  )
}

function SectionTitle({ title, action, onClick }) {
  return (
    <div className="section-title">
      <h2>{title}</h2>
      <button onClick={onClick}>{action}<ChevronRight size={16} /></button>
    </div>
  )
}

function Stat({ icon, label, value }) {
  return (
    <div className="stat">
      {React.cloneElement(icon, { size: 18 })}
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function FeatureChip({ title, text }) {
  return (
    <div className="feature-chip">
      <strong>{title}</strong>
      <span>{text}</span>
    </div>
  )
}

function statusMeta(status) {
  const map = {
    open: ['Открыто', 'green'],
    in_work: ['В работе', 'yellow'],
    review: ['На проверке', 'blue'],
    done: ['Завершено', 'done'],
    canceled: ['Отменено', 'red'],
  }
  return map[status] || ['Открыто', 'green']
}

function levelFor(user) {
  const completed = Number(user.completedTasks || 0)
  const rating = Number(user.rating || 0)
  const turnover = Number(user.turnover || 0)
  if (rating >= 4.9 && completed >= 100 && turnover >= 250000) return 'Elite'
  if (rating >= 4.8 && completed >= 40 && turnover >= 90000) return 'Pro'
  if (rating >= 4.6 && completed >= 10) return 'Проверенный'
  return 'Новичок'
}

function badgesFor(user) {
  const badges = []
  const completed = Number(user.completedTasks || 0)
  if (Number(user.responseMinutes || 999) <= 15) badges.push('Быстро отвечает')
  if (Number(user.completedTasks || 0) >= 100) badges.push('100 заказов')
  if (completed >= 3 && Number(user.rating || 0) >= 4.8) badges.push('Надежный')
  if ((user.skills || []).some((skill) => String(skill).toLowerCase().includes('smm'))) badges.push('SMM эксперт')
  return badges
}

function CategoryFilters({ value, onChange }) {
  const categories = ['Все', 'SMM', 'Дизайн', 'Тексты', 'Монтаж', 'Telegram', 'AI', 'Парсинг', 'Разработка', 'Реклама']
  return (
    <div className="filter-row">
      {categories.map((item) => (
        <button className={value === item ? 'active' : ''} key={item} onClick={() => onChange(item)}>{item}</button>
      ))}
    </div>
  )
}

function TaskList({ tasks, me, run, onOpen, emptyText, emptyAction }) {
  if (tasks.length === 0) return <EmptyState text={emptyText} action={emptyAction} />

  return (
    <div className="task-list">
      {tasks.map((task) => (
        <TaskCard task={task} me={me} run={run} onOpen={onOpen} key={task.id} />
      ))}
    </div>
  )
}

function TaskCard({ task, me, run, onOpen }) {
  const [isApplying, setIsApplying] = useState(false)
  const [message, setMessage] = useState('Готов выполнить. Напишите детали, и я сразу начну.')
  const isOwnTask = task.ownerId === me.id
  const alreadyApplied = Boolean(task.appliedByMe)

  async function sendApply() {
    const fresh = await run(
      () => api.post(`/api/tasks/${task.id}/apply`, { userId: me.id, message }),
      'Отклик отправлен заказчику.',
    )
    if (fresh) setIsApplying(false)
  }

  return (
    <article className={`${task.priority ? 'task-card pro-task' : 'task-card'} status-card ${task.status || 'open'}`}>
      <div className="task-top">
        <span>{task.category}</span>
        <strong>{money(task.budget)}</strong>
      </div>
      <StatusPill status={task.status} />
      <h3 onClick={() => onOpen?.(task)}>{task.title}</h3>
      <p>{task.description || 'Заказчик пока не добавил подробное описание.'}</p>
      {task.recommendedPerformers?.length > 0 && (
        <div className="recommend-box">
          <strong>Автоподбор</strong>
          <span>{task.recommendedPerformers.map((item) => `${item.name} · ${item.level}`).join(', ')}</span>
        </div>
      )}
      <div className="task-meta">
        <span><Clock3 size={15} />{task.deadline}</span>
        <span><Send size={15} />{task.responses} откликов</span>
      </div>

      {isApplying && (
        <div className="apply-box">
          <label>
            Сообщение заказчику
            <textarea value={message} onChange={(event) => setMessage(event.target.value)} />
          </label>
          <div className="apply-actions">
            <button className="ghost-action" onClick={() => setIsApplying(false)}>Отмена</button>
            <button onClick={sendApply}>Отправить отклик</button>
          </div>
        </div>
      )}

      {!isApplying && (
        <div className="task-actions">
          <button className="ghost-action" onClick={() => onOpen?.(task)}>Подробнее</button>
          <button disabled={isOwnTask || alreadyApplied} onClick={() => setIsApplying(true)}>
            {isOwnTask ? 'Это ваше задание' : alreadyApplied ? 'Отклик отправлен' : 'Откликнуться'}
            {!isOwnTask && !alreadyApplied && <ChevronRight size={17} />}
          </button>
        </div>
      )}
    </article>
  )
}

function TaskDetail({ task, me, onOpenChat }) {
  return (
    <section className="view">
      <article className={`task-card detail-card status-card ${task.status || 'open'}`}>
        <div className="task-top">
          <span>{task.category}</span>
          <strong>{money(task.budget)}</strong>
        </div>
        <StatusPill status={task.status} />
        <h3>{task.title}</h3>
        <p>{task.description || 'Описание не добавлено.'}</p>
        <div className="detail-grid">
          <InfoMini label="Срок" value={task.deadline} />
          <InfoMini label="Отклики" value={task.responses} />
          <InfoMini label="Заказчик" value={task.owner?.name || 'Пользователь'} />
        </div>
        {task.applications?.length > 0 && (
          <div className="sub-block">
            <strong>Отклики</strong>
            {task.applications.map((item) => (
              <div className="application-row" key={item.id}>
                <MiniAvatar user={item.user} />
                <div>
                  <b>{item.user?.name || 'Исполнитель'}</b>
                  <span>{item.message}</span>
                </div>
                <em>{item.status === 'accepted' ? 'Выбран' : item.status === 'rejected' ? 'Отклонен' : 'Новый'}</em>
              </div>
            ))}
          </div>
        )}
        {task.workerId && [task.ownerId, task.workerId].includes(me.id) && (
          <button className="chat-open-button" onClick={onOpenChat}>
            <MessageSquare size={18} />
            Открыть чат заказа
            {task.unreadMessages > 0 && <span>{task.unreadMessages}</span>}
          </button>
        )}
      </article>
    </section>
  )
}

function InfoMini({ label, value }) {
  return (
    <div className="info-mini">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function MyOrders({ orders, me, run, onOpenChat }) {
  if (orders.length === 0) return <section className="view"><EmptyState text="Вы еще не создавали задания." /></section>

  return (
    <section className="view">
      {orders.map((task) => (
        <article className="task-card manage-card" key={task.id}>
          <div className="task-top">
            <span>{task.category}</span>
            <strong>{money(task.budget)}</strong>
          </div>
          <StatusPill status={task.status} />
          <h3>{task.title}</h3>
          <p>{task.description || 'Описание не добавлено.'}</p>

          <div className="sub-block">
            <strong>Отклики</strong>
            {task.applications?.length ? task.applications.map((item) => (
              <div className="application-row" key={item.id}>
                <MiniAvatar user={item.user} />
                <div>
                  <b>{item.user?.name || 'Исполнитель'}</b>
                  <span>{item.message}</span>
                </div>
                {item.status === 'new' && task.status === 'open' ? (
                  <button onClick={() => run(() => api.post(`/api/applications/${item.id}/accept`, { userId: me.id }), 'Исполнитель выбран.')}>Выбрать</button>
                ) : <em>{item.status === 'accepted' ? 'Выбран' : 'Отклонен'}</em>}
              </div>
            )) : <p>Откликов пока нет.</p>}
          </div>

          {task.workerId && (
            <button className="chat-open-button" onClick={() => onOpenChat(task)}>
              <MessageSquare size={18} />
              Открыть чат
              {task.unreadMessages > 0 && <span>{task.unreadMessages}</span>}
            </button>
          )}

          {['in_work', 'review'].includes(task.status) && (
            <button onClick={() => run(() => api.post(`/api/tasks/${task.id}/complete`, { userId: me.id, rating: 5 }), 'Заказ завершен, оплата начислена исполнителю.')}>
              <Star size={17} />
              Завершить и оценить 5
            </button>
          )}
        </article>
      ))}
    </section>
  )
}

function MyWork({ work, me, run, onOpenChat }) {
  if (work.length === 0) return <section className="view"><EmptyState text="Вы еще не откликались на задания." /></section>

  return (
    <section className="view">
      {work.map((task) => (
        <article className="task-card manage-card" key={task.id}>
          <div className="task-top">
            <span>{task.category}</span>
            <strong>{money(task.budget)}</strong>
          </div>
          <StatusPill status={task.status} />
          <h3>{task.title}</h3>
          <p>{task.description || 'Описание не добавлено.'}</p>
          <div className="task-meta">
            <span><Clock3 size={15} />{task.deadline}</span>
            <span>{task.workerId === me.id ? 'Вы исполнитель' : 'Отклик отправлен'}</span>
          </div>
          {task.workerId === me.id && task.status === 'in_work' && (
            <button onClick={() => run(() => api.post(`/api/tasks/${task.id}/review`, { userId: me.id }), 'Задание отправлено на проверку.')}>
              Отправить на проверку
            </button>
          )}
          {task.workerId === me.id && (
            <button className="chat-open-button" onClick={() => onOpenChat(task)}>
              <MessageSquare size={18} />
              Открыть чат
              {task.unreadMessages > 0 && <span>{task.unreadMessages}</span>}
            </button>
          )}
        </article>
      ))}
    </section>
  )
}

function ChatPage({ task, me, messages, run }) {
  useEffect(() => {
    if (!task?.id || !me?.id) return
    run(
      () => api.post(`/api/tasks/${task.id}/messages/read`, { userId: me.id }),
      '',
    )
  }, [task?.id, me?.id])

  const partner = me.id === task.ownerId ? task.worker : task.owner

  return (
    <section className="view chat-view">
      <article className="chat-task-head">
        <div>
          <span>{task.category}</span>
          <h2>{task.title}</h2>
          <p>{partner?.name ? `Собеседник: ${partner.name}` : 'Чат доступен участникам заказа'}</p>
        </div>
        <strong>{money(task.budget)}</strong>
      </article>
      <ChatBox task={task} me={me} messages={messages} run={run} />
    </section>
  )
}

function ChatBox({ task, me, messages, run }) {
  const [text, setText] = useState('')
  const taskMessages = messages.filter((item) => item.taskId === task.id)

  async function sendMessage() {
    const fresh = await run(
      () => api.post(`/api/tasks/${task.id}/messages`, { userId: me.id, text }),
      'Сообщение отправлено.',
    )
    if (fresh) setText('')
  }

  return (
    <div className="chat-box">
      <strong>Чат заказа</strong>
      <div className="chat-list">
        {taskMessages.length === 0 ? <span>Сообщений пока нет.</span> : taskMessages.map((message) => (
          <div className={message.fromUserId === me.id ? 'chat-line mine' : 'chat-line'} key={message.id}>
            <MiniAvatar user={message.fromUserId === task.ownerId ? task.owner : task.worker} />
            <div className="chat-message">{message.text}</div>
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input value={text} onChange={(event) => setText(event.target.value)} placeholder="Написать сообщение" />
        <button onClick={sendMessage} disabled={!text.trim()}><Send size={16} /></button>
      </div>
    </div>
  )
}

function MiniAvatar({ user }) {
  if (user?.photoUrl) return <img className="mini-avatar" src={user.photoUrl} alt={user.name || ''} />
  const initial = String(user?.name || 'U').slice(0, 1).toUpperCase()
  return <span className="mini-avatar">{initial}</span>
}

function SkeletonScreen() {
  return (
    <main className="app">
      <div className="skeleton-header">
        <span />
        <i />
      </div>
      <div className="skeleton-card large" />
      <div className="skeleton-row"><span /><span /></div>
      <div className="skeleton-row three"><span /><span /><span /></div>
      <div className="skeleton-card" />
    </main>
  )
}

function AdminPanel({ admin, me, run }) {
  if (!admin) return <section className="view"><EmptyState text="Ваш Telegram ID не добавлен в ADMIN_IDS." /></section>

  return (
    <section className="view">
      <div className="admin-grid">
        <Stat icon={<UserRound />} label="Пользователи" value={admin.users.length} />
        <Stat icon={<ListChecks />} label="Задания" value={admin.tasks.length} />
        <Stat icon={<WalletCards />} label="Выводы" value={admin.withdrawals.length} />
      </div>

      <div className="sheet">
        <div className="sheet-head"><UserRound size={22} /><h2>Пользователи</h2></div>
        {admin.users.map((user) => (
          <div className="admin-row" key={user.id}>
            <div>
              <strong>{user.name}</strong>
              <span>ID {user.telegramId} · {money(user.balance)}</span>
            </div>
            <button onClick={() => run(() => api.post(`/api/admin/users/${user.id}/balance`, { userId: me.id, amount: 1000 }), 'Баланс пользователя пополнен на 1000 ₽.')}>+1000</button>
          </div>
        ))}
      </div>

      <div className="sheet">
        <div className="sheet-head"><ListChecks size={22} /><h2>Задания</h2></div>
        {admin.tasks.length === 0 ? <p className="plain-text">Заданий нет.</p> : admin.tasks.map((task) => (
          <div className="admin-row" key={task.id}>
            <div>
              <strong>{task.title}</strong>
              <span>{task.status} · {money(task.budget)}</span>
            </div>
            <button onClick={() => run(() => api.post(`/api/admin/tasks/${task.id}/status`, { userId: me.id, status: 'canceled', statusLabel: 'Отменено' }), 'Задание отменено админом.')}>Отменить</button>
          </div>
        ))}
      </div>

      <div className="sheet">
        <div className="sheet-head"><WalletCards size={22} /><h2>Вывод средств</h2></div>
        {admin.withdrawals.length === 0 ? <p className="plain-text">Заявок на вывод нет.</p> : admin.withdrawals.map((item) => (
          <div className="admin-row" key={item.id}>
            <div>
              <strong>{money(item.amount)}</strong>
              <span>{item.status} · {item.wallet}</span>
            </div>
            <button onClick={() => run(() => api.post(`/api/admin/withdrawals/${item.id}/status`, { userId: me.id, status: 'paid' }), 'Вывод отмечен оплаченным.')}>Оплачен</button>
          </div>
        ))}
      </div>
    </section>
  )
}

function StatusPill({ status }) {
  const [label, color] = statusMeta(status)
  return (
    <div className={`status-pill ${color}`}>
      <span />
      {label}
    </div>
  )
}

function Notifications({ items, me, run }) {
  return (
    <section className="notifications-panel">
      <div className="notifications-head">
        <h2>Уведомления</h2>
        <span>{items.filter((item) => !item.read).length} новых</span>
      </div>
      {items.length === 0 ? (
        <div className="mini-empty">
          <div className="mini-empty-icon"><Bell size={18} /></div>
          <strong>Пока тихо</strong>
          <p>Здесь появятся отклики, сообщения и статусы заказов.</p>
        </div>
      ) : items.map((item) => (
        <article className={item.read ? 'notification read' : 'notification'} key={item.id}>
          <div>
            <strong>{item.title}</strong>
            <p>{item.text}</p>
          </div>
          {!item.read && (
            <button onClick={() => run(() => api.post(`/api/notifications/${item.id}/read`, { userId: me.id }), 'Уведомление прочитано.')}>
              Ок
            </button>
          )}
        </article>
      ))}
    </section>
  )
}

function EmptyState({ text, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon"><Sparkles size={21} /></div>
      <div>
        <h3>Заданий пока нет</h3>
        <p>{text}</p>
      </div>
      {action && (
        <button onClick={action}>
          <Plus size={17} />
          Создать задание
        </button>
      )}
    </div>
  )
}

function Avatar({ user }) {
  if (user.photoUrl) {
    return <img className="avatar avatar-img" src={user.photoUrl} alt={user.name} />
  }
  const initial = String(user.name || 'U').trim().slice(0, 1).toUpperCase()
  return <div className="avatar avatar-fallback">{initial || <UserRound size={30} />}</div>
}

function InfoLine({ icon, label, value }) {
  return (
    <div className="info-line">
      {React.cloneElement(icon, { size: 19 })}
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function ProfileMetric({ icon, label, value }) {
  return (
    <div className="profile-metric">
      {React.cloneElement(icon, { size: 18 })}
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function NavButton({ active, icon, label, onClick }) {
  return (
    <button className={active ? 'active' : ''} onClick={onClick} title={label}>
      {React.cloneElement(icon, { size: 21 })}
      <span>{label}</span>
    </button>
  )
}

createRoot(document.getElementById('root')).render(<App />)
