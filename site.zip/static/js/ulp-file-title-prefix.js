/**
 * Colored [line-count] prefix in file titles (list, profile, admin, dynamic cards).
 */
(function () {
    'use strict';

    /**
     * @param {HTMLElement} anchorEl
     * @param {string} rawTitle
     * @param {{ vip?: boolean, paid?: boolean }} [opts]
     */
    window.ulpApplyFileTitleLineCountMarkup = function (anchorEl, rawTitle, opts) {
        if (!anchorEl) return;
        opts = opts || {};
        var s = String(rawTitle == null ? '' : rawTitle);
        var m = s.match(/^(\[\d{1,3}(?:,\d{3})*\])/);
        anchorEl.textContent = '';
        if (!m) {
            if (s) anchorEl.appendChild(document.createTextNode(s));
            return;
        }
        var titleRow = anchorEl.closest('.file-title, .data-title, .adm-file-payload-row, .adm-td-file, td');
        var isVip = opts.vip || !!(titleRow && titleRow.querySelector('.icon-gem-gradient, .file-icon-gem-op'));
        var isPaid = !isVip && (opts.paid || !!(titleRow && titleRow.querySelector('.file-icon-paid, .file-icon--paid')));
        var block = document.createElement('span');
        block.className = 'file-title-line-count-block';
        var prefixEl = document.createElement('span');
        prefixEl.className = 'file-title-line-count-prefix'
            + (isVip ? ' file-title-line-count-prefix--vip' : '')
            + (isPaid ? ' file-title-line-count-prefix--paid' : '');
        prefixEl.setAttribute('title', 'Rows in file');
        prefixEl.textContent = m[1];
        block.appendChild(prefixEl);
        var rest = s.slice(m[1].length);
        if (rest.length) {
            block.appendChild(document.createTextNode(rest));
        }
        anchorEl.appendChild(block);
    };

    /**
     * Enhance anchors/spans marked for auto line-count styling (SPA tabs, late DOM).
     * @param {ParentNode} [root]
     */
    window.ulpEnhanceFileTitleLineCountsIn = function (root) {
        root = root || document;
        root.querySelectorAll('[data-ulp-file-title]').forEach(function (el) {
            if (el.dataset.ulpFileTitleEnhanced === '1') return;
            var raw = el.getAttribute('data-ulp-file-title') || '';
            if (!raw) return;
            var opts = {
                vip: el.getAttribute('data-ulp-file-vip') === '1',
                paid: el.getAttribute('data-ulp-file-paid') === '1'
            };
            window.ulpApplyFileTitleLineCountMarkup(el, raw, opts);
            el.dataset.ulpFileTitleEnhanced = '1';
        });
    };

    function bootEnhance() {
        window.ulpEnhanceFileTitleLineCountsIn(document);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootEnhance);
    } else {
        bootEnhance();
    }
    document.addEventListener('pageLoaded', bootEnhance);
})();
