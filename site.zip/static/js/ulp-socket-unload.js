/**
 * Close Engine.IO before socket.io/chat on unload (Safari F5 / pagehide).
 * Loaded from base.html before socket.io.min.js.
 */
(function () {
    'use strict';
    var ulpUnloadClosing = false;

    function ulpNoteReloadUnload() {
        try {
            var now = Date.now();
            var prev = parseInt(sessionStorage.getItem('ulp_eio_unload_ts') || '0', 10);
            if (prev > 0 && now - prev < 2500) {
                var streak = parseInt(sessionStorage.getItem('ulp_rapid_reload_streak') || '0', 10) + 1;
                sessionStorage.setItem('ulp_rapid_reload_streak', String(Math.min(streak, 10)));
            } else {
                sessionStorage.removeItem('ulp_rapid_reload_streak');
            }
            sessionStorage.setItem('ulp_eio_unload_ts', String(now));
        } catch (e) { /* ignore */ }
    }

    window.__ulpReloadGapMs = function () {
        try {
            var ts = parseInt(sessionStorage.getItem('ulp_eio_unload_ts') || '0', 10);
            if (ts <= 0) return 99999;
            return Date.now() - ts;
        } catch (e) {
            return 99999;
        }
    };

    window.__ulpRapidReloadStreak = function () {
        try {
            return parseInt(sessionStorage.getItem('ulp_rapid_reload_streak') || '0', 10);
        } catch (e) {
            return 0;
        }
    };

    function ulpCloseSocketForUnload() {
        if (ulpUnloadClosing) return;
        ulpUnloadClosing = true;
        window.__ulpPageUnloading = true;
        ulpNoteReloadUnload();
        if (window.__ulpConnectDelayTimer) {
            clearTimeout(window.__ulpConnectDelayTimer);
            window.__ulpConnectDelayTimer = null;
        }
        if (window.__ulpConnectCfRetryTimer) {
            clearTimeout(window.__ulpConnectCfRetryTimer);
            window.__ulpConnectCfRetryTimer = null;
        }
        window.__ulpSocketConnectInFlight = false;
        if (typeof window.__ulpAbortMaintenanceHealthFetch === 'function') {
            try { window.__ulpAbortMaintenanceHealthFetch(); } catch (e) { /* ignore */ }
        }
        if (typeof window.__ulpAbortOnlineCountHttpFetch === 'function') {
            try { window.__ulpAbortOnlineCountHttpFetch(); } catch (e) { /* ignore */ }
        }
        var s = window.chatSocket;
        if (!s) return;
        try {
            window._chatIntentionalReconnect = true;
            if (s.io && typeof s.io.reconnection === 'function') s.io.reconnection(false);
            if (s.io && s.io.engine) s.io.engine.close();
            if (s.io) s.io.disconnect();
            s.disconnect();
        } catch (e) { /* ignore */ }
    }

    window.addEventListener('keydown', function (e) {
        if (e.key === 'F5' || ((e.metaKey || e.ctrlKey) && (e.key === 'r' || e.key === 'R'))) {
            ulpCloseSocketForUnload();
        }
    }, true);
    window.addEventListener('pagehide', function (ev) {
        if (ev.persisted) return;
        ulpCloseSocketForUnload();
    }, true);
    window.addEventListener('beforeunload', ulpCloseSocketForUnload, true);
})();
