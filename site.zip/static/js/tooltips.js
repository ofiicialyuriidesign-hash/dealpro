/**
 * Stable Minimalist Tooltip Engine v1.7.0
 * Zero-flicker delegation; touch-safe (no instant hide on synthetic mousedown).
 */
    document.addEventListener('DOMContentLoaded', () => {
    const tooltip = document.createElement('div');
    tooltip.className = 'modern-tooltip';
    document.body.appendChild(tooltip);

    let activeTarget = null;
    let showTimer = null;

    window.hideAllTooltips = function () {
        activeTarget = null;
        clearTimeout(showTimer);
        showTimer = null;
        try {
            tooltip.classList.remove('active', 'tooltip--wrap');
            tooltip.style.display = 'none';
        } catch (e) { /* ignore */ }
    };
    /** Skip the compatibility mousedown that follows a touch (it was killing the tooltip immediately). */
    let skipNextMouseDownClear = false;
    /** After a touch on a tooltip target, ignore flaky synthetic mouseout briefly (mobile WebKit). */
    let touchOutGraceUntil = 0;

    const prefersFinePointerHover =
        typeof window.matchMedia === 'function' &&
        window.matchMedia('(hover: hover) and (pointer: fine)').matches;

    function hideTooltip() {
        activeTarget = null;
        tooltip.classList.remove('active', 'tooltip--wrap');
        clearTimeout(showTimer);
        showTimer = setTimeout(() => {
            if (!activeTarget) tooltip.style.display = 'none';
        }, 150);
    }

    function position(target) {
        const content = target.getAttribute('data-tooltip') || target.getAttribute('title');
        if (!content) return false;

        if (target.hasAttribute('title')) {
            target.setAttribute('data-tooltip', content);
            target.removeAttribute('title');
        }

        tooltip.textContent = content;

        if (target.getAttribute('data-tooltip-wrap') === 'true') {
            tooltip.classList.add('tooltip--wrap');
        } else {
            tooltip.classList.remove('tooltip--wrap');
        }

        const targetRect = target.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();

        let top = targetRect.top - tooltipRect.height - 8;
        let left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
        let pos = 'top';

        if (top < 10) {
            top = targetRect.bottom + 8;
            pos = 'bottom';
        }

        const padding = 10;
        if (left < padding) left = padding;
        if (left + tooltipRect.width > window.innerWidth - padding) {
            left = window.innerWidth - tooltipRect.width - padding;
        }

        tooltip.style.top = `${Math.round(top + window.scrollY)}px`;
        tooltip.style.left = `${Math.round(left + window.scrollX)}px`;
        tooltip.setAttribute('data-pos', pos);
        return true;
    }

    document.addEventListener(
        'pointerdown',
        (e) => {
            if (e.pointerType === 'touch') skipNextMouseDownClear = true;
        },
        true
    );
    document.addEventListener(
        'touchstart',
        () => {
            skipNextMouseDownClear = true;
        },
        { passive: true, capture: true }
    );

    document.addEventListener(
        'touchend',
        (e) => {
            if (prefersFinePointerHover) return;
            const t = e.target.closest('[title], [data-tooltip]');
            if (t) touchOutGraceUntil = Date.now() + 500;
        },
        { passive: true, capture: true }
    );

    document.addEventListener('mouseover', (e) => {
        const target = e.target.closest('[title], [data-tooltip]');
        if (!target) return;

        if (activeTarget === target) return;

        clearTimeout(showTimer);
        activeTarget = target;

        tooltip.style.display = 'block';
        if (position(target)) {
            tooltip.classList.add('active');
        } else {
            tooltip.style.display = 'none';
        }
    });

    document.addEventListener('mouseout', (e) => {
        if (!activeTarget) return;

        if (!prefersFinePointerHover && Date.now() < touchOutGraceUntil) return;

        let related = e.relatedTarget;
        while (related) {
            if (related === activeTarget) return;
            related = related.parentNode;
        }

        hideTooltip();
    });

    document.addEventListener('mousedown', () => {
        if (skipNextMouseDownClear) {
            skipNextMouseDownClear = false;
            return;
        }
        hideTooltip();
    });

    document.addEventListener(
        'click',
        (e) => {
            if (prefersFinePointerHover || !activeTarget) return;
            if (activeTarget.contains(e.target)) return;
            hideTooltip();
        },
        true
    );

    window.addEventListener(
        'scroll',
        () => {
            if (activeTarget) hideTooltip();
        },
        { passive: true }
    );

    const observer = new MutationObserver(() => {
        document.querySelectorAll('[title]').forEach((el) => {
            el.setAttribute('data-tooltip', el.getAttribute('title'));
            el.removeAttribute('title');
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });
});
