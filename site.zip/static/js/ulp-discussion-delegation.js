/**
 * Discussion UI actions via data attributes (file/resource pages).
 */
(function () {
    'use strict';

    if (window.__ulpDiscussionDeleg) return;
    window.__ulpDiscussionDeleg = true;

    document.addEventListener('click', function (e) {
        var bump = e.target.closest('[data-ulp-admin-bump]');
        if (bump && typeof window.ajaxAction === 'function') {
            e.preventDefault();
            e.stopPropagation();
            window.ajaxAction(bump.getAttribute('data-ulp-admin-bump'));
            return;
        }

        var send = e.target.closest('[data-ulp-send-comment]');
        if (send && typeof window.sendComment === 'function') {
            e.preventDefault();
            window.sendComment();
            return;
        }

        var cancel = e.target.closest('[data-ulp-cancel-discussion-edit], [data-ulp-cancel-file-edit], [data-ulp-cancel-resource-edit]');
        if (cancel) {
            e.preventDefault();
            if (typeof window.cancelResourceDiscussionInlineEdit === 'function') {
                window.cancelResourceDiscussionInlineEdit();
            } else if (typeof window.cancelFileDiscussionInlineEdit === 'function') {
                window.cancelFileDiscussionInlineEdit();
            }
            return;
        }

        var act = e.target.closest('[data-ulp-discussion-action]');
        if (!act) return;

        var action = act.getAttribute('data-ulp-discussion-action');
        var commentId = act.getAttribute('data-comment-id');

        if (action === 'edit' && commentId && typeof window.editComment === 'function') {
            window.editComment(commentId);
            return;
        }
        if (action === 'delete' && commentId && typeof window.deleteComment === 'function') {
            window.deleteComment(commentId);
            return;
        }
        if (action === 'reply') {
            var user = act.getAttribute('data-reply-user');
            if (user && typeof window.setCommentReply === 'function') {
                window.setCommentReply(user);
            }
            return;
        }
        if (action === 'reply-jump' && typeof window.jumpToDiscussionEditor === 'function') {
            e.preventDefault();
            window.jumpToDiscussionEditor(e);
            return;
        }
        if (action === 'like' && commentId && typeof window.toggleDiscussionCommentLike === 'function') {
            window.toggleDiscussionCommentLike(commentId);
            return;
        }
        if (action === 'like-login' && typeof window.requireLogin === 'function') {
            window.requireLogin(
                'Please login or register to like comments.',
                window.location.pathname + window.location.search
            );
            return;
        }
    });
})();
