/**
 * Persistent site announcement (stored campaign + public API).
 * Same bottom-left row layout + chrome as realtime showToast (.realtime-toast).
 */
(function () {
    var STORAGE_PREFIX = 'ulp_site_banner_hide_';

    function escapeHtml(s) {
        var div = document.createElement('div');
        div.textContent = s == null ? '' : String(s);
        return div.innerHTML;
    }

    function dismissKey(id) {
        return STORAGE_PREFIX + id;
    }

    function navigate(href) {
        if (!href || href === '#') return;
        if (typeof window.ulpNavigateHref === 'function') {
            window.ulpNavigateHref(href);
            return;
        }
        if (window.loadPage) {
            document.body.style.cursor = 'wait';
            window.loadPage(href);
        } else {
            window.location.href = href;
        }
    }

    function mount(root, data) {
        root.innerHTML = '';
        root.className = 'ulp-site-banner-host';

        var card = document.createElement('div');
        card.className = 'ulp-site-banner-card';
        card.setAttribute('role', 'status');
        card.setAttribute('aria-live', 'polite');
        card.setAttribute('aria-label', 'Site announcement');

        var iconCol = document.createElement('div');
        iconCol.className = 'ulp-corner-toast-iconCol';
        iconCol.innerHTML = '<i class="' + escapeHtml(data.icon || 'fas fa-bullhorn') + '" aria-hidden="true"></i>';

        var textCol = document.createElement('div');
        textCol.className = 'ulp-corner-toast-textCol';

        var titleEl = document.createElement('div');
        titleEl.className = 'ulp-site-banner-title';
        titleEl.textContent = data.title || 'Announcement';

        var msgEl = document.createElement('div');
        msgEl.className = 'ulp-site-banner-msg';
        var msgRaw = data.message || '';
        if (typeof window.linkifyPlainTextForDisplay === 'function') {
            msgEl.innerHTML = window.linkifyPlainTextForDisplay(msgRaw);
            if (typeof window.ulpWireInlineContentLinks === 'function') {
                window.ulpWireInlineContentLinks(msgEl.parentElement || card);
            } else {
                msgEl.querySelectorAll('a.external-link').forEach(function (a) {
                    a.addEventListener('click', function (e) {
                        e.stopPropagation();
                        var href = (a.getAttribute('href') || '').trim();
                        if (!href || href === '#') return;
                        e.preventDefault();
                        navigate(href);
                    });
                });
            }
        } else {
            msgEl.textContent = msgRaw;
        }

        textCol.appendChild(titleEl);
        textCol.appendChild(msgEl);

        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'ulp-corner-toast-close';
        closeBtn.setAttribute('aria-label', 'Dismiss announcement');
        closeBtn.innerHTML = '<i class="fas fa-times" aria-hidden="true"></i>';
        closeBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            e.preventDefault();
            try {
                localStorage.setItem(dismissKey(data.id), String(Date.now()));
            } catch (err) {}
            root.innerHTML = '';
            root.className = '';
        });

        card.appendChild(iconCol);
        card.appendChild(textCol);
        card.appendChild(closeBtn);

        if (data.link) {
            card.style.cursor = 'pointer';
            card.addEventListener('click', function (e) {
                if (e.target.closest('.ulp-corner-toast-close')) return;
                navigate(data.link);
            });
        }

        root.appendChild(card);

        requestAnimationFrame(function () {
            card.classList.add('ulp-site-banner-card--in');
        });
    }

    async function load() {
        var root = document.getElementById('ulp-site-banner-root');
        if (!root) return;
        try {
            var r = await fetch('/api/site-banner', { credentials: 'same-origin', cache: 'no-store' });
            var j = await r.json();
            if (!j || !j.banner) return;
            var id = j.banner.id;
            try {
                if (localStorage.getItem(dismissKey(id))) return;
            } catch (e) {}
            mount(root, j.banner);
        } catch (e) {}
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', load);
    } else {
        load();
    }
})();
