/**
 * listings.js — Shared real-time card rendering helpers.
 * Used by index.html (files) and directory/index.html (resources).
 * v1.0.0
 */

/* ---------------------------------------------------------------
   FILE ITEM RENDERER
   opts = { badge, isLiked, canModerate, isAdmin, onCheckboxChange }
   isAdmin: bulk checkbox column. canModerate: quick mod actions on row.
   badge: 'new' | 'bumped' | 'pending' | null
--------------------------------------------------------------- */
/** Owner delete button HTML (same cleanup as admin delete). */
window.ulpOwnerDeleteButtonHtml = function (entity, contentId, ownerId) {
    var body = document.body;
    var uid = body && body.getAttribute('data-user-id');
    var role = body && body.getAttribute('data-user-role');
    if (!uid || ownerId == null || String(uid) !== String(ownerId)) return '';
    if (role === 'admin' || role === 'moderator') return '';
    var url =
        entity === 'file'
            ? '/my/delete/file/' + contentId
            : entity === 'forum_topic'
              ? '/my/delete/topic/' + contentId
              : '/my/delete/listing/' + contentId;
    var title =
        entity === 'file' ? 'Delete file' : entity === 'forum_topic' ? 'Delete topic' : 'Delete resource';
    return (
        '<button type="button" class="action-icon-btn delete" title="' +
        title +
        '" data-ulp-ajax-action="' +
        url +
        '" aria-label="' +
        title +
        '"><i class="fas fa-trash"></i></button>'
    );
};

function selfBumpCooldownTitle(kind) {
    var titles = window.__ulpSelfBumpCooldownTitles || {};
    if (titles[kind]) return titles[kind];
    return 'Next bump unavailable';
}

/** Owner self-bump button HTML (registered users, once per 24h per content type). */
window.ulpSelfBumpButtonHtml = function (kind, contentId, ownerId, opts) {
    opts = opts || {};
    var body = document.body;
    var uid = body && body.getAttribute('data-user-id');
    var role = body && body.getAttribute('data-user-role');
    if (!uid || ownerId == null || String(uid) !== String(ownerId)) return '';
    if (role === 'admin') return '';
    var availMap = window.__ulpSelfBumpAvailable || {};
    var avail = availMap[kind];
    var cssClass = opts.cssClass || 'action-icon-btn';
    var extraClass = opts.extraClass || '';
    var urlMap = {
        file: '/my/bump/file/',
        listing: '/my/bump/listing/',
        forum_topic: '/my/bump/topic/',
    };
    var base = urlMap[kind];
    if (!base) return '';
    if (avail === false) {
        var cooldownTitle = selfBumpCooldownTitle(kind);
        return (
            '<button type="button" class="' +
            cssClass +
            ' ulp-self-bump-btn is-disabled' +
            (extraClass ? ' ' + extraClass : '') +
            '" data-ulp-self-bump-kind="' +
            kind +
            '" title="' +
            cooldownTitle +
            '" disabled aria-label="' +
            cooldownTitle +
            '">' +
            '<i class="fas fa-level-up-alt" aria-hidden="true"></i></button>'
        );
    }
    if (avail !== true) return '';
    return (
        '<button type="button" class="' +
        cssClass +
        ' ulp-self-bump-btn' +
        (extraClass ? ' ' + extraClass : '') +
        '" data-ulp-self-bump-kind="' +
        kind +
        '" title="Bump to top (once per 24h)" data-ulp-ajax-action="' +
        base +
        contentId +
        '" aria-label="Bump to top (once per 24h)">' +
        '<i class="fas fa-level-up-alt" aria-hidden="true"></i></button>'
    );
};

function normalizeGroupIconClass(iconRaw) {
    if (typeof window.normalizeFaIconClass === 'function') {
        return window.normalizeFaIconClass(iconRaw);
    }
    const raw = ((iconRaw || 'fas fa-star') + '');
    const iconTokenMatch = raw.match(/fa-(?!solid\b|regular\b|brands\b)[a-z0-9-]+/i);
    let token = iconTokenMatch ? iconTokenMatch[0] : 'fa-star';
    const t = token.toLowerCase();
    if (t === 'fa-shield-alt' || t === 'fa-shield-halved') token = 'fa-shield';
    return `fa-solid ${token}`;
}

/** Free-file / resource upload + bump time group. */
window.syncFreeFileBumpTelemetry = function (root, data) {
    if (!root || !data) return;
    if (data.price) return;
    var group = root.querySelector('.telemetry-group.file-time-combo');
    if (!group) return;
    var uploadPod = group.querySelector('.time-pod');
    var bumpPod = group.querySelector('.file-bump-pod');
    if (!uploadPod || !bumpPod) return;

    var uploadTitle = data.upload_precise
        || uploadPod.getAttribute('data-upload-title')
        || (data.precise_date ? 'Uploaded: ' + data.precise_date : '');
    if (uploadTitle) {
        uploadPod.title = uploadTitle;
        uploadPod.setAttribute('data-upload-title', uploadTitle);
    }

    var active = !!(data.is_bumped && data.bump_at);
    group.classList.toggle('file-time-combo--solo', !active);
    if (!active) {
        bumpPod.classList.add('hidden');
        bumpPod.title = '';
        bumpPod.removeAttribute('data-activity-kind');
        var bumpIconHide = bumpPod.querySelector('i');
        if (bumpIconHide) bumpIconHide.className = 'fas fa-comment';
        var bt0 = bumpPod.querySelector('.bump-time-text');
        if (bt0) {
            bt0.textContent = '';
            bt0.removeAttribute('data-ulp-time-ts');
        }
        return;
    }
    bumpPod.classList.remove('hidden');
    bumpPod.title = data.bump_precise || '';
    if (data.bump_kind) bumpPod.setAttribute('data-activity-kind', String(data.bump_kind));
    else bumpPod.removeAttribute('data-activity-kind');
    var bumpIcon = bumpPod.querySelector('i');
    if (bumpIcon) {
        bumpIcon.className = data.bump_icon || (data.bump_kind === 'manual' ? 'fas fa-level-up-alt' : 'fas fa-comment');
    }
    var bt = bumpPod.querySelector('.bump-time-text');
    if (bt) {
        bt.setAttribute('data-ulp-time-ts', String(data.bump_at));
        bt.textContent = data.bump_date || '';
    }
    if (typeof window.ulpUpdateLiveTimes === 'function') {
        window.ulpUpdateLiveTimes(group);
    }
};

function normalizeListingCategory(cat) {
    if (cat == null || cat === '') return '';
    return String(cat).trim().toLowerCase().replace(/\s+/g, '_');
}

/** SPA-safe moderation control (uses admin.js ajaxAction — no form POST / full reload). */
function moderationAjaxBtn(url, className, title, iconClass) {
    const safeUrl = String(url).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
    return (
        '<button type="button" class="action-icon-btn ' + className + '" title="' + title + '" ' +
        'data-ulp-ajax-action="' + safeUrl + '"><i class="' +
        iconClass +
        '"></i></button>'
    );
}

/** Decode HTML entities from DB/pasted web text (e.g. &amp; → &). Matches server plain_text filter. */
function decodePlainTextField(str) {
    if (str == null || str === '') return '';
    var out = String(str);
    for (var i = 0; i < 3; i++) {
        var el = document.createElement('textarea');
        el.innerHTML = out;
        var next = el.value;
        if (next === out) break;
        out = next;
    }
    return out;
}
window.decodePlainTextField = decodePlainTextField;

/** Matches directory filter chips and Jinja `listing_category_label`. */
function listingCategoryLabel(cat) {
    var map = {
        forum: 'Forums',
        market: 'Markets',
        telegram_channel: 'Channels',
        telegram_group: 'Groups',
        other: 'Other'
    };
    var key = normalizeListingCategory(cat);
    if (!key) return '';
    if (map[key]) return map[key];
    return key.replace(/_/g, ' ').replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
}

function formatPriceValue(value) {
    var n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return '';
    var rounded = Math.round((n + Number.EPSILON) * 100) / 100;
    return rounded.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

/** Staff/owner action buttons for forum topic list cards. */
window.ulpForumTopicListActionsHtml = function (topicId, ownerId, opts) {
    opts = opts || {};
    var body = document.body;
    var role = (body && body.getAttribute('data-user-role')) || '';
    var uid = body && body.getAttribute('data-user-id');
    var canModerate =
        opts.canModerate != null ? opts.canModerate : role === 'admin' || role === 'moderator';
    var isAdmin = opts.isAdmin != null ? opts.isAdmin : role === 'admin';
    var isOwner = !!(uid && ownerId != null && String(uid) === String(ownerId));
    if (!canModerate && !isOwner) return '';

    var html = '';
    if (canModerate || isOwner) {
        html +=
            '<a href="/discussions/actions/topic/' +
            topicId +
            '/edit" class="action-icon-btn" title="Edit"><i class="fas fa-edit"></i></a>';
    }
    if (canModerate && opts.openingPending && opts.openingPostId) {
        html +=
            '<button type="button" class="action-icon-btn approve" title="Quick Approve" ' +
            'data-ulp-ajax-action="/admin/approve_forum_post/' +
            opts.openingPostId +
            '"><i class="fas fa-check"></i></button>';
    }
    if (isAdmin) {
        html +=
            '<button type="button" class="action-icon-btn" title="Bump to top" ' +
            'data-ulp-ajax-action="/admin/bump_topic/' +
            topicId +
            '"><i class="fas fa-level-up-alt"></i></button>';
    } else if (isOwner && !canModerate) {
        if (typeof window.ulpSelfBumpButtonHtml === 'function') {
            html += window.ulpSelfBumpButtonHtml('forum_topic', topicId, ownerId) || '';
        }
    }
    if (canModerate) {
        html +=
            '<button type="button" class="action-icon-btn delete" title="Delete topic" ' +
            'data-ulp-ajax-action="/admin/delete_forum_topic/' +
            topicId +
            '"><i class="fas fa-trash"></i></button>';
    } else if (isOwner) {
        if (typeof window.ulpOwnerDeleteButtonHtml === 'function') {
            html += window.ulpOwnerDeleteButtonHtml('forum_topic', topicId, ownerId) || '';
        }
    }
    if (!html) return '';
    return (
        '<div class="file-actions-container file-actions-row" data-topic-id="' +
        topicId +
        '">' +
        html +
        '</div>'
    );
};

window.renderFileItem = function (data, opts) {
    opts = opts || {};
    var canModerate = opts.canModerate || false;
    var isAdmin = opts.isAdmin || false;
    var isLiked = opts.isLiked || false;
    var isRead = opts.isRead || false;
    var badge = opts.badge || null;
    var cbChange = opts.onCheckboxChange || 'updateSelectionMain';
    var csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
    var currentUserId = (function () {
        var cw = (typeof window.__ulpGetFloatingChatRoot === 'function' && window.__ulpGetFloatingChatRoot())
            || document.querySelector('body > #chat-widget-container')
            || document.getElementById('chat-widget-container');
        return cw ? cw.getAttribute('data-user-id') : null;
    }());

    var template = document.getElementById('file-item-template');
    if (!template) return console.error("Template 'file-item-template' not found"), document.createElement('div');
    
    var clone = template.content.cloneNode(true);
    var div = clone.querySelector('.file-item');
    
    div.className = 'file-item list-card-shell list-card-clickable';
    if (isRead) div.classList.add('is-read');
    div.dataset.fileId = data.id;
    div.dataset.url = data.url;
    var listHit = div.querySelector('.list-card-hit');
    if (listHit) listHit.href = data.url;
    var sortTs = parseFloat(data.bumped_at);
    if (!Number.isFinite(sortTs) && data.upload_ts != null) sortTs = parseFloat(data.upload_ts);
    if (!Number.isFinite(sortTs)) sortTs = Date.now() / 1000;
    div.dataset.bumpedAt = String(sortTs);

    if (isAdmin) {
        var adminCol = div.querySelector('.admin-checkbox-col');
        if (adminCol) {
            adminCol.classList.remove('hidden');
            var cb = adminCol.querySelector('input[type="checkbox"]');
            cb.value = data.id;
            cb.id = 'file-cb-' + data.id;
            cb.classList.add('file-checkbox-main', 'selectable-row-checkbox');
        }
    }

    // Icon & Title — VIP gem; paid: coins; free: gift
    var fileIcon = div.querySelector('.file-icon');
    fileIcon.classList.add('tpl-icon');
    fileIcon.classList.remove('file-icon--paid', 'file-icon--free');
    if (data.is_vip_section) {
        fileIcon.className = 'file-icon tpl-icon fas fa-gem icon-gem-gradient';
    } else if (data.price) {
        fileIcon.className = 'file-icon tpl-icon fas fa-coins file-icon--paid';
    } else {
        fileIcon.className = 'file-icon tpl-icon fas fa-gift file-icon--free';
    }
    
    var titleLnk = div.querySelector('.view-file-btn');
    titleLnk.href = data.url;
    window.ulpApplyFileTitleLineCountMarkup(titleLnk, decodePlainTextField(data.title), {
        vip: !!data.is_vip_section,
        paid: !!data.price
    });

    if (data.password_protected) div.querySelector('.password-badge').classList.remove('hidden');
    
    if (badge === 'new') {
        var statusBadge = div.querySelector('.status-badge');
        statusBadge.classList.remove('hidden');
        statusBadge.innerHTML = '<i class="fas fa-plus-circle" aria-hidden="true"></i>';
        statusBadge.title = 'New file';
        statusBadge.setAttribute('aria-label', 'New file');
        statusBadge.classList.add('status-badge--new');
    }

    var publishIcon = div.querySelector('.file-publish-status-icon');
    if (publishIcon) {
        var publishTip = (data.publish_status && data.publish_status.tooltip) || null;
        if (!publishTip && data.scheduled_publish && data.scheduled_publish.precise) {
            publishTip = 'Scheduled publish (UTC): ' + data.scheduled_publish.precise;
        } else if (!publishTip && data.is_approved === false) {
            publishTip = 'Pending moderation';
        }
        if (publishTip) {
            publishIcon.classList.remove('hidden');
            publishIcon.title = publishTip;
            publishIcon.setAttribute('data-tooltip-html', publishTip);
            publishIcon.setAttribute('aria-label', publishTip);
        } else {
            publishIcon.classList.add('hidden');
            publishIcon.removeAttribute('data-tooltip-html');
        }
    }

    // Meta
    var userWrap = div.querySelector('.username-tag');
    userWrap.href = data.profile_url;
    userWrap.className = 'username-tag username-tag-inline ' + (data.role || 'user');
    
    var avatarUrl = window.ulpResolveAvatarUrl(data);
    var chipAv = userWrap.querySelector('.user-avatar-slot .user-avatar-circle');
    if (chipAv) chipAv.src = avatarUrl;
    userWrap.querySelector('.username-text').textContent = data.username;
    if (data.author_is_verified) {
        var verified = document.createElement('i');
        verified.className = 'fas fa-check-circle verified-badge';
        verified.title = 'Verified';
        userWrap.appendChild(verified);
    }

    userWrap.querySelectorAll('.group-badge-pile').forEach(function (n) { n.remove(); });
    userWrap.querySelectorAll(':scope > .group-badge').forEach(function (n) { n.remove(); });

    if (typeof window.appendGroupBadgePile === 'function') {
        window.appendGroupBadgePile(userWrap, data.groups);
    }

    var timeGroup = div.querySelector('.telemetry-group.file-time-combo');
    var timePod = timeGroup ? timeGroup.querySelector('.time-pod') : div.querySelector('.time-pod');
    var timeText = timePod ? timePod.querySelector('.time-text') : null;
    var timeTs = data.time_ts != null ? data.time_ts : (data.upload_ts != null ? data.upload_ts : data.bumped_at);
    if (data.price) {
        var bumpPodHide = timeGroup && timeGroup.querySelector('.file-bump-pod');
        if (bumpPodHide) bumpPodHide.classList.add('hidden');
        if (timePod) {
            timePod.title = data.precise_date || '';
            timePod.removeAttribute('data-upload-title');
        }
        if (timeText) timeText.textContent = data.upload_date || '';
        if (timeTs != null) {
            if (timePod) timePod.setAttribute('data-ulp-time-ts', String(timeTs));
            if (timeText) timeText.setAttribute('data-ulp-time-ts', String(timeTs));
        }
    } else if (timeGroup && timePod) {
        if (timePod) timePod.removeAttribute('data-ulp-time-ts');
        if (timeText) {
            timeText.textContent = data.upload_date || '';
            if (timeTs != null) timeText.setAttribute('data-ulp-time-ts', String(timeTs));
            else timeText.removeAttribute('data-ulp-time-ts');
        }
        if (typeof window.syncFreeFileBumpTelemetry === 'function') {
            window.syncFreeFileBumpTelemetry(div, data);
        }
    }

    // Telemetry
    div.querySelector('.views-count').textContent = data.views || 0;
    div.querySelector('.downloads-count').textContent = data.downloads || 0;
    div.querySelector('.comment-count').textContent = data.comments || 0;
    var likeCount = div.querySelector('.like-count');
    if (likeCount) likeCount.textContent = data.likes || 0;
    var likesPod = div.querySelector('.file-likes-stat, .like-btn-container[data-file-id]');
    var likedByMe = !!(opts.isLiked || data.user_liked);
    if (likesPod) {
        likesPod.classList.add('like-btn-container');
        likesPod.dataset.fileId = String(data.id);
        likesPod.classList.toggle('has-likes', Number(data.likes) > 0);
        likesPod.classList.toggle('is-liked', likedByMe);
        var heart = likesPod.querySelector('.fa-heart');
        if (heart) {
            heart.classList.add('like-btn');
            if (likedByMe) {
                heart.classList.remove('far');
                heart.classList.add('fas');
            } else {
                heart.classList.remove('fas');
                heart.classList.add('far');
            }
        }
    }

    var telGroup = div.querySelector('.telemetry-group.file-stats-group');
    if (telGroup) telGroup.dataset.fileId = data.id;

    if (telGroup && data.price) {
        var pricePod = document.createElement('span');
        pricePod.className = 'telemetry-pod file-price-pod';
        pricePod.dataset.fileId = String(data.id);
        pricePod.title = 'Price';
        pricePod.innerHTML =
            '<i class="fas fa-dollar-sign"></i> <span class="price-amount">' +
            formatPriceValue(data.price) +
            '</span>';
        telGroup.insertBefore(pricePod, telGroup.firstChild);
    }

    div.querySelectorAll('.file-stats-group .telemetry-pod').forEach(function (pod) {
        pod.dataset.fileId = data.id;
    });

    // Actions
    var isOwner = !!(data.user_id != null && currentUserId && String(data.user_id) === String(currentUserId));
    if (canModerate || isOwner) {
        var actions = div.querySelector('.file-actions-container');
        actions.classList.remove('hidden');
        var html = '';
        html += '<a href="/file/' + data.id + '/edit" class="action-icon-btn" title="Edit"><i class="fas fa-edit"></i></a>';
        if (canModerate && !data.is_approved) {
            html += moderationAjaxBtn('/admin/approve_file/' + data.id, 'approve', 'Quick Approve', 'fas fa-check');
        }
        if (canModerate) {
            html += '<button type="button" class="action-icon-btn" title="Bump to top" data-ulp-ajax-action="/admin/bump_file/' + data.id + '"><i class="fas fa-level-up-alt"></i></button>';
            html += moderationAjaxBtn('/admin/delete_file/' + data.id, 'delete', 'Reject/Delete', 'fas fa-trash');
        } else {
            if (data.is_approved && typeof window.ulpSelfBumpButtonHtml === 'function') {
                html += window.ulpSelfBumpButtonHtml('file', data.id, data.user_id) || '';
            }
            if (typeof window.ulpOwnerDeleteButtonHtml === 'function') {
                html += window.ulpOwnerDeleteButtonHtml('file', data.id, data.user_id) || '';
            }
        }
        actions.innerHTML = html;
    }

    return div;
};

/**
 * Feed ordering helper: first .file-item row (excluding excludeId) whose bumped_at is strictly below newBumped.
 * kind 'file' uses dataset.fileId; 'resource' uses dataset.listingId.
 */
window.__ulpFindFeedInsertBefore = function (list, newBumped, excludeId, kind) {
    kind = kind || 'file';
    if (!list) return null;
    var n = Number(newBumped);
    if (!Number.isFinite(n)) n = Date.now() / 1000;
    for (var i = 0; i < list.children.length; i++) {
        var c = list.children[i];
        if (!c || !c.classList || !c.classList.contains('file-item')) continue;
        var bid = kind === 'resource' ? c.dataset.listingId : c.dataset.fileId;
        if (excludeId != null && String(bid) === String(excludeId)) continue;
        var b = parseFloat(c.getAttribute('data-bumped-at'));
        if (!isNaN(b) && n > b) return c;
    }
    return null;
};

/** In-place update of an existing file row after file_bumped (avoids DOM replace when reorder is a no-op / move only). */
window.patchFileItemFromBumpData = function (row, data, opts) {
    opts = opts || {};
    if (!row || !data) return;
    var sortTs = parseFloat(data.bumped_at);
    if (!Number.isFinite(sortTs) && data.upload_ts != null) sortTs = parseFloat(data.upload_ts);
    if (!Number.isFinite(sortTs)) sortTs = Date.now() / 1000;
    row.dataset.bumpedAt = String(sortTs);
    row.setAttribute('data-bumped-at', String(sortTs));
    if (data.url) row.dataset.url = data.url;

    var fileIcon = row.querySelector('.file-icon');
    if (fileIcon) {
        if (data.is_vip_section) {
            fileIcon.className = 'file-icon fas fa-gem icon-gem-gradient file-icon-tpl file-icon-gem-op';
        } else if (data.price) {
            fileIcon.className = 'file-icon fas fa-coins file-icon-tpl file-icon-paid';
        } else {
            fileIcon.className = 'file-icon fas fa-gift file-icon-tpl file-icon-free';
        }
    }

    var titleLnk = row.querySelector('.view-file-btn');
    if (titleLnk && data.title != null) {
        window.ulpApplyFileTitleLineCountMarkup(titleLnk, decodePlainTextField(data.title), {
        vip: !!data.is_vip_section,
        paid: !!data.price
    });
        if (data.url) titleLnk.href = data.url;
    }

    var userWrap = row.querySelector('.username-tag');
    if (userWrap) {
        if (data.profile_url) userWrap.href = data.profile_url;
        userWrap.className = 'username-tag ' + (data.role || 'user');
        if (data.username) {
            var avatarUrl = data.avatar
                ? '/static/uploads/profiles/' + data.avatar
                : window.ulpResolveAvatarUrl(data);
            var av = userWrap.querySelector('.user-avatar-slot .user-avatar-circle');
            if (av) av.src = avatarUrl;
            var ut = userWrap.querySelector('.username-text');
            if (ut) ut.textContent = data.username;
        }
        userWrap.querySelectorAll('.group-badge-pile').forEach(function (n) { n.remove(); });
        userWrap.querySelectorAll(':scope > .group-badge').forEach(function (n) { n.remove(); });
        userWrap.querySelectorAll('.verified-badge').forEach(function (n) { n.remove(); });
        if (data.author_is_verified) {
            var verified = document.createElement('i');
            verified.className = 'fas fa-check-circle verified-badge';
            verified.title = 'Verified';
            userWrap.appendChild(verified);
        }
        if (typeof window.appendGroupBadgePile === 'function') {
            window.appendGroupBadgePile(userWrap, data.groups || []);
        }
    }

    var timeGroup = row.querySelector('.telemetry-group.file-time-combo');
    var timePod = timeGroup ? timeGroup.querySelector('.time-pod') : row.querySelector('.time-pod');
    var timeText = timePod ? timePod.querySelector('.time-text') : row.querySelector('.time-text');
    var timeTs = data.time_ts != null ? data.time_ts : (data.upload_ts != null ? data.upload_ts : data.bumped_at);
    if (data.price) {
        var bumpPodHide = timeGroup && timeGroup.querySelector('.file-bump-pod');
        if (bumpPodHide) bumpPodHide.classList.add('hidden');
        if (timePod) {
            timePod.title = data.precise_date || '';
            timePod.removeAttribute('data-upload-title');
        }
        if (timeText && data.upload_date != null) timeText.textContent = data.upload_date;
        if (timeTs != null) {
            if (timePod) timePod.setAttribute('data-ulp-time-ts', String(timeTs));
            if (timeText) timeText.setAttribute('data-ulp-time-ts', String(timeTs));
        }
    } else if (timeGroup && timePod) {
        if (timePod) timePod.removeAttribute('data-ulp-time-ts');
        if (timeText && data.upload_date != null) timeText.textContent = data.upload_date;
        if (timeText && timeTs != null) timeText.setAttribute('data-ulp-time-ts', String(timeTs));
        if (typeof window.syncFreeFileBumpTelemetry === 'function') {
            window.syncFreeFileBumpTelemetry(row, data);
        }
    }

    var vc = row.querySelector('.views-count');
    if (vc && data.views != null) vc.textContent = data.views;
    var dc = row.querySelector('.downloads-count');
    if (dc && data.downloads != null) dc.textContent = data.downloads;
    var cc = row.querySelector('.comment-count');
    if (cc && data.comments != null) {
        var nextComments = Number(data.comments);
        if (typeof window.__ulpPulseIfStatCountChanged === 'function' && Number.isFinite(nextComments)) {
            window.__ulpPulseIfStatCountChanged(cc, nextComments, '.telemetry-pod');
        }
        cc.textContent = data.comments;
    }

    var lc = row.querySelector('.like-count');
    if (lc && data.likes != null) {
        if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
            window.__ulpPulseIfStatCountChanged(lc, Number(data.likes), '.telemetry-pod');
        }
        lc.textContent = data.likes;
    }
    var likesPod = row.querySelector('.file-likes-stat, .like-btn-container[data-file-id]');
    if (likesPod && data.likes != null) {
        var nlikes = Number(data.likes);
        likesPod.classList.toggle('has-likes', Number.isFinite(nlikes) && nlikes > 0);
    }
    if (likesPod && data.user_liked !== undefined) {
        var likedByMe = !!data.user_liked;
        likesPod.classList.toggle('is-liked', likedByMe);
        var heart = likesPod.querySelector('.fa-heart');
        if (heart) {
            if (likedByMe) {
                heart.classList.remove('far');
                heart.classList.add('fas');
            } else {
                heart.classList.remove('fas');
                heart.classList.add('far');
            }
        }
    }

    var pricePod = row.querySelector('.file-price-pod');
    if (pricePod) {
        if (data.price) {
            pricePod.classList.remove('hidden');
            var amt = pricePod.querySelector('.price-amount');
            if (amt) amt.textContent = formatPriceValue(data.price);
        } else {
            pricePod.classList.add('hidden');
        }
    }
};

/** In-place update of a resource row after listing_bumped. */
window.patchResourceItemFromBumpData = function (row, data, opts) {
    opts = opts || {};
    if (!row || !data) return;
    var sortTs = parseFloat(data.bumped_at);
    if (!Number.isFinite(sortTs)) sortTs = Date.now() / 1000;
    row.dataset.bumpedAt = String(sortTs);
    row.setAttribute('data-bumped-at', String(sortTs));
    if (data.url) row.dataset.url = data.url;

    var titleLnk = row.querySelector('.view-item-btn');
    if (titleLnk && data.title != null) {
        titleLnk.textContent = decodePlainTextField(data.title);
        if (data.url) titleLnk.href = data.url;
    }

    var userWrap = row.querySelector('.username-tag');
    if (userWrap) {
        userWrap.href = '/user/' + (data.username || '');
        userWrap.className = 'username-tag ' + (data.role || 'user');
        if (data.username) {
            var avatarUrl = data.avatar
                ? '/static/uploads/profiles/' + data.avatar
                : window.ulpResolveAvatarUrl(data);
            var av = userWrap.querySelector('.user-avatar-slot .user-avatar-circle');
            if (av) av.src = avatarUrl;
            var ut = userWrap.querySelector('.username-text');
            if (ut) ut.textContent = data.username;
        }
        userWrap.querySelectorAll('.group-badge-pile').forEach(function (n) { n.remove(); });
        userWrap.querySelectorAll(':scope > .group-badge').forEach(function (n) { n.remove(); });
        userWrap.querySelectorAll('.verified-badge').forEach(function (n) { n.remove(); });
        if (data.author_is_verified) {
            var verified = document.createElement('i');
            verified.className = 'fas fa-check-circle verified-badge';
            verified.title = 'Verified';
            userWrap.appendChild(verified);
        }
        if (typeof window.appendGroupBadgePile === 'function') {
            window.appendGroupBadgePile(userWrap, data.groups || []);
        }
    }

    var timeGroup = row.querySelector('.telemetry-group.file-time-combo');
    var timePod = timeGroup ? timeGroup.querySelector('.time-pod') : row.querySelector('.time-pod');
    var timeText = timePod ? timePod.querySelector('.time-text') : row.querySelector('.time-text');
    if (timePod && data.precise_date != null) {
        timePod.title = data.created_precise || ('Created: ' + (data.precise_date || ''));
    }
    if (timeText && data.created_at != null) timeText.textContent = data.created_at;
    var createdTs = data.time_ts != null ? data.time_ts : data.upload_ts;
    if (createdTs != null) {
        if (timePod) timePod.setAttribute('data-ulp-time-ts', String(createdTs));
        if (timeText) timeText.setAttribute('data-ulp-time-ts', String(createdTs));
    }
    if (timeGroup && typeof window.syncFreeFileBumpTelemetry === 'function') {
        window.syncFreeFileBumpTelemetry(row, data);
    } else {
        var legacyTimePod = row.querySelector('.time-pod');
        var legacyTimeText = row.querySelector('.time-text');
        var timeTs = data.time_ts != null ? data.time_ts : (data.upload_ts != null ? data.upload_ts : data.bumped_at);
        if (legacyTimePod) legacyTimePod.title = data.precise_date || '';
        if (legacyTimeText && data.created_at != null) legacyTimeText.textContent = data.created_at;
        if (timeTs != null) {
            if (legacyTimePod) legacyTimePod.setAttribute('data-ulp-time-ts', String(timeTs));
            if (legacyTimeText) legacyTimeText.setAttribute('data-ulp-time-ts', String(timeTs));
        }
    }

    var desc = row.querySelector('.item-description');
    if (desc && data.description != null) {
        desc.textContent = decodePlainTextField(data.description) || 'No description provided.';
    }

    var vc = row.querySelector('.views-count');
    if (vc && data.views != null) vc.textContent = data.views;
    var clk = row.querySelector('.clicks-count');
    if (clk && data.clicks != null) clk.textContent = data.clicks;
    var cc = row.querySelector('.comment-count');
    if (cc && data.comments != null) {
        var nextResComments = Number(data.comments);
        if (typeof window.__ulpPulseIfStatCountChanged === 'function' && Number.isFinite(nextResComments)) {
            window.__ulpPulseIfStatCountChanged(cc, nextResComments, '.telemetry-pod');
        }
        cc.textContent = data.comments;
    }

    var likeCont = row.querySelector('.like-btn-container');
    if (likeCont) {
        var nup = Number(data.upvotes);
        likeCont.classList.toggle('has-likes', Number.isFinite(nup) && nup > 0);
        if (opts.isLiked) {
            likeCont.classList.add('is-liked');
            var hi = likeCont.querySelector('.like-icon');
            if (hi) hi.className = 'like-icon fas fa-heart';
        } else {
            likeCont.classList.remove('is-liked');
            var hi2 = likeCont.querySelector('.like-icon');
            if (hi2) hi2.className = 'like-icon far fa-heart';
        }
        var lc = row.querySelector('.like-count');
        if (lc && data.upvotes != null) lc.textContent = data.upvotes;
    }
};


/* ---------------------------------------------------------------
   RESOURCE ITEM RENDERER
   opts = { badge, isLiked, canModerate, isAdmin, onCheckboxChange }
--------------------------------------------------------------- */
window.renderResourceItem = function (data, opts) {
    opts = opts || {};
    var canModerate = opts.canModerate || false;
    var isAdmin = opts.isAdmin || false;
    var isLiked = opts.isLiked || false;
    var isRead = opts.isRead || false;
    var badge = opts.badge || null;
    var cbChange = opts.onCheckboxChange || 'updateListingSelectionMain';
    var currentUserId = (function () {
        var cw = (typeof window.__ulpGetFloatingChatRoot === 'function' && window.__ulpGetFloatingChatRoot())
            || document.querySelector('body > #chat-widget-container')
            || document.getElementById('chat-widget-container');
        return cw ? cw.getAttribute('data-user-id') : null;
    }());
    var csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

    var template = document.getElementById('resource-item-template');
    if (!template) return console.error("Template 'resource-item-template' not found"), document.createElement('div');
    
    var clone = template.content.cloneNode(true);
    var div = clone.querySelector('.file-item');
    var catKey = normalizeListingCategory(data.category);

    div.className = 'file-item resource-item list-card-shell list-card-clickable ' + (catKey || '');
    if (isRead) div.classList.add('is-read');
    div.dataset.listingId = data.id;
    div.dataset.url = data.url;
    var resHit = div.querySelector('.list-card-hit');
    if (resHit) resHit.href = data.url;
    var resSortTs = parseFloat(data.bumped_at);
    if (!Number.isFinite(resSortTs) && data.upload_ts != null) resSortTs = parseFloat(data.upload_ts);
    if (!Number.isFinite(resSortTs)) resSortTs = Date.now() / 1000;
    div.dataset.bumpedAt = String(resSortTs);

    if (isAdmin) {
        var adminCol = div.querySelector('.admin-checkbox-col');
        if (adminCol) {
            adminCol.classList.remove('hidden');
            var cb = adminCol.querySelector('input[type="checkbox"]');
            cb.value = data.id;
            cb.id = 'listing-cb-' + data.id;
            cb.classList.add('listing-checkbox-main');
        }
    }

    // Category icon (title row) — must match filter chips & category badge icons
    var catIcon = div.querySelector('.category-icon');
    catIcon.classList.add('tpl-icon');
    if (catKey === 'telegram_channel') {
        catIcon.className = 'category-icon fab fa-telegram cat-icon-list-inline';
    } else if (catKey === 'telegram_group') {
        catIcon.className = 'category-icon fas fa-users cat-icon-list-inline';
    } else if (catKey === 'market') {
        catIcon.className = 'category-icon fas fa-shopping-cart cat-icon-list-inline';
    } else if (catKey === 'forum') {
        catIcon.className = 'category-icon fas fa-comments cat-icon-list-inline';
    } else if (catKey === 'other') {
        catIcon.className = 'category-icon fas fa-link cat-icon-list-inline';
    } else {
        catIcon.className = 'category-icon fas fa-link cat-icon-list-inline cat-icon-list-inline--muted';
    }

    if (data.is_verified) div.querySelector('.verified-icon').classList.remove('hidden');

    var titleLnk = div.querySelector('.view-item-btn');
    titleLnk.href = data.url;
    titleLnk.textContent = decodePlainTextField(data.title);

    if (badge === 'pending' || !data.is_active) {
        var sb = div.querySelector('.status-badge');
        sb.classList.remove('hidden');
        sb.textContent = 'PENDING';
    }

    div.querySelector('.item-description').textContent = decodePlainTextField(data.description) || 'No description provided.';

    // Meta
    var userWrap = div.querySelector('.username-tag');
    userWrap.href = '/user/' + data.username;
    userWrap.className = 'username-tag ' + (data.role || 'user');
    
    var avatarUrl = window.ulpResolveAvatarUrl(data);
    var chipAv = userWrap.querySelector('.user-avatar-slot .user-avatar-circle');
    if (chipAv) chipAv.src = avatarUrl;
    userWrap.querySelector('.username-text').textContent = data.username;
    if (data.author_is_verified) {
        var verified = document.createElement('i');
        verified.className = 'fas fa-check-circle verified-badge';
        verified.title = 'Verified';
        userWrap.appendChild(verified);
    }

    userWrap.querySelectorAll('.group-badge-pile').forEach(function (n) { n.remove(); });
    userWrap.querySelectorAll(':scope > .group-badge').forEach(function (n) { n.remove(); });

    if (typeof window.appendGroupBadgePile === 'function') {
        window.appendGroupBadgePile(userWrap, data.groups);
    }

    var catLabel = listingCategoryLabel(data.category);
    var catBadge = div.querySelector('.bg-category');
    catBadge.classList.add(catKey || 'unknown');
    catBadge.replaceChildren();
    var bi = document.createElement('i');
    if (catKey === 'forum') bi.className = 'fas fa-comments';
    else if (catKey === 'market') bi.className = 'fas fa-shopping-cart';
    else if (catKey === 'telegram_channel') bi.className = 'fab fa-telegram';
    else if (catKey === 'telegram_group') bi.className = 'fas fa-users';
    else bi.className = 'fas fa-link';
    bi.classList.add('cat-icon-list');
    catBadge.appendChild(bi);
    catBadge.appendChild(document.createTextNode(' ' + catLabel));
    catBadge.setAttribute('href', catKey ? '/resources?category=' + encodeURIComponent(catKey) : '/resources');
    catBadge.removeAttribute('title');

    var timeGroup = div.querySelector('.telemetry-group.file-time-combo');
    var timePod = timeGroup ? timeGroup.querySelector('.time-pod') : div.querySelector('.time-pod');
    var timeText = timePod ? timePod.querySelector('.time-text') : div.querySelector('.time-text');
    if (timePod) {
        timePod.title = data.created_precise || ('Created: ' + (data.precise_date || ''));
    }
    if (timeText) timeText.textContent = data.created_at || '';
    var createdTs = data.time_ts != null ? data.time_ts : data.upload_ts;
    if (createdTs != null) {
        if (timePod) timePod.setAttribute('data-ulp-time-ts', String(createdTs));
        if (timeText) timeText.setAttribute('data-ulp-time-ts', String(createdTs));
    }
    if (typeof window.syncFreeFileBumpTelemetry === 'function') {
        window.syncFreeFileBumpTelemetry(div, data);
    }

    // Telemetry
    div.querySelector('.views-count').textContent = data.views || 0;
    div.querySelector('.clicks-count').textContent = data.clicks || 0;
    div.querySelector('.comment-count').textContent = data.comments || 0;

    var likeCont = div.querySelector('.like-btn-container');
    likeCont.dataset.listingId = data.id;
    if (data.upvotes > 0) likeCont.classList.add('has-likes');
    if (isLiked) {
        likeCont.classList.add('is-liked');
        likeCont.querySelector('.like-icon').className = 'like-icon fas fa-heart';
    }
    div.querySelector('.like-count').textContent = data.upvotes || 0;

    var resTelGroup = div.querySelector('.file-meta .telemetry-group');
    if (resTelGroup) resTelGroup.dataset.listingId = data.id;

    if (data.tags) {
        var tagsContainer = div.querySelector('.tags-container');
        tagsContainer.classList.remove('hidden');
        var tags = data.tags.split(',').slice(0, 4);
        tags.forEach(function (tag) {
            tag = tag.trim();
            if (tag) {
                var tSpan = document.createElement('span');
                tSpan.className = 'telemetry-pod listing-tag-pod';
                tSpan.textContent = '#' + tag;
                tagsContainer.appendChild(tSpan);
            }
        });
    }

    var actionsHtml = '';
    var hasActions = false;
    
    if (canModerate || (data.user_id && currentUserId && String(currentUserId) === String(data.user_id))) {
        actionsHtml += '<a href="/resources/' + data.id + '/edit" class="action-icon-btn" title="Edit"><i class="fas fa-edit"></i></a>';
        hasActions = true;
    }
    
    if (canModerate) {
        if (!data.is_active) {
            actionsHtml += moderationAjaxBtn('/admin/approve_listing/' + data.id, 'approve', 'Quick Approve', 'fas fa-check');
        }
        if (isAdmin) {
            actionsHtml += moderationAjaxBtn('/admin/bump_listing/' + data.id, '', 'Bump to top', 'fas fa-level-up-alt');
        }
        actionsHtml += moderationAjaxBtn('/admin/delete_listing/' + data.id, 'delete', 'Delete', 'fas fa-trash');
        hasActions = true;
    } else if (data.user_id && currentUserId && String(currentUserId) === String(data.user_id)) {
        if (data.is_active && typeof window.ulpSelfBumpButtonHtml === 'function') {
            actionsHtml += window.ulpSelfBumpButtonHtml('listing', data.id, data.user_id) || '';
        }
        if (typeof window.ulpOwnerDeleteButtonHtml === 'function') {
            actionsHtml += window.ulpOwnerDeleteButtonHtml('listing', data.id, data.user_id) || '';
        }
        hasActions = true;
    }
    
    if (hasActions) {
        var actionsDiv = div.querySelector('.file-actions-container');
        actionsDiv.classList.remove('hidden');
        actionsDiv.innerHTML = actionsHtml;
    }

    return div;
};

/** Sort key for feed insert order (matches server coalesce(bumped_at, upload_date)). */
window.feedItemSortTs = function feedItemSortTs(data) {
    let t = parseFloat(data && data.bumped_at);
    if (!Number.isFinite(t) && data && data.upload_ts != null) t = parseFloat(data.upload_ts);
    return Number.isFinite(t) ? t : Date.now() / 1000;
};

/** Insert a file row on the index feed when socket/upload says a file is new (global — listings.js loads on every page). */
window.applyNewFileToIndexFeed = function applyNewFileToIndexFeed(data) {
    if (!data) return;
    if (data.id != null) {
        const now = Date.now();
        window.__ulpFeedApplyGuard = window.__ulpFeedApplyGuard || {};
        const key = String(data.id);
        const last = window.__ulpFeedApplyGuard[key] || 0;
        if (now - last < 500) return;
        window.__ulpFeedApplyGuard[key] = now;
    }
    const urlParams = new URLSearchParams(window.location.search);
    const page = urlParams.get('page') || '1';
    const searchQ = urlParams.get('q') || '';
    const activeFilter = urlParams.get('filter') || 'all';

    if (page !== '1') return;
    if (searchQ) return;
    if (activeFilter === 'free' && data.price > 0) return;
    if (activeFilter === 'paid' && (!data.price || data.price <= 0)) return;
    if (activeFilter === 'vip' && !data.is_vip_section) return;
    if (activeFilter !== 'vip' && data.is_vip_section) return;

    const fileList = document.querySelector('#ajax-file-list') || document.querySelector('.file-list');
    if (!fileList) return;
    if (typeof window.renderFileItem !== 'function') return;

    const existingRow =
        data.id != null
            ? fileList.querySelector(':scope > .file-item[data-file-id="' + String(data.id) + '"]')
            : null;
    if (existingRow) {
        existingRow.remove();
    }

    const chatWidget = document.getElementById('chat-widget-container');
    const currentUserRole =
        (chatWidget && chatWidget.getAttribute('data-user-role')) ||
        (document.body && document.body.getAttribute('data-user-role')) ||
        '';
    const myUserId =
        (chatWidget && chatWidget.getAttribute('data-user-id')) ||
        (document.body && document.body.getAttribute('data-user-id')) ||
        '';
    const myProfileLink =
        document.querySelector('.nav-btn-profile') ||
        document.querySelector('.profile-link-btn .username');
    const myUsername = myProfileLink ? myProfileLink.textContent.trim() : '';
    const isMe =
        data.username === myUsername ||
        (data.user_id != null && myUserId && String(data.user_id) === String(myUserId));
    const canModerate = ['admin', 'moderator'].includes(currentUserRole);
    const isAdmin = currentUserRole === 'admin';

    if (!data.is_approved && !isMe && !canModerate) return;

    const emptyMsg = fileList.querySelector('.cyber-card.text-center');
    if (emptyMsg) emptyMsg.remove();

    const badge = data.is_approved ? (isMe ? null : 'new') : null;
    const div = window.renderFileItem(data, {
        badge,
        isRead: window.readFileIds ? window.readFileIds.has(data.id) : false,
        canModerate,
        isAdmin,
        onCheckboxChange: null,
    });

    const newBumped = window.feedItemSortTs(data);
    const children = Array.from(fileList.children);
    let inserted = false;
    for (let i = 0; i < children.length; i++) {
        const itemBumped = parseFloat(children[i].getAttribute('data-bumped-at'));
        if (!isNaN(itemBumped) && newBumped > itemBumped) {
            fileList.insertBefore(div, children[i]);
            inserted = true;
            break;
        }
    }
    if (!inserted) fileList.appendChild(div);
};

/** Global feed realtime — works on every page (not only when index-page script loaded). */
(function bindUlpGlobalFeedRealtime() {
    function handleNewFileNotification(data) {
        if (typeof window.applyNewFileToIndexFeed === 'function') {
            window.applyNewFileToIndexFeed(data);
        }
        if (typeof window.bumpVipNewBadgeIfNeeded === 'function') {
            window.bumpVipNewBadgeIfNeeded(data);
        }
    }

    function handleFileStatusUpdate(data) {
        if (!data) return;
        if (data.feed_item) {
            handleNewFileNotification(data.feed_item);
        }
        if (data.status === 'approved' || data.status === 'published') {
            document.querySelectorAll('[data-file-id="' + String(data.id) + '"]').forEach(function (item) {
                var publishIcon = item.querySelector('.file-publish-status-icon');
                if (publishIcon) {
                    publishIcon.classList.add('hidden');
                    publishIcon.removeAttribute('data-tooltip-html');
                }
            });
        }
    }

    function bindFeedRealtime(socket) {
        if (!socket || socket.__ulpGlobalFeedRealtimeBound) return;
        socket.__ulpGlobalFeedRealtimeBound = true;
        socket.on('new_file_notification', handleNewFileNotification);
        socket.on('file_status_update', handleFileStatusUpdate);
    }

    function tryBind() {
        var socket = typeof window.getSharedSocket === 'function' ? window.getSharedSocket() : null;
        if (socket) bindFeedRealtime(socket);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', tryBind);
    } else {
        tryBind();
    }
    document.addEventListener('pageLoaded', tryBind);

    var attempts = 0;
    var poll = setInterval(function () {
        tryBind();
        attempts += 1;
        var s = typeof window.getSharedSocket === 'function' ? window.getSharedSocket() : null;
        if ((s && s.__ulpGlobalFeedRealtimeBound) || attempts > 120) clearInterval(poll);
    }, 250);
})();
