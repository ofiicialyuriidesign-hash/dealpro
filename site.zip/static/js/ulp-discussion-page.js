/**
 * Shared file / resource detail discussion (socket, quill composer, inline edit).
 * Initialized via initUlpDiscussionPage({ ... }) from thin page scripts.
 */
(function () {
    'use strict';

    function readConfig(elementId) {
        var el = document.getElementById(elementId);
        if (!el) return {};
        try {
            return JSON.parse(el.textContent || '{}');
        } catch (e) {
            return {};
        }
    }

    window.initUlpDiscussionPage = function (opts) {
        opts = opts || {};
        var cfg = readConfig(opts.configElementId);
        var socket = window.getSharedSocket ? window.getSharedSocket() : null;
        var entityId = String(cfg[opts.entityIdKey] || '');
        var currentUserId = String(cfg.currentUserId || '');
        var currentUserRole = String(cfg.currentUserRole || '');
        var isAdminOrMod = ['admin', 'moderator'].indexOf(currentUserRole) !== -1;
        var roomType = opts.roomType || 'file';
        var handlersKey = opts.socketHandlersKey || '__ulpDiscussionSocketHandlers';
        var quillProp = opts.quillWindowProp || '__commentQuill';
        var sendBtnId = opts.sendBtnId || '';
        var cancelBtnId = opts.cancelBtnId || '';
        var editBarId = opts.editBarId || '';
        var commentEmitEvent = opts.commentEmitEvent || 'file_comment';
        var cancelExportName = opts.cancelExportName || 'cancelDiscussionInlineEdit';

        if (window.initializeFileRoom && entityId) {
            window.initializeFileRoom(roomType, entityId);
        }

        var editCommentId = null;
        var editOriginalPlain = '';
        var editOriginalHtml = '';
        var editBarEl = null;
        var cancelBtnEl = null;
        var sendBtnEl = null;
        var sendBtnOriginalHtml = '';
        var sendBtnOriginalAria = '';

        function getQuill() {
            return window[quillProp] || null;
        }

        window.__ulpDiscussionCurrentUserId = currentUserId;

        /** Scroll list + page so a comment row is visible (e.g. after send). */
        window.__ulpScrollToDiscussionComment = function (row, opts) {
            if (!row) return;
            opts = opts || {};
            var smooth = opts.smooth !== false;
            var pageScroll = opts.pageScroll !== false;
            var behavior = smooth ? 'smooth' : 'instant';
            var list = document.getElementById('comments-list');

            row.classList.remove('thread-item-hidden');

            if (list) {
                if (typeof list.scrollTo === 'function') {
                    try {
                        list.scrollTo({ top: list.scrollHeight, left: 0, behavior: behavior });
                    } catch (e) {
                        list.scrollTop = list.scrollHeight;
                    }
                } else {
                    list.scrollTop = list.scrollHeight;
                }
            }

            if (!pageScroll) return;

            function revealOnPage() {
                try {
                    row.scrollIntoView({ behavior: behavior, block: 'nearest', inline: 'nearest' });
                } catch (e) {
                    row.scrollIntoView(true);
                }
            }

            if (typeof requestAnimationFrame === 'function') {
                requestAnimationFrame(revealOnPage);
            } else {
                revealOnPage();
            }
            if (smooth) {
                setTimeout(revealOnPage, 200);
            }
        };

        window.appendCommentToDOM = function (data) {
            var list = document.getElementById('comments-list');
            if (!list) return;
            if (window.ulpMayViewPendingModerationPayload && !window.ulpMayViewPendingModerationPayload(data)) {
                return;
            }

            var rowId = 'comment-' + data.id;
            if (document.getElementById(rowId)) return;

            var div = document.createElement('div');
            div.className = 'comment-item discussion-message-card ulp-discussion-enter';
            div.id = rowId;

            var avatarUrl = window.ulpResolveAvatarUrl(data);
            var roleIcon = '<span class="user-avatar-slot"><img src="' + avatarUrl + '" class="user-avatar-circle" alt=""></span>';

            var canEdit = isAdminOrMod || (String(data.user_id || '') === String(currentUserId));
            var editBtn = canEdit
                ? '<button type="button" class="action-btn edit-btn" title="Edit Comment" data-ulp-discussion-action="edit" data-comment-id="' + data.id + '"><i class="fas fa-pen discussion-action-icon discussion-action-icon--sm"></i></button>'
                : '';
            var deleteBtn = isAdminOrMod
                ? '<button type="button" class="action-btn delete-btn" title="Delete Comment" data-ulp-discussion-action="delete" data-comment-id="' + data.id + '"><i class="fas fa-trash discussion-action-icon"></i></button>'
                : '';
            var replyBtn = currentUserRole
                ? '<button type="button" class="action-btn reply-btn" data-ulp-discussion-action="reply" data-reply-user="' + data.username + '" title="Reply"><i class="fas fa-reply discussion-action-icon"></i></button>'
                : '';

            var likesCount = Number(data.likes_count || 0);
            var likedByMe = !!data.user_liked;
            var likeBtn = currentUserRole
                ? '<button type="button" class="telemetry-pod like-btn-container discussion-like-toggle ' + (likesCount > 0 ? 'has-likes ' : '') + (likedByMe ? 'is-liked' : '') + '" title="Like" data-ulp-discussion-action="like" data-comment-id="' + data.id + '"><i class="like-icon ' + (likedByMe ? 'fas' : 'far') + ' fa-heart discussion-action-icon"></i><span class="like-count discussion-like-count">' + likesCount + '</span></button>'
                : '<button type="button" class="telemetry-pod like-btn-container discussion-like-toggle ' + (likesCount > 0 ? 'has-likes' : '') + '" title="Login to like" data-ulp-discussion-action="like-login"><i class="like-icon far fa-heart discussion-action-icon"></i><span class="like-count discussion-like-count">' + likesCount + '</span></button>';

            var verifiedHtml = data.is_verified ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>' : '';
            var pendingBadge = data.is_approved === false ? '<span class="adm-badge adm-badge-yellow discussion-pending-badge">PENDING</span>' : '';
            var groupsHtml = '';
            if (data.groups && data.groups.length > 0) {
                groupsHtml = typeof window.formatGroupBadgePileHtml === 'function'
                    ? window.formatGroupBadgePileHtml(data.groups)
                    : (function () {
                        var s = '';
                        data.groups.forEach(function (g) {
                            var safeIcon = g.icon || 'fas fa-star';
                            var iconColor = g.icon_color || '#f5f8ff';
                            s += '<span class="group-badge" title="' + g.name + '" style="--badge-bg: ' + g.color + '; --badge-icon-color: ' + iconColor + '; background-color: var(--badge-bg);"><i class="' + safeIcon + '"></i></span>';
                        });
                        return '<span class="group-badge-pile" aria-hidden="true">' + s + '</span>';
                    })();
            }

            var stats = data.author_stats || {};
            var authorStatsHtml = '<div class="forum-author-stats telemetry-group" aria-label="Author stats">' +
                '<span class="telemetry-pod" title="Comments"><i class="fas fa-comments"></i> ' + (stats.comments_total || ((stats.posts_count || 0) + (stats.site_comments_count || 0))) + '</span>' +
                '<span class="telemetry-pod" title="Topics created"><i class="fas fa-list"></i> ' + (stats.topics_count || 0) + '</span>' +
                '<span class="telemetry-pod" title="Likes received"><i class="fas fa-heart"></i> ' + (stats.likes_received || 0) + '</span>' +
                '</div>';

            var bodyHtml = typeof window.ulpSanitizeRichHtml === 'function'
                ? window.ulpSanitizeRichHtml(data.content_html || (window.parseLinks ? window.parseLinks(data.content) : data.content))
                : (data.content_html || (window.parseLinks ? window.parseLinks(data.content) : data.content));

            div.innerHTML =
                '<div class="comment-actions">' + pendingBadge + editBtn + deleteBtn + replyBtn + likeBtn +
                '<span class="telemetry-pod comment-shown-time" title="' + (data.created_at_precise || '') + '"' + (data.created_at_ts ? ' data-ulp-time-ts="' + data.created_at_ts + '"' : '') + '><i class="far fa-clock"></i> ' + (data.created_at || data.timestamp || '') + '</span></div>' +
                '<div class="discussion-message-main"><div class="discussion-message-header">' +
                '<a href="/user/' + data.username + '" class="username-tag ' + (data.role || '') + '">' + roleIcon + data.username + verifiedHtml + groupsHtml + '</a>' + authorStatsHtml +
                '</div><div class="discussion-message-body rich-body">' + bodyHtml + '</div></div>';

            list.appendChild(div);
            var isOwnComment = String(data.user_id || '') === String(currentUserId);
            if (isOwnComment && typeof window.__ulpScrollToDiscussionComment === 'function') {
                window.__ulpScrollToDiscussionComment(div, { smooth: true, pageScroll: true });
            } else {
                list.scrollTop = list.scrollHeight;
            }

            if (data.is_approved !== false) {
                document.querySelectorAll('.comment-count').forEach(function (el) {
                    var current = parseInt(el.innerText, 10) || 0;
                    var next = current + 1;
                    if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
                        window.__ulpPulseIfStatCountChanged(el, next, null);
                    }
                    el.innerText = next;
                });
            }
        };

        function bindCommentDeleteConfirmed(sock) {
            if (!sock) return;
            window[handlersKey] = window[handlersKey] || {};
            var handlers = window[handlersKey];
            if (handlers.commentDeleteConfirmed) {
                sock.off('comment_delete_confirmed', handlers.commentDeleteConfirmed);
            }
            handlers.commentDeleteConfirmed = function (payload) {
                var cid = payload && payload.id;
                if (!cid) return;
                var row = document.getElementById('comment-' + cid);
                if (row) {
                    row.classList.add('ulp-discussion-row-exit');
                    setTimeout(function () {
                        if (row.parentNode) row.parentNode.removeChild(row);
                    }, 360);
                }
                var nextCount = Number(payload.comments_count);
                if (payload.was_approved && Number.isFinite(nextCount)) {
                    document.querySelectorAll('.comment-count').forEach(function (el) {
                        if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
                            window.__ulpPulseIfStatCountChanged(el, nextCount, '.telemetry-pod');
                        }
                        el.innerText = nextCount;
                    });
                }
                if (
                    roomType === 'file' &&
                    typeof window.syncFreeFileBumpTelemetry === 'function'
                ) {
                    var metaRoot = document.querySelector('.file-meta');
                    if (metaRoot) window.syncFreeFileBumpTelemetry(metaRoot, payload);
                }
            };
            sock.on('comment_delete_confirmed', handlers.commentDeleteConfirmed);
        }

        if (socket) {
            window[handlersKey] = window[handlersKey] || {};
            var handlers = window[handlersKey];
            if (handlers.connect) socket.off('connect', handlers.connect);
            handlers.connect = function () {
                if (typeof window.__ulpResyncRealtimeSubscriptions === 'function') {
                    window.__ulpResyncRealtimeSubscriptions();
                } else if (window.initializeFileRoom) {
                    window.initializeFileRoom(roomType, entityId);
                }
                var liveSock = window.getSharedSocket ? window.getSharedSocket() : socket;
                bindCommentDeleteConfirmed(liveSock);
            };
            socket.on('connect', handlers.connect);
            if (socket.connected) handlers.connect();
            bindCommentDeleteConfirmed(socket);

            socket.off('comment_like_update');
            socket.on('comment_like_update', function (payload) {
                var cid = payload && payload.comment_id;
                if (!cid) return;
                var row = document.getElementById('comment-' + cid);
                if (!row) return;
                var btn = row.querySelector('.discussion-like-toggle');
                if (!btn) return;
                var likes = Number(payload.likes_count || 0);
                var countEl = btn.querySelector('.discussion-like-count');
                if (countEl) {
                    if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
                        window.__ulpPulseIfStatCountChanged(countEl, likes, '.discussion-like-toggle');
                    }
                    countEl.textContent = String(likes);
                }
                btn.classList.toggle('has-likes', likes > 0);
                var icon = btn.querySelector('i.fa-heart');
                var payloadUserId = parseInt(String(payload.user_id || '0'), 10) || 0;
                var meId = parseInt(String(currentUserId || '0'), 10) || 0;
                if (payloadUserId && meId && payloadUserId === meId) {
                    if (payload.user_liked) {
                        btn.classList.add('is-liked');
                        if (icon) { icon.classList.remove('far'); icon.classList.add('fas'); }
                    } else {
                        btn.classList.remove('is-liked');
                        if (icon) { icon.classList.remove('fas'); icon.classList.add('far'); }
                    }
                }
            });
        }

        window.toggleDiscussionCommentLike = function (commentId) {
            if (!socket || !commentId) return;
            socket.emit('toggle_comment_like', { comment_id: commentId });
        };

        function normalizeEditHtml(html) {
            return String(html || '')
                .replace(/\uFEFF/g, '')
                .replace(/\s+/g, ' ')
                .replace(/<p><br><\/p>/gi, '')
                .trim();
        }

        function sanitizeEditSeedHtml(html) {
            var wrap = document.createElement('div');
            wrap.innerHTML = String(html || '');

            function unwrap(el) {
                if (!el || !el.parentNode) return;
                while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el);
                el.parentNode.removeChild(el);
            }

            wrap.querySelectorAll('*').forEach(function (el) {
                el.removeAttribute('style');
                el.removeAttribute('color');
                el.removeAttribute('face');
                el.removeAttribute('size');
                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'font' || tag === 'small' || tag === 'big') {
                    unwrap(el);
                    return;
                }
                var keep = [];
                (el.className || '').split(/\s+/).forEach(function (c) {
                    if (!c) return;
                    if (c === 'mention' || c === 'mention-link' || c === 'external-link') keep.push(c);
                    if (c.indexOf('ql-') === 0) keep.push(c);
                });
                if (keep.length) el.className = keep.join(' ');
                else el.removeAttribute('class');
            });

            return (wrap.innerHTML || '').normalize('NFKC');
        }

        function setSendPending(text) {
            if (!sendBtnEl) sendBtnEl = document.getElementById(sendBtnId);
            if (!sendBtnEl) return;
            if (!sendBtnOriginalHtml) sendBtnOriginalHtml = sendBtnEl.innerHTML;
            if (!sendBtnOriginalAria) sendBtnOriginalAria = sendBtnEl.getAttribute('aria-label') || 'Send';
            sendBtnEl.disabled = true;
            sendBtnEl.classList.add('is-loading');
            sendBtnEl.innerHTML = '<span class="ulp-composer-send-spinner" aria-hidden="true"></span>';
            sendBtnEl.setAttribute('aria-label', String(text || 'Uploading...'));
        }

        function resetSendPending() {
            if (!sendBtnEl) sendBtnEl = document.getElementById(sendBtnId);
            if (!sendBtnEl) return;
            sendBtnEl.disabled = false;
            sendBtnEl.classList.remove('is-loading');
            if (sendBtnOriginalAria) sendBtnEl.setAttribute('aria-label', sendBtnOriginalAria);
            sendBtnEl.innerHTML = sendBtnOriginalHtml || '<i class="fas fa-paper-plane"></i>';
        }

        function resetEditChrome() {
            editCommentId = null;
            editOriginalPlain = '';
            editOriginalHtml = '';
            if (!editBarEl) editBarEl = document.getElementById(editBarId);
            if (!cancelBtnEl) cancelBtnEl = document.getElementById(cancelBtnId);
            if (!sendBtnEl) sendBtnEl = document.getElementById(sendBtnId);
            if (editBarEl) editBarEl.style.display = 'none';
            if (cancelBtnEl) {
                cancelBtnEl.style.display = 'none';
                var cluster = cancelBtnEl.closest('.discussion-composer-action-cluster');
                if (cluster) cluster.classList.remove('discussion-composer-action-cluster--with-cancel');
            }
            if (sendBtnEl) {
                sendBtnEl.innerHTML = '<i class="fas fa-paper-plane"></i>';
                sendBtnEl.setAttribute('aria-label', 'Send');
            }
        }

        function openInlineEdit(commentId, initialHtml, initialPlain) {
            var q = getQuill();
            if (!q) return;
            var seedHtml = sanitizeEditSeedHtml(initialHtml || '');
            editCommentId = commentId;
            editOriginalPlain = (initialPlain || '').trim();
            editOriginalHtml = normalizeEditHtml(seedHtml);
            q.setContents([{ insert: '\n' }], 'silent');
            if (seedHtml) q.clipboard.dangerouslyPasteHTML(0, seedHtml, 'silent');
            if (!editBarEl) editBarEl = document.getElementById(editBarId);
            if (!cancelBtnEl) cancelBtnEl = document.getElementById(cancelBtnId);
            if (!sendBtnEl) sendBtnEl = document.getElementById(sendBtnId);
            if (editBarEl) editBarEl.style.display = 'flex';
            if (cancelBtnEl) {
                cancelBtnEl.style.display = 'flex';
                var cluster = cancelBtnEl.closest('.discussion-composer-action-cluster');
                if (cluster) cluster.classList.add('discussion-composer-action-cluster--with-cancel');
            }
            if (sendBtnEl) {
                sendBtnEl.innerHTML = '<i class="fas fa-save"></i>';
                sendBtnEl.setAttribute('aria-label', 'Save edit');
            }
            var replyArea = document.querySelector('.file-discussion-shell .comment-input-area');
            if (replyArea) replyArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            setTimeout(function () {
                q.focus();
                if (typeof window.placeQuillCaretAtDocumentEnd === 'function') {
                    window.placeQuillCaretAtDocumentEnd(q);
                }
            }, 30);
        }

        window[cancelExportName] = function () {
            var q = getQuill();
            resetEditChrome();
            if (q && window.clearQuillEditor) window.clearQuillEditor(q);
        };

        function submitCommentEdit() {
            var q = getQuill();
            if (!socket || !editCommentId || !q) return;
            var vEdit = typeof window.validateRichMessageQuill === 'function'
                ? window.validateRichMessageQuill(q)
                : { ok: !!(q.getText() || '').replace(/\uFEFF/g, '').trim() };
            if (!vEdit.ok) {
                if (typeof window.notifyRichMessageValidation === 'function') window.notifyRichMessageValidation(vEdit);
                return;
            }
            var plain = (q.getText() || '').replace(/\uFEFF/g, '').trim();
            var html = (q.root && q.root.innerHTML) ? q.root.innerHTML : '';
            var normalizedHtml = normalizeEditHtml(html);
            if (plain === editOriginalPlain && normalizedHtml === editOriginalHtml) {
                window[cancelExportName]();
                return;
            }
            var commentId = editCommentId;
            var resolveHtml = window.resolveQuillHtmlForSubmit;
            var p = (typeof resolveHtml === 'function') ? resolveHtml(q) : Promise.resolve(html);
            p.then(function (readyHtml) {
                socket.emit('edit_comment', { comment_id: commentId, content: readyHtml });
                resetEditChrome();
                if (window.clearQuillEditor) window.clearQuillEditor(q);
            }).catch(function (err) {
                if (window.showToast) {
                    var details = (typeof window.describeInlineImageUploadError === 'function')
                        ? window.describeInlineImageUploadError(err)
                        : { title: 'Upload failed', message: 'Could not upload one or more images.' };
                    window.showToast(details.title, details.message, null, 'fas fa-image', null, 'error');
                }
            });
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && editCommentId) window[cancelExportName]();
        });

        function sendComment() {
            var q = getQuill();
            if (!q || !socket) return;
            if (!currentUserId) {
                if (window.requireLogin) {
                    window.requireLogin('Please login or register to comment.', window.location.pathname + window.location.search);
                }
                return;
            }
            if (editCommentId) {
                submitCommentEdit();
                return;
            }
            var v = typeof window.validateRichMessageQuill === 'function'
                ? window.validateRichMessageQuill(q)
                : { ok: !!q.getText().replace(/\uFEFF/g, '').trim() };
            if (!v.ok) {
                if (typeof window.notifyRichMessageValidation === 'function') window.notifyRichMessageValidation(v);
                return;
            }
            var resolveHtml = window.resolveQuillHtmlForSubmit;
            var p = (typeof resolveHtml === 'function')
                ? resolveHtml(q, null, {
                    onProgress: function (st) {
                        if (!st || st.phase !== 'uploading') return;
                        var total = Number(st.total || 0);
                        if (total > 0) {
                            setSendPending('Uploading ' + Number(st.done || 0) + '/' + total + ' (' + Number(st.percent || 0) + '%)');
                        } else {
                            setSendPending('Uploading...');
                        }
                    }
                })
                : Promise.resolve(q.root.innerHTML);
            p.then(function (html) {
                setSendPending('Sending...');
                var payload = typeof opts.buildCommentPayload === 'function'
                    ? opts.buildCommentPayload(entityId, html)
                    : { file_id: entityId, content: html };
                var emitComment = function (sock) {
                    sock.emit(commentEmitEvent, payload);
                    if (window.clearQuillEditor) window.clearQuillEditor(q);
                    setTimeout(resetSendPending, 250);
                };
                var ensure = (typeof window.ulpEnsureSharedSocketConnected === 'function')
                    ? window.ulpEnsureSharedSocketConnected(8000)
                    : Promise.resolve(socket);
                ensure.then(emitComment).catch(function (err) {
                    resetSendPending();
                    if (window.showToast) {
                        window.showToast(
                            'Connection',
                            (err && err.message) ? String(err.message) : 'Live connection unavailable. Refresh the page and try again.',
                            null,
                            'fas fa-plug',
                            null,
                            'error'
                        );
                    }
                });
            }).catch(function (err) {
                resetSendPending();
                if (window.showToast) {
                    var details = (typeof window.describeInlineImageUploadError === 'function')
                        ? window.describeInlineImageUploadError(err)
                        : { title: 'Upload failed', message: 'Could not upload one or more images.' };
                    window.showToast(details.title, details.message, null, 'fas fa-image', null, 'error');
                }
            });
        }

        window.sendComment = sendComment;

        function focusDiscussionComposer(scrollOpts) {
            var scroll = scrollOpts !== false;
            if (scroll && typeof window.__ulpScrollDiscussionComposerForKeyboard === 'function') {
                window.__ulpScrollDiscussionComposerForKeyboard();
            } else {
                var replyArea = document.querySelector('.file-discussion-shell .comment-input-area, .file-discussion-shell .forum-reply-area');
                if (replyArea && scroll) {
                    replyArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
            setTimeout(function () {
                try {
                    var q = getQuill();
                    if (q && typeof q.focus === 'function') {
                        q.focus();
                        if (q.getLength() <= 1 && typeof window.placeQuillCaretAtFirstContentPosition === 'function') {
                            setTimeout(function () {
                                window.placeQuillCaretAtFirstContentPosition(q);
                            }, 0);
                        }
                        return;
                    }
                    var editor = document.querySelector('.file-discussion-shell .ql-editor');
                    if (editor && typeof editor.focus === 'function') editor.focus();
                } catch (_) {}
            }, scroll ? 260 : 30);
        }

        window.jumpToDiscussionEditor = function (event) {
            if (event && event.preventDefault) event.preventDefault();
            focusDiscussionComposer(true);
        };

        (function () {
            var list = document.getElementById('comments-list');
            if (!list) return;
            var top = list.scrollHeight;
            if (typeof list.scrollTo === 'function') {
                try {
                    list.scrollTo({ top: top, left: 0, behavior: 'instant' });
                    return;
                } catch (e) { /* fall through */ }
            }
            list.scrollTop = top;
        })();

        window.setCommentReply = function (username) {
            focusDiscussionComposer(true);
            var q = getQuill();
            if (q && window.insertAtRichCursor) {
                window.insertAtRichCursor(q, '@' + username + ', ');
                return;
            }
            var input = document.getElementById('comment-input');
            if (input) {
                input.value = '@' + username + ', ' + input.value;
                input.focus();
            }
        };

        window.deleteComment = async function (id) {
            if (!window.promptDeletionReason) return;
            var reason = await window.promptDeletionReason({
                title: 'Delete comment',
                confirmLabel: 'Delete comment'
            });
            if (reason === null) return;
            var payload = { comment_id: id };
            if (reason) payload.deletion_reason = reason;
            if (socket) socket.emit('delete_comment', payload);
        };

        window.editComment = function (id) {
            var row = document.getElementById('comment-' + id);
            if (!row) return;
            var bodyEl = row.querySelector('.discussion-message-body');
            openInlineEdit(id, bodyEl ? (bodyEl.innerHTML || '') : '', bodyEl ? (bodyEl.innerText || '').trim() : '');
        };

        if (socket) {
            window[handlersKey] = window[handlersKey] || {};
            var h = window[handlersKey];
            if (roomType === 'file') {
                if (h.fileBumpedDetail) socket.off('file_bumped', h.fileBumpedDetail);
                h.fileBumpedDetail = function (data) {
                    if (!data || String(data.id) !== entityId || data.price) return;
                    var metaRoot = document.querySelector('.file-meta');
                    if (metaRoot && typeof window.syncFreeFileBumpTelemetry === 'function') {
                        window.syncFreeFileBumpTelemetry(metaRoot, data);
                    }
                };
                socket.on('file_bumped', h.fileBumpedDetail);
            }
        }
    };
})();
