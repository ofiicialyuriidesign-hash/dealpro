/**
 * Header notifications: click handler + dropdown hover/touch (SPA re-init).
 * Extracted from templates/base.html.
 */
(function () {
    'use strict';

window.handleNotificationClick = function (event, element) {
    if (!event || !element) return;
    // 1. If clicking a link (like username), DO NOT mark as read or close
    if (event.target && event.target.closest && event.target.closest('a')) return;

    // 2. Otherwise, mark as read and remove
    // Get notification ID
    const notificationId = element.getAttribute('data-id');
    const link = (element.getAttribute('data-link') || '').trim();
    if (!link || link === '#') {
        element.style.opacity = '0';
        setTimeout(() => element.remove(), 300);
        const badge = document.getElementById('global-badge');
        if (badge) {
            let count = parseInt(badge.innerText) || 0;
            if (count > 0) {
                count--;
                badge.innerText = count;
                if (count === 0) badge.style.display = 'none';
            }
        }
        if (notificationId) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            fetch(`/notifications/read/${notificationId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
            }).catch(() => {});
        }
        return;
    }

    // Optimistic UI Update: Remove item and decrease count Immediately
    element.style.opacity = '0';
    setTimeout(() => element.remove(), 300); // Remove after fade out

    // Update badge immediately
    const badge = document.getElementById('global-badge');
    if (badge) {
        let count = parseInt(badge.innerText) || 0;
        if (count > 0) {
            count--;
            badge.innerText = count;
            if (count === 0) badge.style.display = 'none';
        }
    }

    // Define Navigation Helper
    const navigate = () => {
        if (!link || link === '#') return;
        if (typeof window.ulpNavigateHref === 'function') {
            window.ulpNavigateHref(link);
            return;
        }
        if (window.loadPage) {
            document.body.style.cursor = 'wait';
            window.loadPage(link);
        } else {
            window.location.href = link;
        }
    };

    if (notificationId) {
        // Use Reliable FETCH instead of Socket
        // This ensures the server marks it as read BEFORE we navigate away
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        fetch(`/notifications/read/${notificationId}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            }
        })
            .then(response => {
            })
            .catch(err => {
                console.error('Error marking notification read:', err);
                // If fetch fails, try socket fallback
                const _s = (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) || window.socket;
                if (_s && _s.connected) _s.emit('mark_notification_read', { id: notificationId });
            })
            .finally(() => {
                // Navigate regardless of success
                navigate();
            });
    } else {
        navigate();
    }
};

window.handleNotificationHistoryClick = function (event, element) {
    if (!event || !element) return;
    if (event.target && event.target.closest && event.target.closest('a')) return;

    var notificationId = element.getAttribute('data-id');
    var link = (element.getAttribute('data-link') || '').trim();
    var csrfMeta = document.querySelector('meta[name="csrf-token"]');
    var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

    var navigate = function () {
        if (!link || link === '#') return;
        if (typeof window.ulpNavigateHref === 'function') {
            window.ulpNavigateHref(link);
            return;
        }
        if (window.loadPage) window.loadPage(link);
        else window.location.href = link;
    };

    element.classList.remove('is-unread');
    if (!notificationId) {
        navigate();
        return;
    }

    fetch('/notifications/read/' + notificationId, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
    }).finally(function () {
        var badge = document.getElementById('global-badge');
        if (badge) {
            var nextCount = Math.max((parseInt(badge.innerText, 10) || 0) - 1, 0);
            badge.innerText = String(nextCount);
            if (nextCount === 0) badge.style.display = 'none';
        }
        navigate();
    });
};

if (!window.__ulpNotificationClickDeleg) {
    window.__ulpNotificationClickDeleg = true;
    document.addEventListener('click', function (e) {
        var item = e.target.closest('.notification-item.clickable[data-id]');
        if (!item) return;
        if (item.closest('#alerts-history-list')) {
            window.handleNotificationHistoryClick(e, item);
        } else {
            window.handleNotificationClick(e, item);
        }
    });
}

function bindAlertsMarkAllRead() {
    var markAllBtn = document.getElementById('alerts-mark-all-read-btn');
    if (!markAllBtn || markAllBtn.getAttribute('data-ulp-bound') === '1') return;
    markAllBtn.setAttribute('data-ulp-bound', '1');
    markAllBtn.addEventListener('click', function () {
        var csrf = document.querySelector('meta[name="csrf-token"]');
        var csrfToken = csrf ? csrf.getAttribute('content') : '';
        markAllBtn.disabled = true;
        fetch('/notifications/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken }
        }).finally(function () {
            if (window.loadPage) window.loadPage('/notifications', true);
            else window.location.href = '/notifications';
        });
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindAlertsMarkAllRead);
} else {
    bindAlertsMarkAllRead();
}
document.addEventListener('pageLoaded', bindAlertsMarkAllRead);

(function () {
    var CLOSE_DELAY_MS = 420;
    var closeTimerByRoot = new WeakMap();

    /**
     * Touch-first UIs: avoid hover/focus auto-open (same tap would open then break toggle).
     * Broaden detection — some mobile browsers omit (pointer: coarse) alone.
     */
    function shouldUseTouchToggle() {
        try {
            if (window.matchMedia('(pointer: coarse)').matches) return true;
            if (window.matchMedia('(hover: none) and (pointer: coarse)').matches) return true;
            if (window.matchMedia('(hover: none)').matches && window.matchMedia('(any-pointer: coarse)').matches) {
                return true;
            }
        } catch (err) {}
        try {
            var mtp = typeof navigator !== 'undefined' ? navigator.maxTouchPoints || 0 : 0;
            if (mtp > 0 && window.matchMedia('(hover: none)').matches) return true;
        } catch (e2) {}
        return false;
    }

    /** Same breakpoint as mobile header CSS — mouse-only users need tap-to-toggle, not hover-only. */
    function notificationsNarrowViewport() {
        try {
            return window.matchMedia('(max-width: 768px)').matches;
        } catch (e3) {
            return false;
        }
    }

    function notificationsPreferClickToggle() {
        return shouldUseTouchToggle() || notificationsNarrowViewport();
    }

    function syncNotifAria(root) {
        var tb = root.querySelector('.notification-trigger');
        if (!tb) return;
        tb.setAttribute('aria-expanded', root.classList.contains('notifications-open') ? 'true' : 'false');
    }

    function clearCloseTimer(root) {
        var t = closeTimerByRoot.get(root);
        if (t) {
            clearTimeout(t);
            closeTimerByRoot.delete(root);
        }
    }

    function scheduleClose(root) {
        clearCloseTimer(root);
        var t = setTimeout(function () {
            closeTimerByRoot.delete(root);
            if (!root.matches(':focus-within')) {
                root.classList.remove('notifications-open');
                syncNotifAria(root);
            }
        }, CLOSE_DELAY_MS);
        closeTimerByRoot.set(root, t);
    }

    function openNotifications(root) {
        clearCloseTimer(root);
        root.classList.add('notifications-open');
        syncNotifAria(root);
    }

    function closeNotificationsNow(root) {
        clearCloseTimer(root);
        root.classList.remove('notifications-open');
        syncNotifAria(root);
        var tb = root.querySelector('.notification-trigger');
        if (tb && document.activeElement === tb) {
            try {
                tb.blur();
            } catch (errB) {}
        }
    }

    function bindNotificationContainer(root) {
        if (root.dataset.notifHoverDelayBound === '1') return;
        root.dataset.notifHoverDelayBound = '1';

        root.addEventListener('mouseenter', function () {
            if (notificationsPreferClickToggle()) return;
            openNotifications(root);
        });
        root.addEventListener('mouseleave', function () {
            scheduleClose(root);
        });
        root.addEventListener('focusin', function () {
            if (notificationsPreferClickToggle()) return;
            openNotifications(root);
        });
        root.addEventListener('focusout', function (ev) {
            var rt = ev.relatedTarget;
            if (rt && root.contains(rt)) return;
            scheduleClose(root);
        });

        var trigger = root.querySelector('.notification-trigger');
        if (trigger) {
            trigger.addEventListener('click', function (ev) {
                if (!notificationsPreferClickToggle()) return;
                ev.preventDefault();
                if (root.classList.contains('notifications-open')) {
                    closeNotificationsNow(root);
                } else {
                    openNotifications(root);
                }
            });
        }

        syncNotifAria(root);
    }

    function initNotificationHoverDelay() {
        document.querySelectorAll('.notification-container').forEach(bindNotificationContainer);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initNotificationHoverDelay);
    } else {
        initNotificationHoverDelay();
    }

    /* SPA (spa.js) replaces #site-header-wrapper on each navigation — old nodes lose listeners. */
    window.initNotificationHoverDelay = initNotificationHoverDelay;
    document.addEventListener('pageLoaded', initNotificationHoverDelay);

    /* Close when the user scrolls the page (not the alerts list inside .notification-dropdown). */
    if (!window.__ulpNotifScrollCloseBound) {
        window.__ulpNotifScrollCloseBound = true;
        window.addEventListener(
            'scroll',
            function (ev) {
                var t = ev.target;
                if (t && t.nodeType === 1 && typeof t.closest === 'function' && t.closest('.notification-dropdown')) {
                    return;
                }
                document.querySelectorAll('.notification-container.notifications-open').forEach(function (root) {
                    closeNotificationsNow(root);
                });
            },
            true
        );
    }

    document.addEventListener('keydown', function (ev) {
        if (ev.key !== 'Escape') return;
        var ae = document.activeElement;
        if (!ae || !ae.closest) return;
        var w = ae.closest('.notification-container');
        if (!w) return;
        clearCloseTimer(w);
        w.classList.remove('notifications-open');
        syncNotifAria(w);
        try {
            ae.blur();
        } catch (err) {}
        var tb = w.querySelector('.notification-trigger');
        if (tb) {
            try {
                tb.blur();
            } catch (err2) {}
        }
    });
})();

})();
