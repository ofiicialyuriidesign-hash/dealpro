(function () {
    // Flag to prevent multiple attachments of global listeners
    if (window._uploadListenersAttached) return;

    const PREVIEW_MIME = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    function isElHidden(el) {
        if (!el) return true;
        return window.getComputedStyle(el).display === 'none';
    }

    function toggleElPanel(panel, arrowEl) {
        if (!panel) return;
        const willOpen = isElHidden(panel);
        if (
            panel.classList.contains('form-advanced-panel')
        ) {
            panel.classList.toggle('is-open', willOpen);
            panel.style.display = '';
        } else {
            panel.style.display = willOpen ? 'block' : 'none';
        }
        if (arrowEl) {
            arrowEl.classList.toggle('fa-chevron-up', willOpen);
            arrowEl.classList.toggle('fa-chevron-down', !willOpen);
        }
    }

    function readScheduledPublishAt(inputEl) {
        if (!inputEl || !inputEl.value) return null;
        // Live "now" in the field = publish immediately (user did not pick a time).
        if (inputEl.dataset.scheduleAutonow === '1') return null;
        // Field shows server UTC wall clock (datetime-local has no TZ suffix).
        const d = new Date(inputEl.value + 'Z');
        if (Number.isNaN(d.getTime())) return null;
        return d.toISOString();
    }

    let uploadServerTimeOffsetMs = 0;
    let uploadServerTimeSyncPromise = null;

    function syncUploadServerTimeOffset() {
        if (uploadServerTimeSyncPromise) return uploadServerTimeSyncPromise;
        uploadServerTimeSyncPromise = fetch('/api/server-time', { credentials: 'same-origin' })
            .then((r) => (r.ok ? r.json() : null))
            .then((data) => {
                if (data && Number.isFinite(Number(data.unix_ms))) {
                    uploadServerTimeOffsetMs = Number(data.unix_ms) - Date.now();
                }
            })
            .catch(() => {})
            .then(() => uploadServerTimeOffsetMs);
        return uploadServerTimeSyncPromise;
    }

    function getUploadServerNow() {
        return new Date(Date.now() + uploadServerTimeOffsetMs);
    }

    function setScheduleDatetimeLocalMin(input) {
        if (!input) return;
        const d = new Date(getUploadServerNow().getTime() + 3 * 60 * 1000);
        input.min = formatDatetimeLocalValueUTC(d);
    }

    let uploadScheduleClockTimer = null;
    let uploadScheduleActiveInput = null;

    function formatDatetimeLocalValueUTC(d) {
        const pad = (n) => String(n).padStart(2, '0');
        return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    }

    function tickUploadScheduleInput(input) {
        if (!input) return;
        if (input.dataset.scheduleUserEdited === '1') return;
        if (document.activeElement === input) return;
        input.value = formatDatetimeLocalValueUTC(getUploadServerNow());
        input.dataset.scheduleAutonow = '1';
    }

    function stopUploadScheduleClock() {
        if (uploadScheduleClockTimer) {
            clearInterval(uploadScheduleClockTimer);
            uploadScheduleClockTimer = null;
        }
        uploadScheduleActiveInput = null;
    }

    function bindUploadScheduleInput(input) {
        if (!input || input.dataset.scheduleBound === '1') return;
        input.dataset.scheduleBound = '1';
        input.addEventListener('input', () => {
            if (!input.value) {
                input.dataset.scheduleUserEdited = '0';
                input.dataset.scheduleAutonow = '1';
                tickUploadScheduleInput(input);
                return;
            }
            input.dataset.scheduleUserEdited = '1';
            input.dataset.scheduleAutonow = '0';
        });
        input.addEventListener('change', () => {
            if (!input.value) {
                input.dataset.scheduleUserEdited = '0';
                input.dataset.scheduleAutonow = '1';
                return;
            }
            input.dataset.scheduleUserEdited = '1';
            input.dataset.scheduleAutonow = '0';
        });
    }

    function startUploadScheduleClock(input) {
        stopUploadScheduleClock();
        if (!input) return;
        uploadScheduleActiveInput = input;
        const tick = () => {
            if (!uploadScheduleActiveInput || !uploadScheduleActiveInput.isConnected) {
                stopUploadScheduleClock();
                return;
            }
            tickUploadScheduleInput(uploadScheduleActiveInput);
        };
        tick();
        uploadScheduleClockTimer = setInterval(tick, 1000);
    }

    function buildUploadScheduleFieldsHtml(scheduleId) {
        return `
            <div class="forum-new-topic-field">
                <label class="forum-new-topic-label" for="${scheduleId}">Schedule publish (optional)</label>
                <input type="datetime-local" id="${scheduleId}" class="cyber-input upload-schedule-input" autocomplete="off">
                <p class="text-secondary form-hint">Server time (UTC). Leave as-is to publish immediately.</p>
            </div>
        `;
    }

    function initUploadScheduleClock(scheduleInputId) {
        const input = document.getElementById(scheduleInputId);
        if (!input) return;
        syncUploadServerTimeOffset().then(() => {
            if (!input.isConnected) return;
            bindUploadScheduleInput(input);
            setScheduleDatetimeLocalMin(input);
            startUploadScheduleClock(input);
        });
    }

    function getImageFromClipboard(clipboardData) {
        if (!clipboardData) return null;
        if (clipboardData.files && clipboardData.files.length) {
            const f = clipboardData.files[0];
            if (f.type && f.type.startsWith('image/')) return f;
        }
        if (!clipboardData.items) return null;
        for (let i = 0; i < clipboardData.items.length; i++) {
            const item = clipboardData.items[i];
            if (item.type && item.type.startsWith('image/')) {
                const blob = item.getAsFile();
                if (blob) return blob;
            }
        }
        return null;
    }

    function extForMime(mime) {
        if (mime === 'image/jpeg') return 'jpg';
        if (mime === 'image/png') return 'png';
        if (mime === 'image/gif') return 'gif';
        if (mime === 'image/webp') return 'webp';
        return 'img';
    }

    function getImageFileInputInZone(zone) {
        if (!zone) return null;
        for (const inp of zone.querySelectorAll('input[type="file"]')) {
            const a = (inp.getAttribute('accept') || '').toLowerCase();
            if (a.includes('.txt') && !a.includes('jpg') && !a.includes('jpeg') && !a.includes('png') && !a.includes('gif') && !a.includes('webp') && !a.includes('image')) {
                continue;
            }
            if (a.includes('image') || a.includes('jpg') || a.includes('jpeg') || a.includes('png') || a.includes('gif') || a.includes('webp')) {
                return inp;
            }
        }
        return zone.querySelector('input.file-upload-hit-input[type="file"]');
    }

    function syncCompactImageThumb(fileInput) {
        const zone = fileInput && fileInput.closest('.file-upload-preview-zone');
        if (!zone) return;
        const slot = zone.querySelector('.file-upload-preview-thumb-slot');
        const img = slot && slot.querySelector('img');
        if (!slot || !img) return;
        const file = fileInput.files && fileInput.files[0];
        if (!file || !file.type || !file.type.startsWith('image/')) {
            slot.classList.remove('has-image');
            img.removeAttribute('src');
            return;
        }
        const r = new FileReader();
        r.onload = () => {
            img.src = r.result;
            slot.classList.add('has-image');
        };
        r.readAsDataURL(file);
    }

    function normalizePreviewNameDisplay(inputEl, nameDisplayEl) {
        syncCompactImageThumb(inputEl);
        if (!nameDisplayEl) return;
        const empty = nameDisplayEl.getAttribute('data-empty-label') || 'No image selected';
        if (inputEl.files && inputEl.files.length > 0) {
            nameDisplayEl.textContent = inputEl.files[0].name;
            nameDisplayEl.style.color = 'var(--text-primary)';
        } else {
            nameDisplayEl.textContent = empty;
            nameDisplayEl.style.color = 'var(--text-secondary)';
        }
    }

    function clearFileUploadPreviewImage(zone) {
        if (!zone || zone.classList.contains('resource-screenshot-zone')) return;
        const inputEl = getImageFileInputInZone(zone);
        if (!inputEl) return;
        const nameDisplay = zone.querySelector('.file-upload-preview-visual .file-name-display')
            || zone.querySelector('.file-name-display');
        const dt = new DataTransfer();
        inputEl.files = dt.files;
        normalizePreviewNameDisplay(inputEl, nameDisplay || null);
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function applyImageToPreviewInput(inputEl, nameDisplayEl, file, looseMime) {
        if (!inputEl) return;
        const ok = looseMime
            ? (file && file.type && file.type.startsWith('image/'))
            : (file && file.type && PREVIEW_MIME.includes(file.type));
        if (!ok) {
            if (typeof showToast === 'function') {
                showToast(looseMime ? 'Please use an image file.' : 'Use JPG, PNG, GIF, or WEBP.', 'error');
            }
            return;
        }
        const name = file.name && file.name !== 'image.png'
            ? file.name
            : `paste-${Date.now()}.${extForMime(file.type)}`;
        const wrapped = file instanceof File ? file : new File([file], name, { type: file.type });
        const dt = new DataTransfer();
        dt.items.add(wrapped);
        inputEl.files = dt.files;
        normalizePreviewNameDisplay(inputEl, nameDisplayEl);
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    }

    function isTxtFile(file) {
        if (!file || !file.name) return false;
        const n = file.name.toLowerCase();
        return n.endsWith('.txt') || file.type === 'text/plain';
    }

    function normalizeTxtFileDisplay(inputEl) {
        const zone = inputEl && inputEl.closest('.file-upload-txt-zone');
        if (!zone || !inputEl) return;
        const slot = zone.querySelector('.file-upload-preview-thumb-slot');
        const nameDisplay = zone.querySelector('.file-name-display');
        const empty = (nameDisplay && nameDisplay.getAttribute('data-empty-label')) || 'No file selected';
        const file = inputEl.files && inputEl.files[0];
        if (!file || !isTxtFile(file)) {
            if (slot) slot.classList.remove('has-file');
            if (nameDisplay) {
                nameDisplay.textContent = empty;
                nameDisplay.style.color = 'var(--text-secondary)';
            }
            return;
        }
        if (slot) slot.classList.add('has-file');
        if (nameDisplay) {
            nameDisplay.textContent = file.name;
            nameDisplay.style.color = 'var(--text-primary)';
        }
    }

    function clearTxtFileUploadZone(zone) {
        if (!zone) return;
        const inputEl = zone.querySelector('input[type="file"]');
        if (!inputEl) return;
        const dt = new DataTransfer();
        inputEl.files = dt.files;
        normalizeTxtFileDisplay(inputEl);
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
    }

    /**
     * .txt zone: full-area click, drop .txt only (same shell as image zone).
     */
    function initTextFileDropZone(inputEl) {
        if (!inputEl) return;
        const zone = inputEl.closest('.file-upload-txt-zone');
        if (!zone || zone.dataset.txtDropInit === '1') return;
        zone.dataset.txtDropInit = '1';

        inputEl.addEventListener('change', () => normalizeTxtFileDisplay(inputEl));

        function applyTxtFile(file) {
            if (!isTxtFile(file)) {
                if (typeof showToast === 'function') {
                    showToast('Only .txt files are allowed.', 'error');
                }
                return;
            }
            const dt = new DataTransfer();
            dt.items.add(file);
            inputEl.files = dt.files;
            inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        }

        let dragDepth = 0;
        zone.addEventListener('dragenter', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth++;
            zone.classList.add('file-upload-preview-zone--drag');
        });
        zone.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
        });
        zone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth--;
            if (dragDepth <= 0) {
                dragDepth = 0;
                zone.classList.remove('file-upload-preview-zone--drag');
            }
        });
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth = 0;
            zone.classList.remove('file-upload-preview-zone--drag');
            const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
            if (f) applyTxtFile(f);
        });
    }

    /**
     * Preview image zone: paste (⌘/Ctrl+V) and drag-drop; syncs hidden file input.
     */
    function initPreviewImagePasteZone(inputEl, nameDisplayEl) {
        if (!inputEl || !nameDisplayEl) return;
        const zone = inputEl.closest('.file-upload-preview-zone');
        if (!zone || zone.dataset.pasteInit === '1') return;
        zone.dataset.pasteInit = '1';

        inputEl.addEventListener('change', () => normalizePreviewNameDisplay(inputEl, nameDisplayEl));

        let dragDepth = 0;
        zone.addEventListener('dragenter', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth++;
            zone.classList.add('file-upload-preview-zone--drag');
        });
        zone.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.stopPropagation();
        });
        zone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth--;
            if (dragDepth <= 0) {
                dragDepth = 0;
                zone.classList.remove('file-upload-preview-zone--drag');
            }
        });
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();
            dragDepth = 0;
            zone.classList.remove('file-upload-preview-zone--drag');
            const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
            if (f) applyImageToPreviewInput(inputEl, nameDisplayEl, f);
        });
    }

    let __ulpPointerX = -1;
    let __ulpPointerY = -1;

    function handleGlobalImagePaste(e) {
        const blob = getImageFromClipboard(e.clipboardData);
        if (!blob) return;

        const ae = document.activeElement;
        if (ae && ae.closest && ae.closest('.ql-editor')) return;

        let zone = null;
        if (__ulpPointerX >= 0 && __ulpPointerY >= 0) {
            const hit = document.elementFromPoint(__ulpPointerX, __ulpPointerY);
            if (hit && hit.closest) {
                zone = hit.closest('.file-upload-preview-zone:not(.file-upload-txt-zone)');
            }
        }
        if (!zone && ae && ae.closest) {
            zone = ae.closest('.file-upload-preview-zone:not(.file-upload-txt-zone)');
        }
        if (!zone) return;

        const hit = (__ulpPointerX >= 0 && __ulpPointerY >= 0)
            ? document.elementFromPoint(__ulpPointerX, __ulpPointerY)
            : null;
        const pointerInZone = hit && zone.contains(hit);
        const focusInZone = ae && zone.contains(ae);
        if (!pointerInZone && !focusInZone) return;

        const textLike = ae && (
            ae.tagName === 'TEXTAREA' ||
            ae.tagName === 'SELECT' ||
            (ae.tagName === 'INPUT' && ['text', 'url', 'email', 'password', 'search', 'tel', 'number', 'date'].includes(ae.type)) ||
            ae.isContentEditable
        );
        if (textLike && !zone.contains(ae) && !pointerInZone) return;

        const fileInput = getImageFileInputInZone(zone);
        if (!fileInput) return;
        const nameDisplay = zone.querySelector('.file-upload-preview-visual .file-name-display')
            || zone.querySelector('.file-name-display');
        if (!nameDisplay) return;

        const looseMime = zone.classList.contains('resource-screenshot-zone');
        e.preventDefault();
        e.stopPropagation();
        applyImageToPreviewInput(fileInput, nameDisplay, blob, looseMime);
    }

    function isUploadFormPage() {
        return !!document.querySelector('.upload-page-shell form');
    }

    function isMainFilesFeedPage() {
        let p = (window.location && window.location.pathname) ? window.location.pathname : '/';
        p = p.replace(/\/+$/, '') || '/';
        return p === '/files' || p === '/';
    }

    function resetUploadPageForm() {
        const form = document.querySelector('.upload-page-shell form');
        if (!form) return;
        form.reset();
        const txtZone = form.querySelector('.file-upload-txt-zone');
        const imgZone = form.querySelector('.upload-image-preview-zone');
        if (txtZone) clearTxtFileUploadZone(txtZone);
        if (imgZone) clearFileUploadPreviewImage(imgZone);
        initFormAutosize(form);
        const adv = form.querySelector('#advanced-options');
        const arrow = form.querySelector('#adv-arrow');
        if (adv) {
            adv.classList.remove('is-open');
            adv.style.display = '';
            if (arrow) {
                arrow.classList.remove('fa-chevron-up');
                arrow.classList.add('fa-chevron-down');
            }
        }
        const sched = form.querySelector('#scheduled_publish_at');
        if (sched) sched.value = '';
    }

    function setUploadPageFormBusy(busy) {
        const form = document.querySelector('.upload-page-shell form');
        if (!form) return;
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) submitBtn.disabled = !!busy;
    }

    /** Sync optional Quill description editor into the hidden field before AJAX upload. */
    function syncUploadDescriptionFromQuill() {
        if (typeof window.readDescriptionQuillHtml === 'function') {
            return window.readDescriptionQuillHtml('file-description-editor');
        }
        const hidden = document.getElementById('file-description-field');
        return Promise.resolve((hidden && hidden.value ? hidden.value : '').trim());
    }

    /** Upload page form: AJAX POST instead of full document navigation. */
    function bindUploadPageForm() {
        const form = document.querySelector('.upload-page-shell form[method="POST"]');
        if (!form || form.dataset.uploadAjaxBound === '1') return;
        const fileInput = form.querySelector('input[name="file"]');
        if (!fileInput) return;
        form.dataset.uploadAjaxBound = '1';
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const fileInput = form.querySelector('input[name="file"]');
            const file = fileInput && fileInput.files && fileInput.files[0];
            if (!file) {
                if (typeof showToast === 'function') {
                    showToast('Select a .txt file first.', 'error');
                }
                return;
            }
            syncUploadDescriptionFromQuill()
                .then((description) => {
                    const title = (form.querySelector('[name="title"]')?.value || '').trim();
                    const previewInput = form.querySelector('[name="preview_image"]');
                    const previewImage = (previewInput && previewInput.files && previewInput.files[0])
                        ? previewInput.files[0]
                        : null;
                    const { isAdmin, isStaff } = getUploadRoleFlags();
                    const password = isStaff ? form.querySelector('[name="password"]')?.value || null : null;
                    const expiration = isStaff ? form.querySelector('[name="expiration"]')?.value || null : null;
                    const price = isStaff ? (form.querySelector('[name="price"]')?.value || '').trim() || null : null;
                    const isVipSection = isAdmin && !!form.querySelector('[name="is_vip_section"]')?.checked;
                    const schedInput = isAdmin
                        ? form.querySelector('#scheduled_publish_at, [name="scheduled_publish_at"]')
                        : null;
                    const scheduledPublishAt = readScheduledPublishAt(schedInput);
                    handleFileUpload(
                        file,
                        title || null,
                        password,
                        expiration,
                        price,
                        description || null,
                        previewImage,
                        isVipSection,
                        scheduledPublishAt,
                    );
                })
                .catch(() => {});
        });
    }

    function initPageUploadZones() {
        bindUploadPageForm();
        const fileIn = document.getElementById('file');
        if (fileIn) {
            initTextFileDropZone(fileIn);
            normalizeTxtFileDisplay(fileIn);
        }
        const pi = document.getElementById('preview_image');
        const pn = document.getElementById('preview-name-display');
        if (pi && pn) {
            initPreviewImagePasteZone(pi, pn);
            normalizePreviewNameDisplay(pi, pn);
        }
        const schedIn = document.getElementById('scheduled_publish_at');
        if (schedIn) {
            initUploadScheduleClock('scheduled_publish_at');
        }
        const editAv = document.getElementById('avatar');
        const editAvName = document.getElementById('edit-profile-avatar-name');
        if (editAv && editAvName) {
            initPreviewImagePasteZone(editAv, editAvName);
            normalizePreviewNameDisplay(editAv, editAvName);
        }
        const editBg = document.getElementById('background');
        const editBgName = document.getElementById('edit-profile-background-name');
        if (editBg && editBgName) {
            initPreviewImagePasteZone(editBg, editBgName);
            normalizePreviewNameDisplay(editBg, editBgName);
        }
    }

    /**
     * Textareas with class js-autogrow: start compact, expand as user types.
     * @param {ParentNode} [root] - default document
     */
    function initFormAutosize(root) {
        const scope = root || document;
        scope.querySelectorAll('textarea.js-autogrow').forEach((el) => {
            if (el.dataset.autogrowBound === '1') return;
            el.dataset.autogrowBound = '1';
            const resize = () => {
                const cs = getComputedStyle(el);
                const maxH = parseFloat(cs.maxHeight);
                const cap = Number.isFinite(maxH) && maxH > 0 ? maxH : 1e9;
                const lh = parseFloat(cs.lineHeight);
                const fs = parseFloat(cs.fontSize);
                const linePx = Number.isFinite(lh) && lh > 0 ? lh : (Number.isFinite(fs) ? fs * 1.35 : 19);
                const pt = parseFloat(cs.paddingTop);
                const pb = parseFloat(cs.paddingBottom);
                const floor = linePx + (Number.isFinite(pt) ? pt : 0) + (Number.isFinite(pb) ? pb : 0);

                el.style.overflowY = 'hidden';
                el.style.minHeight = '0';
                el.style.height = '0';
                const sh = el.scrollHeight;
                const target = Math.min(Math.max(sh, floor), cap);
                el.style.height = `${target}px`;
                el.style.minHeight = '';
                el.style.overflowY = sh > cap ? 'auto' : 'hidden';
            };
            el.addEventListener('input', resize);
            resize();
        });
    }

    window.initFormAutosize = initFormAutosize;

    function escapeHtml(str) {
        if (str == null) return '';
        const d = document.createElement('div');
        d.textContent = String(str);
        return d.innerHTML;
    }


    function formatUploadFileSizeKb(file) {
        return (file.size / 1024).toFixed(1);
    }

    function getUploadRoleFlags() {
        const role = (document.body && document.body.getAttribute('data-user-role')) || '';
        return {
            role,
            isAdmin: role === 'admin',
            isStaff: role === 'admin' || role === 'moderator',
        };
    }

    function uploadModalFieldIds(variant) {
        if (variant === 'bulk') {
            return {
                panel: 'bulk-adv-panel',
                toggle: 'bulk-adv-toggle',
                icon: 'bulk-adv-icon',
                pass: 'bulk-global-pass',
                exp: 'bulk-global-exp',
                price: 'bulk-global-price',
                vip: 'bulk-global-vip',
                schedule: 'bulk-global-schedule',
            };
        }
        return {
            panel: 'advanced-options-panel',
            toggle: 'advanced-options-toggle',
            icon: 'advanced-options-icon',
            pass: 'modal-file-key',
            exp: 'modal-file-expiration',
            price: 'modal-file-price',
            vip: 'modal-file-vip',
            schedule: 'modal-file-schedule',
        };
    }

    function buildUploadModalFormShell(title, iconClass, closeOpts, bodyHtml, actionsHtml, opts) {
        opts = opts || {};
        const closeAttr = closeOpts && closeOpts.id ? `id="${closeOpts.id}"` : 'data-modal-close';
        const bulkClass = opts.bulk ? ' upload-modal-form--bulk' : '';
        const staffHtml = opts.staffHtml || '';
        const staffBlock = staffHtml
            ? `<div class="upload-modal-staff-section">${staffHtml}</div>`
            : '';
        return `
            <div class="upload-modal-form cyber-card detail-main-card edit-content-form${bulkClass}">
                <header class="edit-content-form-header upload-modal-form-header">
                    <h2 class="edit-content-form-title"><i class="${iconClass} icon"></i> ${title}</h2>
                    <button type="button" class="modal-close-btn upload-modal-close-btn" ${closeAttr} aria-label="Close">
                        <i class="fas fa-times" aria-hidden="true"></i>
                    </button>
                </header>
                <div class="upload-modal-form-scroll">${bodyHtml}</div>
                ${staffBlock}
                ${actionsHtml}
            </div>
        `;
    }

    function buildUploadModalTxtFileDisplayHtml(file) {
        const sizeKb = formatUploadFileSizeKb(file);
        return `
            <div class="file-upload-preview-zone file-upload-txt-zone upload-modal-txt-readonly" tabindex="-1" role="group"
                aria-label="Selected text file">
                <div class="file-upload-preview-visual">
                    <div class="file-upload-preview-main-row">
                        <span class="file-custom-btn"><i class="fas fa-file-lines icon"></i> .txt selected</span>
                        <div class="file-upload-preview-thumb-slot file-upload-txt-thumb-slot has-file">
                            <div class="file-upload-doc-preview" aria-hidden="true">
                                <i class="fas fa-file-lines"></i>
                            </div>
                        </div>
                        <span class="file-name-display" data-empty-label="No file selected">${escapeHtml(file.name)}</span>
                    </div>
                    <p class="file-upload-paste-hint">${sizeKb} KB · selected from drop or file picker</p>
                </div>
            </div>
        `;
    }

    function buildUploadModalPreviewZoneHtml(inputId, nameId) {
        return `
            <div class="file-upload-preview-zone upload-image-preview-zone" tabindex="0" role="group"
                aria-label="Preview image: click, paste, or drop">
                <input type="file" id="${inputId}" class="file-upload-hit-input"
                    accept=".jpg,.jpeg,.png,.gif,.webp" tabindex="-1">
                <div class="file-upload-preview-visual">
                    <div class="file-upload-preview-main-row">
                        <span class="file-custom-btn"><i class="fas fa-image icon"></i> Choose image</span>
                        <div class="file-upload-preview-thumb-slot">
                            <img class="file-upload-preview-thumb-img" alt="">
                            <button type="button"
                                class="file-upload-thumb-remove file-upload-preview-remove-btn"
                                aria-label="Remove preview image" title="Remove image">
                                <i class="fas fa-times" aria-hidden="true"></i>
                            </button>
                        </div>
                        <span class="file-name-display" id="${nameId}" data-empty-label="No image selected">No image selected</span>
                    </div>
                    <p class="file-upload-paste-hint">Click anywhere in this box, paste (⌘V / Ctrl+V), or drop an image.</p>
                </div>
            </div>
        `;
    }

    function buildUploadModalPerFileFields(file, index, variant) {
        const bulk = variant === 'bulk';
        const titleId = bulk ? `bulk-title-${index}` : 'modal-file-title';
        const descEditorId = bulk ? `bulk-desc-editor-${index}` : 'modal-file-description-editor';
        const descHiddenId = bulk ? `bulk-desc-field-${index}` : 'modal-file-description-field';
        const previewId = bulk ? `bulk-preview-${index}` : 'modal-file-preview';
        const nameId = bulk ? `bulk-preview-name-${index}` : 'modal-preview-name';
        const maxDesc = (typeof window.DESCRIPTION_MAX_PLAIN_CHARS === 'number' && window.DESCRIPTION_MAX_PLAIN_CHARS) || 2000;
        const blockLabel = bulk
            ? `<div class="upload-modal-file-block-label"><i class="fas fa-file-lines icon"></i> ${escapeHtml(file.name)}</div>`
            : '';
        const inner = `
            ${blockLabel}
            <div class="forum-new-topic-field">
                <label class="forum-new-topic-label" for="${titleId}">Title (optional)</label>
                <textarea id="${titleId}" class="cyber-input js-autogrow" rows="1" placeholder="File title…" autocomplete="off"></textarea>
            </div>
            <div class="upload-page-grid upload-files-pair forum-new-topic-field">
                <div class="upload-grid-cell">
                    <label class="forum-new-topic-label">Text file</label>
                    ${buildUploadModalTxtFileDisplayHtml(file)}
                </div>
                <div class="upload-grid-cell">
                    <label class="forum-new-topic-label" for="${previewId}">Preview image (optional)</label>
                    ${buildUploadModalPreviewZoneHtml(previewId, nameId)}
                </div>
            </div>
            <div class="forum-new-topic-field">
                <label class="forum-new-topic-label" for="${descEditorId}">Description (optional, max ${maxDesc} characters)</label>
                <div class="rich-editor-wrap upload-modal-desc-editor-wrap">
                    <div id="${descEditorId}" data-upload-description-editor data-hidden-field="${descHiddenId}" data-placeholder="Short description for your file…"></div>
                </div>
                <textarea id="${descHiddenId}" name="description" tabindex="-1" aria-hidden="true" class="composer-honeypot-offscreen"></textarea>
            </div>
        `;
        return bulk ? `<div class="upload-modal-file-block">${inner}</div>` : inner;
    }

    function buildUploadModalUserOptionsRowHtml(ids) {
        return `
            <div class="form-grid-2">
                <div>
                    <label class="forum-new-topic-label" for="${ids.pass}">Password (optional)</label>
                    <input type="text" id="${ids.pass}" class="cyber-input" placeholder="Optional password…" autocomplete="off">
                </div>
                <div>
                    <label class="forum-new-topic-label" for="${ids.exp}">Expiration</label>
                    <select id="${ids.exp}" class="cyber-input">
                        <option value="never" selected>Never expire</option>
                        <option value="1h">1 Hour</option>
                        <option value="1d">1 Day</option>
                        <option value="1w">1 Week</option>
                        <option value="1view">Burn after 1 view</option>
                    </select>
                </div>
            </div>
        `;
    }

    function buildUploadModalStaffOptionsHtml(isAdmin, isStaff, ids) {
        if (!isStaff) return '';
        return `
            <div class="forum-new-topic-field">
                <label class="forum-new-topic-label" for="${ids.price}">Price (USD)</label>
                <input type="number" step="0.01" min="0" id="${ids.price}" class="cyber-input" placeholder="0.00 (empty = free)">
            </div>
            ${
                isAdmin
                    ? `<label class="form-check-row form-check-row--vip">
                <input type="checkbox" id="${ids.vip}" class="cyber-checkbox" value="on">
                <span class="vip-caption-text ulp-list-toolbar-text">
                    <i class="fas fa-gem icon icon-gem-gradient"></i> VIP section
                </span>
            </label>
            ${buildUploadScheduleFieldsHtml(ids.schedule)}`
                    : ''
            }`;
    }

    function buildUploadModalOptionsSection(isAdmin, isStaff, variant) {
        if (!isStaff) return '';
        const ids = uploadModalFieldIds(variant);
        return `
            <div class="forum-new-topic-field">
                <button type="button" id="${ids.toggle}" class="btn btn-secondary btn-toolbar edit-content-staff-toggle">
                    <span><i class="fas fa-user-shield icon"></i> Staff options</span>
                    <i class="fas fa-chevron-down" id="${ids.icon}"></i>
                </button>
            </div>
            <div id="${ids.panel}" class="form-advanced-panel">
                ${buildUploadModalUserOptionsRowHtml(ids)}
                ${buildUploadModalStaffOptionsHtml(isAdmin, isStaff, ids)}
            </div>
        `;
    }

    function collectUploadModalConfirmExtras(variant, isAdmin, isStaff) {
        const ids = uploadModalFieldIds(variant);
        let password = null;
        let expiration = null;
        let price = null;
        let isVipSection = false;
        let scheduledPublishAt = null;
        if (isStaff) {
            password = (document.getElementById(ids.pass)?.value || '').trim() || null;
            expiration = document.getElementById(ids.exp)?.value || 'never';
            price = (document.getElementById(ids.price)?.value || '').trim() || null;
        }
        if (isAdmin) {
            isVipSection = !!document.getElementById(ids.vip)?.checked;
            scheduledPublishAt = readScheduledPublishAt(document.getElementById(ids.schedule));
        }
        return { password, expiration, price, isVipSection, scheduledPublishAt };
    }

    function buildUploadModalActionsHtml(confirmId, confirmLabel, cancelId) {
        const cancelAttr = cancelId ? `id="${cancelId}"` : 'data-modal-close';
        return `
            <div class="edit-content-form-actions upload-modal-form-actions">
                <button type="button" class="btn btn-secondary btn-toolbar" ${cancelAttr}>
                    <i class="fas fa-times icon"></i> Cancel
                </button>
                <button type="button" id="${confirmId}" class="btn btn-toolbar">
                    <i class="fas fa-upload icon"></i> ${confirmLabel}
                </button>
            </div>
        `;
    }

    function wireUploadModalAdvanced(variant, isAdmin, isStaff) {
        const ids = uploadModalFieldIds(variant);
        if (isStaff) {
            const advToggle = document.getElementById(ids.toggle);
            const advPanel = document.getElementById(ids.panel);
            const advIcon = document.getElementById(ids.icon);
            if (advToggle && advPanel) {
                advToggle.addEventListener('click', () => toggleElPanel(advPanel, advIcon));
            }
        }
        if (isAdmin) {
            const sched = document.getElementById(ids.schedule);
            if (sched) initUploadScheduleClock(ids.schedule);
        }
    }

    function scopeGetById(root, id) {
        if (!id) return null;
        const scope = root || document;
        if (typeof scope.getElementById === 'function') return scope.getElementById(id);
        return scope.querySelector('#' + CSS.escape(id));
    }

    function initUploadModalPreviewInScope(scopeEl, fileCount, variant) {
        const bulk = variant === 'bulk';
        const n = bulk ? fileCount : 1;
        for (let i = 0; i < n; i++) {
            const previewId = bulk ? `bulk-preview-${i}` : 'modal-file-preview';
            const nameId = bulk ? `bulk-preview-name-${i}` : 'modal-preview-name';
            const previewInput = scopeGetById(document, previewId);
            const previewName = scopeGetById(document, nameId);
            if (previewInput && previewName) {
                const z = previewInput.closest('.file-upload-preview-zone');
                if (z) delete z.dataset.pasteInit;
                initPreviewImagePasteZone(previewInput, previewName);
                normalizePreviewNameDisplay(previewInput, previewName);
            }
        }
    }


    /**
     * Admin/staff: confirm placement + per-file title, description, preview before sequential POST /upload.
     * Resolves { items: [{ file, title, description, previewImage }], global: { price, isVipSection, password, expiration } }.
     */
    function openBulkTxtConfirmModal(txtFiles) {
        return new Promise((resolve, reject) => {
            if (!txtFiles || !txtFiles.length) {
                reject(new Error('no-files'));
                return;
            }
            if (!window.showModalContent) {
                reject(new Error('no-modal'));
                return;
            }

            const role = document.body.getAttribute('data-user-role') || '';
            const isAdmin = role === 'admin';
            const isStaff = role === 'admin' || role === 'moderator';

            let rowsHtml = '';
            txtFiles.forEach((f, i) => {
                rowsHtml += buildUploadModalPerFileFields(f, i, 'bulk');
            });

            const staffHtml = isStaff ? buildUploadModalOptionsSection(isAdmin, isStaff, 'bulk') : '';
            const modalHtml = buildUploadModalFormShell(
                `Bulk upload (${txtFiles.length})`,
                'fas fa-layer-group',
                { id: 'bulk-modal-x' },
                `<div class="upload-modal-files-scroll">${rowsHtml}</div>`,
                buildUploadModalActionsHtml('bulk-confirm-upload-btn', `Upload ${txtFiles.length}`, 'bulk-cancel-upload-btn'),
                { bulk: true, staffHtml }
            );

            const container = document.querySelector('.modal-container');
            if (container) {
                container.classList.add('upload-modal-container', 'upload-modal-container--bulk');
            }
            window.showModalContent(modalHtml);

            const closeAndReject = () => {
                window.closeModal();
                reject(new Error('cancel'));
            };

            document.getElementById('bulk-cancel-upload-btn')?.addEventListener('click', closeAndReject);
            document.getElementById('bulk-modal-x')?.addEventListener('click', closeAndReject);

            wireUploadModalAdvanced('bulk', isAdmin, isStaff);

            document.getElementById('bulk-confirm-upload-btn')?.addEventListener('click', () => {
                const extras = collectUploadModalConfirmExtras('bulk', isAdmin, isStaff);
                const global = {
                    price: extras.price,
                    isVipSection: extras.isVipSection,
                    password: extras.password || null,
                    expiration: extras.expiration === 'never' ? null : extras.expiration,
                    scheduledPublishAt: extras.scheduledPublishAt,
                };
                const readDesc = typeof window.readDescriptionQuillHtml === 'function'
                    ? window.readDescriptionQuillHtml.bind(window)
                    : () => Promise.resolve('');
                Promise.all(
                    txtFiles.map((f, i) =>
                        readDesc(`bulk-desc-editor-${i}`).then((description) => ({
                            file: f,
                            title: (document.getElementById(`bulk-title-${i}`)?.value || '').trim() || null,
                            description: description || null,
                            previewImage: document.getElementById(`bulk-preview-${i}`)?.files?.[0] || null,
                        }))
                    )
                )
                    .then((items) => {
                        window.closeModal();
                        resolve({ items, global });
                    })
                    .catch(() => {});
            });

            setTimeout(() => {
                const scope = document.getElementById('modal-content-area') || document;
                initFormAutosize(scope);
                initUploadModalPreviewInScope(scope, txtFiles.length, 'bulk');
                if (typeof window.initDescriptionEditorsInRoot === 'function') {
                    window.initDescriptionEditorsInRoot(scope);
                }
            }, 80);
        });
    }

    window.openBulkTxtConfirmModal = openBulkTxtConfirmModal;

    /**
     * Sequential upload after modal confirmation. Returns { ok, fail }.
     * @param {{ skipToast?: boolean, skipReload?: boolean }} [seqOpts] — e.g. admin dashboard uses its own toast and no feed reload.
     */
    window.runBulkTxtUploadSequence = async function (items, globalOpts, seqOpts) {
        const g = globalOpts || {};
        const so = seqOpts || {};
        let ok = 0;
        let fail = 0;
        let feedUpdated = false;
        const loader = document.getElementById('global-loader');
        const loaderText = loader ? loader.querySelector('span') : null;
        const n = items.length;
        for (let i = 0; i < n; i++) {
            const it = items[i];
            const f = it.file;
            if (loader) {
                if (loaderText) loaderText.textContent = `Uploading ${i + 1}/${n}: ${f.name}`;
                loader.classList.add('active');
            }
            const result = await postTxtUploadRaw(f, {
                title: it.title,
                description: it.description,
                previewImage: it.previewImage,
                price: g.price,
                isVipSection: !!g.isVipSection,
                password: g.password,
                expiration: g.expiration,
                scheduledPublishAt: g.scheduledPublishAt,
            });
            if (result.ok && result.data && result.data.success) {
                ok++;
                if (
                    !so.skipReload &&
                    isMainFilesFeedPage() &&
                    result.data.feed_item &&
                    typeof window.applyNewFileToIndexFeed === 'function'
                ) {
                    window.applyNewFileToIndexFeed(result.data.feed_item);
                    feedUpdated = true;
                }
            } else {
                fail++;
                const msg = (result.data && result.data.message) || result.clientError || 'failed';
                console.warn('Bulk upload failed:', f.name, msg);
            }
        }
        resetUploadGlobalLoader();
        if (!so.skipToast) {
            const toastFn = typeof window.showToast === 'function' ? window.showToast : null;
            if (toastFn) {
                toastFn(
                    fail
                        ? `Bulk upload: ${ok} succeeded, ${fail} failed.`
                        : `Uploaded ${ok} file(s).`,
                    fail ? 'error' : 'success'
                );
            }
        }
        if (!so.skipReload && ok > 0 && !feedUpdated) {
            if (window.loadPage) {
                try {
                    await window.loadPage(window.location.pathname + window.location.search);
                } catch (err) {
                    console.warn('loadPage after bulk:', err);
                }
            } else {
                window.location.reload();
            }
        }
        return { ok, fail };
    };

    function resetUploadGlobalLoader() {
        const loader = document.getElementById('global-loader');
        if (loader) {
            loader.classList.remove('active');
            loader.style.display = 'none';
            const loaderText = loader.querySelector('span');
            if (loaderText) loaderText.textContent = 'Syncing...';
        }
    }

    /**
     * One POST /upload; returns { ok, data, clientError, redirected, url, error }.
     * Used by single-file flow and admin window bulk drop.
     */
    function postTxtUploadRaw(file, opts = {}) {
        const {
            title = null,
            password = null,
            expiration = null,
            price = null,
            description = null,
            previewImage = null,
            isVipSection = false,
            scheduledPublishAt = null,
        } = opts;

        if (!file.name.toLowerCase().endsWith('.txt')) {
            return Promise.resolve({ ok: false, clientError: 'Error: Only .txt files are allowed!' });
        }
        if (file.size > 16 * 1024 * 1024) {
            return Promise.resolve({ ok: false, clientError: 'Error: File size exceeds 16MB limit.' });
        }

        const formData = new FormData();
        const uploadFormCsrf = document.querySelector('form[action="/upload"] input[name="csrf_token"], form input[name="csrf_token"]')?.value;
        const csrfToken = uploadFormCsrf || document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
        if (csrfToken) formData.append('csrf_token', csrfToken);
        formData.append('file', file);
        if (title) formData.append('title', title);
        const { isAdmin, isStaff } = getUploadRoleFlags();
        if (isStaff && password) formData.append('password', password);
        if (isStaff && expiration) formData.append('expiration', expiration);
        if (description) formData.append('description', description);
        if (previewImage) formData.append('preview_image', previewImage);
        if (isStaff && price) formData.append('price', price);
        if (isAdmin && isVipSection) formData.append('is_vip_section', 'on');
        if (isAdmin && scheduledPublishAt) formData.append('scheduled_publish_at', scheduledPublishAt);

        return fetch('/upload', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                'X-CSRFToken': csrfToken || '',
                'X-Requested-With': 'XMLHttpRequest',
                Accept: 'application/json',
            },
        })
            .then(async (response) => {
                if (response.redirected) {
                    return { ok: false, redirected: true, url: response.url };
                }
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.indexOf('application/json') !== -1) {
                    const data = await response.json();
                    return { ok: !!data.success, data, response };
                }
                if (response.ok) {
                    return { ok: true, data: { success: true, message: 'File uploaded successfully!' }, response };
                }
                return { ok: false, data: null, response };
            })
            .catch((error) => {
                console.error('Upload fetch error:', error);
                return { ok: false, error };
            });
    }

    function handleFileUpload(file, title = null, password = null, expiration = null, price = null, description = null, previewImage = null, isVipSection = false, scheduledPublishAt = null) {
        const onUploadPage = isUploadFormPage();
        setUploadPageFormBusy(true);
        const loader = document.getElementById('global-loader');
        if (loader) {
            const loaderText = loader.querySelector('span');
            if (loaderText) loaderText.textContent = `Uploading ${file.name}...`;
            loader.classList.add('active');
        }

        postTxtUploadRaw(file, { title, password, expiration, price, description, previewImage, isVipSection, scheduledPublishAt }).then((result) => {
            if (result.clientError) {
                showToast(result.clientError, 'error');
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
                return;
            }
            if (result.redirected && result.url) {
                window.location.href = result.url;
                return;
            }
            const data = result.data;
            if (result.ok && data && data.success) {
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
                showToast(data.message || 'File uploaded successfully!', 'success');
                if (onUploadPage) {
                    resetUploadPageForm();
                    return;
                }
                if (
                    isMainFilesFeedPage() &&
                    data.feed_item &&
                    typeof window.applyNewFileToIndexFeed === 'function'
                ) {
                    window.applyNewFileToIndexFeed(data.feed_item);
                    return;
                }
                setTimeout(async () => {
                    if (data.redirect) {
                        if (window.loadPage) {
                            try {
                                await window.loadPage(data.redirect, false, { showLoader: false });
                            } catch (e) {
                                window.location.href = data.redirect;
                                return;
                            }
                        } else {
                            window.location.href = data.redirect;
                        }
                    } else if (!window.loadPage) {
                        window.location.reload();
                    }
                }, 1500);
            } else if (result.error) {
                showToast('Upload error.', 'error');
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
            } else if (data && !data.success) {
                const msg = String(data.message || '').toLowerCase();
                const looksLikeCsrf =
                    msg.includes('security token') ||
                    msg.includes('session expired') ||
                    msg.includes('csrf');
                if (looksLikeCsrf) {
                    showToast(
                        (data.message || 'Session expired.') + ' Reloading…',
                        'warning',
                    );
                    setTimeout(() => {
                        window.location.reload();
                    }, 900);
                } else {
                    showToast(data.message || 'Upload failed.', 'error');
                }
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
            } else if (result.response && result.response.ok) {
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
                showToast('File uploaded successfully! Syncing...', 'success');
                if (onUploadPage) {
                    resetUploadPageForm();
                } else {
                    setTimeout(() => window.location.reload(), 2000);
                }
            } else {
                const st = result.response ? result.response.status : '?';
                showToast('Upload failed with status: ' + st, 'error');
                resetUploadGlobalLoader();
                setUploadPageFormBusy(false);
            }
        });
    }

    // Global Drag Events attached ONCE
    // Use a counter to handle dragenter/dragleave firing on every child element crossing.
    let _dragCounter = 0;

    /** Reset drop overlay (SPA navigation, URL changes, etc.). */
    function resetWindowFileDropOverlay() {
        _dragCounter = 0;
        const dropOverlay = document.getElementById('drop-overlay');
        if (dropOverlay) dropOverlay.style.display = 'none';
    }

    /**
     * Window file drop → upload modal only on the main files feed.
     * Production URL is often /files; in this repo main.index is '/'.
     */
    function isMainFilesFeedPageForWindowDrop() {
        let p = (window.location && window.location.pathname) ? window.location.pathname : '/';
        p = p.replace(/\/+$/, '') || '/';
        return p === '/files' || p === '/';
    }

    document.addEventListener('pageLoaded', resetWindowFileDropOverlay);

    window.addEventListener('dragenter', (e) => {
        // Only care about file drags
        if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return;
        if (!isMainFilesFeedPageForWindowDrop()) return;
        e.preventDefault();
        _dragCounter++;
        const dropOverlay = document.getElementById('drop-overlay');
        if (dropOverlay) dropOverlay.style.display = 'flex';
    });

    window.addEventListener('dragover', (e) => {
        if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return;
        if (!isMainFilesFeedPageForWindowDrop()) return;
        e.preventDefault(); // Required to allow drop
    });

    window.addEventListener('dragleave', (e) => {
        if (!e.dataTransfer || !e.dataTransfer.types.includes('Files')) return;
        if (!isMainFilesFeedPageForWindowDrop()) return;
        e.preventDefault();
        _dragCounter--;
        if (_dragCounter <= 0) {
            _dragCounter = 0;
            const dropOverlay = document.getElementById('drop-overlay');
            if (dropOverlay) dropOverlay.style.display = 'none';
        }
    });

    window.addEventListener('drop', (e) => {
        if (!isMainFilesFeedPageForWindowDrop()) {
            return; // do not preventDefault — default browser behavior on other pages
        }
        e.preventDefault();
        _dragCounter = 0; // Always reset on drop
        const dropOverlay = document.getElementById('drop-overlay');
        if (dropOverlay) dropOverlay.style.display = 'none';

        // Check Authentication First
        const isAuthenticated = document.body.getAttribute('data-is-authenticated') === 'true';
        if (!isAuthenticated) {
            if (window.requireLogin) {
                window.requireLogin('Registration required to upload files.', window.location.pathname + window.location.search);
            } else {
                showToast('Login Required', 'Registration required to upload files.', null, 'fas fa-user-lock', null, 'system');
            }
            return;
        }

        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const userRole = document.body.getAttribute('data-user-role') || '';
            const rawList = Array.from(files);
            const txtFiles = [];
            let skipped = 0;
            for (const f of rawList) {
                if (!f.name.toLowerCase().endsWith('.txt')) {
                    skipped++;
                    continue;
                }
                if (f.size > 16 * 1024 * 1024) {
                    skipped++;
                    continue;
                }
                txtFiles.push(f);
            }
            if (skipped > 0) {
                showToast(`${skipped} file(s) skipped (only .txt up to 16MB).`, 'error');
            }
            if (txtFiles.length === 0) {
                return;
            }

            // Staff: 2+ valid .txt → confirm modal (section, price, per-file title/desc/preview), then sequential /upload.
            const staffBulk = userRole === 'admin' || userRole === 'moderator';
            if (staffBulk && txtFiles.length >= 2) {
                openBulkTxtConfirmModal(txtFiles)
                    .then(({ items, global }) => window.runBulkTxtUploadSequence(items, global))
                    .catch((err) => {
                        if (err && err.message !== 'cancel' && err.message !== 'no-files' && err.message !== 'no-modal') {
                            console.warn(err);
                            if (typeof showToast === 'function') {
                                showToast(err.message || 'Bulk upload could not start.', 'error');
                            }
                        }
                    });
                return;
            }

            const file = txtFiles[0];
            const isAdmin = userRole === 'admin';
            const isStaff = userRole === 'admin' || userRole === 'moderator';

            const staffHtml = isStaff ? buildUploadModalOptionsSection(isAdmin, isStaff, 'single') : '';
            const modalHtml = buildUploadModalFormShell(
                'Upload file',
                'fas fa-upload',
                {},
                buildUploadModalPerFileFields(file, 0, 'single'),
                buildUploadModalActionsHtml('confirm-upload-btn', 'Upload', null),
                { staffHtml }
            );
            // Open Modal using the helper from base.html
            if (window.showModalContent) {
                // Apply specific width class
                const container = document.querySelector('.modal-container');
                if (container) container.classList.add('upload-modal-container');

                window.showModalContent(modalHtml);

                wireUploadModalAdvanced('single', isAdmin, isStaff);

                setTimeout(() => {
                    const scope = document.getElementById('modal-content-area') || document;
                    initFormAutosize(scope);
                    initUploadModalPreviewInScope(scope, 1, 'single');
                    if (typeof window.initDescriptionEditorsInRoot === 'function') {
                        window.initDescriptionEditorsInRoot(scope);
                    }
                    const input = document.getElementById('modal-file-title');
                    if (input) input.focus();
                }, 100);

                const confirmBtn = document.getElementById('confirm-upload-btn');
                const previewInput = document.getElementById('modal-file-preview');

                if (!confirmBtn) return;
                confirmBtn.onclick = () => {
                    const readDesc = typeof window.readDescriptionQuillHtml === 'function'
                        ? window.readDescriptionQuillHtml('modal-file-description-editor')
                        : Promise.resolve('');
                    readDesc.then((description) => {
                        const title = (document.getElementById('modal-file-title')?.value || '').trim();
                        const extras = collectUploadModalConfirmExtras('single', isAdmin, isStaff);
                        const previewImage = (previewInput && previewInput.files && previewInput.files[0]) ? previewInput.files[0] : null;

                        window.closeModal();
                        handleFileUpload(
                            file,
                            title,
                            extras.password,
                            extras.expiration,
                            extras.price,
                            description || null,
                            previewImage,
                            extras.isVipSection,
                            extras.scheduledPublishAt
                        );
                    }).catch(() => {});
                };

            } else {
                // Fallback if modal logic missing
                handleFileUpload(file);
            }
        }
    });

    document.addEventListener('pointermove', (ev) => {
        __ulpPointerX = ev.clientX;
        __ulpPointerY = ev.clientY;
    }, true);
    document.addEventListener('paste', handleGlobalImagePaste, true);

    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.file-upload-preview-remove-btn');
        if (!btn) return;
        const zone = btn.closest('.file-upload-preview-zone');
        if (!zone || zone.classList.contains('resource-screenshot-zone')) return;
        e.preventDefault();
        e.stopPropagation();
        if (zone.classList.contains('file-upload-txt-zone')) {
            clearTxtFileUploadZone(zone);
            return;
        }
        clearFileUploadPreviewImage(zone);
    });

    window._uploadListenersAttached = true;
    window.initUpload = function () {
        initPageUploadZones();
        initFormAutosize();
    };

    function bootUploadPage() {
        initPageUploadZones();
        initFormAutosize();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootUploadPage);
    } else {
        bootUploadPage();
    }
})();
