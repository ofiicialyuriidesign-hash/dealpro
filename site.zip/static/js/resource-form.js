/**
 * resource-form.js
 * Add/Edit resource listing: screenshot zone (full click, paste, drop), SPA-safe delegation.
 */

(function () {
    const getFileInput = () => document.getElementById('screenshot');
    const getScreenshotNameEl = () => document.getElementById('resource-screenshot-name');
    const getPreviewContainer = () => document.getElementById('preview-container');
    const getPreviewImg = () => document.getElementById('preview-img');

    function updateScreenshotFilename(fileInput) {
        const el = getScreenshotNameEl();
        if (!el || !fileInput) return;
        const empty = el.getAttribute('data-empty-label') || 'No image selected';
        if (fileInput.files && fileInput.files[0]) {
            el.textContent = fileInput.files[0].name;
            el.style.color = 'var(--text-primary)';
        } else {
            el.textContent = empty;
            el.style.color = 'var(--text-secondary)';
        }
    }

    function showPreview(file) {
        const previewContainer = getPreviewContainer();
        const previewImg = getPreviewImg();
        if (!previewContainer || !previewImg || !file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            previewImg.src = e.target.result;
            previewContainer.classList.add('has-image');
        };
        reader.readAsDataURL(file);
    }

    function hideScreenshotThumb() {
        const previewContainer = getPreviewContainer();
        const previewImg = getPreviewImg();
        if (previewContainer) previewContainer.classList.remove('has-image');
        if (previewImg) previewImg.removeAttribute('src');
    }

    function applyScreenshotFile(fileInput, file) {
        if (!file || !file.type || !file.type.startsWith('image/')) {
            if (typeof showToast === 'function') {
                showToast('Please use an image file.', 'error');
            }
            return;
        }
        const name = file.name && file.name !== 'image.png'
            ? file.name
            : `image-${Date.now()}.${file.type === 'image/jpeg' ? 'jpg' : (file.type.split('/')[1] || 'png')}`;
        const wrapped = file instanceof File ? file : new File([file], name, { type: file.type });
        const dt = new DataTransfer();
        dt.items.add(wrapped);
        fileInput.files = dt.files;
        updateScreenshotFilename(fileInput);
        showPreview(wrapped);
    }

    document.addEventListener('change', (e) => {
        if (e.target && e.target.id === 'screenshot') {
            const file = e.target.files[0];
            if (file) showPreview(file);
            else hideScreenshotThumb();
            updateScreenshotFilename(e.target);
        }
    });

    document.addEventListener('click', (e) => {
        const trigger = e.target.closest('[data-ulp-trigger-file-input]');
        if (trigger) {
            e.preventDefault();
            const inputId = trigger.getAttribute('data-ulp-trigger-file-input')
                || trigger.getAttribute('data-input-id')
                || 'screenshot';
            const input = document.getElementById(inputId);
            if (input) input.click();
            return;
        }
        const removeBtn = e.target.closest('#remove-img');
        if (!removeBtn) return;
        e.preventDefault();
        e.stopPropagation();
        const fileInput = getFileInput();
        if (fileInput) {
            const dt = new DataTransfer();
            fileInput.files = dt.files;
        }
        hideScreenshotThumb();
        updateScreenshotFilename(fileInput);
    });

    document.addEventListener('dragenter', (e) => {
        const z = e.target.closest('.resource-screenshot-zone');
        if (!z) return;
        e.preventDefault();
        e.stopPropagation();
        z.classList.add('file-upload-preview-zone--drag');
    });

    document.addEventListener('dragover', (e) => {
        if (!e.target.closest('.resource-screenshot-zone')) return;
        e.preventDefault();
        e.stopPropagation();
    });

    document.addEventListener('dragleave', (e) => {
        const z = e.target.closest('.resource-screenshot-zone');
        if (!z) return;
        const rel = e.relatedTarget;
        if (rel && z.contains(rel)) return;
        e.preventDefault();
        e.stopPropagation();
        z.classList.remove('file-upload-preview-zone--drag');
    });

    document.addEventListener('drop', (e) => {
        const z = e.target.closest('.resource-screenshot-zone');
        if (!z) return;
        e.preventDefault();
        e.stopPropagation();
        z.classList.remove('file-upload-preview-zone--drag');
        const fileInput = getFileInput();
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (fileInput && f) applyScreenshotFile(fileInput, f);
    });

    function runResourceFormInit() {
        if (typeof window.initFormAutosize === 'function') {
            window.initFormAutosize();
        }
        const fi = getFileInput();
        if (fi) updateScreenshotFilename(fi);
    }

    function toggleStaffPanel(panelId, arrowId) {
        var panel = document.getElementById(panelId);
        var arrow = document.getElementById(arrowId);
        if (!panel || !arrow) return;
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
            arrow.classList.remove('fa-chevron-down');
            arrow.classList.add('fa-chevron-up');
        } else {
            panel.style.display = 'none';
            arrow.classList.remove('fa-chevron-up');
            arrow.classList.add('fa-chevron-down');
        }
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-ulp-resource-action="toggle-staff"]');
        if (!btn) return;
        var panelId = btn.getAttribute('data-panel-id');
        var arrowId = btn.getAttribute('data-arrow-id');
        if (panelId && arrowId) toggleStaffPanel(panelId, arrowId);
    });

    document.addEventListener('DOMContentLoaded', runResourceFormInit);
    document.addEventListener('pageLoaded', runResourceFormInit);
})();
