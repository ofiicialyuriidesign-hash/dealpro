/**
 * Files index — VIP cookie, bulk actions, realtime feed.
 */
(function () {
    'use strict';
    function readConfig() {
        var el = document.getElementById('ulp-files-index-page-config');
        if (!el) return {};
        try { return JSON.parse(el.textContent || '{}'); } catch (e) { return {}; }
    }
    var cfg = readConfig();

(function markVipFeedSeenCookie() {
        try {
            if (document.body && document.body.getAttribute('data-is-authenticated') === 'true') return;
            var u = new URL(window.location.href);
            if ((u.searchParams.get('filter') || 'all').toLowerCase() !== 'vip') return;
            var ts = Math.floor(Date.now() / 1000);
            var maxAge = cfg.vipFeedSeenMaxAge || 31536000;
            var secure = window.location.protocol === 'https:' ? ';Secure' : '';
            document.cookie = (cfg.vipFeedSeenCookie || 'ulp_vip_feed_seen') + '=' + ts + ';path=/;max-age=' + maxAge + ';SameSite=Lax' + secure;
        } catch (e) { /* ignore */ }
    })();

    function bumpVipNewBadgeIfNeeded(data) {
        if (!data || !data.is_vip_section) return;
        if (document.body && document.body.getAttribute('data-is-authenticated') === 'true') return;
        var u = new URL(window.location.href);
        if ((u.searchParams.get('filter') || 'all').toLowerCase() === 'vip') return;
        var el = document.getElementById('vip-new-badge');
        if (!el) return;
        var raw = (el.textContent || '').trim();
        var n = 0;
        if (raw === '99+') n = 99;
        else {
            n = parseInt(raw, 10);
            if (!Number.isFinite(n)) n = 0;
        }
        n += 1;
        el.textContent = n > 99 ? '99+' : String(n);
        el.hidden = false;
        el.removeAttribute('aria-hidden');
        el.setAttribute('aria-label', n + ' new VIP file(s) since you last opened this tab');
        el.classList.remove('filter-chip__badge--empty', 'hidden');
    }

    // Bulk Actions JS
    function updateSelectionMain() {
        var checkboxes = document.querySelectorAll('.file-checkbox-main:checked');
        var count = checkboxes.length;

        var countEl = document.getElementById('selection-count-main');
        if (countEl) countEl.textContent = `${count} SELECTED`;

        var approveBtn = document.getElementById('approve-selected-main-btn');
        var deleteBtn = document.getElementById('delete-selected-main-btn');
        var moveVipBtn = document.getElementById('move-vip-to-free-main-btn');

        var bulkBar = document.getElementById('bulk-action-bar');
        if (count > 0) {
            if (approveBtn) { approveBtn.disabled = false; approveBtn.style.opacity = '1'; }
            if (deleteBtn) { deleteBtn.disabled = false; deleteBtn.style.opacity = '1'; }
            if (moveVipBtn) { moveVipBtn.disabled = false; moveVipBtn.style.opacity = '1'; }
            if (bulkBar) bulkBar.classList.add('active');
        } else {
            if (approveBtn) { approveBtn.disabled = true; approveBtn.style.opacity = '0.5'; }
            if (deleteBtn) { deleteBtn.disabled = true; deleteBtn.style.opacity = '0.5'; }
            if (moveVipBtn) { moveVipBtn.disabled = true; moveVipBtn.style.opacity = '0.5'; }
            if (bulkBar) bulkBar.classList.remove('active');
        }

        // Update select all checkbox state
        var allCheckboxes = document.querySelectorAll('.file-checkbox-main');
        var selectAllCheckbox = document.getElementById('select-all-files');
        if (allCheckboxes.length > 0 && selectAllCheckbox) {
            selectAllCheckbox.checked = count === allCheckboxes.length;
        }
    }

    function toggleSelectAllFiles(checkbox) {
        var checkboxes = document.querySelectorAll('.file-checkbox-main');
        checkboxes.forEach(cb => {
            cb.checked = checkbox.checked;
        });
        updateSelectionMain();
    }

    function bulkApproveMain() {
        var checkboxes = document.querySelectorAll('.file-checkbox-main:checked');
        var ids = Array.from(checkboxes).map(function (cb) { return cb.value; });
        if (!ids.length || !window.runBulkModerationForm) return;
        window.runBulkModerationForm({
            endpoint: cfg.bulkApproveUrl,
            fieldName: 'file_ids[]',
            ids: ids,
            confirmMessage: 'Approve ' + ids.length + ' file(s)?',
            entity: 'file',
            verb: 'approve',
            checkboxSelector: '.file-checkbox-main',
            selectAllId: 'select-all-files',
            onSelectionReset: updateSelectionMain,
        });
    }

    function bulkDeleteMain() {
        var checkboxes = document.querySelectorAll('.file-checkbox-main:checked');
        var ids = Array.from(checkboxes).map(function (cb) { return cb.value; });
        if (!ids.length || !window.runBulkModerationForm) return;
        window.runBulkModerationForm({
            endpoint: cfg.bulkDeleteUrl,
            fieldName: 'file_ids[]',
            ids: ids,
            confirmMessage: 'DELETE ' + ids.length + ' file(s)? This action cannot be undone!',
            entity: 'file',
            verb: 'delete',
            checkboxSelector: '.file-checkbox-main',
            selectAllId: 'select-all-files',
            onSelectionReset: updateSelectionMain,
        });
    }

    function bulkVipToFreeMain() {
        var checkboxes = document.querySelectorAll('.file-checkbox-main:checked');
        if (checkboxes.length === 0) return;
        if (!confirm(
            'Move ' + checkboxes.length + ' file(s) from VIP to the public free feed?\n\n' +
            'Views, likes, downloads, and comments will be permanently cleared. URLs stay the same.'
        )) return;

        var formData = new FormData();
        checkboxes.forEach(function (cb) {
            formData.append('file_ids[]', cb.value);
        });
        var csrfMeta = document.querySelector('meta[name="csrf-token"]');
        var csrf = csrfMeta ? csrfMeta.content : '';
        if (csrf) formData.append('csrf_token', csrf);

        fetch(cfg.bulkVipToFreeUrl, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                'X-CSRFToken': csrf,
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        })
            .then(function (r) {
                return r.text().then(function (text) {
                    var data = null;
                    try {
                        data = text ? JSON.parse(text) : {};
                    } catch (e) {
                        throw new Error('Invalid JSON (HTTP ' + r.status + '): ' + (text || '').substring(0, 200));
                    }
                    if (!r.ok) {
                        throw new Error((data && data.message) ? data.message : ('HTTP ' + r.status));
                    }
                    return data;
                });
            })
            .then(function (data) {
                if (data.status === 'success' && data.moved_ids && data.moved_ids.length) {
                    data.moved_ids.forEach(function (id) {
                        document.querySelectorAll('.file-item[data-file-id="' + id + '"]').forEach(function (el) {
                            el.remove();
                        });
                    });
                    document.querySelectorAll('.file-checkbox-main').forEach(function (cb) { cb.checked = false; });
                    var selAll = document.getElementById('select-all-files');
                    if (selAll) selAll.checked = false;
                    updateSelectionMain();
                    if (window.showToast) {
                        window.showToast('VIP to Free', data.message || 'Done', null, 'fas fa-arrow-right', null, 'success');
                    }
                } else if (data.message && window.showToast) {
                    window.showToast('VIP to Free', data.message, null, 'fas fa-exclamation-triangle', null, 'moderation');
                }
            })
            .catch(function (err) {
                console.error(err);
                if (window.showToast) {
                    window.showToast('Error', err.message || 'Request failed.', null, 'fas fa-bug', null, 'moderation');
                }
            });
    }

    window.readFileIds = new Set(cfg.readFileIds || []);

    window.__ulpBindIndexFeedSocketHandlers = function (socket) {
        if (!socket || typeof socket.on !== 'function') return;
        window.__indexSocketHandlers = window.__indexSocketHandlers || {};
        var h = window.__indexSocketHandlers;

        if (h.connect) socket.off('connect', h.connect);
        if (h.fileBumped) socket.off('file_bumped', h.fileBumped);
        if (h.fileStatusUpdate) socket.off('file_status_update', h.fileStatusUpdate);

        h.connect = function () {
            if (socket.connected) socket.emit('join_files_feed');
        };
        if (socket.connected) socket.emit('join_files_feed');

        h.fileBumped = (data) => {
            var fileList = document.querySelector('#ajax-file-list') || document.querySelector('.file-list');
            if (!fileList) return;
            if (window.readFileIds) window.readFileIds.delete(data.id);
            var urlParams = new URLSearchParams(window.location.search);
            if ((urlParams.get('page') || '1') !== '1') return;
            if (urlParams.get('q')) return;

            var activeFilter = urlParams.get('filter') || 'all';
            var filterStaleRow = fileList.querySelector(':scope > .file-item[data-file-id="' + data.id + '"]');
            if (activeFilter === 'free' && data.price > 0) {
                if (filterStaleRow) filterStaleRow.remove();
                return;
            }
            if (activeFilter === 'paid' && (!data.price || data.price <= 0)) {
                if (filterStaleRow) filterStaleRow.remove();
                return;
            }
            if (activeFilter === 'vip' && !data.is_vip_section) {
                if (filterStaleRow) filterStaleRow.remove();
                return;
            }
            if (activeFilter !== 'vip' && data.is_vip_section) {
                if (filterStaleRow) filterStaleRow.remove();
                return;
            }

            var chatWidget = document.getElementById('chat-widget-container');
            var currentUserRole = (chatWidget && chatWidget.getAttribute('data-user-role')) || (document.body && document.body.getAttribute('data-user-role')) || '';
            var myUserId = (chatWidget && chatWidget.getAttribute('data-user-id')) || (document.body && document.body.getAttribute('data-user-id')) || '';
            var myProfileLink = document.querySelector('.nav-btn-profile') || document.querySelector('.profile-link-btn .username');
            var myUsername = myProfileLink ? myProfileLink.textContent.trim() : '';
            var isMe = (data.username === myUsername) || (data.user_id != null && myUserId && String(data.user_id) === String(myUserId));
            var canModerate = ['admin', 'moderator'].includes(currentUserRole);
            var isAdmin = currentUserRole === 'admin';

            if (!data.is_approved && !isMe && !canModerate) return;

            var oldRow = fileList.querySelector(':scope > .file-item[data-file-id="' + data.id + '"]');

            var newBumped = window.feedItemSortTs(data);
            var insertBefore = (typeof window.__ulpFindFeedInsertBefore === 'function')
                ? window.__ulpFindFeedInsertBefore(fileList, newBumped, data.id, 'file')
                : null;

            if (data.engagement_reset) {
                fileList.querySelectorAll(':scope > .file-item[data-file-id="' + data.id + '"]').forEach(function (el) { el.remove(); });
                var divReset = window.renderFileItem(data, {
                    isRead: window.readFileIds ? window.readFileIds.has(data.id) : false,
                    canModerate: canModerate,
                    isAdmin: isAdmin,
                    onCheckboxChange: null
                });
                var ch = Array.from(fileList.children);
                var ins = false;
                for (var ri = 0; ri < ch.length; ri++) {
                    var itemBumped = parseFloat(ch[ri].getAttribute('data-bumped-at'));
                    if (!isNaN(itemBumped) && newBumped > itemBumped) {
                        fileList.insertBefore(divReset, ch[ri]);
                        ins = true;
                        break;
                    }
                }
                if (!ins) fileList.appendChild(divReset);
                return;
            }

            if (oldRow && typeof window.patchFileItemFromBumpData === 'function') {
                window.patchFileItemFromBumpData(oldRow, data, {
                    isRead: window.readFileIds ? window.readFileIds.has(data.id) : false,
                });
                if (insertBefore) {
                    fileList.insertBefore(oldRow, insertBefore);
                } else {
                    fileList.appendChild(oldRow);
                }
                return;
            }

            var div = window.renderFileItem(data, {
                isRead: window.readFileIds ? window.readFileIds.has(data.id) : false,
                canModerate: canModerate,
                isAdmin: isAdmin,
                onCheckboxChange: null
            });

            var children = Array.from(fileList.children);
            var inserted = false;
            for (var i = 0; i < children.length; i++) {
                var itemBumped = parseFloat(children[i].getAttribute('data-bumped-at'));
                if (!isNaN(itemBumped) && newBumped > itemBumped) {
                    fileList.insertBefore(div, children[i]);
                    inserted = true;
                    break;
                }
            }
            if (!inserted) fileList.appendChild(div);
        };

        h.fileStatusUpdate = function (data) {
            // Row insert: listings.js global bind (new_file_notification). Here: status-only UI patches.
            if (data.status === 'approved' || data.status === 'published') {
                var fileItems = document.querySelectorAll('[data-file-id="' + data.id + '"]');
                fileItems.forEach(function (item) {
                    var publishIcon = item.querySelector('.file-publish-status-icon');
                    if (publishIcon) publishIcon.classList.add('hidden');
                    var actionsContainer = item.querySelector('.file-actions-container');
                    if (actionsContainer) {
                        actionsContainer.querySelectorAll('form').forEach(function (f) { f.remove(); });
                    }
                });
            }
        };

        socket.on('connect', h.connect);
        socket.on('file_bumped', h.fileBumped);
        socket.on('file_status_update', h.fileStatusUpdate);
    };

    (function bindIndexFeedWhenSocketReady() {
        var tries = 0;
        function attempt() {
            var s = window.getSharedSocket ? window.getSharedSocket() : null;
            if (s) {
                window.__ulpBindIndexFeedSocketHandlers(s);
                return;
            }
            if (++tries < 80) setTimeout(attempt, 100);
        }
        attempt();
    })();

    // Scheduled publishes and feed changes are pushed via socket; long-idle resync uses fragment refresh in realtime.js.
    (function startFilesFeedSoftResync() {
        if (window.__ulpFilesFeedSoftResyncStarted) return;
        window.__ulpFilesFeedSoftResyncStarted = true;
        var inFlight = false;
        function isFilesRoot() {
            var p = (window.location && window.location.pathname) || '/';
            p = p.replace(/\/+$/, '') || '/';
            return p === '/';
        }
        function softResync() {
            if (inFlight) return;
            if (document.hidden) return;
            if (!isFilesRoot()) return;
            inFlight = true;
            var done = function () { inFlight = false; };
            if (typeof window.__ulpRefreshFeedFragment === 'function') {
                Promise.resolve(
                    window.__ulpRefreshFeedFragment(window.location.pathname + window.location.search)
                ).finally(done);
                return;
            }
            if (typeof window.loadPage !== 'function') {
                done();
                return;
            }
            Promise.resolve(
                window.loadPage(window.location.pathname + window.location.search, false, {
                    showLoader: false,
                    preserveScroll: true,
                })
            ).finally(done);
        }
        window.__ulpFilesFeedSoftResync = softResync;
    })();

    window.updateSelectionMain = updateSelectionMain;
    window.toggleSelectAllFiles = toggleSelectAllFiles;
    window.bulkApproveMain = bulkApproveMain;
    window.bulkDeleteMain = bulkDeleteMain;
    window.bulkVipToFreeMain = bulkVipToFreeMain;

    // Initialize UI (Runs every time page is loaded via SPA)
    updateSelectionMain();
})();
