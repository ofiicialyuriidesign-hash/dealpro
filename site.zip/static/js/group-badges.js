/**
 * Shared HTML/DOM helpers for user group badges (solid colors + custom CSS / gradients).
 * Loaded after listings.js so normalizeGroupIconClass is available when present.
 */
(function () {
    function escAttr(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;');
    }

    function escHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function normIcon(iconRaw) {
        if (typeof window.normalizeGroupIconClass === 'function') {
            return window.normalizeGroupIconClass(iconRaw);
        }
        var raw = (iconRaw || 'fas fa-star') + '';
        var m = raw.match(/fa-(?!solid\b|regular\b|brands\b)[a-z0-9-]+/i);
        var token = m ? m[0] : 'fa-star';
        var t = token.toLowerCase();
        if (t === 'fa-shield-alt' || t === 'fa-shield-halved') token = 'fa-shield';
        return 'fa-solid ' + token;
    }

    window.formatGroupBadgePileHtml = function (groups, opts) {
        opts = opts || {};
        var badgeHref = opts.badgeHref ? String(opts.badgeHref) : '';
        if (!groups || !groups.length) return '';
        var list = groups.length > 3 ? groups.slice(0, 3) : groups;
        var parts = [];
        for (var i = 0; i < list.length; i++) {
            var g = list[i];
            var name = escAttr(g.name || '');
            var icon = escAttr(normIcon(g.icon));
            var linkAttrs = '';
            if (badgeHref) {
                linkAttrs =
                    ' class="group-badge-link-target" data-badge-href="' +
                    escAttr(badgeHref) +
                    '"';
            }
            if (g.badge_shell_style) {
                var icInner = g.badge_icon_style
                    ? ' style="' + escAttr(g.badge_icon_style) + '"'
                    : ' style="color:' + escAttr(g.icon_color || '#f5f8ff') + '"';
                var admB = !!(g.admin_border === true || g.admin_border === 1);
                parts.push(
                    '<span class="group-badge' +
                        (admB ? ' group-badge--admin-border' : '') +
                        '"' +
                        linkAttrs +
                        ' title="' +
                        name +
                        '" style="' +
                        escAttr(g.badge_shell_style) +
                        '"><i class="' +
                        icon +
                        '"' +
                        icInner +
                        '></i></span>'
                );
            } else {
                var c = escAttr(g.color || '#00ff9d');
                var icol = escAttr(g.icon_color || '#f5f8ff');
                var icOnly = g.badge_icon_style
                    ? ' style="' + escAttr(g.badge_icon_style) + '"'
                    : '';
                var admB2 = !!(g.admin_border === true || g.admin_border === 1);
                parts.push(
                    '<span class="group-badge' +
                        (admB2 ? ' group-badge--admin-border' : '') +
                        '"' +
                        linkAttrs +
                        ' title="' +
                        name +
                        '" style="--badge-bg: ' +
                        c +
                        '; --badge-icon-color: ' +
                        icol +
                        '; background-color: var(--badge-bg);"><i class="' +
                        icon +
                        '"' +
                        icOnly +
                        '></i></span>'
                );
            }
        }
        return '<span class="group-badge-pile" aria-hidden="true">' + parts.join('') + '</span>';
    };

    /** One inline badge (same shape as feed piles) — e.g. alerts dropdown + socket rows. */
    window.formatSingleGroupBadgeHtml = function (g) {
        if (!g) return '';
        var name = escAttr(g.name || '');
        var icon = escAttr(normIcon(g.icon));
        if (g.badge_shell_style) {
            var icInner2 = g.badge_icon_style
                ? ' style="' + escAttr(g.badge_icon_style) + '"'
                : ' style="color:' + escAttr(g.icon_color || '#f5f8ff') + '"';
            var admS = !!(g.admin_border === true || g.admin_border === 1);
            return (
                '<span class="group-badge notification-list-group-badge' +
                (admS ? ' group-badge--admin-border' : '') +
                '" title="' +
                name +
                '" style="' +
                escAttr(g.badge_shell_style) +
                '"><i class="' +
                icon +
                '"' +
                icInner2 +
                '></i></span>'
            );
        }
        var c2 = escAttr(g.color || '#00ff9d');
        var icol2 = escAttr(g.icon_color || '#f5f8ff');
        var icOnly2 = g.badge_icon_style ? ' style="' + escAttr(g.badge_icon_style) + '"' : '';
        var admS2 = !!(g.admin_border === true || g.admin_border === 1);
        return (
            '<span class="group-badge notification-list-group-badge' +
            (admS2 ? ' group-badge--admin-border' : '') +
            '" title="' +
            name +
            '" style="--badge-bg: ' +
            c2 +
            '; --badge-icon-color: ' +
            icol2 +
            '; background-color: var(--badge-bg);"><i class="' +
            icon +
            '"' +
            icOnly2 +
            '></i></span>'
        );
    };

    /** Admin Users tab: labeled chip with achievement shell styles + remove control. */
    window.formatAdminUserGroupChipHtml = function (g, userId) {
        if (!g) return '';
        var gid = String(g.id != null ? g.id : '');
        var uid = String(userId == null ? '' : userId);
        var name = escHtml(g.name || '');
        var icon = escAttr(normIcon(g.icon));
        var admB = !!(g.admin_border === true || g.admin_border === 1);
        var shellClass =
            'adm-user-group-chip group-badge--vars' +
            (g.badge_shell_style ? ' group-badge--shell' : '') +
            (admB ? ' group-badge--admin-border' : '');
        var shellStyle = '';
        var iconHtml;
        if (g.badge_shell_style) {
            shellStyle = ' style="' + escAttr(g.badge_shell_style) + '"';
            iconHtml = g.badge_icon_style
                ? '<i class="' + icon + '" style="' + escAttr(g.badge_icon_style) + '"></i>'
                : '<i class="' + icon + '" style="color:' + escAttr(g.icon_color || '#f5f8ff') + '"></i>';
        } else {
            var c = escAttr(g.color || '#00ff9d');
            var icol = escAttr(g.icon_color || '#f5f8ff');
            shellStyle =
                ' style="--badge-bg: ' +
                c +
                '; --badge-icon-color: ' +
                icol +
                '; background-color: var(--badge-bg);"';
            iconHtml = g.badge_icon_style
                ? '<i class="' + icon + '" style="' + escAttr(g.badge_icon_style) + '"></i>'
                : '<i class="' + icon + '"></i>';
        }
        return (
            '<span class="' +
            shellClass +
            '"' +
            shellStyle +
            ' title="' +
            escAttr(g.name || '') +
            '">' +
            iconHtml +
            '<span class="adm-user-group-chip__label">' +
            name +
            '</span>' +
            '<i class="fas fa-times adm-group-chip__x" data-user-id="' +
            escAttr(uid) +
            '" data-group-id="' +
            escAttr(gid) +
            '" data-adm-action="unassign-group" title="Remove achievement" role="button" tabindex="0"></i>' +
            '</span>'
        );
    };

    /** Username chip matching utils.html_username_tag_chip / forum_user_tag (avatar slot + pile). */
    window.formatUsernameTagChipHtml = function (opts) {
        opts = opts || {};
        var username = String(opts.username == null ? '' : opts.username);
        if (!username) username = 'Guest';
        var role = String(opts.role || 'user').trim() || 'user';
        var avatarUrl =
            opts.avatarUrl ||
            window.ulpResolveAvatarUrl({
                username: username,
                avatar: opts.avatar,
                avatar_color: opts.avatar_color || opts.avatarColor,
            });
        var linked = opts.linked !== false;
        var tag = linked ? 'a' : 'span';
        var href = linked ? ' href="/user/' + encodeURIComponent(username) + '"' : '';
        var extraClass = String(opts.extraClass || 'forum-user-tag').trim();
        var groupsHtml = '';
        if (opts.showGroups !== false && opts.groups && opts.groups.length) {
            var badgeHref =
                '/user/' + encodeURIComponent(username) + '?tab=achievements';
            groupsHtml =
                typeof window.formatGroupBadgePileHtml === 'function'
                    ? window.formatGroupBadgePileHtml(opts.groups, { badgeHref: badgeHref })
                    : '';
        }
        var verifiedHtml = opts.verified
            ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>'
            : '';
        var style = 'display: inline-flex; align-items: center; text-decoration: none';
        return (
            '<' +
            tag +
            href +
            ' class="username-tag ' +
            escAttr(role) +
            (extraClass ? ' ' + escAttr(extraClass) : '') +
            '" style="' +
            style +
            '"><span class="user-avatar-slot"><img src="' +
            escAttr(avatarUrl) +
            '" class="user-avatar-circle" alt=""></span>' +
            escHtml(username) +
            verifiedHtml +
            groupsHtml +
            '</' +
            tag +
            '>'
        );
    };

    window.appendGroupBadgePile = function (userWrap, groups) {
        if (!userWrap) return;
        userWrap.querySelectorAll('.group-badge-pile').forEach(function (n) {
            n.remove();
        });
        userWrap.querySelectorAll(':scope > .group-badge').forEach(function (n) {
            n.remove();
        });
        if (!groups || !groups.length) return;
        var badgeHref = '';
        var chipHref = (userWrap.getAttribute && userWrap.getAttribute('href')) || '';
        if (chipHref) {
            try {
                var badgeUrl = new URL(chipHref, window.location.origin);
                badgeUrl.searchParams.set('tab', 'achievements');
                badgeHref = badgeUrl.pathname + badgeUrl.search + badgeUrl.hash;
            } catch (err) {
                badgeHref = chipHref;
            }
        } else if (userWrap.closest && userWrap.closest('.profile-identity-name-row .username-tag')) {
            try {
                var profileUrl = new URL(window.location.pathname, window.location.origin);
                profileUrl.searchParams.set('tab', 'achievements');
                badgeHref = profileUrl.pathname + profileUrl.search + profileUrl.hash;
            } catch (err2) {
                badgeHref = window.location.pathname + '?tab=achievements';
            }
        }
        var html = window.formatGroupBadgePileHtml(
            groups,
            badgeHref ? { badgeHref: badgeHref } : undefined
        );
        if (!html) return;
        var tpl = document.createElement('template');
        tpl.innerHTML = html.trim();
        userWrap.appendChild(tpl.content.firstChild);
    };
})();
