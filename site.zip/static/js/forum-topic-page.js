/**
 * Forum topic page — realtime, typing, bulk moderation, mod toolbar.
 */
(function () {
    'use strict';

    function readConfig() {
        var el = document.getElementById('ulp-forum-topic-page-config');
        if (!el) return {};
        try {
            return JSON.parse(el.textContent || '{}');
        } catch (e) {
            return {};
        }
    }

    var cfg = readConfig();

        var socket = window.getSharedSocket ? window.getSharedSocket() : null;
        var topicId = String(cfg.topicId || '');
        var currentUserId = String(cfg.currentUserId || '');
        var currentUserRole = String(cfg.currentUserRole || '');
        var isAdmin = (currentUserRole === 'admin');
        var topicSlug = String(cfg.topicSlug || '');
        var compactCount = window.formatCompactCount || function (value) {
            var n = Number(value || 0);
            if (!Number.isFinite(n)) return '0';
            var sign = n < 0 ? '-' : '';
            n = Math.abs(Math.trunc(n));
            if (n < 1000) return sign + String(n);
            var units = [{ d: 1000000000, s: 'b' }, { d: 1000000, s: 'm' }, { d: 1000, s: 'k' }];
            for (var i = 0; i < units.length; i += 1) {
                if (n >= units[i].d) {
                    var v = n / units[i].d;
                    var txt = (v >= 100 ? v.toFixed(0) : v.toFixed(1)).replace(/\.0$/, '');
                    return sign + txt + units[i].s;
                }
            }
            return sign + String(n);
        };

        window.setForumReply = function (username) {
            if (window.__forumReplyQuill && window.insertAtRichCursor) {
                window.insertAtRichCursor(window.__forumReplyQuill, '@' + username + ', ');
                return;
            }
        };

        window.jumpToForumReplyEditor = function (event) {
            if (event && event.preventDefault) event.preventDefault();
            if (typeof window.__ulpScrollDiscussionComposerForKeyboard === 'function') {
                window.__ulpScrollDiscussionComposerForKeyboard();
            } else {
                var replyArea = document.querySelector('.forum-reply-area');
                if (replyArea) replyArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
            setTimeout(function () {
                try {
                    var qJump = window.__forumReplyQuill;
                    if (qJump && typeof qJump.focus === 'function') {
                        qJump.focus();
                        if (qJump.getLength() <= 1 && typeof window.placeQuillCaretAtFirstContentPosition === 'function') {
                            setTimeout(function () {
                                window.placeQuillCaretAtFirstContentPosition(qJump);
                            }, 0);
                        }
                        return;
                    }
                    var editor = document.querySelector('#forum-reply-editor .ql-editor');
                    if (editor && typeof editor.focus === 'function') editor.focus();
                } catch (_) {}
            }, 260);
        };

        /* forum post likes: HTTP API + server Socket.IO fan-out (see toggleForumPostLike in realtime.js). */

        function forumTopicDeleteRedirectUrl() {
            var root = document.getElementById('forum-topic-root');
            var u = root && root.getAttribute('data-after-topic-delete-url');
            return (u && String(u).trim()) || '/discussions';
        }

        window.deleteForumPost = async function (id) {
            var chatWidget = document.getElementById('chat-widget-container');
            var role = (chatWidget && chatWidget.getAttribute('data-user-role')) || (document.body && document.body.getAttribute('data-user-role')) || '';
            var isStaff = role === 'admin' || role === 'moderator';
            var payload = { post_id: id };
            if (isStaff) {
                if (!window.promptDeletionReason) return;
                var reason = await window.promptDeletionReason({
                    title: 'Delete forum post',
                    confirmLabel: 'Delete post',
                });
                if (reason === null) return;
                if (reason) payload.deletion_reason = reason;
            } else if (!confirm('Delete this post?')) {
                return;
            }
            var row = document.getElementById('forum-post-' + id);
            var isOpeningPost = !!(row && row.classList.contains('forum-post-op'));
            var dest = forumTopicDeleteRedirectUrl();
            if (socket) socket.emit('delete_forum_post', payload);
            if (!isOpeningPost && row && typeof window.ulpRemoveForumPostFromDom === 'function') {
                window.ulpRemoveForumPostFromDom(id);
            }
            if (isOpeningPost) {
                setTimeout(function () {
                    if (window.location.pathname.indexOf('/discussions/t/') === 0) {
                        if (window.loadPage) {
                            window.loadPage(dest, true, { showLoader: false });
                        } else {
                            window.location.replace(dest);
                        }
                    }
                }, 400);
                setTimeout(function () {
                    if (window.location.pathname.indexOf('/discussions/t/') === 0) {
                        if (window.loadPage) {
                            window.loadPage(dest, true, { showLoader: false });
                        } else {
                            window.location.replace(dest);
                        }
                    }
                }, 1600);
            }
        };

        var editBarEl = document.getElementById('forum-inline-edit-bar');
        var editCancelBtnEl = document.getElementById('forum-inline-edit-cancel-btn');
        var sendBtnEl = document.getElementById('forum-reply-send-btn');
        var editPostId = null;
        var editOriginalPlain = '';
        var editOriginalHtml = '';
        var forumTypingTimeout = null;
        var forumIsTyping = false;
        var forumSendOriginalHtml = sendBtnEl ? sendBtnEl.innerHTML : '';
        var forumSendOriginalAria = sendBtnEl ? (sendBtnEl.getAttribute('aria-label') || 'Send') : 'Send';
        function setForumSendPending(text) {
            if (!sendBtnEl) return;
            sendBtnEl.disabled = true;
            sendBtnEl.classList.add('is-loading');
            sendBtnEl.innerHTML = '<span class="ulp-composer-send-spinner" aria-hidden="true"></span>';
            sendBtnEl.setAttribute('aria-label', String(text || 'Uploading...'));
        }
        function resetForumSendPending() {
            if (!sendBtnEl) return;
            sendBtnEl.disabled = false;
            sendBtnEl.classList.remove('is-loading');
            if (forumSendOriginalAria) sendBtnEl.setAttribute('aria-label', forumSendOriginalAria);
            sendBtnEl.innerHTML = forumSendOriginalHtml || '<i class="fas fa-paper-plane"></i>';
        }
        function getReplyQuill() { return window.__forumReplyQuill || null; }
        function forumTypingPayload() { return { topic_id: topicId }; }
        function stopForumTyping() {
            if (!socket) return;
            if (forumIsTyping) {
                socket.emit('typing_end', forumTypingPayload());
                forumIsTyping = false;
            }
            if (forumTypingTimeout) clearTimeout(forumTypingTimeout);
            forumTypingTimeout = null;
        }
        function bindForumTypingEmitter() {
            var q = getReplyQuill();
            if (!q || q.__ulpTypingBound) return false;
            q.__ulpTypingBound = true;
            q.on('text-change', function (_delta, _oldDelta, source) {
                if (source !== 'user') return;
                var hasText = !!(q.getText() || '').replace(/\uFEFF/g, '').trim();
                if (!hasText) {
                    stopForumTyping();
                    return;
                }
                if (!forumIsTyping) {
                    socket.emit('typing_start', forumTypingPayload());
                    forumIsTyping = true;
                }
                if (forumTypingTimeout) clearTimeout(forumTypingTimeout);
                forumTypingTimeout = setTimeout(stopForumTyping, 2000);
            });
            q.on('selection-change', function (range) {
                if (!range) stopForumTyping();
            });
            return true;
        }
        function bindForumTypingDomFallback() {
            var editorEl = document.querySelector('#forum-reply-editor .ql-editor');
            if (!editorEl || editorEl.__ulpTypingBound) return false;
            editorEl.__ulpTypingBound = true;
            editorEl.addEventListener('input', function () {
                if (!socket || !currentUserId) return;
                var hasText = !!(editorEl.textContent || '').replace(/\uFEFF/g, '').trim();
                if (!hasText) {
                    stopForumTyping();
                    return;
                }
                if (!forumIsTyping) {
                    socket.emit('typing_start', forumTypingPayload());
                    forumIsTyping = true;
                }
                if (forumTypingTimeout) clearTimeout(forumTypingTimeout);
                forumTypingTimeout = setTimeout(stopForumTyping, 2000);
            });
            editorEl.addEventListener('blur', stopForumTyping);
            return true;
        }

        function normalizeEditorHtml(html) {
            return String(html || '')
                .replace(/\uFEFF/g, '')
                .replace(/\s+/g, ' ')
                .replace(/<p><br><\/p>/gi, '')
                .trim();
        }

        function sanitizeEditorSeedHtml(html) {
            var wrap = document.createElement('div');
            wrap.innerHTML = String(html || '');

            function unwrap(el) {
                if (!el || !el.parentNode) return;
                while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el);
                el.parentNode.removeChild(el);
            }

            wrap.querySelectorAll('*').forEach(function (el) {
                el.removeAttribute('style');
                el.removeAttribute('color');
                el.removeAttribute('face');
                el.removeAttribute('size');

                var tag = (el.tagName || '').toLowerCase();
                if (tag === 'font' || tag === 'small' || tag === 'big') {
                    unwrap(el);
                    return;
                }

                var keep = [];
                (el.className || '').split(/\s+/).forEach(function (c) {
                    if (!c) return;
                    if (c === 'mention' || c === 'mention-link' || c === 'external-link') keep.push(c);
                    if (c.indexOf('ql-') === 0) keep.push(c);
                });
                if (keep.length) el.className = keep.join(' ');
                else el.removeAttribute('class');
            });

            return (wrap.innerHTML || '').normalize('NFKC');
        }

        function openForumEditModal(postId, initialHtml, initialPlain) {
            var q = getReplyQuill();
            if (!q) return;
            var seedHtml = sanitizeEditorSeedHtml(initialHtml || '');
            editPostId = postId;
            editOriginalPlain = (initialPlain || '').trim();
            editOriginalHtml = normalizeEditorHtml(seedHtml);
            q.setContents([{ insert: '\n' }], 'silent');
            if (seedHtml) q.clipboard.dangerouslyPasteHTML(0, seedHtml, 'silent');
            if (editBarEl) editBarEl.style.display = 'flex';
            if (editCancelBtnEl) {
                editCancelBtnEl.style.display = 'flex';
                var fac = editCancelBtnEl.closest('.discussion-composer-action-cluster');
                if (fac) fac.classList.add('discussion-composer-action-cluster--with-cancel');
            }
            if (sendBtnEl) {
                sendBtnEl.innerHTML = '<i class="fas fa-save"></i>';
                sendBtnEl.setAttribute('aria-label', 'Save edit');
            }
            var replyArea = document.querySelector('.forum-reply-area');
            if (typeof window.__ulpScrollDiscussionComposerForKeyboard === 'function') {
                window.__ulpScrollDiscussionComposerForKeyboard();
            } else if (replyArea) {
                replyArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            setTimeout(function () {
                q.focus();
                if (typeof window.placeQuillCaretAtDocumentEnd === 'function') {
                    window.placeQuillCaretAtDocumentEnd(q);
                }
            }, 30);
        }

        window.closeForumEditModal = function () {
            editPostId = null;
            editOriginalPlain = '';
            editOriginalHtml = '';
            if (editBarEl) editBarEl.style.display = 'none';
            if (editCancelBtnEl) {
                editCancelBtnEl.style.display = 'none';
                var fac = editCancelBtnEl.closest('.discussion-composer-action-cluster');
                if (fac) fac.classList.remove('discussion-composer-action-cluster--with-cancel');
            }
            if (sendBtnEl) {
                sendBtnEl.innerHTML = '<i class="fas fa-paper-plane"></i>';
                sendBtnEl.setAttribute('aria-label', 'Send');
            }
        };

        window.submitForumPostEdit = function () {
            var q = getReplyQuill();
            if (!socket || !editPostId || !q) return;
            var vEdit = typeof window.validateRichMessageQuill === 'function'
                ? window.validateRichMessageQuill(q)
                : { ok: !!(q.getText() || '').replace(/\uFEFF/g, '').trim() };
            if (!vEdit.ok) {
                if (typeof window.notifyRichMessageValidation === 'function') {
                    window.notifyRichMessageValidation(vEdit);
                }
                return;
            }
            var plain = (q.getText() || '').replace(/\uFEFF/g, '').trim();
            var html = (q.root && q.root.innerHTML) ? q.root.innerHTML : '';
            var normalizedHtml = normalizeEditorHtml(html);
            var isSamePlain = plain === editOriginalPlain;
            var isSameHtml = normalizedHtml === editOriginalHtml;
            if (isSamePlain && isSameHtml) {
                window.closeForumEditModal();
                return;
            }
            var resolveHtml = window.resolveQuillHtmlForSubmit;
            var p = (typeof resolveHtml === 'function')
                ? resolveHtml(q)
                : Promise.resolve(html);
            p.then(function (readyHtml) {
                socket.emit('edit_forum_post', { post_id: editPostId, content: readyHtml });
                window.closeForumEditModal();
                if (window.clearQuillEditor) window.clearQuillEditor(q);
            }).catch(function (err) {
                if (window.showToast) {
                    var details = (typeof window.describeInlineImageUploadError === 'function')
                        ? window.describeInlineImageUploadError(err)
                        : { title: 'Upload failed', message: 'Could not upload one or more images.' };
                    window.showToast(details.title, details.message, null, 'fas fa-image', null, 'error');
                }
            });
        };

        window.cancelForumInlineEdit = function () {
            var q = getReplyQuill();
            window.closeForumEditModal();
            if (q && window.clearQuillEditor) window.clearQuillEditor(q);
        };
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && editPostId) {
                window.cancelForumInlineEdit();
            }
        });

        window.editForumPost = function (id) {
            var row = document.getElementById('forum-post-' + id);
            if (!row) return;
            var bodyEl = row.querySelector('.forum-post-body');
            var currentHtml = bodyEl ? (bodyEl.innerHTML || '') : '';
            var currentText = bodyEl ? (bodyEl.innerText || '').trim() : '';
            openForumEditModal(id, currentHtml, currentText);
        };

        window.appendForumPostToDOM = function (data) {
            var list = document.getElementById('forum-posts-list');
            if (!list) return;
            var elId = 'forum-post-' + data.id;
            if (document.getElementById(elId)) return;

            var div = document.createElement('div');
            div.className = 'forum-post-item forum-post-card comment-item' + (isAdmin ? ' has-bulk-checkbox' : '');
            div.id = elId;
            div.setAttribute('data-post-id', data.id);
            div.setAttribute('data-author-id', data.user_id);
            div.style.animation = 'fadeIn 0.3s ease';

            var avatarUrl = window.ulpResolveAvatarUrl(data);
            var roleIcon = '<span class="user-avatar-slot"><img src="' + avatarUrl + '" class="user-avatar-circle" alt=""></span>';
            var canDelete = isAdmin || (String(data.user_id) === String(currentUserId));
            var canEdit = canDelete;
            var editBtn = canEdit ? '<button type="button" class="action-btn edit-btn" title="Edit post" data-ulp-forum-action="edit" data-post-id="' + data.id + '"><i class="fas fa-pen" style="font-size: 0.75rem;"></i></button>' : '';
            var deleteBtn = canDelete ? '<button type="button" class="action-btn delete-btn" title="Delete post" data-ulp-forum-action="delete" data-post-id="' + data.id + '"><i class="fas fa-trash" style="font-size: 0.8rem;"></i></button>' : '';
            var replyBtn = currentUserRole ? '<button type="button" class="action-btn reply-btn" data-ulp-forum-action="reply" data-reply-user="' + String(data.username || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;') + '" title="Reply"><i class="fas fa-reply" style="font-size: 0.8rem;"></i></button>' : '';
            var verifiedHtml = data.is_verified ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>' : '';
            var topicAuthorBadge = data.is_topic_author
                ? '<span class="forum-topic-author-badge telemetry-pod" title="Topic author"><i class="fas fa-user"></i></span>'
                : '';
            var pendingBadge = (data.is_approved === false) ? '<span class="adm-badge adm-badge-yellow" style="font-size: 0.6rem; padding: 1px 4px;">PENDING</span>' : '';
            var likedByMe = !!data.user_liked;
            var likesCount = Number(data.likes_count || 0);
            var faceHeart = currentUserRole
                ? '<button type="button" class="ulp-like-likers__heart-hit telemetry-pod like-btn-container forum-post-like-toggle ' + (likesCount > 0 ? 'has-likes ' : '') + (likedByMe ? 'is-liked ' : '') + '" data-post-id="' + data.id + '" data-ulp-forum-action="like" title="Like"><span class="ulp-like-likers__heart-slot"><i class="like-btn ' + (likedByMe ? 'fas' : 'far') + ' fa-heart" aria-hidden="true"></i></span></button>'
                : '<button type="button" class="ulp-like-likers__heart-hit telemetry-pod like-btn-container forum-post-like-toggle" data-ulp-forum-action="like-login" title="Login to like"><span class="ulp-like-likers__heart-slot"><i class="like-btn far fa-heart" aria-hidden="true"></i></span></button>';
            var faceStrip =
                '<div class="forum-post-like-likers-row"><div class="ulp-like-likers ulp-like-likers--facepile-only ulp-like-likers--with-heart-hit" data-likers-strip data-likers-kind="forum_post" data-interactive-heart="1" data-viewer-liked="' +
                (likedByMe ? '1' : '0') +
                '" data-post-id="' +
                String(data.id) +
                '" data-likers-total="' +
                String(likesCount) +
                '">' +
                faceHeart +
                '</div></div>';
            var groupsHtml = '';
            if (data.groups && data.groups.length > 0) {
                groupsHtml = (typeof window.formatGroupBadgePileHtml === 'function')
                    ? window.formatGroupBadgePileHtml(data.groups)
                    : (function () {
                        var s = '';
                        data.groups.forEach(function (g) {
                            var iconCls = (typeof window.normalizeFaIconClass === 'function')
                                ? window.normalizeFaIconClass(g.icon || 'fas fa-star')
                                : (g.icon || 'fas fa-star');
                            var iconColor = g.icon_color || '#f5f8ff';
                            s += '<span class="group-badge" title="' + (g.name || '') + '" style="--badge-bg: ' + (g.color || '#333') + '; --badge-icon-color: ' + iconColor + '; background-color: var(--badge-bg);"><i class="' + iconCls + '"></i></span>';
                        });
                        return '<span class="group-badge-pile" aria-hidden="true">' + s + '</span>';
                    })();
            }
            var stats = data.author_stats || {};
            var forumStatsHtml = '<div class="forum-author-stats telemetry-group" aria-label="Author stats">' +
                topicAuthorBadge +
                '<span class="telemetry-pod" data-forum-author-stat="comments" title="Comments"><i class="fas fa-comments"></i> <span class="forum-author-stat-value">' + compactCount(stats.comments_total || ((stats.posts_count || 0) + (stats.site_comments_count || 0))) + '</span></span>' +
                '<span class="telemetry-pod" data-forum-author-stat="topics" title="Topics created"><i class="fas fa-list"></i> <span class="forum-author-stat-value">' + compactCount(stats.topics_count || 0) + '</span></span>' +
                '<span class="telemetry-pod" data-forum-author-stat="likes" title="Likes received"><i class="fas fa-heart"></i> <span class="forum-author-stat-value">' + compactCount(stats.likes_received || 0) + '</span></span>' +
                '</div>';
            var bodyHtml = data.content_html || (window.parseLinks ? window.parseLinks(data.content) : escapeHtml(data.content));
            if (typeof window.ulpSanitizeRichHtml === 'function') {
                bodyHtml = window.ulpSanitizeRichHtml(bodyHtml);
            }

            var bulkCheckbox = isAdmin
                ? '<div class="list-bulk-checkbox-cell"><label><input type="checkbox" id="forum-post-sel-' + data.id + '" name="forum_post_ids[]" class="cyber-checkbox forum-post-checkbox" value="' + data.id + '" aria-label="Select post for bulk delete"></label></div>'
                : '';

            div.innerHTML = bulkCheckbox + '<div class="comment-actions forum-post-actions">' +
                pendingBadge + editBtn + deleteBtn + replyBtn +
                '<span class="telemetry-pod" title="' + (data.created_at_precise || '') + '"' + (data.created_at_ts ? ' data-ulp-time-ts="' + data.created_at_ts + '"' : '') + '><i class="far fa-clock"></i> ' + (data.created_at || data.timestamp || '') + '</span></div>' +
                '<div class="forum-post-main"><div class="forum-post-header"><a href="/user/' + encodeURIComponent(data.username) + '" class="username-tag ' + (data.role || '') + ' forum-user-tag" style="display: inline-flex; align-items: center; text-decoration: none;">' +
                roleIcon + data.username + verifiedHtml + groupsHtml + '</a>' + forumStatsHtml + '</div>' +
                '<div class="forum-post-body rich-body">' + bodyHtml + '</div>' +
                faceStrip + '</div>';

            list.appendChild(div);
            list.scrollTop = list.scrollHeight;
            try {
                var qDraft = window.__forumReplyQuill;
                var hasDraft = qDraft && typeof qDraft.getText === 'function'
                    && qDraft.getText().replace(/\uFEFF/g, '').trim().length > 0;
                var replyArea = document.querySelector('.forum-reply-area');
                if (hasDraft && replyArea && typeof replyArea.scrollIntoView === 'function') {
                    replyArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                } else if (typeof div.scrollIntoView === 'function') {
                    div.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            } catch (_) {}
            if (isAdmin && typeof window.updateForumPostSelection === 'function') {
                window.updateForumPostSelection();
            }
        };

        function escapeHtml(s) {
            if (!s) return '';
            var d = document.createElement('div');
            d.textContent = s;
            return d.innerHTML;
        }

        window.sendForumReply = function () {
            var q = getReplyQuill();
            if (!q || !socket) return;
            if (!currentUserId) {
                if (window.requireLogin) {
                    window.requireLogin('Please login or register to reply in discussions.', window.location.pathname + window.location.search);
                }
                return;
            }
            var vSend = typeof window.validateRichMessageQuill === 'function'
                ? window.validateRichMessageQuill(q)
                : { ok: !!q.getText().replace(/\uFEFF/g, '').trim() };
            if (!vSend.ok) {
                if (typeof window.notifyRichMessageValidation === 'function') {
                    window.notifyRichMessageValidation(vSend);
                }
                return;
            }
            var plain = q.getText().replace(/\uFEFF/g, '').trim();
            if (editPostId) {
                window.submitForumPostEdit();
                return;
            }
            var resolveHtml = window.resolveQuillHtmlForSubmit;
            var p = (typeof resolveHtml === 'function')
                ? resolveHtml(q, null, {
                    onProgress: function (st) {
                        if (!st) return;
                        if (st.phase === 'uploading') {
                            var total = Number(st.total || 0);
                            if (total > 0) {
                                setForumSendPending('Uploading ' + Number(st.done || 0) + '/' + total + ' (' + Number(st.percent || 0) + '%)');
                            } else {
                                setForumSendPending('Uploading...');
                            }
                        }
                    }
                })
                : Promise.resolve(q.root.innerHTML);
            p.then(function (html) {
                setForumSendPending('Sending...');
                var doEmit = function (sock) {
                    sock.emit('forum_post', { topic_id: topicId, content: html }, function (resp) {
                        if (!resp || resp.ok !== true) {
                            resetForumSendPending();
                            // Cooldown: server already emits `show_toast` — avoid duplicate client toasts.
                            return;
                        }
                        stopForumTyping();
                        if (window.clearQuillEditor) window.clearQuillEditor(q);
                        var postData = resp.post || null;
                        // Apply author + header stats *before* appending the new row so every existing card matches
                        // the same payload (avoids 69/70 split when the new DOM node is built first).
                        if (postData) {
                            if (postData.user_id != null && postData.author_stats && typeof window.ulpApplyForumAuthorStatsForUser === 'function') {
                                window.ulpApplyForumAuthorStatsForUser(postData.user_id, postData.author_stats);
                            }
                            if (typeof window.ulpPatchForumTopicPageStatsStrip === 'function') {
                                var tid = (postData && postData.topic_id != null) ? postData.topic_id : (resp && resp.topic_id != null ? resp.topic_id : null);
                                if (tid != null) {
                                    var hdrPatch = {};
                                    var trc = (postData && postData.topic_reply_count != null) ? postData.topic_reply_count : (resp && resp.topic_reply_count != null ? resp.topic_reply_count : null);
                                    var tpc = (postData && postData.topic_participant_count != null) ? postData.topic_participant_count : (resp && resp.topic_participant_count != null ? resp.topic_participant_count : null);
                                    var tv = (postData && postData.topic_views != null) ? postData.topic_views : (resp && resp.topic_views != null ? resp.topic_views : null);
                                    if (trc !== undefined && trc !== null) hdrPatch.replyCount = Number(trc);
                                    if (tpc !== undefined && tpc !== null) hdrPatch.participants = Number(tpc);
                                    if (tv !== undefined && tv !== null) hdrPatch.views = Number(tv);
                                    if (Object.keys(hdrPatch).length) {
                                        window.ulpPatchForumTopicPageStatsStrip(tid, hdrPatch);
                                    }
                                }
                            }
                        }
                        if (postData && postData.id && !document.getElementById('forum-post-' + postData.id) && window.appendForumPostToDOM) {
                            window.appendForumPostToDOM(postData);
                        }
                        resetForumSendPending();
                    });
                };
                var ensure = (typeof window.ulpEnsureSharedSocketConnected === 'function')
                    ? window.ulpEnsureSharedSocketConnected(8000)
                    : Promise.resolve(socket);
                ensure.then(doEmit).catch(function (err) {
                    resetForumSendPending();
                    if (window.showToast) {
                        window.showToast(
                            'Connection',
                            (err && err.message) ? String(err.message) : 'Live connection unavailable. Refresh the page and try again.',
                            null,
                            'fas fa-plug',
                            null,
                            'error'
                        );
                    }
                });
            }).catch(function (err) {
                resetForumSendPending();
                if (window.showToast) {
                    var details = (typeof window.describeInlineImageUploadError === 'function')
                        ? window.describeInlineImageUploadError(err)
                        : { title: 'Upload failed', message: 'Could not upload one or more images.' };
                    window.showToast(details.title, details.message, null, 'fas fa-image', null, 'error');
                }
            });
        };

        function joinTopicRoom() {
            if (socket) socket.emit('join_forum_topic', { topic_id: topicId });
        }
        if (socket) {
            window.__forumTopicSocketHandlers = window.__forumTopicSocketHandlers || {};
            var h = window.__forumTopicSocketHandlers;
            var leftTopicRoom = false;
            var topicPath = String(cfg.topicPath || '');
            function renderForumTyping(data) {
                var container = document.getElementById('typing-indicator-container');
                if (!container || !data || !data.username) return;
                if (currentUserId && String(data.user_id || '') === String(currentUserId)) return;
                var bubbleId = 'typing-' + data.username;
                if (data.is_typing) {
                    var bubble = document.getElementById(bubbleId);
                    if (!bubble) {
                        bubble = document.createElement('div');
                        bubble.id = bubbleId;
                        bubble.className = 'typing-bubble';
                        bubble.innerHTML = '<span class="typing-name"></span> is typing<div class="typing-dots"><span></span><span></span><span></span></div>';
                        var nameEl = bubble.querySelector('.typing-name');
                        if (nameEl) nameEl.textContent = data.username;
                        container.appendChild(bubble);
                    }
                } else {
                    var ex = document.getElementById(bubbleId);
                    if (ex) ex.remove();
                }
            }

            function leaveTopicRoom() {
                if (!socket || leftTopicRoom) return;
                leftTopicRoom = true;
                // Critical: remove reconnect handler — otherwise a later socket reconnect
                // re-joins this topic while the user is already on another page (SPA).
                if (h.connect) {
                    socket.off('connect', h.connect);
                    h.connect = null;
                }
                socket.emit('leave_forum_topic', { topic_id: topicId });
            }

            function normalizePresencePath(path) {
                if (!path) return '';
                return (path !== '/' && path.endsWith('/')) ? path.slice(0, -1) : path;
            }

            function handlePossibleRouteLeave() {
                var p = normalizePresencePath(window.location && window.location.pathname ? window.location.pathname : '');
                if (!p) return;
                var tp = normalizePresencePath(topicPath);
                var topicPrefix = '/discussions/t/' + topicId;
                if (p !== tp && p.indexOf(topicPrefix) !== 0) {
                    leaveTopicRoom();
                }
            }

            if (h.connect) socket.off('connect', h.connect);
            if (h.forumDeleteResult) socket.off('forum_delete_result', h.forumDeleteResult);
            if (h.forumPostApproved) socket.off('forum_post_approved', h.forumPostApproved);
            if (h.forumPostUpdated) socket.off('forum_post_updated', h.forumPostUpdated);
            if (h.forumPostLikeUpdate) socket.off('forum_post_like_update', h.forumPostLikeUpdate);
            delete h.forumPostLikeUpdate;
            if (h.userTyping) socket.off('user_typing', h.userTyping);
            if (h.pagehide) window.removeEventListener('pagehide', h.pagehide);
            if (h.beforeunload) window.removeEventListener('beforeunload', h.beforeunload);
            if (h.pageLoaded) document.removeEventListener('pageLoaded', h.pageLoaded);

            joinTopicRoom();
            h.connect = joinTopicRoom;
            socket.on('connect', h.connect);
            h.pagehide = leaveTopicRoom;
            h.beforeunload = leaveTopicRoom;
            h.pageLoaded = handlePossibleRouteLeave;
            window.addEventListener('pagehide', h.pagehide);
            window.addEventListener('beforeunload', h.beforeunload);
            document.addEventListener('pageLoaded', h.pageLoaded);

            h.forumDeleteResult = function (payload) {
                if (!payload) return;
                if (payload.ok !== true) {
                    if (window.showToast && payload.message) {
                        window.showToast('Error', payload.message, null, 'fas fa-circle-exclamation', null, 'error');
                    }
                    return;
                }
                if (payload.topic_deleted) {
                    var dest = (payload.redirect_url && String(payload.redirect_url).trim()) || forumTopicDeleteRedirectUrl();
                    if (window.loadPage) {
                        window.loadPage(dest, true, { showLoader: false });
                    } else {
                        window.location.replace(dest);
                    }
                    return;
                }
                var deletedPostId = payload.post_id;
                if (deletedPostId == null) return;
                if (typeof window.ulpRemoveForumPostFromDom === 'function') {
                    window.ulpRemoveForumPostFromDom(deletedPostId);
                }
            };
            socket.on('forum_delete_result', h.forumDeleteResult);
            if (h.forumPostDeleted) socket.off('forum_post_deleted', h.forumPostDeleted);
            h.forumPostDeleted = function (payload) {
                if (!payload || payload.post_id == null) return;
                if (typeof window.ulpRemoveForumPostFromDom === 'function') {
                    window.ulpRemoveForumPostFromDom(payload.post_id);
                }
            };
            socket.on('forum_post_deleted', h.forumPostDeleted);

            h.forumPostApproved = function (payload) {
                var id = payload && payload.id;
                if (!id) return;
                var row = document.getElementById('forum-post-' + id);
                if (!row) return;
                var badges = row.querySelectorAll('.adm-badge-yellow');
                badges.forEach(function (b) { b.remove(); });
            };
            socket.on('forum_post_approved', h.forumPostApproved);

            h.forumPostUpdated = function (payload) {
                var id = payload && payload.id;
                if (!id) return;
                var row = document.getElementById('forum-post-' + id);
                if (!row) return;
                var body = row.querySelector('.forum-post-body');
                if (!body) return;
                var updatedBodyHtml = payload.content_html || escapeHtml(payload.content || '');
                if (typeof window.ulpSanitizeRichHtml === 'function') {
                    updatedBodyHtml = window.ulpSanitizeRichHtml(updatedBodyHtml);
                }
                body.innerHTML = updatedBodyHtml;
            };
            socket.on('forum_post_updated', h.forumPostUpdated);

            h.userTyping = function (payload) {
                if (!payload) return;
                if (String(payload.topic_id || '') !== String(topicId)) return;
                renderForumTyping(payload);
            };
            socket.on('user_typing', h.userTyping);

            /* forum_post_like_update / forum_post_like_status: realtime.js (applyForumPostLikeUIPayload). */
        }

        if (socket && currentUserId) {
            bindForumTypingEmitter();
            bindForumTypingDomFallback();
            setTimeout(bindForumTypingEmitter, 200);
            setTimeout(bindForumTypingDomFallback, 200);
            setTimeout(bindForumTypingEmitter, 700);
            setTimeout(bindForumTypingDomFallback, 700);
            setTimeout(bindForumTypingEmitter, 1500);
            setTimeout(bindForumTypingDomFallback, 1500);
            window.addEventListener('beforeunload', stopForumTyping);
            window.addEventListener('pagehide', stopForumTyping);
        }

        var listEl = document.getElementById('forum-posts-list');
        if (listEl) listEl.scrollTop = listEl.scrollHeight;

        if (isAdmin) {
            window.updateForumPostSelection = function () {
                var checked = document.querySelectorAll('.forum-post-checkbox:checked');
                var count = checked.length;
                var countEl = document.getElementById('selection-count-forum-posts');
                if (countEl) countEl.textContent = count + ' SELECTED';
                var approveBtn = document.getElementById('approve-selected-forum-posts-btn');
                var deleteBtn = document.getElementById('delete-selected-forum-posts-btn');
                var bar = document.getElementById('bulk-action-bar-forum-posts');
                if (approveBtn) approveBtn.disabled = count === 0;
                if (deleteBtn) deleteBtn.disabled = count === 0;
                if (bar) bar.classList.toggle('active', count > 0);
                var all = document.querySelectorAll('.forum-post-checkbox');
                var selectAll = document.getElementById('select-all-forum-posts');
                if (selectAll && all.length) selectAll.checked = count === all.length;
            };

            window.toggleSelectAllForumPosts = function (el) {
                document.querySelectorAll('.forum-post-checkbox').forEach(function (cb) {
                    cb.checked = !!(el && el.checked);
                });
                window.updateForumPostSelection();
            };

            function submitBulkForumPosts(endpoint, opts) {
                var selected = document.querySelectorAll('.forum-post-checkbox:checked');
                var ids = Array.from(selected).map(function (cb) { return cb.value; });
                if (!ids.length || !window.runBulkForumModeration) return;
                if (opts && opts.approve) {
                    if (!confirm('Approve ' + ids.length + ' selected forum post(s)?')) return;
                    var formData = new FormData();
                    ids.forEach(function (id) { formData.append('post_ids[]', id); });
                    var csrf = document.querySelector('meta[name="csrf-token"]');
                    var token = csrf ? csrf.content : '';
                    if (token) formData.append('csrf_token', token);
                    fetch(endpoint + '?ajax=true', {
                        method: 'POST',
                        body: formData,
                        headers: { 'X-CSRFToken': token, 'X-Requested-With': 'XMLHttpRequest' },
                    }).then(function (r) { return r.json(); }).then(function (data) {
                        if (data.status === 'success' && window.loadPage) {
                            window.loadPage(window.location.pathname + window.location.search, true, { showLoader: false });
                        }
                    });
                    return;
                }
                window.runBulkForumModeration({
                    endpoint: endpoint,
                    fieldName: 'post_ids[]',
                    ids: ids,
                    verb: 'delete',
                    checkboxSelector: '.forum-post-checkbox',
                    selectAllId: 'select-all-forum-posts',
                    onSelectionReset: window.updateForumPostSelection,
                    reloadPage: true,
                });
            }

            window.bulkApproveForumPosts = function () {
                submitBulkForumPosts(cfg.bulkApprovePostsUrl, { approve: true });
            };

            window.bulkDeleteForumPosts = function () {
                submitBulkForumPosts(cfg.bulkDeletePostsUrl, { delete: true });
            };
        }

        (function wireForumTopicCategoryFlydownToolbar() {
            if (window.__forumTopicToolbarFlyDelegation) return;
            window.__forumTopicToolbarFlyDelegation = true;

            function closeToolbarSlots(toolbar, exceptSlot) {
                if (!toolbar) return;
                toolbar.querySelectorAll('.forum-topic-cat-slot').forEach(function (slot) {
                    if (exceptSlot && slot === exceptSlot) return;
                    slot.classList.remove('is-open');
                    var fly = slot.querySelector('.forum-topic-cat-flydown');
                    var btn = slot.querySelector('.forum-topic-cat-fly-toggle');
                    if (fly) fly.hidden = true;
                    if (btn) btn.setAttribute('aria-expanded', 'false');
                });
            }

            document.addEventListener('click', function (e) {
                var toolbar = document.getElementById('forum-topic-cat-toolbar');
                if (!toolbar) return;

                var tgl = e.target.closest('.forum-topic-cat-fly-toggle');
                if (tgl && toolbar.contains(tgl)) {
                    e.preventDefault();
                    e.stopPropagation();
                    var slot = tgl.closest('.forum-topic-cat-slot');
                    if (!slot) return;
                    var fly = slot.querySelector('.forum-topic-cat-flydown');
                    var opening = !slot.classList.contains('is-open');
                    closeToolbarSlots(toolbar, opening ? slot : null);
                    if (opening) {
                        slot.classList.add('is-open');
                        if (fly) fly.hidden = false;
                        tgl.setAttribute('aria-expanded', 'true');
                    } else {
                        slot.classList.remove('is-open');
                        if (fly) fly.hidden = true;
                        tgl.setAttribute('aria-expanded', 'false');
                    }
                    return;
                }

                if (!toolbar.contains(e.target)) closeToolbarSlots(toolbar, null);
            });

            document.addEventListener('keydown', function (e) {
                if (e.key !== 'Escape') return;
                closeToolbarSlots(document.getElementById('forum-topic-cat-toolbar'), null);
            });
        })();

        (function syncForumTopicModToolbarIcons() {
            var form = document.querySelector('.forum-topic-mod-form--icons');
            if (!form) return;
            var lockSel = form.querySelector('select[name="is_locked"]');
            var pinSel = form.querySelector('select[name="pin_scope"]');
            var lockIc = form.querySelector('.forum-topic-mod-icon--lock i');
            var pinWrap = form.querySelector('.forum-topic-mod-icon--pin');
            function syncLock() {
                if (!lockSel || !lockIc) return;
                lockIc.className = lockSel.value === '1' ? 'fas fa-lock' : 'fas fa-lock-open';
            }
            function syncPin() {
                if (!pinSel || !pinWrap) return;
                pinWrap.classList.remove('is-off', 'is-category', 'is-global');
                var v = pinSel.value;
                if (v === 'category') pinWrap.classList.add('is-category');
                else if (v === 'global') pinWrap.classList.add('is-global');
                else pinWrap.classList.add('is-off');
            }
            if (lockSel) lockSel.addEventListener('change', syncLock);
            if (pinSel) pinSel.addEventListener('change', syncPin);
        })();

        (function wireForumTopicModLabelPicker() {
            var form = document.querySelector('.forum-topic-mod-form--icons');
            if (!form) return;
            form.querySelectorAll('.forum-topic-mod-field').forEach(function (label) {
                var sel = label.querySelector('select');
                if (!sel) return;
                label.addEventListener('click', function (e) {
                    if (sel.contains(e.target)) return;
                    e.preventDefault();
                    if (typeof sel.showPicker === 'function') {
                        try {
                            sel.showPicker();
                        } catch (err) {
                            sel.focus();
                        }
                    } else {
                        sel.focus();
                    }
                });
            });
        })();

})();
