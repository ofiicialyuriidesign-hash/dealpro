/**
 * Shared crypto checkout (paid files + VIP). Page JSON config + short-lived session.
 */
(function () {
    'use strict';

    function readJsonEl(id) {
        var el = document.getElementById(id);
        if (!el) return null;
        try {
            return JSON.parse(el.textContent || '{}');
        } catch (e) {
            return null;
        }
    }

    function readPageConfig() {
        return (
            readJsonEl('ulp-crypto-checkout-config') ||
            readJsonEl('ulp-file-purchase-config') ||
            readJsonEl('ulp-crypto-checkout-page')
        );
    }

    function notify(title, message, icon, category) {
        var cat = category || 'error';
        var ic = icon || 'fas fa-circle-info';
        if (typeof window.showToast === 'function') {
            var nt = cat === 'success' ? 'success' : cat === 'warning' ? 'warning' : 'error';
            window.showToast(title, message, null, ic, null, nt);
        } else if (typeof window.createFlash === 'function') {
            window.createFlash(message, cat);
        }
    }

    function formatPriceLabel(price) {
        var n = Number(price || 0);
        return new Intl.NumberFormat('en-US', {
            minimumFractionDigits: n % 1 === 0 ? 0 : 2,
            maximumFractionDigits: 2,
        }).format(n);
    }

    function currencyGridHtml() {
        return (
            '<div class="crypto-checkout-coin-shell">' +
            '<div class="crypto-currency-grid">' +
            '<button type="button" data-ulp-crypto-currency="BTC" class="btn btn-toolbar crypto-currency-btn"><span class="crypto-currency-icon"><i class="fab fa-bitcoin" aria-hidden="true"></i></span><span class="crypto-currency-label">BTC</span></button>' +
            '<button type="button" data-ulp-crypto-currency="LTC" class="btn btn-toolbar crypto-currency-btn"><span class="crypto-currency-icon crypto-symbol">Ł</span><span class="crypto-currency-label">LTC</span></button>' +
            '<button type="button" data-ulp-crypto-currency="ETH" class="btn btn-toolbar crypto-currency-btn"><span class="crypto-currency-icon"><i class="fab fa-ethereum" aria-hidden="true"></i></span><span class="crypto-currency-label">ETH</span></button>' +
            '<button type="button" data-ulp-crypto-currency="USDT" class="btn btn-toolbar crypto-currency-btn"><span class="crypto-currency-icon"><i class="fas fa-dollar-sign" aria-hidden="true"></i></span><span class="crypto-currency-label crypto-currency-label--dual"><span class="crypto-usdt-name">USDT</span><span class="crypto-usdt-net">TRC20</span></span></button>' +
            '</div></div>'
        );
    }

    function prepareCryptoModalContainer(isVip) {
        var container = document.querySelector('.modal-container');
        if (!container) return;
        container.classList.remove('auth-modal', 'upload-modal-container', 'upload-modal-container--bulk');
        container.classList.add('cyber-card', 'crypto-checkout-modal');
        container.classList.toggle('crypto-checkout-modal--vip', !!isVip);
    }

    function bindCryptoButtons() {
        var area = document.getElementById('modal-content-area');
        if (!area) return;
        area.querySelectorAll('[data-ulp-crypto-currency]').forEach(function (btn) {
            if (btn.getAttribute('data-ulp-crypto-bound') === '1') return;
            btn.setAttribute('data-ulp-crypto-bound', '1');
            btn.addEventListener('click', function (ev) {
                ev.preventDefault();
                ev.stopPropagation();
                var cur = btn.getAttribute('data-ulp-crypto-currency');
                if (cur) window.processPurchase(cur);
            });
        });
    }

    function redirectToCheckout(orderId) {
        var checkoutUrl = '/payments/checkout/' + orderId;
        if (typeof window.closeModal === 'function') window.closeModal();
        if (window.loadPage) window.loadPage(checkoutUrl);
        else window.location.href = checkoutUrl;
    }

    function requireLogin(loginUrl) {
        if (typeof window.closeModal === 'function') window.closeModal();
        var url = loginUrl || '/login';
        if (window.loadPage) {
            Promise.resolve(window.loadPage(url)).catch(function () {
                window.location.href = url;
            });
        } else {
            window.location.href = url;
        }
    }

    /**
     * @param {object} session
     * @param {string} session.title
     * @param {string} session.titleIconHtml
     * @param {number} session.price
     * @param {string} session.createOrderUrl
     * @param {string} session.csrfToken
     * @param {boolean} session.isAuthenticated
     * @param {string} [session.loginUrl]
     * @param {string} [session.errorTitle]
     * @param {object} [session.extraBody]
     */
    function openCheckout(session) {
        if (!session || !session.createOrderUrl) {
            notify('Payment', 'Checkout is not configured. Refresh the page.', 'fas fa-circle-info', 'error');
            return;
        }
        window.__ulpCheckoutSession = session;

        var priceLabel = formatPriceLabel(session.price);
        var iconHtml = session.titleIconHtml || '<i class="fas fa-shopping-cart" aria-hidden="true"></i>';
        var isVip = !!(session.isVip || (session.title && String(session.title).toLowerCase().indexOf('vip') !== -1));
        var modalHtml =
            '<div class="modal-header crypto-checkout-header">' +
            '<h2 class="crypto-checkout-title">' +
            iconHtml +
            ' <span>' + (session.title || 'Checkout') + '</span>' +
            '</h2>' +
            '<button type="button" class="modal-close-btn" data-modal-close="1" aria-label="Close checkout"><i class="fas fa-times"></i></button>' +
            '</div>' +
            '<div class="modal-body crypto-checkout-body' + (isVip ? ' crypto-checkout-body--vip' : '') + '">' +
            '<p class="crypto-checkout-subtitle">Select a cryptocurrency to pay <strong>$' +
            priceLabel +
            '</strong></p>' +
            currencyGridHtml() +
            '<div id="purchase-status" class="crypto-checkout-status" style="display:none;"><i class="fas fa-spinner fa-spin"></i> Generating payment address...</div>' +
            '</div>';


        if (typeof window.showModalContent === 'function') {
            prepareCryptoModalContainer(isVip);
            window.showModalContent(modalHtml);
            bindCryptoButtons();
        } else {
            notify('Payment', 'Modal logic not loaded. Please refresh.', 'fas fa-circle-info', 'error');
        }
    }

    window.ulpOpenCryptoCheckout = openCheckout;

    window.openCryptoModal = function () {
        var cfg = readPageConfig();
        if (!cfg || !cfg.createOrderUrl) {
            notify('Payment', 'Payment config missing. Refresh the page.', 'fas fa-circle-info', 'error');
            return;
        }
        openCheckout({
            title: 'Unlock file',
            titleIconHtml: '<i class="fas fa-shopping-cart" aria-hidden="true"></i>',
            price: cfg.price,
            createOrderUrl: cfg.createOrderUrl,
            csrfToken: cfg.csrfToken || '',
            isAuthenticated: !!cfg.isAuthenticated,
            loginUrl: cfg.loginUrl,
            errorTitle: 'Purchase Error',
            extraBody: {},
        });
    };

    window.openVipCryptoModal = function (planId, price) {
        var cfg = readPageConfig();
        var vipUrl = (cfg && (cfg.purchaseVipUrl || cfg.createOrderUrl)) || '';
        if (!cfg || !vipUrl) {
            notify('VIP', 'Checkout is not configured. Refresh the page.', 'fas fa-triangle-exclamation', 'error');
            return;
        }
        openCheckout({
            title: 'VIP checkout',
            isVip: true,
            titleIconHtml: '<i class="fas fa-gem icon-gem-gradient" aria-hidden="true"></i>',
            price: price,
            createOrderUrl: vipUrl,
            csrfToken: cfg.csrfToken || '',
            isAuthenticated: !!cfg.isAuthenticated,
            loginUrl: cfg.loginUrl,
            errorTitle: 'VIP purchase',
            extraBody: { plan_id: parseInt(planId, 10) || planId },
        });
    };

    window.processPurchase = function (currency) {
        var session = window.__ulpCheckoutSession;
        if (!session || !session.createOrderUrl) {
            notify('Payment', 'No active checkout. Open checkout again.', 'fas fa-circle-info', 'error');
            return;
        }
        if (!session.isAuthenticated) {
            requireLogin(session.loginUrl);
            return;
        }

        var statusEl = document.getElementById('purchase-status');
        if (statusEl) statusEl.style.display = 'block';

        var body = { currency: currency };
        if (session.extraBody) {
            Object.keys(session.extraBody).forEach(function (k) {
                body[k] = session.extraBody[k];
            });
        }

        fetch(session.createOrderUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': session.csrfToken || '',
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: JSON.stringify(body),
        })
            .then(function (response) {
                return response.json().then(function (data) {
                    return { data: data };
                });
            })
            .then(function (result) {
                if (result.data && result.data.error) {
                    notify(session.errorTitle || 'Purchase Error', result.data.error, 'fas fa-triangle-exclamation', 'error');
                    if (statusEl) statusEl.style.display = 'none';
                    return;
                }
                if (!result.data || !result.data.order_id) {
                    notify(session.errorTitle || 'Purchase Error', 'Invalid server response. Try again.', 'fas fa-triangle-exclamation', 'error');
                    if (statusEl) statusEl.style.display = 'none';
                    return;
                }
                redirectToCheckout(result.data.order_id);
            })
            .catch(function () {
                notify('Network Error', 'Unable to create order right now. Please try again.', 'fas fa-wifi', 'error');
                if (statusEl) statusEl.style.display = 'none';
            });
    };

    window.processVipPurchase = window.processPurchase;

    if (!window.__ulpCryptoUnlockDeleg) {
        window.__ulpCryptoUnlockDeleg = true;
        document.addEventListener('click', function (ev) {
            var fileBtn = ev.target.closest('[data-open-crypto-modal]');
            if (fileBtn) {
                ev.preventDefault();
                window.openCryptoModal();
                return;
            }
            var vipBtn = ev.target.closest('[data-open-vip-checkout]');
            if (vipBtn) {
                ev.preventDefault();
                var planId = vipBtn.getAttribute('data-plan-id');
                var planPrice = vipBtn.getAttribute('data-plan-price');
                if (planId) window.openVipCryptoModal(planId, planPrice);
            }
        });
    }
})();
