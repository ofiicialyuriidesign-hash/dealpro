// Optional local fallback stub.
// This file is referenced in base.html to support environments
// where additional Cloudflare-specific client hooks may be injected.
// On local/dev it intentionally does nothing.
