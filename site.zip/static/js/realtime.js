/**
 * realtime.js
 * Handles global real-time events: Moderation, Notifications, Presence.
 * Loaded in base.html.
 */

(function () {
    if (window._realtimeInitialized) {
        return;
    }
    window._realtimeInitialized = true;

    /** Match HTML meta so a fresh page load after deploy does not trigger a second full reload on socket connect. */
    (function ulpPrimeServerBootTsFromPage() {
        try {
            const el = document.querySelector('meta[name="ulp-server-boot-ts"]');
            const pageBoot = el && el.getAttribute('content');
            if (pageBoot != null && pageBoot !== '') {
                sessionStorage.setItem('socket_server_boot_ts', String(pageBoot));
            }
        } catch (e) { /* sessionStorage blocked */ }
    })();

    const TOAST_LIFETIME_MS = 10000;
    /** Visible tab: keep in sync with events.HEARTBEAT_INTERVAL_S. Hidden tabs use a slower pulse (browser timer throttling). */
    const GLOBAL_ONLINE_PULSE_MS = 30000;
    const GLOBAL_ONLINE_PULSE_HIDDEN_MS = 60000;
    /** Upper bound for reported idle (sanity); server enforces real max via PRESENCE_MAX_IDLE_MS. */
    const PRESENCE_IDLE_REPORT_MAX_MS = 7 * 86400000;
    const socket = window.getSharedSocket ? window.getSharedSocket() : (window.socket || null);
    window._realtimeSocket = socket;
    if (socket) {
    } else {
        console.error('Realtime: NO SOCKET INSTANCE FOUND during init!');
    }

    // --- HELPERS ---
    /**
     * parseLinks: Converts plain-text URLs to clickable anchor tags.
     * NOTE: Do NOT HTML-escape the input here — chat content from the backend
     * already has safe HTML from mention_to_link(). Escaping again would corrupt it.
     * Only used for raw-text paths (system announcements) where no backend processing occurs.
     */
    const parseLinks = (text) => {
        if (!text) return '';
        // Only replace bare URLs not already inside an existing <a> tag
        const urlRegex = /(?<!href=["'])(https?:\/\/[^\s<>"]+)/g;
        return text.replace(urlRegex, (url) => {
            let display = url;
            if (url.length > 50) {
                display = url.substring(0, 35) + '…' + url.substring(url.length - 12);
            }
            const linkStyle = 'color: var(--primary-color); text-decoration: underline;';
            if (typeof window.ulpBuildInlineLinkHtml === 'function') {
                return window.ulpBuildInlineLinkHtml(url, display, linkStyle);
            }
            return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="external-link" style="${linkStyle}">${display}</a>`;
        });
    };

    // Expose globally for chat.js
    window.parseLinks = parseLinks;

    /** Escape text for safe HTML insertion. */
    function escapePlainTextForHtml(text) {
        if (typeof window.ulpEscapeHtml === 'function') {
            return window.ulpEscapeHtml(text == null ? '' : String(text));
        }
        const d = document.createElement('div');
        d.textContent = text == null ? '' : String(text);
        return d.innerHTML;
    }

    function applyInlineBroadcastMarkup(escapedLine) {
        let html = escapedLine;
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');
        html = html.replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
        return html;
    }

    function linkifyEscapedLine(escapedLine) {
        const linkStyle = 'color: var(--primary-color); text-decoration: underline;';
        const buildLink = typeof window.ulpBuildInlineLinkHtml === 'function'
            ? window.ulpBuildInlineLinkHtml
            : null;
        return escapedLine.replace(
            /(https?:\/\/[^\s<>"']+)|(?<![:/\w])(\/[^\s<>"']+)/g,
            (match, httpUrl, relPath) => {
                const href = httpUrl || relPath;
                if (!href) return match;
                let display = href;
                if (httpUrl && httpUrl.length > 50) {
                    display = httpUrl.substring(0, 35) + '…' + httpUrl.substring(httpUrl.length - 12);
                }
                if (buildLink) {
                    return buildLink(href, display, linkStyle);
                }
                const safeHref = href.replace(/"/g, '&quot;');
                return `<a href="${safeHref}" target="_blank" rel="noopener noreferrer" class="external-link" style="${linkStyle}">${display}</a>`;
            }
        );
    }

    /** Plain text → safe HTML: new lines, **bold**, *italic*, http(s) and /paths (toasts, banners). */
    function linkifyPlainTextForDisplay(text) {
        if (text == null || text === '') return '';
        const normalized = String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        const html = normalized.split('\n').map((line) => {
            const escaped = escapePlainTextForHtml(line);
            const marked = applyInlineBroadcastMarkup(escaped);
            return linkifyEscapedLine(marked);
        }).join('<br>');
        return sanitizeRichHtml(html);
    }
    window.linkifyPlainTextForDisplay = linkifyPlainTextForDisplay;

    function wireToastInlineLinks(toast) {
        if (!toast) return;
        if (typeof window.ulpWireInlineContentLinks === 'function') {
            window.ulpWireInlineContentLinks(toast);
            return;
        }
        toast.querySelectorAll('.ulp-toast-message a.external-link').forEach((a) => {
            a.addEventListener('click', (e) => {
                e.stopPropagation();
                const href = (a.getAttribute('href') || '').trim();
                if (!href || href === '#') return;
                e.preventDefault();
                if (typeof window.ulpIsExternalNavHref === 'function' && window.ulpIsExternalNavHref(href)) {
                    return;
                }
                if (typeof window.ulpNavigateHref === 'function') {
                    window.ulpNavigateHref(href);
                } else if (href.startsWith('/') && window.loadPage) {
                    document.body.style.cursor = 'wait';
                    window.loadPage(href);
                } else {
                    window.open(href, '_blank', 'noopener,noreferrer');
                }
            });
        });
    }
    window.wireToastInlineLinks = wireToastInlineLinks;

    /**
     * Defense-in-depth sanitizer for rich HTML coming from realtime payloads.
     * Server already sanitizes, but we strip dangerous tags/attrs client-side too.
     */
    const sanitizeRichHtml = (raw) => {
        if (!raw) return '';
        const tpl = document.createElement('template');
        tpl.innerHTML = String(raw);
        tpl.content.querySelectorAll('script,style,iframe,object,embed,link,meta,base,form,input,button,textarea,select').forEach((n) => n.remove());
        tpl.content.querySelectorAll('*').forEach((el) => {
            Array.from(el.attributes).forEach((attr) => {
                const n = (attr.name || '').toLowerCase();
                const v = String(attr.value || '');
                if (n.startsWith('on') || n === 'srcdoc') {
                    el.removeAttribute(attr.name);
                    return;
                }
                if ((n === 'href' || n === 'src') && /^\s*(javascript:|vbscript:)/i.test(v)) {
                    el.removeAttribute(attr.name);
                    return;
                }
                if (n === 'href') {
                    const sanitizer = typeof window.ulpSanitizeNotificationHref === 'function'
                        ? window.ulpSanitizeNotificationHref
                        : (h) => String(h || '').trim();
                    const safeHref = sanitizer(v);
                    if (!safeHref) {
                        el.removeAttribute(attr.name);
                        return;
                    }
                    el.setAttribute('href', safeHref);
                    if (typeof window.ulpIsInternalHref === 'function' && window.ulpIsInternalHref(safeHref)) {
                        const dest = typeof window.ulpResolveInternalHref === 'function'
                            ? window.ulpResolveInternalHref(safeHref)
                            : safeHref;
                        if (dest) el.setAttribute('href', dest);
                        el.removeAttribute('target');
                        el.removeAttribute('rel');
                    } else {
                        el.setAttribute('target', '_blank');
                        el.setAttribute('rel', 'noopener noreferrer');
                    }
                    return;
                }
                if (n === 'src' && /^\s*data:/i.test(v) && el.tagName.toLowerCase() !== 'img') {
                    el.removeAttribute(attr.name);
                }
            });
        });
        return tpl.innerHTML;
    };
    window.ulpSanitizeRichHtml = sanitizeRichHtml;

    function formatUlpCompactTimeFromTs(tsSeconds) {
        const n = Number(tsSeconds);
        if (!Number.isFinite(n)) return '';
        const dt = new Date(n * 1000);
        const now = new Date();
        if (dt > now) {
            const sameYearFuture = dt.getUTCFullYear() === now.getUTCFullYear();
            const d = String(dt.getUTCDate()).padStart(2, '0');
            const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
            const h = String(dt.getUTCHours()).padStart(2, '0');
            const min = String(dt.getUTCMinutes()).padStart(2, '0');
            return sameYearFuture ? `${d}.${m} / ${h}:${min}` : `${d}.${m}.${String(dt.getUTCFullYear()).slice(-2)} / ${h}:${min}`;
        }
        const diffMs = now.getTime() - dt.getTime();
        if (diffMs < 60000) return 'now';
        if (diffMs < 3600000) return `${Math.floor(diffMs / 60000)}m`;
        if (diffMs < 86400000) return `${Math.floor(diffMs / 3600000)}h`;
        if (diffMs < 604800000) return `${Math.floor(diffMs / 86400000)}d`;
        const d = String(dt.getUTCDate()).padStart(2, '0');
        const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
        if (dt.getUTCFullYear() === now.getUTCFullYear()) return `${d}.${m}`;
        return `${d}.${m}.${String(dt.getUTCFullYear()).slice(-2)}`;
    }

    function updateUlpLiveTimes(root) {
        const scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('[data-ulp-time-ts]').forEach((el) => {
            const next = formatUlpCompactTimeFromTs(el.getAttribute('data-ulp-time-ts'));
            if (!next) return;
            const target = el.classList.contains('ulp-live-time')
                ? el
                : el.querySelector('.ulp-live-time, .time-text, .bump-time-text');
            if (target) {
                target.textContent = next;
                return;
            }
            for (const node of Array.from(el.childNodes).reverse()) {
                if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim()) {
                    node.nodeValue = ' ' + next;
                    return;
                }
            }
            el.appendChild(document.createTextNode(' ' + next));
        });
    }

    window.ulpUpdateLiveTimes = updateUlpLiveTimes;
    updateUlpLiveTimes();
    setInterval(updateUlpLiveTimes, 30000);
    document.addEventListener('pageLoaded', () => updateUlpLiveTimes());

    /** Pending comments/posts: only author and staff (defense-in-depth vs socket rooms). */
    function mayViewPendingModerationPayload(data) {
        if (!data || data.is_approved !== false) return true;
        const body = document.body;
        if (!body) return false;
        const role = (body.getAttribute('data-user-role') || '').toLowerCase();
        if (role === 'admin' || role === 'moderator') return true;
        const me = body.getAttribute('data-user-id') || '';
        return me !== '' && String(data.user_id || '') === String(me);
    }
    window.ulpMayViewPendingModerationPayload = mayViewPendingModerationPayload;

    /** Topic list cards: public only when opening post is approved (approved replies alone are not enough). */
    function mayViewForumTopicListCard(data) {
        if (!data) return false;
        const body = document.body;
        const role = (body && body.getAttribute('data-user-role') || '').toLowerCase();
        const isStaff = role === 'admin' || role === 'moderator';
        if (data.opening_post_approved === false) {
            return (
                isStaff ||
                mayViewPendingModerationPayload({
                    is_approved: false,
                    user_id: data.user_id,
                })
            );
        }
        if (data.opening_post_approved === true) return true;
        if (data.is_approved === false) {
            return (
                isStaff ||
                mayViewPendingModerationPayload({
                    is_approved: false,
                    user_id: data.user_id,
                })
            );
        }
        return true;
    }
    window.ulpMayViewForumTopicListCard = mayViewForumTopicListCard;

    function ulpRemoveForumTopicListCards(topicId) {
        if (topicId == null || topicId === '') return;
        const tid = String(topicId);
        document.querySelectorAll(`.forum-topic-list-card[data-topic-id="${tid}"]`).forEach((card) => {
            card.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
            card.style.opacity = '0';
            card.style.transform = 'scale(0.98)';
            setTimeout(() => {
                if (card.parentNode) card.parentNode.removeChild(card);
            }, 360);
        });
    }
    window.ulpRemoveForumTopicListCards = ulpRemoveForumTopicListCards;

    function ulpAnimateRemoveElement(el, delayMs) {
        if (!el || !el.parentNode) return;
        const ms = delayMs == null ? 480 : Number(delayMs);
        el.style.transition = 'opacity 0.45s ease, transform 0.45s ease';
        el.style.opacity = '0';
        el.style.transform = 'scale(0.98)';
        setTimeout(() => {
            if (el.parentNode) el.parentNode.removeChild(el);
        }, Number.isFinite(ms) ? ms : 480);
    }

    function ulpRemoveForumPostFromDom(postId) {
        if (postId == null || postId === '') return;
        const pid = String(postId);
        const sel = `#forum-post-${pid}, .forum-post-item[data-post-id="${pid}"], [data-post-id="${pid}"].forum-post-item`;
        document.querySelectorAll(sel).forEach((el) => ulpAnimateRemoveElement(el, 480));
    }
    window.ulpRemoveForumPostFromDom = ulpRemoveForumPostFromDom;

    function ulpForumVisibleTopicIdSet() {
        const el = document.getElementById('ulp-forum-visible-topic-ids');
        if (!el) return null;
        try {
            const raw = JSON.parse(el.textContent || '[]');
            if (!Array.isArray(raw)) return null;
            return new Set(raw.map((x) => String(x)));
        } catch (e) {
            return null;
        }
    }
    window.ulpForumVisibleTopicIdSet = ulpForumVisibleTopicIdSet;

    function ulpStripNonPublicForumTopicCards() {
        const body = document.body;
        const role = (body && body.getAttribute('data-user-role') || '').toLowerCase();
        if (role === 'admin' || role === 'moderator') return;
        const allow = ulpForumVisibleTopicIdSet();
        document.querySelectorAll('.forum-topic-list-card').forEach((card) => {
            const tid = card.getAttribute('data-topic-id');
            if (!tid) return;
            if (allow) {
                if (!allow.has(String(tid))) ulpRemoveForumTopicListCards(tid);
                return;
            }
            if (card.getAttribute('data-list-public') === '1') return;
            ulpRemoveForumTopicListCards(tid);
        });
    }
    window.ulpStripNonPublicForumTopicCards = ulpStripNonPublicForumTopicCards;

    const escapeHtml = (text) => {
        return String(text == null ? '' : text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    };

    /**
     * Footer «online / recently active» pill — must register before heavy Socket.IO handlers so a thrown error
     * elsewhere in this file cannot skip listeners (popover would never open).
     */
    (function initOnlinePresencePopoverEarly() {
        let popoverOpen = false;
        let ulpOnlinePopoverResizeObserver = null;
        let ulpOnlinePopoverSettleTimer = null;
        let ulpOnlinePopoverAnimEndHandler = null;
        let ulpOnlinePopoverRoRaf = null;

        function cleanupOnlinePopoverWatchers(cardEl) {
            if (ulpOnlinePopoverSettleTimer) {
                clearTimeout(ulpOnlinePopoverSettleTimer);
                ulpOnlinePopoverSettleTimer = null;
            }
            if (ulpOnlinePopoverResizeObserver) {
                try {
                    ulpOnlinePopoverResizeObserver.disconnect();
                } catch (e) {
                    /* ignore */
                }
                ulpOnlinePopoverResizeObserver = null;
            }
            if (ulpOnlinePopoverRoRaf) {
                cancelAnimationFrame(ulpOnlinePopoverRoRaf);
                ulpOnlinePopoverRoRaf = null;
            }
            const c = cardEl || document.querySelector('#ulp-online-popover .ulp-online-popover__card');
            if (c && ulpOnlinePopoverAnimEndHandler) {
                c.removeEventListener('animationend', ulpOnlinePopoverAnimEndHandler);
                ulpOnlinePopoverAnimEndHandler = null;
            }
        }

        function getPop() {
            return document.getElementById('ulp-online-popover');
        }
        function getListEl() {
            return document.getElementById('ulp-online-popover-list');
        }
        function getEmptyEl() {
            return document.getElementById('ulp-online-popover-empty');
        }
        function getTitleEl() {
            return document.getElementById('ulp-online-popover-title');
        }

        function getGuestMetaEl() {
            return document.getElementById('ulp-online-popover-guest-meta');
        }

        function getTrigger() {
            return document.getElementById('ulp-online-dot-trigger');
        }

        function setAriaExpanded(exp) {
            const btn = getTrigger();
            if (btn) btn.setAttribute('aria-expanded', exp ? 'true' : 'false');
        }

        function detachPopoverLayoutListeners() {
            window.removeEventListener('resize', positionPopover);
        }

        /** Popover is absolute inside .ulp-online-anchor; width matches main column (footer has nested .container). */
        function positionPopover() {
            const pop = getPop();
            const btn = getTrigger();
            if (!pop || !btn) return;
            const card = pop.querySelector('.ulp-online-popover__card');
            if (!card) return;

            pop.style.left = '';
            pop.style.right = '';
            pop.style.top = '';
            pop.style.bottom = '';
            pop.style.width = '';

            const anchor = pop.closest('.ulp-online-anchor');
            const mainEl = document.querySelector('main.container') || document.querySelector('main');
            if (anchor && mainEl) {
                const ar = anchor.getBoundingClientRect();
                let pl = 0;
                let pr = 0;
                try {
                    const st = window.getComputedStyle(mainEl);
                    pl = parseFloat(st.paddingLeft) || 0;
                    pr = parseFloat(st.paddingRight) || 0;
                } catch (e) {
                    /* ignore */
                }
                const mr = mainEl.getBoundingClientRect();
                const innerW = Math.max(100, mr.width - pl - pr);
                const innerLeft = mr.left + pl;
                pop.style.left = `${Math.round(innerLeft - ar.left)}px`;
                pop.style.width = `${Math.round(innerW)}px`;
                pop.style.right = 'auto';
            }

            const br = btn.getBoundingClientRect();
            const ih = window.innerHeight;
            const ch = card.getBoundingClientRect().height || card.offsetHeight || 120;
            const gap = 8;

            let placement = 'above';
            if (br.top < ch + gap) {
                placement = 'below';
            }
            if (placement === 'below' && ih - br.bottom < ch + gap && br.top >= ch + gap) {
                placement = 'above';
            }

            pop.dataset.placement = placement;
            card.dataset.placement = placement;
            const trig = getTrigger();
            if (trig) {
                trig.dataset.ulpPopoverPlacement = placement;
            }
        }

        function getOnlinePopoverMode() {
            const btn = getTrigger();
            return (btn && btn.dataset.ulpOnlineMode) || 'recent';
        }

        function setOnlinePopoverGuestMeta(guestMetaEl, guestCount) {
            if (!guestMetaEl) return;
            const n = Math.max(0, Math.floor(Number(guestCount) || 0));
            if (n > 0) {
                guestMetaEl.textContent = `${n} guest${n === 1 ? '' : 's'}`;
                guestMetaEl.removeAttribute('hidden');
            } else {
                guestMetaEl.textContent = '';
                guestMetaEl.setAttribute('hidden', '');
            }
        }

        function resolveLiveGuestCount(data, listedUsersLen) {
            if (!data) return 0;
            let resolved = 0;
            const live = Number(data.live_guests);
            if (Number.isFinite(live) && live >= 0) {
                resolved = Math.floor(live);
            } else {
                const guests = Number(data.guests);
                if (Number.isFinite(guests) && guests >= 0) {
                    resolved = Math.floor(guests);
                } else {
                    const registered = Number(data.registered_count);
                    const total = Number(data.count);
                    if (Number.isFinite(registered) && Number.isFinite(total) && total >= registered) {
                        resolved = Math.max(0, Math.floor(total - registered));
                    }
                }
            }
            const total = Number(data.count);
            if (Number.isFinite(total) && total > listedUsersLen) {
                resolved = Math.max(resolved, Math.floor(total - listedUsersLen));
            }
            return resolved;
        }

        function renderLiveOnlinePresence(data) {
            const listEl = getListEl();
            const emptyEl = getEmptyEl();
            const titleEl = getTitleEl();
            const guestMetaEl = getGuestMetaEl();
            if (!listEl || !emptyEl) return;
            listEl.innerHTML = '';
            const entries = Array.isArray(data.entries) ? data.entries : [];
            const users = entries.filter((entry) => entry && entry.kind === 'user' && entry.username_html);
            const guestCount = resolveLiveGuestCount(data, users.length);
            if (titleEl) {
                titleEl.textContent = 'Online now';
            }
            setOnlinePopoverGuestMeta(guestMetaEl, guestCount);
            if (!users.length && guestCount === 0) {
                emptyEl.hidden = false;
                return;
            }
            emptyEl.hidden = true;
            users.forEach((entry) => {
                const li = document.createElement('li');
                li.className = 'ulp-online-popover__user-row';
                li.innerHTML = String(entry.username_html);
                listEl.appendChild(li);
            });
        }

        function renderWidgetPresence(data) {
            const listEl = getListEl();
            const emptyEl = getEmptyEl();
            const titleEl = getTitleEl();
            const guestMetaEl = getGuestMetaEl();
            if (!listEl || !emptyEl) return;
            listEl.innerHTML = '';
            const guests = Number(data.guests) || 0;
            const users = Array.isArray(data.users) ? data.users : [];
            if (titleEl) {
                titleEl.textContent = 'Recently active';
            }
            setOnlinePopoverGuestMeta(guestMetaEl, guests);
            if (!users.length && guests === 0) {
                emptyEl.hidden = false;
                setOnlinePopoverGuestMeta(guestMetaEl, 0);
                return;
            }
            emptyEl.hidden = true;
            users.forEach((u) => {
                const li = document.createElement('li');
                li.className = 'ulp-online-popover__user-row';
                const rawHtml = u && u.username_html ? String(u.username_html) : '';
                if (rawHtml) li.innerHTML = rawHtml;
                listEl.appendChild(li);
            });
        }

        /** Prepare list / empty state from API payload (popover stays closed until revealPopover). */
        function applyPresencePayload(data) {
            const listEl = getListEl();
            const emptyEl = getEmptyEl();
            if (!listEl || !emptyEl) return;
            listEl.innerHTML = '';
            const gm = getGuestMetaEl();
            if (gm) {
                gm.textContent = '';
                gm.hidden = true;
            }
            if (!data) {
                emptyEl.hidden = false;
                return;
            }
            if (Array.isArray(data.entries)) {
                renderLiveOnlinePresence(data);
            } else {
                renderWidgetPresence(data);
            }
        }

        function fetchPresencePopoverJson(timeoutMs) {
            const ctrl = new AbortController();
            const ms = typeof timeoutMs === 'number' && timeoutMs > 0 ? timeoutMs : 12000;
            const tid = setTimeout(() => ctrl.abort(), ms);
            const url = getOnlinePopoverMode() === 'live' ? '/api/online-now' : '/api/widget-presence';
            return fetch(url, { credentials: 'omit', signal: ctrl.signal }).finally(() =>
                clearTimeout(tid),
            );
        }

        /** Show loading on the clicked pill; open popover after presence API returns (or times out). */
        function fetchPresenceThenReveal(btn) {
            btn.classList.add('ulp-online-dot-btn--loading');
            btn.setAttribute('aria-busy', 'true');
            fetchPresencePopoverJson(12000)
                .then((r) => (r.ok ? r.json() : null))
                .then((data) => {
                    applyPresencePayload(data);
                })
                .catch(() => {
                    applyPresencePayload(null);
                })
                .finally(() => {
                    btn.classList.remove('ulp-online-dot-btn--loading');
                    btn.removeAttribute('aria-busy');
                    revealPopover();
                });
        }

        function closePopover() {
            detachPopoverLayoutListeners();
            popoverOpen = false;
            cleanupOnlinePopoverWatchers(null);
            const pop = getPop();
            if (pop) pop.hidden = true;
            setAriaExpanded(false);
            const trig = getTrigger();
            if (trig) {
                trig.classList.remove('ulp-online-dot-btn--attached');
                trig.classList.remove('ulp-online-dot-btn--loading');
                trig.removeAttribute('aria-busy');
                trig.removeAttribute('data-ulp-popover-placement');
            }
        }

        function revealPopover() {
            const pop = getPop();
            if (!pop) return;
            cleanupOnlinePopoverWatchers(null);
            popoverOpen = true;
            pop.hidden = false;
            const trig = getTrigger();
            if (trig) {
                trig.classList.add('ulp-online-dot-btn--attached');
            }
            setAriaExpanded(true);
            window.addEventListener('resize', positionPopover);
            positionPopover();
            requestAnimationFrame(() => positionPopover());
            const card = pop.querySelector('.ulp-online-popover__card');
            if (card) {
                ulpOnlinePopoverAnimEndHandler = (ev) => {
                    if (ev.target !== card) return;
                    if (ev.animationName && String(ev.animationName).indexOf('ulp-online-popover-reveal') === -1) {
                        return;
                    }
                    if (popoverOpen) positionPopover();
                };
                card.addEventListener('animationend', ulpOnlinePopoverAnimEndHandler);
                ulpOnlinePopoverResizeObserver = new ResizeObserver(() => {
                    if (!popoverOpen) return;
                    if (ulpOnlinePopoverRoRaf) cancelAnimationFrame(ulpOnlinePopoverRoRaf);
                    ulpOnlinePopoverRoRaf = requestAnimationFrame(() => {
                        ulpOnlinePopoverRoRaf = null;
                        positionPopover();
                    });
                });
                try {
                    ulpOnlinePopoverResizeObserver.observe(card);
                } catch (e) {
                    /* ignore */
                }
            }
            ulpOnlinePopoverSettleTimer = setTimeout(() => {
                ulpOnlinePopoverSettleTimer = null;
                if (popoverOpen) positionPopover();
            }, 420);
        }

        document.addEventListener(
            'click',
            (ev) => {
                const pop = getPop();
                const btn = ev.target.closest('#ulp-online-dot-trigger');
                if (btn) {
                    ev.preventDefault();
                    ev.stopPropagation();
                    if (btn.classList.contains('ulp-online-dot-btn--loading')) {
                        return;
                    }
                    if (popoverOpen) {
                        closePopover();
                    } else {
                        fetchPresenceThenReveal(btn);
                    }
                    return;
                }
                if (ev.target.closest('.ulp-online-popover__close')) {
                    closePopover();
                    return;
                }
                if (!popoverOpen || !pop || pop.hidden) return;
                if (!ev.target.closest('#ulp-online-popover') && !ev.target.closest('#ulp-online-dot-trigger')) {
                    closePopover();
                }
            },
            true,
        );

        document.addEventListener('keydown', (ev) => {
            if (ev.key === 'Escape' && popoverOpen) {
                closePopover();
            }
        });

        document.addEventListener('pageLoaded', () => {
            if (popoverOpen) closePopover();
        });

        function hookOnlinePopoverSocketRefresh() {
            if (window.__ulpOnlinePopoverSocketHooked) return;
            window.__ulpOnlinePopoverSocketHooked = true;
            let last = 0;
            const refreshIfOpen = () => {
                const pop = getPop();
                if (!popoverOpen || !pop || pop.hidden) return;
                const n = Date.now();
                if (n - last < 3500) return;
                last = n;
                fetchPresencePopoverJson(10000)
                    .then((r) => (r.ok ? r.json() : null))
                    .then((data) => {
                        if (!data || !popoverOpen) return;
                        if (Array.isArray(data.entries)) {
                            renderLiveOnlinePresence(data);
                        } else {
                            renderWidgetPresence(data);
                        }
                        positionPopover();
                    })
                    .catch(() => {});
            };
            const attach = (s) => {
                if (!s || s.__ulpOnlinePopoverListener) return;
                s.__ulpOnlinePopoverListener = true;
                s.on('update_global_online', refreshIfOpen);
            };
            const tryHook = () => {
                const s =
                    window._realtimeSocket ||
                    (typeof window.getSharedSocket === 'function' && window.getSharedSocket());
                if (s && s.connected) {
                    attach(s);
                    return;
                }
                setTimeout(tryHook, 400);
            };
            tryHook();
        }
        hookOnlinePopoverSocketRefresh();
    })();

    const stripGrantedFromBadgeHtml = (html) => {
        if (!html || html.toLowerCase().indexOf('granted:') === -1) return html;
        let s = html;
        const reCls =
            /(?:<br\s*\/?>)*\s*<span[^>]*\bnotif-granted-line\b[^>]*>[\s\S]*?<\/span>(?:\s*<br\s*\/?>)*/gi;
        const reLoose =
            /(?:<br\s*\/?>)*\s*<span[^>]*>\s*Granted:[\s\S]*?<\/span>(?:\s*<br\s*\/?>)*/gi;
        const rePlain = /(?:<br\s*\/?>)+(?:\s*)Granted:[^<]*/gi;
        for (let i = 0; i < 8; i++) {
            const t = s.replace(reCls, '').replace(reLoose, '');
            if (t === s) break;
            s = t;
        }
        for (let i = 0; i < 4; i++) {
            const t = s.replace(rePlain, '');
            if (t === s) break;
            s = t;
        }
        return s.trim();
    };

    const stripEmptyReasonFromBadgeHtml = (html) => {
        if (!html || html.toLowerCase().indexOf('reason:') === -1) return html;
        let s = html;
        const reDash =
            /<span[^>]*\bnotif-detail\b[^>]*>\s*Reason:\s*(?:—|-|…|\.{3}|&#8212;|&mdash;|&#x2013;)\s*<\/span>(?:\s*<br\s*\/?>)*/gi;
        const reBlank =
            /<span[^>]*\bnotif-detail\b[^>]*>\s*Reason:\s*<\/span>(?:\s*<br\s*\/?>)*/gi;
        for (let i = 0; i < 10; i++) {
            const t = s.replace(reDash, '').replace(reBlank, '');
            if (t === s) break;
            s = t;
        }
        return s.trim();
    };

    const legacyStrongBadgeToPrimary = (html) => {
        if (!html || html.toLowerCase().indexOf('notif-msg-primary') !== -1) return html;
        const m = html.match(/^\s*(<strong[^>]*>[\s\S]*?<\/strong>)\s*(?:<br\s*\/?>)\s*([\s\S]*)\s*$/i);
        if (!m) return html;
        const title = m[1].trim();
        const rest = (m[2] || '').trim();
        const sm = title.match(/<strong[^>]*>([\s\S]*?)<\/strong>/i);
        if (!sm) return html;
        const nameHtml = (sm[1] || '').trim();
        if (!nameHtml) return html;
        let reasonTail = '';
        const rsm = rest.match(/<span[^>]*\bnotif-detail\b[^>]*>\s*Reason:\s*([\s\S]*?)<\/span>/i);
        if (rsm) {
            const body = (rsm[1] || '').trim();
            if (
                body &&
                body !== '—' &&
                body !== '-' &&
                body !== '…' &&
                body !== '...' &&
                body !== '&mdash;' &&
                body !== '&#8212;' &&
                body !== '&#x2013;'
            ) {
                reasonTail = '<br><span class="notif-detail">Reason: ' + body + '</span>';
            }
        }
        const primary =
            '<span class="notif-msg-primary"><i class="fas fa-award" aria-hidden="true"></i> ' +
            '<b class="notif-ach-inline-label">Achievement unlocked</b> — ' +
            'Staff added the <strong>' +
            nameHtml +
            '</strong> badge to your profile.</span>';
        return primary + reasonTail;
    };

    /**
     * Match server-side wrap_notification_message_for_compact_layout (alerts dropdown grid).
     */
    const notifInlineTitleWithOptionalColon = (title, rest, notifType) => {
        let t = String(title || '').trim();
        const r = String(rest || '').trim();
        if (!r) return t;
        const nt = String(notifType || '').toLowerCase();
        if (nt === 'like' || nt === 'comment' || nt === 'approval') {
            if (t && /<\/span>\s*$/i.test(t)) {
                if (!/[:.!?]\s*<\/span>\s*$/i.test(t)) {
                    t = t.replace(/<\/span>\s*$/i, ':</span>');
                }
            } else if (t && !/[:.!?]\s*$/.test(t)) {
                t += ':';
            }
        }
        return (t ? t + ' ' : '') + r;
    };

    const inferKindFromApprovalHead = (headText) => {
        const low = String(headText || '').toLowerCase();
        if (low.indexOf('comment') !== -1) return 'comment';
        if (low.indexOf('forum') !== -1 || low.indexOf(' post') !== -1) return 'post';
        if (low.indexOf('resource') !== -1) return 'resource';
        if (low.indexOf('file') !== -1) return 'file';
        return 'content';
    };

    const kindLabelForApproval = (kind) => {
        const map = { file: 'file', resource: 'resource', listing: 'resource', comment: 'comment', post: 'forum post', content: 'content' };
        return map[String(kind || '').toLowerCase()] || 'content';
    };

    const buildApprovalInlineMessage = (kind, title, link) => {
        const esc = (s) =>
            String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        const label = kindLabelForApproval(kind);
        const primary =
            '<span class="notif-msg-primary"><b class="notif-approved">approved</b> your ' +
            esc(label) +
            '</span>';
        const safeTitle = esc((title || '').trim().slice(0, 200) || '—');
        const href = String(link || '').trim();
        const tail = href
            ? '<a href="' + esc(href) + '" class="notif-link notif-entity-title">' + safeTitle + '</a>'
            : safeTitle;
        return primary + tail;
    };

    const coerceApprovalCompactToInline = (html) => {
        const raw = String(html || '').trim();
        if (!raw || /notif-msg-primary/i.test(raw)) return raw;
        if (raw.indexOf('notif-msg-compact') === -1) return raw;
        const titleM = raw.match(/<div[^>]*\bnotif-msg-compact__title\b[^>]*>([\s\S]*?)<\/div>/i);
        if (!titleM) return raw;
        const headPlain = (titleM[1] || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        const kind = inferKindFromApprovalHead(headPlain);
        const linkM = raw.match(/<a[^>]*\bnotif-(?:link|entity-title)\b[^>]*>[\s\S]*?<\/a>/i);
        let detail = '';
        let href = '';
        if (linkM) {
            detail = (linkM[0].match(/>([\s\S]*?)<\/a>/i) || [])[1] || '';
            detail = detail.replace(/<[^>]+>/g, '').trim();
            const hrefM = linkM[0].match(/href\s*=\s*["']([^"']+)["']/i);
            href = hrefM ? hrefM[1] : '';
        }
        return buildApprovalInlineMessage(kind, detail || '—', href);
    };

    const coerceLegacyApprovalSentenceToInline = (html) => {
        const raw = String(html || '').trim();
        if (!raw || /notif-msg-primary/i.test(raw)) return raw;
        if (!/has been approved/i.test(raw)) return raw;
        const linkM = raw.match(/<a[^>]*\bnotif-(?:link|entity-title)\b[^>]*>[\s\S]*?<\/a>/i);
        let detail = '';
        let href = '';
        if (linkM) {
            detail = (linkM[0].match(/>([\s\S]*?)<\/a>/i) || [])[1] || '';
            detail = detail.replace(/<[^>]+>/g, '').trim();
            const hrefM = linkM[0].match(/href\s*=\s*["']([^"']+)["']/i);
            href = hrefM ? hrefM[1] : '';
        } else {
            const textOnly = raw.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
            const dm = textOnly.match(/(?:on|in)\s+(.+?)\s+has been approved/i);
            if (dm) detail = dm[1].trim();
        }
        const low = raw.toLowerCase();
        const kind = low.indexOf('comment') !== -1 ? 'comment' : low.indexOf('post') !== -1 ? 'post' : 'file';
        return buildApprovalInlineMessage(kind, detail || '—', href);
    };

    const unwrapNotifEntityLinks = (html) => {
        const raw = String(html || '');
        if (!raw || raw.toLowerCase().indexOf('<a') === -1) return raw;
        return raw.replace(
            /<a[^>]*\bclass\s*=\s*["'][^"']*\bnotif-(?:link|entity-title)\b[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi,
            (_, inner) => {
                const text = String(inner || '')
                    .replace(/<[^>]+>/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();
                return text
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;') || '—';
            }
        );
    };

    const normalizeApprovalNotificationHtml = (html) => {
        const raw = String(html || '').trim();
        if (!raw || /notif-msg-primary/i.test(raw)) return raw;
        if (raw.indexOf('notif-msg-compact') !== -1) return coerceApprovalCompactToInline(raw);
        if (/has been approved/i.test(raw)) return coerceLegacyApprovalSentenceToInline(raw);
        return raw;
    };

    const splitNotifPrimarySpan = (rawHtml) => {
        const raw = String(rawHtml || '');
        const openRe = /<span[^>]*\bnotif-msg-primary\b[^>]*>/i;
        const openMatch = openRe.exec(raw);
        if (!openMatch || openMatch.index == null) return null;

        const start = openMatch.index;
        const tagsRe = /<span\b[^>]*>|<\/span\s*>/gi;
        tagsRe.lastIndex = start + openMatch[0].length;
        let depth = 1;
        let m;
        while ((m = tagsRe.exec(raw)) !== null) {
            const token = String(m[0] || '').toLowerCase();
            if (token.startsWith('<span')) depth += 1;
            else depth -= 1;
            if (depth === 0) {
                const end = tagsRe.lastIndex;
                return {
                    title: raw.slice(start, end),
                    rest: raw.slice(end).trim()
                };
            }
        }
        return null;
    };

    const normalizeModerationRemovalHtml = (html) => {
        const raw = String(html || '').trim();
        if (!raw) return raw;
        const low = raw.toLowerCase();
        if (low.indexOf('notif-msg-compact__rest') !== -1 && low.indexOf('notif-msg-compact__body') === -1) {
            return raw;
        }
        const titleM = raw.match(/<div[^>]*\bnotif-msg-compact__title\b[^>]*>([\s\S]*?)<\/div>/i);
        if (!titleM) return raw;
        const titleInner = (titleM[1] || '').trim();
        const bodyM = raw.match(/<div[^>]*\bnotif-msg-compact__body\b[^>]*>([\s\S]*?)<\/div>/i);
        const reasonM = raw.match(
            /<div[^>]*\bnotif-msg-compact__reason\b[^>]*>\s*Reason:\s*([\s\S]*?)<\/div>/i
        );
        let entity = '';
        if (bodyM) entity = (bodyM[1] || '').replace(/<[^>]+>/g, '').trim();
        let reason = '';
        if (reasonM) reason = (reasonM[1] || '').replace(/<[^>]+>/g, '').trim();
        const esc = (s) =>
            String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        const parts = [];
        if (entity) parts.push('<span class="notif-detail">' + esc(entity) + '</span>');
        if (reason) {
            parts.push(
                '<span class="notif-detail notif-detail--reason">Reason: ' + esc(reason) + '</span>'
            );
        }
        if (!parts.length) return raw;
        return (
            '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' +
            titleInner +
            '</div><div class="notif-msg-compact__rest">' +
            parts.join('') +
            '</div></div>'
        );
    };

    const applyPendingModerationCount = (count) => {
        const n = Math.max(0, parseInt(count, 10) || 0);
        const badge = document.getElementById('pending-badge');
        if (badge) {
            badge.innerText = String(n);
            if (n > 0) {
                badge.classList.remove('hidden');
                badge.style.display = 'grid';
                badge.style.animation = 'none';
                badge.offsetHeight;
                badge.style.animation = 'pulse-glow 1s ease-out';
            } else {
                badge.classList.add('hidden');
                badge.style.display = 'none';
            }
        }
        document.querySelectorAll('.js-pending-moderation-count').forEach((el) => {
            el.textContent = String(n);
        });
        const overviewVal = document.getElementById('pending-overview-count');
        if (overviewVal) overviewVal.textContent = String(n);
        const queueTotal = document.getElementById('pending-queue-total');
        if (queueTotal) queueTotal.textContent = String(n);
        document.querySelectorAll('.adm-overview-kpi--pending-slot').forEach((kpi) => {
            kpi.classList.toggle('adm-overview-kpi--warn', n > 0);
        });
        const queueBanner = document.getElementById('adm-overview-pending-banner');
        if (queueBanner) {
            queueBanner.classList.toggle('adm-overview-pending--clear', n === 0);
        }
    };
    window.applyPendingModerationCount = applyPendingModerationCount;

    const requestPendingCountRefresh = () => {
        const hasStaffPendingUi =
            document.getElementById('pending-badge') ||
            document.querySelector('.js-pending-moderation-count');
        if (!hasStaffPendingUi) return;
        const sock =
            (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
            window.socket ||
            null;
        if (sock && sock.connected) {
            sock.emit('request_pending_count');
        }
    };
    window.requestPendingCountRefresh = requestPendingCountRefresh;

    const onPendingCountSocketPayload = (data) => {
        if (!data || typeof data.count === 'undefined') return;
        applyPendingModerationCount(data.count);
    };

    const bindPendingCountSocketHandlers = (sock) => {
        if (!sock) return;
        if (sock._ulpPendingCountBound) return;
        sock._ulpPendingCountBound = true;
        sock.on('update_pending_count', onPendingCountSocketPayload);
    };
    window.__ulpBindPendingCountSocketHandlers = bindPendingCountSocketHandlers;
    if (socket) {
        bindPendingCountSocketHandlers(socket);
    }

    /** Corner toast: block lines so filename and "Reason:" do not glue (inline spans). */
    const formatNotificationHtmlForToast = (html) => {
        const raw = String(html || '').trim();
        if (!raw || raw.indexOf('notif-msg-compact') === -1) return raw;
        const wrap = document.createElement('div');
        wrap.innerHTML = raw;
        const titleEl = wrap.querySelector('.notif-msg-compact__title');
        const lines = [];
        const esc = (s) =>
            String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        const pushDetail = (elOrText, isReason) => {
            let html = '';
            let plain = '';
            if (elOrText && elOrText.nodeType === 1) {
                const anchor = elOrText.querySelector('a.notif-link, a.notif-entity-title');
                if (anchor) {
                    html = anchor.outerHTML;
                    plain = (anchor.textContent || '').trim();
                } else {
                    plain = (elOrText.textContent || '').trim();
                }
            } else {
                plain = String(elOrText || '').replace(/\s+/g, ' ').trim();
            }
            if (!plain && !html) return;
            const cls = isReason
                ? 'ulp-toast-notif-detail ulp-toast-notif-detail--reason'
                : 'ulp-toast-notif-detail';
            lines.push('<div class="' + cls + '">' + (html || esc(plain)) + '</div>');
        };
        if (titleEl) {
            lines.push('<div class="ulp-toast-notif-lead">' + titleEl.innerHTML + '</div>');
        }
        wrap.querySelectorAll('.notif-msg-compact__rest .notif-detail').forEach((el) => {
            const plain = (el.textContent || '').trim();
            pushDetail(el, /^reason:/i.test(plain));
        });
        if (!wrap.querySelector('.notif-msg-compact__rest .notif-detail')) {
            const bodyEl = wrap.querySelector('.notif-msg-compact__body');
            const reasonEl = wrap.querySelector('.notif-msg-compact__reason');
            if (bodyEl) pushDetail((bodyEl.textContent || '').trim(), false);
            if (reasonEl) pushDetail((reasonEl.textContent || '').trim(), true);
        }
        return lines.length ? lines.join('') : raw;
    };

    const wrapNotificationDropdownMessage = (messageHtml, notifType) => {
        const raw0 = String(messageHtml || '').trim();
        if (!raw0) return '';
        const nt0 = String(notifType || '').toLowerCase();
        let raw = raw0;
        if (
            nt0 === 'moderation' ||
            raw.toLowerCase().indexOf('moderation-removal') !== -1 ||
            raw.toLowerCase().indexOf('notif-msg-compact__body') !== -1
        ) {
            raw = normalizeModerationRemovalHtml(raw);
            raw = unwrapNotifEntityLinks(raw);
        }
        const nt = String(notifType || '').toLowerCase();
        if (nt === 'approval' || raw0.toLowerCase().indexOf('has been approved') !== -1) {
            raw = normalizeApprovalNotificationHtml(raw);
        }
        if (raw.indexOf('notif-msg-compact') !== -1) return raw;
        if (nt === 'like' || nt === 'comment' || nt === 'approval') {
            const split = splitNotifPrimarySpan(raw);
            if (split && split.title) {
                const title = split.title;
                const rest = (split.rest || '').trim();
                if (rest) {
                    const inline = notifInlineTitleWithOptionalColon(title, rest, nt);
                    return (
                        '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' +
                        inline +
                        '</div></div>'
                    );
                }
                return (
                    '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' + title + '</div></div>'
                );
            }
            // Legacy alerts may miss notif-msg-primary; keep "... on <file>" in one line.
            const mLegacy = raw.match(/^(.*?)(<a[^>]*\bnotif-entity-title\b[^>]*>[\s\S]*?<\/a>)\s*$/i);
            if (mLegacy) {
                const lead = (mLegacy[1] || '').replace(/(?:\s*<br\s*\/?>\s*)+/gi, ' ').trim();
                const tail = (mLegacy[2] || '').trim();
                const inline = notifInlineTitleWithOptionalColon(lead, tail, nt);
                return (
                    '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' +
                    inline +
                    '</div></div>'
                );
            }
        }
        if (nt === 'group_badge') {
            const rawGb = legacyStrongBadgeToPrimary(
                stripEmptyReasonFromBadgeHtml(stripGrantedFromBadgeHtml(raw))
            );
            const split = splitNotifPrimarySpan(rawGb);
            if (split && split.title) {
                let title = split.title;
                const rest = (split.rest || '').trim();
                if (rest) {
                    return (
                        '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' +
                        title +
                        '</div><div class="notif-msg-compact__rest">' +
                        rest +
                        '</div></div>'
                    );
                }
                if (title.indexOf('notif-ach-inline-label') === -1 && title.indexOf('Achievement unlocked') === -1) {
                    title = title.replace(
                        /^(<span[^>]*\bnotif-msg-primary\b[^>]*>)(\s*(?:<i\b[^>]*>[\s\S]*?<\/i>\s*)?)/i,
                        '$1$2<b class="notif-ach-inline-label">Achievement unlocked</b> — '
                    );
                }
                return (
                    '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' + title + '</div></div>'
                );
            }
            const m = rawGb.match(/^\s*(<strong[^>]*>[\s\S]*?<\/strong>)\s*(?:<br\s*\/?>)\s*([\s\S]*)\s*$/i);
            if (m) {
                const title = m[1];
                let rest = (m[2] || '').trim();
                if (!rest) {
                    rest =
                        '<span class="notif-detail notif-ach-lead">Achievement unlocked. This achievement was added to your profile.</span>';
                }
                return (
                    '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' +
                    title +
                    '</div><div class="notif-msg-compact__rest">' +
                    rest +
                    '</div></div>'
                );
            }
        }
        if (raw.indexOf('<') === -1) {
            const esc = raw
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
            return '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' + esc + '</div></div>';
        }
        return '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' + raw + '</div></div>';
    };
    window.wrapNotificationDropdownMessage = wrapNotificationDropdownMessage;

    // Corner toasts: must work for AJAX (bump, delete) even when Socket.IO is unavailable.
    // Toast Container (Lazy Create)
    function getToastContainer() {
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            const dock = document.getElementById('ulp-corner-dock');
            if (dock) {
                dock.insertBefore(container, dock.firstChild);
            } else {
                document.body.appendChild(container);
            }
        }
        return container;
    }

    // Show Toast Function
    window.showToast = function (title, message, link, iconClass = 'fas fa-bell', notificationId = null, notifType = null, persistent = false) {
        const LEGACY_TYPE = { error: 1, danger: 1, success: 1, warning: 1, info: 1 };
        const normalizeLegacyKeyword = (kw) => (kw === 'danger' ? 'error' : kw);

        // Legacy: showToast(body, 'error'|'success'|'warning'|'info') — 2nd arg was used as a type keyword
        if (typeof message === 'string' && LEGACY_TYPE[message.toLowerCase()]) {
            const kw = normalizeLegacyKeyword(message.toLowerCase());
            const body = title;
            title = '';
            message = typeof body === 'string' ? body : '';
            notifType = notifType || kw;
            if (!iconClass || iconClass === 'fas fa-bell') {
                iconClass = kw === 'success' ? 'fas fa-check-circle'
                    : kw === 'warning' ? 'fas fa-triangle-exclamation'
                        : kw === 'info' ? 'fas fa-info-circle'
                            : 'fas fa-circle-exclamation';
            }
        } else {
            const tRaw = String(title || '').trim();
            const tKey = tRaw.toLowerCase();
            // Legacy: showToast('error'|'success'|..., body) — title was only the type keyword
            if (LEGACY_TYPE[tKey] && tRaw.length === tKey.length) {
                const kw = normalizeLegacyKeyword(tKey);
                const body = message;
                title = kw === 'success' ? 'Success' : kw === 'warning' ? 'Notice' : kw === 'info' ? 'Info' : 'Error';
                message = typeof body === 'string' ? body : '';
                notifType = notifType || kw;
                if (!iconClass || iconClass === 'fas fa-bell') {
                    iconClass = kw === 'success' ? 'fas fa-check-circle'
                        : kw === 'warning' ? 'fas fa-triangle-exclamation'
                            : kw === 'info' ? 'fas fa-info-circle'
                                : 'fas fa-circle-exclamation';
                }
            }
        }

        const container = getToastContainer();
        const toast = document.createElement('div');
        const cleanTitle = (title || '').trim();
        const hasTitle = cleanTitle && !['new notification', 'new alert', 'system broadcast', 'notification', 'alert'].includes(cleanTitle.toLowerCase());
        const iconLower = String(iconClass || '').toLowerCase();
        let notifLower = String(notifType || '').toLowerCase();
        if (notifLower === 'danger') notifLower = 'error';
        if (notifLower === 'moderation') {
            link = null;
        }

        const toneMap = {
            like: { color: '#ff4757', border: 'rgba(255, 71, 87, 0.45)', glow: 'rgba(255, 71, 87, 0.18)' },
            comment: { color: '#4cd137', border: 'rgba(76, 209, 55, 0.45)', glow: 'rgba(76, 209, 55, 0.18)' },
            payment: { color: '#facc15', border: 'rgba(250, 204, 21, 0.45)', glow: 'rgba(250, 204, 21, 0.18)' },
            mention: { color: '#00ff9d', border: 'rgba(0, 255, 157, 0.45)', glow: 'rgba(0, 255, 157, 0.18)' },
            group_badge: { color: '#fff1c9', border: 'rgba(251, 191, 36, 0.48)', glow: 'rgba(245, 197, 66, 0.24)' },
            moderation: { color: '#a78bfa', border: 'rgba(167, 139, 250, 0.45)', glow: 'rgba(167, 139, 250, 0.18)' },
            approval: { color: '#2ed573', border: 'rgba(46, 213, 115, 0.5)', glow: 'rgba(46, 213, 115, 0.2)' },
            system: { color: 'var(--primary-color, #00ff9d)', border: 'rgba(0, 255, 157, 0.45)', glow: 'rgba(0, 255, 157, 0.14)' },
            error: { color: '#ff6b6b', border: 'rgba(255, 107, 107, 0.5)', glow: 'rgba(255, 107, 107, 0.2)' },
            success: { color: '#2ed573', border: 'rgba(46, 213, 115, 0.5)', glow: 'rgba(46, 213, 115, 0.2)' },
            warning: { color: '#ffa502', border: 'rgba(255, 165, 2, 0.5)', glow: 'rgba(255, 165, 2, 0.2)' },
            info: { color: '#74b9ff', border: 'rgba(116, 185, 255, 0.5)', glow: 'rgba(116, 185, 255, 0.2)' }
        };
        let tone = toneMap.system;
        if (notifLower && toneMap[notifLower]) {
            tone = toneMap[notifLower];
        } else if (iconLower.includes('heart')) {
            tone = toneMap.like;
        } else if (iconLower.includes('comment')) {
            tone = toneMap.comment;
        } else if (iconLower.includes('dollar') || iconLower.includes('credit') || iconLower.includes('bitcoin') || iconLower.includes('check-double')) {
            tone = toneMap.payment;
        } else if (iconLower.includes('at') || iconLower.includes('bullhorn')) {
            tone = toneMap.mention;
        } else if (iconLower.includes('shield') || iconLower.includes('ban') || iconLower.includes('gavel')) {
            tone = toneMap.moderation;
        } else if (iconLower.includes('check-circle') && notifLower !== 'error') {
            tone = toneMap.success;
        } else if (iconLower.includes('circle-exclamation') || iconLower.includes('exclamation-circle')) {
            tone = toneMap.error;
        } else if (iconLower.includes('triangle-exclamation') || (iconLower.includes('triangle') && iconLower.includes('exclamation'))) {
            tone = toneMap.warning;
        }

        // Unified broadcast-like styling (.realtime-toast — shell in style.css “corner notifications”)
        toast.className = 'realtime-toast';
        toast.style.border = `1px solid ${tone.border}`;
        toast.style.boxShadow = `0 10px 24px rgba(0, 0, 0, 0.45), 0 0 14px ${tone.glow}`;
        toast.style.cursor = link ? 'pointer' : 'default';

        const esc =
            typeof window.ulpEscapeHtml === 'function'
                ? window.ulpEscapeHtml
                : function (s) {
                      const d = document.createElement('div');
                      d.textContent = s == null ? '' : String(s);
                      return d.innerHTML;
                  };

        let toastBody = message;
        if (toastBody && String(toastBody).indexOf('<') !== -1) {
            const wrapped = wrapNotificationDropdownMessage(toastBody, notifType || notifLower);
            if (wrapped) toastBody = wrapped;
            if (String(toastBody).indexOf('notif-msg-compact') !== -1) {
                toastBody = formatNotificationHtmlForToast(toastBody);
            }
        } else if (toastBody != null && toastBody !== '') {
            toastBody = linkifyPlainTextForDisplay(toastBody);
        }

        const decodePlain = typeof window.decodePlainTextField === 'function'
            ? window.decodePlainTextField
            : (s) => (s == null ? '' : String(s));
        const safeTitle = esc(decodePlain(cleanTitle));

        toast.innerHTML = `
            <div class="ulp-corner-toast-iconCol" style="color: ${tone.color};">
                <i class="${iconClass}"></i>
            </div>
            <div class="ulp-corner-toast-textCol">
                ${hasTitle ? `<div class="ulp-site-banner-title" style="color: ${tone.color};">${safeTitle}</div>` : ''}
                <div class="ulp-site-banner-msg ulp-toast-message">${toastBody}</div>
            </div>
            <button type="button" class="ulp-corner-toast-close" aria-label="Dismiss">
                <i class="fas fa-times"></i>
            </button>
        `;

        const toastCloseBtn = toast.querySelector('.ulp-corner-toast-close');
        if (toastCloseBtn) {
            toastCloseBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                e.preventDefault();
                toast.style.transform = 'translateX(-120%)';
                setTimeout(() => toast.remove(), 300);
            });
        }

        // Click Handler (SPA-aware)
        if (link && link !== '#') {
            toast.onclick = (e) => {
                e.stopPropagation();

                // Optimistic Remove
                toast.style.transform = 'translateX(-120%)';
                setTimeout(() => toast.remove(), 300);

                const navigate = () => {
                    if (typeof window.ulpNavigateHref === 'function') {
                        window.ulpNavigateHref(link);
                        return;
                    }
                    if (window.loadPage) {
                        document.body.style.cursor = 'wait';
                        window.loadPage(link);
                    } else {
                        window.location.href = link;
                    }
                };

                // If Notification ID exists, mark as read BEFORE navigating (using reliable FETCH)
                if (notificationId) {
                    const csrfTokenMeta = document.querySelector('meta[name="csrf-token"]');
                    const csrfToken = csrfTokenMeta ? csrfTokenMeta.getAttribute('content') : '';

                    fetch(`/notifications/read/${notificationId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRFToken': csrfToken
                        }
                    })
                        .catch(e => console.error('Toast mark read error:', e))
                        .finally(() => navigate());
                } else {
                    navigate();
                }
            };
        }

        // Add to DOM
        container.appendChild(toast);
        wireToastInlineLinks(toast);

        // Animate In
        requestAnimationFrame(() => {
            toast.style.transform = 'translateX(0)';
        });

        // Auto remove only when this toast is not persistent.
        if (!persistent) {
            setTimeout(() => {
                toast.style.transform = 'translateX(-120%)';
                setTimeout(() => toast.remove(), 300);
            }, TOAST_LIFETIME_MS);
        }
    };


    const formatCompactCount = (value) => {
        const raw = Number(value || 0);
        if (!Number.isFinite(raw)) return '0';
        const sign = raw < 0 ? '-' : '';
        const n = Math.abs(Math.trunc(raw));
        if (n < 1000) return `${sign}${n}`;
        const units = [
            { d: 1_000_000_000, s: 'b' },
            { d: 1_000_000, s: 'm' },
            { d: 1_000, s: 'k' },
        ];
        for (const u of units) {
            if (n >= u.d) {
                const v = n / u.d;
                const txt = (v >= 100 ? v.toFixed(0) : v.toFixed(1)).replace(/\.0$/, '');
                return `${sign}${txt}${u.s}`;
            }
        }
        return `${sign}${n}`;
    };
    window.formatCompactCount = formatCompactCount;

    /** Font Awesome <i> next to a .views-count / .downloads-count / .like-count / etc. */
    function ulpResolveStatIcon(countEl) {
        if (!countEl) return null;
        const prev = countEl.previousElementSibling;
        if (prev && prev.tagName && String(prev.tagName).toLowerCase() === 'i') return prev;
        const row = countEl.closest(
            '.telemetry-pod, .like-btn-container, .forum-post-like-toggle, .discussion-like-toggle'
        );
        if (!row || !row.querySelector) return null;
        return row.querySelector(':scope > i') || row.querySelector('i');
    }

    /** like | download | comment | default — drives icon colour in CSS keyframes. */
    function ulpStatPulseVariantFromCountEl(countEl) {
        if (!countEl) return 'default';
        if (countEl.classList && countEl.classList.contains('comment-count')) return 'comment';
        if (countEl.classList && countEl.classList.contains('downloads-count')) return 'download';
        if (countEl.classList && countEl.classList.contains('clicks-count')) return 'download';
        if (countEl.classList && countEl.classList.contains('like-count')) return 'like';
        if (countEl.classList && countEl.classList.contains('forum-author-stat-value')) {
            const pod = countEl.closest('.telemetry-pod');
            const k = pod && pod.getAttribute ? pod.getAttribute('data-forum-author-stat') : '';
            if (k === 'likes') return 'like';
            if (k === 'comments') return 'comment';
        }
        const ic = countEl.querySelector && countEl.querySelector(':scope > i');
        if (ic) {
            const cls = ic.className || '';
            if (/\bfa-heart\b/.test(cls)) return 'like';
            if (/\bfa-download\b/.test(cls)) return 'download';
            if (/\bfa-external-link|fa-up-right-from-square|fa-arrow-up-right-from-square\b/.test(cls)) {
                return 'download';
            }
            if (/\bfa-reply\b/.test(cls)) return 'comment';
            if (/\bfa-comment/.test(cls)) return 'comment';
        }
        return 'default';
    }

    function ulpStripRtStatPulseClasses(el) {
        if (!el || !el.classList) return;
        el.classList.remove(
            'ulp-rt-stat-pulse-icon',
            'ulp-rt-stat-pulse-icon--like',
            'ulp-rt-stat-pulse-icon--download',
            'ulp-rt-stat-pulse-icon--comment'
        );
    }

    function ulpNormalizeRtPulseVariant(variant) {
        const v = String(variant || 'default').toLowerCase();
        if (v === 'like' || v === 'download' || v === 'comment') return v;
        return 'default';
    }

    /** One-shot pulse on a stat <i> (or first <i> inside wrapper). variant: like | download | comment | default */
    function ulpAttachRealtimeStatPulse(target, variant) {
        if (!target || typeof target.classList === 'undefined') return;
        const v = ulpNormalizeRtPulseVariant(variant);
        let pulseEl = target;
        const tag = target.tagName ? String(target.tagName).toLowerCase() : '';
        if (tag !== 'i') {
            const inner =
                (target.querySelector && (target.querySelector(':scope > i') || target.querySelector('i'))) || null;
            pulseEl = inner || target;
        }
        try {
            ulpStripRtStatPulseClasses(pulseEl);
            void pulseEl.offsetWidth;
            pulseEl.classList.add('ulp-rt-stat-pulse-icon');
            if (v !== 'default') pulseEl.classList.add(`ulp-rt-stat-pulse-icon--${v}`);
            const done = () => {
                try {
                    ulpStripRtStatPulseClasses(pulseEl);
                } catch (e) { /* ignore */ }
                pulseEl.removeEventListener('animationend', done);
            };
            pulseEl.addEventListener('animationend', done, { once: true });
            setTimeout(() => {
                try {
                    ulpStripRtStatPulseClasses(pulseEl);
                } catch (e) { /* ignore */ }
            }, 900);
        } catch (e) { /* ignore */ }
    }
    window.__ulpPulseRealtimeStat = ulpAttachRealtimeStatPulse;

    function ulpPulseCommentCountSpan(countEl) {
        if (!countEl || !countEl.classList || !countEl.classList.contains('comment-count')) return;
        try {
            countEl.classList.remove('ulp-rt-stat-pulse-count--comment');
            void countEl.offsetWidth;
            countEl.classList.add('ulp-rt-stat-pulse-count--comment');
            setTimeout(() => {
                try {
                    countEl.classList.remove('ulp-rt-stat-pulse-count--comment');
                } catch (e) { /* ignore */ }
            }, 900);
        } catch (e) { /* ignore */ }
    }

    function ulpStatIntFromText(el) {
        if (!el) return NaN;
        const raw = String(el.textContent || '').replace(/,/g, '').trim();
        const compact = raw.match(/([\d.]+)\s*([km])\b/i);
        if (compact) {
            let n = parseFloat(compact[1]);
            if (!Number.isFinite(n)) return NaN;
            const suf = String(compact[2] || '').toLowerCase();
            if (suf === 'k') n *= 1000;
            else if (suf === 'm') n *= 1_000_000;
            return Math.round(n);
        }
        const t = raw.replace(/[^\d.-]/g, '').trim();
        if (!t) return NaN;
        const n = parseInt(t, 10);
        return Number.isFinite(n) ? n : NaN;
    }

    function ulpPulseIfNumericCountChanged(countEl, nextVal, hostSelector) {
        if (!countEl || nextVal === undefined || nextVal === null) return;
        const nextN = Number(nextVal);
        if (!Number.isFinite(nextN)) return;
        const prevN = ulpStatIntFromText(countEl);
        if (!Number.isFinite(prevN) || prevN !== nextN) {
            const variant = ulpStatPulseVariantFromCountEl(countEl);
            const icon = ulpResolveStatIcon(countEl);
            if (icon) ulpAttachRealtimeStatPulse(icon, variant);
            else {
                const host =
                    (hostSelector && countEl.closest(hostSelector)) ||
                    countEl.closest('.telemetry-pod') ||
                    countEl.closest('.like-btn-container') ||
                    countEl.closest('.forum-post-like-toggle') ||
                    countEl.closest('.discussion-like-toggle');
                if (host) ulpAttachRealtimeStatPulse(host, variant);
            }
            if (variant === 'comment' && countEl.classList && countEl.classList.contains('comment-count')) {
                ulpPulseCommentCountSpan(countEl);
            }
        }
    }

    window.__ulpPulseIfStatCountChanged = ulpPulseIfNumericCountChanged;

    function ulpCurrentUserId() {
        const host = (typeof window.__ulpGetFloatingChatRoot === 'function' && window.__ulpGetFloatingChatRoot())
            || document.querySelector('body > #chat-widget-container')
            || document.getElementById('chat-widget-container');
        const rawHost = host ? host.getAttribute('data-user-id') : '';
        const rawBody =
            (document.body && document.body.getAttribute && document.body.getAttribute('data-user-id')) || '';
        const raw = String(rawHost || rawBody || '').trim();
        const id = parseInt(String(raw || '0'), 10) || 0;
        return id;
    }

    const formatUsdPrice = (value) => {
        const n = Number(value);
        if (!Number.isFinite(n) || n <= 0) return '';
        const rounded = Math.round((n + Number.EPSILON) * 100) / 100;
        return rounded.toLocaleString('en-US', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 2,
        });
    };

    const invoiceStatusMap = {
        paid: {
            label: 'Paid',
            className: 'status-paid',
            icon: 'fas fa-check-circle'
        },
        expired: {
            label: 'Expired',
            className: 'status-expired',
            icon: 'fas fa-exclamation-circle'
        },
        processing: {
            label: 'Processing',
            className: 'status-processing',
            icon: 'fas fa-sync fa-spin'
        },
        pending: {
            label: 'Awaiting payment',
            className: 'status-pending',
            icon: 'fas fa-spinner fa-spin'
        }
    };

    const renderOrderStatusBadge = (status) => {
        const cfg = invoiceStatusMap[status] || invoiceStatusMap.pending;
        return `<span class="invoice-status-chip ${cfg.className}" data-order-status="${status}"><i class="${cfg.icon}" aria-hidden="true"></i><span class="invoice-status-chip__label">${cfg.label}</span></span>`;
    };

    const patchOrderStatus = (orderId, status) => {
        if (!orderId) return;
        const orderItems = document.querySelectorAll(`.order-item[data-order-id="${orderId}"]`);
        orderItems.forEach(item => {
            const statusContainer = item.querySelector('.data-status');
            if (statusContainer) {
                statusContainer.innerHTML = renderOrderStatusBadge(status);
            }
        });
    };


    const getAnnouncements = () => JSON.parse(sessionStorage.getItem('active_announcements') || '[]');
    const saveAnnouncements = (arr) => sessionStorage.setItem('active_announcements', JSON.stringify(arr));

    const syncBadge = () => {
        const stored = getAnnouncements();
        let badge = document.getElementById('global-badge');

        // If no stored announcements and no badge, do nothing
        if (stored.length === 0 && !badge) return;

        if (!badge && stored.length > 0) {
            const trigger = document.querySelector('.notification-trigger');
            if (trigger) {
                badge = document.createElement('span');
                badge.className = 'notification-badge';
                badge.id = 'global-badge';
                badge.innerText = '0';
                trigger.appendChild(badge);
            }
        }

        if (badge) {
            const currentVal = parseInt(badge.innerText) || 0;
            // Since we re-inject on load/SPA swap, we should only add if not already accounted for.
            // A simpler way: when we inject, we just make sure the badge reflects the total.
            // But we don't know the server-side count easily without a data attribute.
            // Let's assume on F5, the badge.innerText is the server count.
            if (!badge.hasAttribute('data-synced')) {
                badge.innerText = currentVal + stored.length;
                badge.setAttribute('data-synced', 'true');
            }
            badge.style.display = stored.length + currentVal > 0 ? 'flex' : 'none';
        }
    };

    /** DB unread count + sessionStorage system announcements (must match syncBadge totals). */
    const applyNotificationBadgeCount = (serverUnread) => {
        const stored = getAnnouncements();
        const total = Math.max(0, Number(serverUnread) || 0) + stored.length;
        let badge = document.getElementById('global-badge');
        if (total === 0) {
            if (badge) {
                badge.innerText = '0';
                badge.style.display = 'none';
                badge.setAttribute('data-synced', 'true');
            }
            return;
        }
        if (!badge) {
            const trigger = document.querySelector('.notification-trigger');
            if (trigger) {
                badge = document.createElement('span');
                badge.className = 'notification-badge';
                badge.id = 'global-badge';
                trigger.appendChild(badge);
            }
        }
        if (badge) {
            badge.innerText = total > 99 ? '99+' : String(total);
            badge.style.display = 'flex';
            badge.setAttribute('data-synced', 'true');
        }
    };

    const ulpIsAuthenticatedBody = () =>
        document.body && document.body.getAttribute('data-is-authenticated') === 'true';

    let _vipBadgeRefreshTimer = null;
    const applyVipNewBadgeCount = (n) => {
        const el = document.getElementById('vip-new-badge');
        if (!el) return;
        const ct = Number(n);
        if (!Number.isFinite(ct) || ct <= 0) {
            el.textContent = '';
            el.hidden = true;
            el.setAttribute('aria-hidden', 'true');
            el.classList.add('filter-chip__badge--empty', 'hidden');
            el.removeAttribute('aria-label');
            return;
        }
        const clipped = ct > 99 ? '99+' : String(ct);
        el.textContent = clipped;
        el.hidden = false;
        el.removeAttribute('aria-hidden');
        el.setAttribute('aria-label', String(ct) + ' new VIP file(s) since you last opened this tab');
        el.classList.remove('filter-chip__badge--empty', 'hidden');
    };

    const ulpAccountFetchDelayMs = (baseMs) => {
        try {
            if (typeof window.__ulpApiFetchDelayMs === 'function') {
                return window.__ulpApiFetchDelayMs(baseMs);
            }
        } catch (e) { /* ignore */ }
        return baseMs;
    };

    const scheduleVipNewBadgeRefetch = () => {
        if (!ulpIsAuthenticatedBody()) return;
        clearTimeout(_vipBadgeRefreshTimer);
        _vipBadgeRefreshTimer = setTimeout(() => {
            _vipBadgeRefreshTimer = null;
            fetch('/api/account/vip-new-count', {
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
            })
                .then((r) => (r.ok ? r.json() : null))
                .then((data) => {
                    if (!data || typeof data.count !== 'number') return;
                    applyVipNewBadgeCount(data.count);
                })
                .catch(() => {});
        }, ulpAccountFetchDelayMs(200));
    };

    let _notifPreviewRefreshTimer = null;
    let _notifPreviewInFlight = false;
    const refreshAccountNotificationsPreview = () => {
        if (!ulpIsAuthenticatedBody()) return;
        clearTimeout(_notifPreviewRefreshTimer);
        _notifPreviewRefreshTimer = setTimeout(() => {
            _notifPreviewRefreshTimer = null;
            if (_notifPreviewInFlight) return;
            const list = document.getElementById('user-notifications-list');
            if (!list) return;
            _notifPreviewInFlight = true;
            fetch('/api/account/notifications-preview', {
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                cache: 'no-store',
            })
                .then((r) => (r.ok ? r.json() : null))
                .then((data) => {
                    if (!data || typeof data.count !== 'number') return;
                    list.innerHTML = data.list_html || '';
                    applyNotificationBadgeCount(data.count);
                    const clearBtn = document.getElementById('clear-notifications-btn');
                    if (clearBtn) {
                        if (data.show_clear) {
                            clearBtn.classList.remove('hidden');
                            clearBtn.style.display = 'flex';
                        } else {
                            clearBtn.classList.add('hidden');
                            clearBtn.style.display = 'none';
                        }
                    }
                    injectAnnouncementsToList();
                })
                .catch(() => {})
                .finally(() => {
                    _notifPreviewInFlight = false;
                });
        }, ulpAccountFetchDelayMs(200));
    };

    const refreshHeaderAccountState = () => {
        scheduleVipNewBadgeRefetch();
        refreshAccountNotificationsPreview();
    };
    window.refreshHeaderAccountState = refreshHeaderAccountState;

    const injectAnnouncementsToList = () => {
        const list = document.getElementById('user-notifications-list');
        if (!list) return;

        const stored = getAnnouncements();

        // Always sync badge first
        syncBadge();

        if (stored.length === 0) return;

        stored.forEach(data => {
            if (list.querySelector(`.notification-item[data-announcement-id="${data.timestamp}"]`)) return;

            if (list.querySelector('.fa-bell') && list.children.length === 1) {
                list.innerHTML = '';
            }

            const newItem = document.createElement('div');
            newItem.className = 'notification-item system-announcement-item notif-system';
            newItem.setAttribute('data-announcement-id', data.timestamp);
            newItem.style.cssText = 'animation: fadeIn 0.3s ease-out;';

            const iconBox = document.createElement('div');
            iconBox.className = 'icon-box';
            const icon = document.createElement('i');
            icon.className = 'fas fa-bullhorn';
            iconBox.appendChild(icon);
            newItem.appendChild(iconBox);

            const bodyDiv = document.createElement('div');
            bodyDiv.className = 'notification-item-body';

            const kicker = document.createElement('div');
            kicker.className = 'notification-kicker';
            const dot = document.createElement('span');
            dot.className = 'notification-kicker-dot';
            kicker.appendChild(dot);
            kicker.appendChild(document.createTextNode('System broadcast'));
            bodyDiv.appendChild(kicker);

            const msgDiv = document.createElement('div');
            msgDiv.className = 'msg';
            msgDiv.innerHTML = sanitizeRichHtml(
                wrapNotificationDropdownMessage(parseLinks(data.msg), 'system')
            );
            bodyDiv.appendChild(msgDiv);

            const metaDiv = document.createElement('div');
            metaDiv.className = 'notification-item-meta';
            const timeSpan = document.createElement('span');
            timeSpan.className = 'telemetry-pod notification-time-pod';
            const t = data.time || 'Received';
            timeSpan.title = t;
            const clockIcon2 = document.createElement('i');
            clockIcon2.className = 'far fa-clock';
            timeSpan.appendChild(clockIcon2);
            timeSpan.appendChild(document.createTextNode(' ' + t));
            metaDiv.appendChild(timeSpan);
            bodyDiv.appendChild(metaDiv);

            newItem.appendChild(bodyDiv);
            list.insertBefore(newItem, list.firstChild);
        });

        const clearBtn = document.getElementById('clear-notifications-btn');
        if (clearBtn && (stored.length > 0 || list.children.length > 1)) {
            clearBtn.classList.remove('hidden');
            clearBtn.style.display = 'flex';
        }
    };

    if (!socket) {
        console.error('Realtime: CRITICAL - No socket available at init!');
    }

    // --- Socket event handlers (must live outside `if (socket)` blocks — block-scoped functions break rebinding). ---
    function __ulpOnFileStatsUpdate(data) {
        if (!data || data.id == null) return;
        const patchCommentCount = (pod) => {
            const countEl = pod.querySelector('.comment-count');
            if (countEl) {
                ulpPulseIfNumericCountChanged(countEl, data.comments, '.telemetry-pod');
                countEl.innerText = data.comments;
            }
        };
        document.querySelectorAll(`.telemetry-pod[data-file-id="${data.id}"]`).forEach(patchCommentCount);
        document.querySelectorAll(`.telemetry-group[data-file-id="${data.id}"]`).forEach(patchCommentCount);
    }

    function __ulpOnResourceStatsUpdate(data) {
        if (!data || data.id == null) return;
        const resPods = document.querySelectorAll(`.telemetry-pod[data-listing-id="${data.id}"]`);
        resPods.forEach(pod => {
            const countEl = pod.querySelector('.comment-count');
            if (countEl) {
                ulpPulseIfNumericCountChanged(countEl, data.comments, '.telemetry-pod');
                countEl.innerText = data.comments;
            }
        });
    }

    function ulpForumReplyComposerContainsFocus() {
        const replyRoot = document.getElementById('forum-reply-editor');
        const ae = document.activeElement;
        return !!(replyRoot && ae && replyRoot.contains(ae));
    }

    function ulpForumReplyHasDraftContent() {
        try {
            const q = window.__forumReplyQuill;
            if (!q || typeof q.getLength !== 'function') {
                return false;
            }
            if (q.getLength() > 1) {
                return true;
            }
            if (typeof q.getContents === 'function') {
                const ops = q.getContents().ops || [];
                for (let i = 0; i < ops.length; i += 1) {
                    const ins = ops[i].insert;
                    if (typeof ins === 'string') {
                        if (ins.replace(/\uFEFF/g, '').trim().length > 0) {
                            return true;
                        }
                    } else if (ins != null) {
                        return true;
                    }
                }
            }
        } catch (e) {
            /* ignore */
        }
        return false;
    }

    function ulpForumTopicPreserveComposerSpaReload() {
        return ulpForumReplyComposerContainsFocus() || ulpForumReplyHasDraftContent();
    }

    function ulpPatchForumTopicReplyPaginationMeta(postsList, topicReplyCount) {
        if (!postsList || postsList.getAttribute('data-paginated') !== '1') {
            return;
        }
        const perPage = parseInt(postsList.getAttribute('data-per-page') || '0', 10) || 0;
        if (perPage <= 0) {
            return;
        }
        const n = Number(topicReplyCount);
        if (!Number.isFinite(n)) {
            return;
        }
        const maxPage = Math.max(1, Math.ceil(Math.max(n, 0) / perPage));
        postsList.setAttribute('data-pages', String(maxPage));
    }

    function ulpForumTopicToastNewRepliesOnOtherPage() {
        if (typeof window.showToast === 'function') {
            window.showToast(
                'Discussions',
                'New replies were added on another page.',
                null,
                'fas fa-comments',
                null,
                null
            );
        }
    }

    if (socket) {

    // After deploy/restart, reload stale tabs once (old boot_ts in sessionStorage).
    // Skip if this document already matches the server boot (meta tag / ulpPrimeServerBootTsFromPage).
    socket.on('server_session', (data) => {
        try {
            const ts = data && data.boot_ts != null ? String(data.boot_ts) : null;
            if (!ts) return;
            const key = 'socket_server_boot_ts';
            const pageBootEl = document.querySelector('meta[name="ulp-server-boot-ts"]');
            const pageBoot = pageBootEl && pageBootEl.getAttribute('content');
            if (pageBoot != null && pageBoot !== '' && String(pageBoot) === ts) {
                sessionStorage.setItem(key, ts);
                return;
            }
            const prev = sessionStorage.getItem(key);
            sessionStorage.setItem(key, ts);
            if (pageBootEl) pageBootEl.setAttribute('content', ts);
            if (prev != null && prev !== ts) {
                const liveSock =
                    (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
                    socket;
                if (liveSock && liveSock.connected && typeof window.ulpResumeRealtimeNow === 'function') {
                    window.ulpResumeRealtimeNow();
                } else if (typeof window.ulpSoftResyncLiveSession === 'function') {
                    window.ulpSoftResyncLiveSession();
                } else {
                    window.location.reload();
                }
            }
        } catch (e) {
            /* sessionStorage blocked */
        }
    });

    // --- PHASE 1: MODERATION ---

    // Handle Forced Disconnect / Ban
    socket.on('force_disconnect', (data) => {
        console.warn('FORCE DISCONNECT:', data.reason);
        if (window.showToast) {
            window.showToast('Disconnected', data.reason || "You have been disconnected.", null, 'fas fa-ban', null, 'moderation');
            setTimeout(() => window.location.reload(), 3000); // Reloading will likely show the "Banned" page or Login
        } else {
            alert(data.reason || "You have been disconnected.");
            window.location.reload(); 
        }
    });

    // Handle Content Removal
    socket.on('content_removed', (data) => {
        if (!data || !data.type) return;
        const { type, id } = data;

        // 1. Remove from Lists (File items, Resource cards)
        let selector = '';
        if (type === 'file') {
            // VIP→free republish: only strip feed cards; view_file.html uses data-file-id on telemetry (do not remove).
            if (data.skip_view_redirect) {
                selector = `.file-item[data-file-id="${id}"]`;
            } else {
                selector = `[data-file-id="${id}"], .file-item[data-url*="/file/${id}"], #file-${id}`;
            }
        } else if (type === 'resource') {
            selector = `[data-listing-id="${id}"], .resource-item[data-url*="/resources/${id}"], #resource-${id}`;
        } else if (type === 'comment') {
            selector = `#comment-${id}, [data-comment-id="${id}"]`;
        } else if (type === 'forum_post') {
            selector = `#forum-post-${id}, .forum-post-item[data-post-id="${id}"], [data-post-id="${id}"].forum-post-item`;
        } else if (type === 'forum_topic') {
            selector = `.forum-topic-list-card[data-topic-id="${id}"], #forum-topic-${id}`;
        }

        let removedDomCount = 0;
        if (selector) {
            const elements = document.querySelectorAll(selector);
            removedDomCount = elements.length;
            const instantFileListRemove = type === 'file' && data.skip_view_redirect;
            elements.forEach(el => {
                if (instantFileListRemove) {
                    el.remove();
                    return;
                }
                // Animate removal
                el.style.transition = 'all 0.5s ease';
                el.style.opacity = '0';
                el.style.transform = 'scale(0.9)';
                setTimeout(() => {
                    el.remove();
                    // Also remove potential parent wrapper if it's empty/only container
                    // But usually the element IS the item.
                }, 500);
            });
        }

        // 2. Redirect if viewing the deleted item directly
        const currentPath = window.location.pathname;
        const navigateTo = (url, delayMs = 0) => {
            const go = () => {
                if (window.loadPage) {
                    window.loadPage(url, true, { showLoader: false });
                } else {
                    window.location.href = url;
                }
            };
            if (delayMs > 0) setTimeout(go, delayMs);
            else go();
        };
        const viewerRemovalToastHtml = (head) =>
            '<div class="notif-msg-compact"><div class="notif-msg-compact__title">' + head + '</div></div>';
        const ulpPageContentOwnerId = () => {
            const el = document.querySelector('[data-ulp-content-owner-id]');
            return el ? String(el.getAttribute('data-ulp-content-owner-id') || '').trim() : '';
        };
        const ulpIsCurrentUserContentOwner = () => {
            const owner = ulpPageContentOwnerId();
            const me = String((document.body && document.body.getAttribute('data-user-id')) || '').trim();
            return !!(owner && me && owner === me);
        };
        const showViewerRemovalToast = (title, messageHtml, icon, redirectUrl, delayMs) => {
            if (ulpIsCurrentUserContentOwner()) {
                navigateTo(redirectUrl, delayMs);
                return;
            }
            if (window.showToast) {
                window.showToast(title, messageHtml, null, icon, null, 'moderation');
                navigateTo(redirectUrl, delayMs);
            } else {
                alert(messageHtml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
                navigateTo(redirectUrl, 0);
            }
        };
        if (type === 'file' && currentPath.includes(`/file/${id}`) && !data.skip_view_redirect) {
            showViewerRemovalToast(
                'Content Removed',
                viewerRemovalToastHtml('This file has been deleted by a moderator.'),
                'fas fa-trash',
                '/',
                2500
            );
        } else if (type === 'resource' && currentPath.includes(`/resources/${id}`)) {
            if (!currentPath.includes('edit')) {
                showViewerRemovalToast(
                    'Content Removed',
                    viewerRemovalToastHtml('This resource has been deleted by a moderator.'),
                    'fas fa-trash',
                    '/resources',
                    2500
                );
            }
        } else if (type === 'forum_topic' && currentPath.startsWith('/discussions/t/') && currentPath.includes(`/discussions/t/${id}`)) {
            const redirectUrl = data.redirect_url || (data.category_slug ? `/discussions/c/${data.category_slug}` : '/discussions');
            showViewerRemovalToast(
                'Topic removed',
                viewerRemovalToastHtml('This discussion was removed.'),
                'fas fa-trash',
                redirectUrl,
                900
            );
        }
        // Fallback for discussions pages: if topic card wasn't removed by selector race/order,
        // force a lightweight SPA refresh so all users see the updated forum state immediately.
        if (type === 'forum_topic' && (currentPath.startsWith('/discussions/c/') || currentPath === '/discussions')) {
            if (window.loadPage) {
                setTimeout(() => {
                    window.loadPage(window.location.pathname + window.location.search, true);
                }, 350);
            }
        }

        if (type === 'forum_post') {
            const topicId = data.topic_id;
            const topicReplyCount = Number(data.topic_reply_count);
            const topicCard = topicId
                ? document.querySelector(`.forum-topic-list-card[data-topic-id="${topicId}"]`)
                : null;
            if (topicCard) {
                const boundedReplies = Number.isFinite(topicReplyCount) ? Math.max(topicReplyCount, 0) : NaN;
                const commentsEl =
                    topicCard.querySelector('.telemetry-pod[title="Comments"]') ||
                    Array.from(topicCard.querySelectorAll('.forum-topic-stats .telemetry-pod')).find((el) => {
                        const icon = el.querySelector('i');
                        return icon && (icon.classList.contains('fa-comment') || icon.classList.contains('fa-comments'));
                    });
                if (commentsEl && Number.isFinite(boundedReplies)) {
                    ulpSetTelemetryPodCount(commentsEl, boundedReplies, 'fas fa-comment');
                }
                const repliesEl = topicCard.querySelector('.telemetry-pod[title="Replies"]');
                if (repliesEl && Number.isFinite(boundedReplies)) {
                    ulpSetTelemetryPodCount(repliesEl, boundedReplies, 'fas fa-reply');
                }
                ulpRenderForumTopicReplyMeta(topicCard, {
                    replyCt: Number.isFinite(boundedReplies) ? boundedReplies : 0,
                    activityCompact: data.topic_activity_compact || data.topic_last_comment_time || '',
                    activityTitle: data.topic_activity_title || '',
                    activityTs: data.topic_activity_ts || data.created_at_ts || null,
                    author: data.last_reply_author || null,
                });
            }

            const categoryCard = data.topic_category_id
                ? document.querySelector(`.forum-category-card[data-category-id="${data.topic_category_id}"]`)
                : null;
            if (categoryCard) {
                const postsPod = categoryCard.querySelector('.forum-category-card-meta .telemetry-group .telemetry-pod i.fa-comments')?.closest('.telemetry-pod');
                if (postsPod) {
                    const current = Number(postsPod.getAttribute('data-count') || 0);
                    const next = Math.max(0, Number.isFinite(current) ? current - 1 : 0);
                    postsPod.setAttribute('data-count', String(next));
                    ulpSetTelemetryPodCount(postsPod, next, 'fas fa-comments');
                }
            }

            // On paginated topic pages, if current replies page became empty after removals,
            // navigate to the previous valid page so users don't stay on a blank page.
            const postsList = document.getElementById('forum-posts-list');
            if (postsList && postsList.getAttribute('data-paginated') === '1') {
                const path = window.location.pathname || '';
                if (path.startsWith('/discussions/t/')) {
                    const pageTopicIdRaw = (postsList.getAttribute('data-page-id') || '').replace('forum_topic_', '');
                    const pageTopicId = parseInt(pageTopicIdRaw || '0', 10) || 0;
                    const eventTopicId = parseInt(String(data.topic_id || '0'), 10) || 0;
                    if (pageTopicId && eventTopicId && pageTopicId !== eventTopicId) {
                        return;
                    }
                    const checkAndNavigateIfEmpty = () => {
                        const remaining = postsList.querySelectorAll('.forum-post-item').length;
                        const currentPage = parseInt(postsList.getAttribute('data-page') || '1', 10) || 1;
                        const perPage = parseInt(postsList.getAttribute('data-per-page') || '0', 10) || 0;
                        const replyCount = Number(data.topic_reply_count);
                        if (perPage > 0 && Number.isFinite(replyCount)) {
                            const maxPage = Math.max(1, Math.ceil(Math.max(replyCount, 0) / perPage));
                            if (currentPage > maxPage) {
                                ulpPatchForumTopicReplyPaginationMeta(postsList, replyCount);
                                if (ulpForumTopicPreserveComposerSpaReload()) {
                                    if (typeof window.showToast === 'function') {
                                        window.showToast(
                                            'Discussions',
                                            'Pagination changed. Use the page controls when you are ready to sync.',
                                            null,
                                            'fas fa-comments',
                                            null,
                                            null
                                        );
                                    }
                                    return;
                                }
                                const qsMax = new URLSearchParams(window.location.search || '');
                                qsMax.set('page', String(maxPage));
                                const maxUrl = `${path}?${qsMax.toString()}`;
                                if (window.loadPage) window.loadPage(maxUrl, true);
                                else window.location.href = maxUrl;
                                return;
                            }
                        }
                        if (remaining === 0 && currentPage > 1) {
                            ulpPatchForumTopicReplyPaginationMeta(postsList, replyCount);
                            if (ulpForumTopicPreserveComposerSpaReload()) {
                                if (typeof window.showToast === 'function') {
                                    window.showToast(
                                        'Discussions',
                                        'This page is empty after a delete. Use the page controls when you are ready.',
                                        null,
                                        'fas fa-comments',
                                        null,
                                        null
                                    );
                                }
                                return;
                            }
                            const targetPage = currentPage - 1;
                            const qs = new URLSearchParams(window.location.search || '');
                            qs.set('page', String(targetPage));
                            const nextUrl = `${path}?${qs.toString()}`;
                            if (window.loadPage) window.loadPage(nextUrl, true);
                            else window.location.href = nextUrl;
                            return;
                        }
                    };
                    // content_removed removes DOM with animation timeout, so run after it.
                    setTimeout(checkAndNavigateIfEmpty, 560);
                }
            }
        }

        // 3. Resync feed only when this client actually had the row (avoids "Syncing..." for hidden scheduled files).
        const isFilesFeed = currentPath === '/';
        const isResourcesFeed = currentPath.startsWith('/resources');
        if (removedDomCount > 0) {
            if ((type === 'file' && isFilesFeed) || (type === 'resource' && isResourcesFeed)) {
                if (window.loadPage) {
                    window.loadPage(window.location.pathname + window.location.search, true);
                }
            }
        }
    });

    socket.on('notification_badge_sync', (data) => {
        if (!data || data.count == null) return;
        applyNotificationBadgeCount(data.count);
        const list = document.getElementById('user-notifications-list');
        if (!list) return;
        const stored = getAnnouncements().length;
        const serverCount = Math.max(0, Number(data.count) || 0);
        const visibleRows = list.querySelectorAll('.notification-item[data-id]').length;
        if (serverCount + stored > visibleRows) {
            refreshAccountNotificationsPreview();
        }
    });

    socket.on('vip_new_badge_sync', (data) => {
        if (!data || data.count == null) return;
        applyVipNewBadgeCount(data.count);
    });

    socket.on('vip_new_badge_refresh', () => {
        scheduleVipNewBadgeRefetch();
    });

    // --- PHASE 2: NOTIFICATIONS ---

    // showToast/getToastContainer moved above (socket-independent).

    // Socket Listener for Personal Notifications
    socket.on('new_notification', (data) => {
        // 1. Show Toast (Now passing ID)
        window.showToast(data.title || 'New Alert', data.message, data.link, data.icon || 'fas fa-info-circle', data.id, data.notif_type || null);

        // Check if this notification (by ID) already exists in the list
        const list = document.getElementById('user-notifications-list');
        const existingItem = list ? list.querySelector(`.notification-item[data-id="${data.id}"]`) : null;

        // Badge count: server emits `notification_badge_sync` immediately after `new_notification`.
        if (existingItem) {
            // If existing, remove it so we can re-insert at top (bump)
            existingItem.remove();
        }

        // 4. Update Dropdown List
        if (list) {
            // Remove empty-state placeholder if exists
            if (list.querySelector('.fa-bell') && list.children.length === 1) {
                list.innerHTML = '';
            }

            const newItem = document.createElement('div');
            const notifLowerRow = String(data.notif_type || '').toLowerCase();
            const isClickable =
                notifLowerRow !== 'moderation' &&
                data.link &&
                String(data.link).trim() &&
                data.link !== '#';
            newItem.setAttribute('data-id', data.id);
            newItem.setAttribute('data-link', isClickable ? data.link : '');
            newItem.className = [
                'notification-item',
                isClickable ? 'clickable' : '',
                data.notif_type ? 'notif-' + data.notif_type : ''
            ].filter(Boolean).join(' ');
            newItem.style.cssText = 'animation: fadeIn 0.3s ease-out;';

            // Icon box — group badge alerts use full shell + icon CSS from server
            const iconBox = document.createElement('div');
            const isGroupBadge =
                data.notif_type === 'group_badge' &&
                data.group_badge &&
                typeof window.formatSingleGroupBadgeHtml === 'function';
            if (isGroupBadge) {
                iconBox.className = 'icon-box icon-box--group-badge';
                iconBox.innerHTML = window.formatSingleGroupBadgeHtml(data.group_badge);
            } else {
                iconBox.className = 'icon-box';
                const icon = document.createElement('i');
                icon.className = data.icon || 'fas fa-info';
                iconBox.appendChild(icon);
            }
            newItem.appendChild(iconBox);

            const body = document.createElement('div');
            body.className = 'notification-item-body';
            const msg = document.createElement('div');
            msg.className = 'msg';
            msg.innerHTML = sanitizeRichHtml(
                wrapNotificationDropdownMessage(
                    typeof data.message === 'string' ? data.message : '',
                    data.notif_type
                )
            );
            body.appendChild(msg);

            const meta = document.createElement('div');
            meta.className = 'notification-item-meta';
            const timeInfo = document.createElement('span');
            timeInfo.className = 'telemetry-pod notification-time-pod';
            let compact = data.timestamp_compact != null && data.timestamp_compact !== '' ? String(data.timestamp_compact) : '';
            let precise = data.timestamp_precise != null && data.timestamp_precise !== '' ? String(data.timestamp_precise) : '';
            if (!compact && data.timestamp) compact = String(data.timestamp);
            if (!precise) precise = (data.timestamp_title != null && data.timestamp_title !== '') ? String(data.timestamp_title) : compact;
            timeInfo.title = precise;
            const clockI = document.createElement('i');
            clockI.className = 'far fa-clock';
            timeInfo.appendChild(clockI);
            timeInfo.appendChild(document.createTextNode(' ' + compact));
            meta.appendChild(timeInfo);
            body.appendChild(meta);

            newItem.appendChild(body);

            // Insert at top
            list.insertBefore(newItem, list.firstChild);

            // Keep dropdown compact: show preview of newest 10 unread rows.
            const itemsWithId = list.querySelectorAll('.notification-item[data-id]');
            if (itemsWithId.length > 10) {
                const last = itemsWithId[itemsWithId.length - 1];
                if (last) last.remove();
            }

            // Show clear button
            const clearBtn = document.getElementById('clear-notifications-btn');
            if (clearBtn) {
                clearBtn.classList.remove('hidden');
                clearBtn.style.display = 'flex';
            }
        }
    });

    // v68: Global Payment Confirmation Listener
    socket.on('payment_confirmed', (data) => {
        window.showToast(
            'PAYMENT SUCCESSFUL',
            data.message || 'Transaction verified on the blockchain.',
            `/file/${data.file_id}?paid=true`,
            'fas fa-check-double',
            null,
            'payment'
        );

        // Update Profile/Modal Invoice Status if present
        patchOrderStatus(data.order_id, 'paid');
    });

    // Handle System Announcements
    socket.on('system_announcement', (data) => {
        // Legacy path standardization: render using same look and flow as regular notifications.
        const rawTitle = data && data.title ? String(data.title).trim() : '';
        const displayTitle = rawTitle || 'Announcement';
        const iconClass = (data && data.icon && String(data.icon).trim()) || 'fas fa-bullhorn';
        const legacyData = {
            id: data && data.campaign_id ? `broadcast_${data.campaign_id}` : `legacy_system_${Date.now()}`,
            title: displayTitle,
            message: (data && data.msg) || '',
            link: (data && data.link) || null,
            icon: iconClass,
            notif_type: 'system',
            timestamp: (data && data.time) || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        window.showToast(legacyData.title, legacyData.message, legacyData.link, legacyData.icon, null, 'system', true);

        const list = document.getElementById('user-notifications-list');
        if (list) {
            if (list.querySelector('.fa-bell') && list.children.length === 1) {
                list.innerHTML = '';
            }
            const newItem = document.createElement('div');
            const sysHasLink = legacyData.link && legacyData.link !== '#';
            newItem.className = 'notification-item system-announcement-item notif-system' + (sysHasLink ? ' clickable' : '');
            newItem.style.cssText = 'animation: fadeIn 0.3s ease-out;';
            newItem.setAttribute('data-link', legacyData.link || '#');
            newItem.setAttribute('data-id', legacyData.id || '');

            const iconBox = document.createElement('div');
            iconBox.className = 'icon-box';
            const iconLegacy = document.createElement('i');
            iconLegacy.className = legacyData.icon || 'fas fa-info';
            iconBox.appendChild(iconLegacy);
            newItem.appendChild(iconBox);

            const bodySys = document.createElement('div');
            bodySys.className = 'notification-item-body';
            const kickerSys = document.createElement('div');
            kickerSys.className = 'notification-kicker';
            const dotSys = document.createElement('span');
            dotSys.className = 'notification-kicker-dot';
            kickerSys.appendChild(dotSys);
            kickerSys.appendChild(document.createTextNode(displayTitle));
            bodySys.appendChild(kickerSys);
            const msg = document.createElement('div');
            msg.className = 'msg';
            const legacyRaw = legacyData.message || '';
            msg.innerHTML = sanitizeRichHtml(
                wrapNotificationDropdownMessage(
                    typeof linkifyPlainTextForDisplay === 'function'
                        ? linkifyPlainTextForDisplay(legacyRaw)
                        : legacyRaw,
                    'system'
                )
            );
            const metaSys = document.createElement('div');
            metaSys.className = 'notification-item-meta';
            const timeInfo = document.createElement('span');
            timeInfo.className = 'telemetry-pod notification-time-pod';
            const tsys = legacyData.timestamp || '';
            timeInfo.title = tsys;
            const ic = document.createElement('i');
            ic.className = 'far fa-clock';
            timeInfo.appendChild(ic);
            timeInfo.appendChild(document.createTextNode(' ' + tsys));
            metaSys.appendChild(timeInfo);
            bodySys.appendChild(msg);
            bodySys.appendChild(metaSys);
            newItem.appendChild(bodySys);
            list.insertBefore(newItem, list.firstChild);
        }
    });

    // --- PHASE 3: PRESENCE (Avatar Pile) ---

    socket.on('update_viewers', (data) => {
        if (!data || typeof data.room !== 'string' || !data.room) return;
        // data: { count: N, room: '...', avatars: [{username, avatar}, ...] }
        // 2. Render Avatar Pile - Targeted Selection
        // We look for .telemetry-group or containers with data-room-id matching the room
        let selector = '';
        if (data.room.startsWith('file_')) {
            const fileId = data.room.replace('file_', '');
            selector = `.telemetry-group[data-file-id="${fileId}"] .avatar-pile`;
        } else if (data.room.startsWith('resource_')) {
            const resId = data.room.replace('resource_', '');
            selector = `.telemetry-group[data-listing-id="${resId}"] .avatar-pile`;
        } else if (data.room.startsWith('forum_topic_')) {
            const topicId = data.room.replace('forum_topic_', '');
            selector = `.telemetry-group[data-topic-id="${topicId}"] .avatar-pile`;
        }

        if (!selector) return;

        const pileContainers = document.querySelectorAll(selector);
        if (pileContainers.length === 0) return;

        pileContainers.forEach(container => {
            container.innerHTML = ''; // Clear previous

            // 1. Render Avatars
            if (data.avatars && data.avatars.length > 0) {
                data.avatars.forEach(user => {
                    const img = document.createElement('img');
                    const avatarUrl = window.ulpResolveAvatarUrl(user);

                    img.className = 'pile-avatar';
                    img.src = avatarUrl;
                    img.title = user.username + ' is here';

                    container.appendChild(img);
                });
            }

            // 2. Render Overflow (Guests or more users)
            const registeredCount = (data.avatars ? data.avatars.length : 0);
            const overflow = data.count - registeredCount;
            if (overflow > 0) {
                const overflowEl = document.createElement('span');
                overflowEl.className = 'pile-avatar pile-overflow';
                overflowEl.innerText = `+${overflow}`;
                overflowEl.title = `${data.count} people are here`;
                container.appendChild(overflowEl);
            }
        });
    });

    const applyGlobalOnlineSocketPayload = (data) => {
        if (!data) return;
        if (data.widget_activity_total != null) {
            const actEl = document.getElementById('ulp-activity-count');
            if (actEl) actEl.textContent = String(Number(data.widget_activity_total) || 0);
        }
    };

    function bindCoreRealtimeSocketHandlers(sock) {
        if (!sock || typeof sock.on !== 'function') return;
        if (!sock.__ulpCoreRealtimeHandlers) {
            sock.__ulpCoreRealtimeHandlers = true;
            sock.on('update_global_online', (data) => {
                applyGlobalOnlineSocketPayload(data);
            });
        }
        if (sock.__ulpForumLiveHandlers) return;
        sock.__ulpForumLiveHandlers = true;
        sock.on('forum_post_deleted', (data) => {
            if (!data || data.post_id == null) return;
            ulpRemoveForumPostFromDom(data.post_id);
        });
        sock.on('forum_topic_hide_from_public_list', (data) => {
            if (!data || data.topic_id == null) return;
            if (
                typeof mayViewForumTopicListCard === 'function' &&
                !mayViewForumTopicListCard({ opening_post_approved: false, user_id: data.user_id })
            ) {
                ulpRemoveForumTopicListCards(data.topic_id);
            }
        });
    }
    if (socket) {
        bindCoreRealtimeSocketHandlers(socket);
    }
    window.__ulpBindCoreRealtimeSocketHandlers = bindCoreRealtimeSocketHandlers;

    /**
     * Last *site action* for presence TTL + server idle kick (30m default).
     * Clicks, keys, touch, pointer — not scroll (avoids keeping passive/bot-like sessions "alive").
     * Admin "Last click" still uses lastUiClickMs (clicks only).
     */
    let lastSiteActionMs = Date.now();
    /** First real click timestamp only; sent as click_idle_ms for admin "Last click". */
    let lastUiClickMs = null;
    const bumpSiteAction = () => {
        lastSiteActionMs = Date.now();
        const live =
            (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
            socket ||
            null;
        if (window._presenceIdleSessionEnded || (live && !live.connected)) {
            window._presenceIdleSessionEnded = false;
            ulpEnableSharedSocketReconnection();
            if (typeof window.ulpConnectSharedSocketOnce === 'function') {
                window.ulpConnectSharedSocketOnce(true);
            }
        }
    };
    document.addEventListener(
        'click',
        () => {
            const now = Date.now();
            lastSiteActionMs = now;
            lastUiClickMs = now;
        },
        { capture: true, passive: true },
    );
    ['keydown', 'touchstart', 'pointerdown'].forEach((evt) => {
        document.addEventListener(evt, bumpSiteAction, { capture: true, passive: true });
    });

    /** Page Visibility + idle since last click/key/touch/pointer (not scroll). */
    const presenceVisiblePayload = () => {
        const rawIdle = Date.now() - lastSiteActionMs;
        const idle_ms = Math.min(Math.max(0, rawIdle), PRESENCE_IDLE_REPORT_MAX_MS);
        const payload = {
            visible: typeof document !== 'undefined' && !document.hidden,
            idle_ms,
        };
        if (lastUiClickMs == null) {
            payload.click_idle_ms = null;
        } else {
            const c = Date.now() - lastUiClickMs;
            payload.click_idle_ms = Math.min(Math.max(0, c), PRESENCE_IDLE_REPORT_MAX_MS);
        }
        return payload;
    };

    const buildPresenceRoutePayload = () => {
        try {
            const u = new URL(window.location.href, window.location.origin);
            const path = ((u.pathname || '/').length > 1 && (u.pathname || '/').endsWith('/'))
                ? (u.pathname || '/').slice(0, -1)
                : (u.pathname || '/');
            const mTopic = path.match(/^\/discussions\/t\/(\d+)/);
            const mFile = path.match(/^\/file\/(\d+)/);
            const mRes = path.match(/^\/resources\/(\d+)/);
            return {
                forum_topic_id: mTopic ? mTopic[1] : null,
                file_id: mFile ? mFile[1] : null,
                listing_id: mRes ? mRes[1] : null,
                files_feed: path === '/',
                resources_feed: path === '/resources',
                discussions_feed: path === '/discussions' || /^\/discussions\/c\//i.test(path),
            };
        } catch (e) {
            return {
                forum_topic_id: null,
                file_id: null,
                listing_id: null,
                files_feed: false,
                resources_feed: false,
                discussions_feed: false,
            };
        }
    };

    const emitPresenceRouteSync = () => {
        const payload = buildPresenceRoutePayload();
        if (socket && socket.connected) {
            socket.emit('sync_presence_route', payload);
        } else if (window.getSharedSocket) {
            const s = window.getSharedSocket();
            if (s && s.connected) s.emit('sync_presence_route', payload);
        }
    };

    const emitPresencePulse = () => {
        if (window._presenceIdleSessionEnded) return;
        const payload = presenceVisiblePayload();
        const liveSocket =
            (socket && socket.connected && socket) ||
            (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
            socket ||
            null;
        if (!liveSocket || !liveSocket.connected) {
            if (typeof window.ulpConnectSharedSocketOnce === 'function') {
                try {
                    window.ulpConnectSharedSocketOnce();
                } catch (e) { /* ignore */ }
            }
            ulpRefreshOnlineCountViaHttp();
            return;
        }
        liveSocket.emit('request_global_online', payload);
        liveSocket.emit('sync_presence_route', buildPresenceRoutePayload());
    };

    let onlineCountHttpTimer = null;
    let onlineCountHttpAbortCtrl = null;

    /** Skip HTTP presence fallback during reload/unload — WebKit logs aborted credentialed fetches as CORS. */
    function ulpShouldSkipPresenceHttpFetch() {
        if (window.__ulpPageUnloading || window._chatIntentionalReconnect) return true;
        try {
            const ts = parseInt(sessionStorage.getItem('ulp_eio_unload_ts') || '0', 10);
            if (ts > 0 && Date.now() - ts < 6500) return true;
        } catch (e) { /* ignore */ }
        return false;
    }

    function ulpAbortOnlineCountHttpFetch() {
        if (!onlineCountHttpAbortCtrl) return;
        try {
            onlineCountHttpAbortCtrl.abort();
        } catch (e) { /* ignore */ }
        onlineCountHttpAbortCtrl = null;
    }
    window.__ulpAbortOnlineCountHttpFetch = ulpAbortOnlineCountHttpFetch;

    const ulpRefreshOnlineCountViaHttp = () => {
        if (ulpShouldSkipPresenceHttpFetch()) return;
        ulpAbortOnlineCountHttpFetch();
        const ctrl = new AbortController();
        onlineCountHttpAbortCtrl = ctrl;
        fetch('/api/widget-presence', { credentials: 'omit', cache: 'no-store', signal: ctrl.signal })
            .then((r) => (r.ok ? r.json() : null))
            .then((data) => {
                if (data && data.activity_total != null) {
                    applyGlobalOnlineSocketPayload({ widget_activity_total: data.activity_total });
                }
            })
            .catch(() => {})
            .finally(() => {
                if (onlineCountHttpAbortCtrl === ctrl) onlineCountHttpAbortCtrl = null;
            });
    };
    const scheduleOnlineCountHttpFallback = () => {
        if (onlineCountHttpTimer) clearInterval(onlineCountHttpTimer);
        ulpRefreshOnlineCountViaHttp();
        onlineCountHttpTimer = setInterval(() => {
            const s =
                (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
                socket ||
                null;
            if (s && s.connected) return;
            ulpRefreshOnlineCountViaHttp();
        }, 45000);
    };

    let presencePulseTimer = null;
    const schedulePresencePulse = () => {
        if (window._presenceIdleSessionEnded) return;
        if (presencePulseTimer) clearTimeout(presencePulseTimer);
        const delay =
            typeof document !== 'undefined' && document.hidden
                ? GLOBAL_ONLINE_PULSE_HIDDEN_MS
                : GLOBAL_ONLINE_PULSE_MS;
        presencePulseTimer = setTimeout(() => {
            emitPresencePulse();
            schedulePresencePulse();
        }, delay);
    };

    /**
     * Legacy hook for older cached HTML — same as automatic soft resync after long idle.
     */
    window.__ulpResumeLiveAfterIdlePause = function () {
        if (typeof window.ulpSoftResyncLiveSession === 'function') {
            window.ulpSoftResyncLiveSession();
            return;
        }
        window._presenceIdleSessionEnded = false;
        try {
            bumpSiteAction();
        } catch (e) { /* ignore */ }
        window.location.reload();
    };

    // --- Persistence & SPA Sync ---
    document.addEventListener('DOMContentLoaded', () => {
        bumpSiteAction();
        injectAnnouncementsToList();
        scheduleOnlineCountHttpFallback();
        emitPresencePulse();
    });

    schedulePresencePulse();

    function ulpResumeRealtimeNow() {
        window._presenceIdleSessionEnded = false;
        ulpEnableSharedSocketReconnection();
        try {
            bumpSiteAction();
        } catch (e) { /* ignore */ }
        if (typeof window.ulpConnectSharedSocketOnce === 'function') {
            try {
                window.ulpConnectSharedSocketOnce(true);
            } catch (e) { /* ignore */ }
        }
        if (typeof window.ulpEnsureRealtimeSocketBindings === 'function') {
            const s0 =
                (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) ||
                socket ||
                null;
            if (s0) window.ulpEnsureRealtimeSocketBindings(s0);
        }
        emitPresenceRouteSync();
        emitPresencePulse();
        schedulePresencePulse();
        requestPendingCountRefresh();
        refreshHeaderAccountState();
        if (typeof window.ulpUpdateLiveTimes === 'function') {
            window.ulpUpdateLiveTimes();
        }
        try {
            const s = (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) || socket;
            if (s && typeof window.__ulpBindIndexFeedSocketHandlers === 'function') {
                window.__ulpBindIndexFeedSocketHandlers(s);
            }
            if (s && typeof window.__ulpBindStatsSocketHandlers === 'function') {
                window.__ulpBindStatsSocketHandlers(s);
            }
            if (s && s.connected && typeof window.__ulpResyncRealtimeSubscriptions === 'function') {
                window.__ulpResyncRealtimeSubscriptions();
            }
        } catch (e) { /* ignore */ }
    }
    window.ulpResumeRealtimeNow = ulpResumeRealtimeNow;

    /** Resync socket + feed fragment after long hidden tab or server presence-idle kick (no full loadPage). */
    let _ulpTabHiddenAtMs = 0;
    let _ulpLiveResyncInFlight = false;
    let _ulpPendingIdleRecovery = false;
    const LONG_HIDDEN_RESYNC_MS = 5 * 60 * 1000;
    const LIVE_RESYNC_LOADER_MIN_MS = 600;
    window.__ulpLongHiddenResyncMs = LONG_HIDDEN_RESYNC_MS;

    function ulpWaitForSharedSocketConnect(timeoutMs) {
        const ms = Math.max(500, Number(timeoutMs) || 8000);
        return new Promise((resolve) => {
            const getSocket = () => (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) || null;
            let s = getSocket();
            if (s && s.connected) {
                resolve(true);
                return;
            }
            let done = false;
            let handler = null;
            const finish = (ok) => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                s = getSocket();
                if (s && handler) {
                    try { s.off('connect', handler); } catch (e) { /* ignore */ }
                }
                resolve(!!ok);
            };
            handler = () => finish(true);
            s = getSocket();
            if (s) s.on('connect', handler);
            const timer = setTimeout(() => finish(getSocket() && getSocket().connected), ms);
        });
    }

    function ulpHideSyncLoaderAfterMinDelay(startedAtMs) {
        if (typeof window.__ulpHideSyncLoaderDeferred === 'function') {
            window.__ulpHideSyncLoaderDeferred();
        } else if (typeof window.__ulpHideSyncLoader === 'function') {
            window.__ulpHideSyncLoader();
        }
        const elapsed = Date.now() - (startedAtMs || Date.now());
        const waitMs = Math.max(0, LIVE_RESYNC_LOADER_MIN_MS - elapsed);
        if (waitMs <= 0) {
            return Promise.resolve();
        }
        return new Promise((resolve) => {
            setTimeout(resolve, waitMs);
        });
    }

    function ulpShowSoftResyncLoader() {
        if (ulpIsFreshDocumentSession()) return;
        if (typeof window.__ulpShowSyncLoaderDeferred === 'function') {
            window.__ulpShowSyncLoaderDeferred('Syncing...');
            return;
        }
        if (typeof window.__ulpShowSyncLoader === 'function') {
            window.__ulpShowSyncLoader('Syncing...');
        }
    }

    function ulpIsFreshDocumentSession() {
        try {
            const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
            if (nav && (nav.type === 'reload' || nav.type === 'navigate')) {
                const ageMs = Date.now() - (nav.startTime + (performance.timeOrigin || 0));
                if (ageMs >= 0 && ageMs < 5000) return true;
            }
        } catch (e) { /* ignore */ }
        const loadAt = Number(window.__ulpPageLoadAt || 0);
        return loadAt > 0 && Date.now() - loadAt < 5000;
    }

    function ulpClearPresenceIdleOverlay() {
        try {
            document.getElementById('presence-idle-overlay')?.remove();
        } catch (e) { /* ignore */ }
    }

    function ulpEnableSharedSocketReconnection() {
        try {
            const s = (typeof window.getSharedSocket === 'function' && window.getSharedSocket())
                || socket
                || window.chatSocket
                || null;
            if (s && s.io && typeof s.io.reconnection === 'function') {
                s.io.reconnection(true);
            }
        } catch (e) { /* ignore */ }
    }

    function ulpNotifyLiveResyncFeedFailed() {
        console.warn('Realtime: feed fragment refresh failed; socket resync completed.');
        if (typeof window.showToast !== 'function') return;
        window.showToast(
            'Sync incomplete',
            'Could not refresh the list. Tap to reload the page.',
            null,
            'fas fa-sync',
            null,
            'warning',
            true
        );
        try {
            const container = document.getElementById('toast-container');
            const toast = container && container.lastElementChild;
            if (!toast) return;
            toast.style.cursor = 'pointer';
            toast.addEventListener('click', (e) => {
                if (e.target.closest('.ulp-corner-toast-close')) return;
                window.location.reload();
            });
        } catch (e) { /* ignore */ }
    }

    async function ulpSoftResyncLiveSession() {
        if (_ulpLiveResyncInFlight) return;
        if (typeof document !== 'undefined' && document.visibilityState !== 'visible') {
            _ulpPendingIdleRecovery = true;
            return;
        }

        _ulpLiveResyncInFlight = true;
        const startedAtMs = Date.now();
        ulpClearPresenceIdleOverlay();
        ulpShowSoftResyncLoader();
        try {
            window._presenceIdleSessionEnded = false;
            _ulpPendingIdleRecovery = false;
            ulpEnableSharedSocketReconnection();

            try {
                if (typeof window.ulpForceNewSocketHandshake === 'function') {
                    window.ulpForceNewSocketHandshake();
                }
            } catch (e) { /* ignore */ }

            await ulpWaitForSharedSocketConnect(8000);

            try {
                bumpSiteAction();
            } catch (e) { /* ignore */ }

            ulpResumeRealtimeNow();

            if (typeof window.__ulpRefreshFeedFragment === 'function') {
                const targetUrl = window.location.pathname + window.location.search + (window.location.hash || '');
                const feedOk = await window.__ulpRefreshFeedFragment(targetUrl);
                if (!feedOk) {
                    ulpNotifyLiveResyncFeedFailed();
                }
            }

            try {
                document.dispatchEvent(new CustomEvent('pageLoaded'));
            } catch (e) { /* ignore */ }
        } finally {
            await ulpHideSyncLoaderAfterMinDelay(startedAtMs);
            _ulpLiveResyncInFlight = false;
        }
    }
    window.ulpSoftResyncLiveSession = ulpSoftResyncLiveSession;
    window.ulpSoftResyncAfterLongHidden = ulpSoftResyncLiveSession;

    document.addEventListener('visibilitychange', () => {
        if (typeof document === 'undefined' || !document.visibilityState) return;
        if (document.visibilityState === 'hidden') {
            _ulpTabHiddenAtMs = Date.now();
        } else if (document.visibilityState === 'visible') {
            const hiddenFor = _ulpTabHiddenAtMs ? Date.now() - _ulpTabHiddenAtMs : 0;
            if (window._presenceIdleSessionEnded || _ulpPendingIdleRecovery) {
                ulpSoftResyncLiveSession();
                return;
            }
            if (hiddenFor >= LONG_HIDDEN_RESYNC_MS) {
                if (ulpIsFreshDocumentSession()) {
                    ulpResumeRealtimeNow();
                } else {
                    ulpSoftResyncLiveSession();
                }
                return;
            }
            ulpResumeRealtimeNow();
        }
        if (document.visibilityState !== 'visible') {
            emitPresencePulse();
            schedulePresencePulse();
        }
    });

    window.addEventListener('focus', () => {
        ulpResumeRealtimeNow();
    });

    window.addEventListener('pageshow', (ev) => {
        _ulpLiveResyncInFlight = false;
        if (typeof window.__ulpHideSyncLoaderDeferred === 'function') {
            window.__ulpHideSyncLoaderDeferred();
        } else if (typeof window.__ulpHideSyncLoader === 'function') {
            window.__ulpHideSyncLoader();
        }
        if (ev && ev.persisted) {
            window._presenceIdleSessionEnded = false;
        }
        ulpResumeRealtimeNow();
    });

    window.addEventListener('online', () => {
        if (typeof document === 'undefined' || document.visibilityState === 'visible') {
            ulpResumeRealtimeNow();
        }
    });

    // Robust Reconnection
    if (socket) {
        socket.on('connect', () => {
            emitPresencePulse();
            schedulePresencePulse();
            requestPendingCountRefresh();
            refreshHeaderAccountState();
            if (typeof window.ulpRequestGlobalChatHistory === 'function') {
                window.ulpRequestGlobalChatHistory(socket);
            }
            if (typeof window.__ulpBindStatsSocketHandlers === 'function') {
                window.__ulpBindStatsSocketHandlers(socket);
            }
        });

        socket.on('reconnect', () => {
            emitPresencePulse();
            schedulePresencePulse();
            requestPendingCountRefresh();
            refreshHeaderAccountState();
            if (typeof window.ulpRequestGlobalChatHistory === 'function') {
                window.ulpRequestGlobalChatHistory(socket);
            }
            if (typeof window.__ulpBindStatsSocketHandlers === 'function') {
                window.__ulpBindStatsSocketHandlers(socket);
            }
        });
    }

    if (socket) {
        socket.on('presence_idle_expired', (data) => {
            window._presenceIdleSessionEnded = true;
            if (presencePulseTimer) {
                clearTimeout(presencePulseTimer);
                presencePulseTimer = null;
            }
            try {
                if (socket.io && typeof socket.io.reconnection === 'function') {
                    socket.io.reconnection(false);
                }
            } catch (e) { /* ignore */ }
            try {
                socket.disconnect();
            } catch (e) { /* ignore */ }
            /* Server already dropped the session — allow an explicit user action to reconnect. */
            ulpEnableSharedSocketReconnection();
        });
    }

    document.addEventListener('pageLoaded', () => {
        bumpSiteAction();
        refreshHeaderAccountState();
        injectAnnouncementsToList();
        emitPresencePulse();
        schedulePresencePulse();
    });

    } // if (socket): handlers above — forum helpers + HTTP post like below must run when Socket.IO is missing

    function ulpSetTelemetryPodCount(pod, nextVal, iconClass) {
        if (!pod) return;
        const n = Number(nextVal);
        if (!Number.isFinite(n)) return;

        let icon = pod.querySelector(':scope > i');
        if (!icon) {
            icon = document.createElement('i');
            pod.prepend(icon);
        }
        if (iconClass) icon.className = iconClass;

        // Prefer any in-pod .forum-author-stat-value (not only direct child) so FA/wrappers cannot break the match.
        const countSpan =
            pod.querySelector('.forum-author-stat-value') ||
            pod.querySelector(':scope > .like-count') ||
            pod.querySelector(':scope > .comment-count') ||
            pod.querySelector(':scope > .views-count') ||
            pod.querySelector(':scope > .participants-count') ||
            pod.querySelector(':scope > .downloads-count') ||
            pod.querySelector(':scope > .clicks-count');

        if (countSpan) {
            const pulseHost = countSpan.classList.contains('like-count') ? '.like-btn-container' : '.telemetry-pod';
            ulpPulseIfNumericCountChanged(countSpan, n, pulseHost);
            countSpan.textContent = formatCompactCount(n);
            return;
        }

        ulpPulseIfNumericCountChanged(pod, n, null);

        // Author-style pods are often `<i></i> 12` with whitespace split across text nodes; taking only the
        // first text node can delete the real digits. Strip all non-icon children, then append one text node.
        const label = ` ${formatCompactCount(n)}`;
        const iconKeep = icon;
        Array.from(pod.childNodes).forEach((node) => {
            if (node !== iconKeep) {
                try {
                    node.remove();
                } catch (e) {
                    /* ignore */
                }
            }
        });
        pod.appendChild(document.createTextNode(label));
    }

    function ulpForumTopicDomScope() {
        return document.getElementById('forum-topic-root') || document;
    }

    function ulpForumPostRowsForAuthor(uid) {
        if (!uid) return [];
        const out = [];
        const scope = ulpForumTopicDomScope();
        try {
            scope.querySelectorAll('.forum-post-item[data-author-id]').forEach((row) => {
                const rid = parseInt(String(row.getAttribute('data-author-id') || '0'), 10) || 0;
                if (rid === uid) out.push(row);
            });
        } catch (e) {
            /* ignore */
        }
        return out;
    }

    function ulpResolveForumAuthorLikesPod(group) {
        if (!group || !group.querySelector) return null;
        let likesEl =
            group.querySelector('[data-forum-author-stat="likes"]') ||
            group.querySelector('.telemetry-pod[title="Likes received"]');
        if (!likesEl) {
            likesEl =
                Array.from(group.querySelectorAll(':scope > .telemetry-pod')).find((p) => {
                    if (p.classList.contains('like-btn-container')) return false;
                    const ic = p.querySelector(':scope > i');
                    const cls = ic ? ic.className || '' : '';
                    return /\bfa-heart\b/.test(cls) && !/\blike-icon\b/.test(cls);
                }) || null;
        }
        return likesEl;
    }

    /** Lightweight: only the "likes received" number next to the author in the current topic DOM. */
    function ulpPatchForumTopicAuthorLikesReceived(userId, likesReceived) {
        const uid = parseInt(String(userId), 10) || 0;
        const n = Number(likesReceived);
        if (!uid || !Number.isFinite(n)) return;
        const txt = formatCompactCount(n);
        const root = document.getElementById('forum-topic-root');
        const prefix = root ? '#forum-topic-root ' : '';
        const authorLikesValueSel = `${prefix}.forum-post-item[data-author-id="${uid}"] [data-forum-author-stat="likes"] .forum-author-stat-value`;
        try {
            document.querySelectorAll(authorLikesValueSel).forEach((el) => {
                el.textContent = txt;
            });
        } catch (e) {
            /* ignore */
        }
        ulpForumPostRowsForAuthor(uid).forEach((row) => {
            const group = row.querySelector('.forum-author-stats');
            if (!group) return;
            let el = group.querySelector('[data-forum-author-stat="likes"] .forum-author-stat-value');
            if (!el) {
                const pod = group.querySelector('.telemetry-pod[title="Likes received"]');
                if (pod) el = pod.querySelector('.forum-author-stat-value');
            }
            if (el) {
                el.textContent = txt;
            } else {
                const likesPod = ulpResolveForumAuthorLikesPod(group);
                if (likesPod) ulpSetTelemetryPodCount(likesPod, n, 'fas fa-heart');
            }
        });
    }
    window.ulpPatchForumTopicAuthorLikesReceived = ulpPatchForumTopicAuthorLikesReceived;

    function ulpNormalizeForumAuthorStats(raw) {
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
        const co = (v) => {
            const n = Number(v);
            return Number.isFinite(n) ? Math.trunc(n) : 0;
        };
        const hasCommentsTotal = Object.prototype.hasOwnProperty.call(raw, 'comments_total')
            || Object.prototype.hasOwnProperty.call(raw, 'commentsTotal');
        const comments_total = hasCommentsTotal ? co(raw.comments_total ?? raw.commentsTotal) : NaN;
        return {
            posts_count: co(raw.posts_count ?? raw.postsCount),
            topics_count: co(raw.topics_count ?? raw.topicsCount),
            likes_received: co(raw.likes_received ?? raw.likesReceived),
            site_comments_count: co(raw.site_comments_count ?? raw.siteCommentsCount),
            comments_total,
        };
    }

    function ulpApplyForumAuthorStatsForUser(userId, authorStats) {
        if (userId == null || !authorStats || typeof authorStats !== 'object') return;
        const uid = parseInt(String(userId), 10) || 0;
        if (!uid) return;
        let raw = authorStats;
        if (typeof raw === 'string') {
            try {
                raw = JSON.parse(raw);
            } catch (e) {
                return;
            }
        }
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return;
        const st = ulpNormalizeForumAuthorStats(Object.assign({}, raw));
        if (!st) return;
        const posts = st.posts_count;
        const siteComments = st.site_comments_count;
        let commentsTotal = st.comments_total;
        if (!Number.isFinite(commentsTotal)) {
            commentsTotal = posts + siteComments;
        }
        const topics = st.topics_count;
        const likesRec = st.likes_received;
        ulpForumPostRowsForAuthor(uid).forEach((row) => {
            const group = row.querySelector('.forum-author-stats');
            if (!group) return;
            const commentsEl =
                group.querySelector('[data-forum-author-stat="comments"]') ||
                group.querySelector('.telemetry-pod[title="Comments"]');
            if (commentsEl) ulpSetTelemetryPodCount(commentsEl, commentsTotal, 'fas fa-comments');
            const topicsEl =
                group.querySelector('[data-forum-author-stat="topics"]') ||
                group.querySelector('.telemetry-pod[title="Topics created"]');
            if (topicsEl) ulpSetTelemetryPodCount(topicsEl, topics, 'fas fa-list');
            const likesEl = ulpResolveForumAuthorLikesPod(group);
            if (likesEl) ulpSetTelemetryPodCount(likesEl, likesRec, 'fas fa-heart');
        });
    }
    window.ulpApplyForumAuthorStatsForUser = ulpApplyForumAuthorStatsForUser;

    function ulpPatchForumTopicPageStatsStrip(topicId, patch) {
        if (topicId == null || !patch || typeof patch !== 'object') return;
        const tid = parseInt(String(topicId), 10) || 0;
        if (!tid) return;
        const root = document.querySelector(`#forum-topic-root[data-topic-id="${tid}"]`);
        if (!root) return;
        const strip = root.querySelector('.forum-topic-stats');
        if (!strip) return;
        if (patch.views !== undefined && patch.views !== null) {
            const n = Number(patch.views);
            if (Number.isFinite(n)) {
                let pod = strip.querySelector('.telemetry-pod[title="Views"]');
                if (!pod) {
                    pod =
                        Array.from(strip.querySelectorAll('.telemetry-pod')).find((el) => {
                            const icon = el.querySelector('i');
                            return icon && icon.classList.contains('fa-eye');
                        }) || null;
                }
                if (pod) ulpSetTelemetryPodCount(pod, n, 'fas fa-eye');
            }
        }
        if (patch.replyCount !== undefined && patch.replyCount !== null) {
            const n = Number(patch.replyCount);
            if (Number.isFinite(n)) {
                let pod = strip.querySelector('.telemetry-pod[title="Comments"]');
                if (!pod) {
                    pod =
                        Array.from(strip.querySelectorAll('.telemetry-pod')).find((el) => {
                            const icon = el.querySelector('i');
                            return icon && (icon.classList.contains('fa-comment') || icon.classList.contains('fa-comments'));
                        }) || null;
                }
                if (pod) ulpSetTelemetryPodCount(pod, n, 'fas fa-comment');
            }
        }
        if (patch.participants !== undefined && patch.participants !== null) {
            const n = Number(patch.participants);
            if (Number.isFinite(n)) {
                const pod = strip.querySelector('.telemetry-pod[title="Participants"]');
                if (pod) ulpSetTelemetryPodCount(pod, n, 'fas fa-users');
            }
        }
    }
    window.ulpPatchForumTopicPageStatsStrip = ulpPatchForumTopicPageStatsStrip;

    /**
     * Forum topic page: update author stats strip + per-post like button from a like payload.
     * Lives here (not inline in topic.html) so SPA navigation still has handlers — innerHTML swap does not run <script>.
     */
    function ulpApplyForumPostLikeUIPayload(payload) {
        if (!payload) return;
        const aid = payload.post_author_id != null ? payload.post_author_id : payload.postAuthorId;
        const ast = payload.author_stats != null ? payload.author_stats : payload.authorStats;
        const lrTop = payload.likes_received != null ? payload.likes_received : payload.likesReceived;
        const uid = parseInt(String(aid ?? '0'), 10) || 0;
        const lrN = lrTop != null && Number.isFinite(Number(lrTop)) ? Number(lrTop) : null;
        // author_stats from the server can lag likes_received vs the top-level aggregate; never paint stale hearts.
        if (uid && ast && typeof ast === 'object' && !Array.isArray(ast)) {
            const merged = Object.assign({}, ast);
            if (lrN != null) merged.likes_received = lrN;
            ulpApplyForumAuthorStatsForUser(uid, merged);
        }
        // Always patch the numeric span directly (telemetry-pod path can miss or reshape nodes).
        if (uid && lrN != null) {
            ulpPatchForumTopicAuthorLikesReceived(uid, lrN);
        }
        const postIdRaw = payload.post_id != null ? payload.post_id : payload.postId;
        const postIdNum = postIdRaw != null && postIdRaw !== '' ? Number(postIdRaw) : NaN;
        const postId = Number.isFinite(postIdNum) && postIdNum > 0 ? postIdNum : null;
        if (!postId) return;
        const row =
            document.getElementById('forum-post-' + postId) ||
            document.querySelector(`.forum-post-item[data-post-id="${postId}"]`) ||
            document.querySelector(`[data-post-id="${postId}"].forum-post-card`);
        if (!row) return;
        const payloadUserId = parseInt(String(payload.user_id || '0'), 10) || 0;
        const meId = ulpCurrentUserId();
        const likesCount = Number(payload.likes_count || 0);

        if (row) {
            const faceStrip = row.querySelector('.ulp-like-likers[data-interactive-heart="1"][data-likers-kind="forum_post"]');
            if (faceStrip && payloadUserId && meId && payloadUserId === meId && payload.user_liked !== undefined) {
                faceStrip.setAttribute('data-viewer-liked', payload.user_liked ? '1' : '0');
            }
        }

        const toggleButtons = [];
        if (row) {
            row.querySelectorAll('.forum-post-like-toggle').forEach((btn) => {
                toggleButtons.push(btn);
            });
        }
        toggleButtons.forEach((btn) => {
            const countEl = btn.querySelector('.forum-post-like-count');
            if (countEl) {
                if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
                    window.__ulpPulseIfStatCountChanged(countEl, likesCount, '.forum-post-like-toggle');
                }
                countEl.textContent = formatCompactCount(likesCount);
            }
            btn.classList.toggle('has-likes', likesCount > 0);
            const icon =
                btn.querySelector('i.fa-heart') ||
                btn.querySelector('i.like-icon') ||
                btn.querySelector('i[class*="fa-heart"]');
            if (payloadUserId && meId && payloadUserId === meId) {
                if (payload.user_liked) {
                    btn.classList.add('is-liked');
                    if (icon) {
                        icon.classList.remove('far');
                        icon.classList.add('fas');
                    }
                } else {
                    btn.classList.remove('is-liked');
                    if (icon) {
                        icon.classList.remove('fas');
                        icon.classList.add('far');
                    }
                }
            }
        });
        if (
            typeof window.__ulpPatchForumPostLikeLikers === 'function' &&
            payload.recent_likers != null &&
            payload.likers_total != null
        ) {
            window.__ulpPatchForumPostLikeLikers(payload);
        }
    }
    window.applyForumPostLikeUIPayload = ulpApplyForumPostLikeUIPayload;

    /**
     * Forum post like Socket.IO payloads (room `forum_post_like_update`, actor `forum_post_like_status`).
     * Registered here on the same singleton socket as other forum handlers so likes work even if
     * likes.js `initializeLikes()` ran before `chatSocket` existed or rebinding order changed.
     */
    function ulpNormalizeForumPostLikeSocketPayload(payload) {
        let p = payload;
        if (typeof p === 'string') {
            try {
                p = JSON.parse(p);
            } catch (e) {
                return null;
            }
        }
        if (Array.isArray(p) && p.length) p = p[0];
        if (!p || typeof p !== 'object') return null;
        return p;
    }
    function ulpOnForumPostLikeSocketEvent(payload) {
        const p = ulpNormalizeForumPostLikeSocketPayload(payload);
        if (!p) return;
        ulpApplyForumPostLikeUIPayload(p);
        if (p.first_post && p.topic_id != null && p.likes_count !== undefined) {
            ulpApplyForumTopicLikeListUpdate(p);
        }
    }
    if (socket) {
        socket.on('forum_post_like_update', ulpOnForumPostLikeSocketEvent);
        socket.on('forum_post_like_status', ulpOnForumPostLikeSocketEvent);
    }

    function ulpForumPostLikeShowToastFromPayload(p) {
        if (!p || typeof p !== 'object') return;
        if (p.success === false && p.message && typeof window.showToast === 'function') {
            window.showToast('Error', String(p.message), null, 'fas fa-circle-exclamation', null, 'error');
            return;
        }
        if (!p.toast || typeof window.showToast !== 'function') return;
        const t = p.toast;
        const rawType = String(t.notif_type || t.type || '').toLowerCase();
        const nt = rawType === 'danger' ? 'error' : rawType;
        const isErr = nt === 'error';
        const isOk = nt === 'success';
        const isWarn = nt === 'warning';
        const defIcon = isErr
            ? 'fas fa-circle-exclamation'
            : isOk
              ? 'fas fa-check-circle'
              : isWarn
                ? 'fas fa-triangle-exclamation'
                : 'fas fa-info-circle';
        window.showToast(
            t.title || (isErr ? 'Error' : isOk ? 'Success' : isWarn ? 'Notice' : 'Attention'),
            t.message || '',
            t.link || null,
            t.icon || defIcon,
            t.id || null,
            nt && ['error', 'success', 'warning', 'info', 'system'].includes(nt) ? nt : isErr ? 'error' : null,
        );
    }

    function ulpForumPostLikeApplySuccessPayload(p) {
        let raw = p;
        if (typeof raw === 'string') {
            try {
                raw = JSON.parse(raw);
            } catch (e) {
                return;
            }
        }
        if (Array.isArray(raw) && raw.length) raw = raw[0];
        if (!raw || typeof raw !== 'object') return;
        p = raw;
        ulpForumPostLikeShowToastFromPayload(p);
        if (p.ok === false) return;
        // Do not require post_id here: socket acks are often empty while the room broadcast carries the full
        // payload; author-strip updates must still run when only post_author_id + likes_received are present.
        ulpApplyForumPostLikeUIPayload(p);
        if (p.first_post && p.topic_id != null && p.likes_count !== undefined) {
            ulpApplyForumTopicLikeListUpdate(p);
        }
    }

    /** Per-post client cooldown for forum likes (matches file/listing `toggleLike` + server copy). */
    const forumPostLikeThrottles = Object.create(null);
    const FORUM_POST_LIKE_COOLDOWN_MS = 2000;

    /**
     * Forum post likes: HTTP JSON API (reliable ack + CSRF). Socket.IO still pushes to other viewers via server fan-out.
     * Optional: join topic room when socket is up (presence + room broadcasts for other tabs).
     */
    window.toggleForumPostLike = function (postId) {
        if (postId == null || postId === '') return;
        const postPk = Number(postId);
        const postIdEmit = Number.isFinite(postPk) && postPk > 0 ? postPk : postId;
        const itemKey = 'forum_post_' + String(postIdEmit);
        const nowMs = Date.now();
        if (forumPostLikeThrottles[itemKey] && nowMs - forumPostLikeThrottles[itemKey] < FORUM_POST_LIKE_COOLDOWN_MS) {
            if (typeof window.showToast === 'function') {
                window.showToast(
                    'Slow down',
                    'Please wait 2 seconds before toggling like again.',
                    null,
                    'fas fa-triangle-exclamation',
                    null,
                    'warning',
                );
            } else if (typeof window.createFlash === 'function') {
                window.createFlash('Please wait 2 seconds before toggling like again.', 'error');
            }
            return;
        }
        forumPostLikeThrottles[itemKey] = nowMs;

        const sk = typeof window.getSharedSocket === 'function' && window.getSharedSocket();
        if (sk && sk.connected) {
            try {
                const root = document.getElementById('forum-topic-root');
                const tid = root && root.getAttribute('data-topic-id');
                if (tid) {
                    sk.emit('join_forum_topic', { topic_id: tid });
                }
            } catch (e) {
                /* ignore */
            }
        }
        const csrfMeta = document.querySelector('meta[name="csrf-token"]');
        const csrf = csrfMeta ? csrfMeta.getAttribute('content') : '';
        const url = `/discussions/api/post/${encodeURIComponent(String(postIdEmit))}/like`;
        fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRFToken': csrf,
            },
            body: JSON.stringify(csrf ? { csrf_token: csrf } : {}),
        })
            .then((r) =>
                r
                    .json()
                    .catch(() => ({}))
                    .then((data) => ({ ok: r.ok, status: r.status, data })),
            )
            .then(({ ok, status, data }) => {
                const p = data && typeof data === 'object' ? data : {};
                if (!ok) {
                    ulpForumPostLikeShowToastFromPayload(p);
                    if (typeof window.showToast === 'function' && !p.toast && p.error) {
                        const msg =
                            p.error === 'auth'
                                ? 'Please log in to like posts.'
                                : p.error === 'banned'
                                  ? 'You cannot like posts while banned.'
                                  : p.message || `Could not update like (${status}).`;
                        window.showToast('Error', msg, null, 'fas fa-circle-exclamation', null, 'error');
                    }
                    return;
                }
                ulpForumPostLikeApplySuccessPayload(p);
            })
            .catch(() => {
                if (typeof window.showToast === 'function') {
                    window.showToast(
                        'Error',
                        'Network error while updating like. Check your connection and try again.',
                        null,
                        'fas fa-circle-exclamation',
                        null,
                        'error',
                    );
                }
            });
    };

    /** First-post aggregate like counts on /discussions topic list cards (topic page uses per-post like UI + facepile under OP). */
    function ulpApplyForumTopicLikeListUpdate(data) {
        if (!data || data.topic_id == null || data.likes_count === undefined) return;
        const tid = String(data.topic_id);
        if (!tid) return;
        const likesVal = Number(data.likes_count);
        if (!Number.isFinite(likesVal)) return;
        const actorId = parseInt(String(data.user_id || '0'), 10) || 0;
        const meId = ulpCurrentUserId();
        const pods = new Set();
        document.querySelectorAll(`.forum-topic-like-indicator[data-topic-id="${tid}"]`).forEach((el) => pods.add(el));
        document.querySelectorAll(`.forum-topic-list-card[data-topic-id="${tid}"]`).forEach((card) => {
            const direct = card.querySelector('.forum-topic-stats .telemetry-pod[title="Topic likes"]');
            if (direct) {
                pods.add(direct);
                return;
            }
            const byIcon = Array.from(card.querySelectorAll('.forum-topic-stats .telemetry-pod')).find((el) => {
                const icon = el.querySelector('i');
                return icon && icon.classList.contains('fa-heart');
            }) || null;
            if (byIcon) pods.add(byIcon);
        });
        pods.forEach((pod) => {
            let likedByMe = pod.classList.contains('is-liked');
            if (actorId && meId && actorId === meId) {
                likedByMe = !!data.user_liked;
            }
            pod.classList.toggle('has-likes', likesVal > 0);
            pod.classList.toggle('is-liked', likedByMe);
            ulpSetTelemetryPodCount(
                pod,
                likesVal,
                `like-icon ${likedByMe ? 'fas' : 'far'} fa-heart`
            );
        });
        const opAid = data.post_author_id ?? data.postAuthorId;
        const opUid = parseInt(String(opAid || '0'), 10) || 0;
        const opLr = data.likes_received ?? data.likesReceived;
        if (opUid && opLr != null && Number.isFinite(Number(opLr))) {
            ulpPatchForumTopicAuthorLikesReceived(opUid, Number(opLr));
        }
        const opAst = data.author_stats ?? data.authorStats;
        if (opAid != null && opAst && typeof opAst === 'object') {
            ulpApplyForumAuthorStatsForUser(opAid, opAst);
        }
        if (
            typeof window.__ulpPatchForumPostLikeLikers === 'function' &&
            data.post_id != null &&
            data.recent_likers != null &&
            data.likers_total != null
        ) {
            window.__ulpPatchForumPostLikeLikers(data);
        }
    }

    if (socket) {

    socket.on('forum_author_stats_update', (data) => {
        if (!data) return;
        const uid = parseInt(String(data.user_id ?? data.userId ?? '0'), 10) || 0;
        const rawStats = data.author_stats ?? data.authorStats;
        if (uid && rawStats != null && typeof rawStats === 'object' && !Array.isArray(rawStats)) {
            ulpApplyForumAuthorStatsForUser(uid, rawStats);
        }
    });

    // forum_post_like_update / forum_post_like_status: bound above (with applyForumPostLikeUIPayload).

    socket.on('forum_topic_header_sync', (data) => {
        if (!data || data.topic_id == null) return;
        const p = {};
        if (data.topic_reply_count !== undefined && data.topic_reply_count !== null) {
            p.replyCount = Number(data.topic_reply_count);
        }
        if (data.topic_views !== undefined && data.topic_views !== null) {
            p.views = Number(data.topic_views);
        }
        if (data.topic_participant_count !== undefined && data.topic_participant_count !== null) {
            p.participants = Number(data.topic_participant_count);
        }
        if (Object.keys(p).length) {
            ulpPatchForumTopicPageStatsStrip(data.topic_id, p);
        }
    });

    // Forum topic views (server: process_stat_increment → forum_topic_update)
    function __ulpOnForumTopicUpdate(data) {
        if (!data || data.topic_id == null || data.views === undefined) return;
        const viewsVal = Number(data.views);
        if (!Number.isFinite(viewsVal)) return;
        ulpPatchForumTopicPageStatsStrip(data.topic_id, { views: viewsVal });
        document.querySelectorAll(`.forum-topic-list-card[data-topic-id="${data.topic_id}"]`).forEach((card) => {
            let pod = card.querySelector('.forum-topic-stats .telemetry-pod[title="Views"]');
            if (!pod) {
                pod = Array.from(card.querySelectorAll('.forum-topic-stats .telemetry-pod')).find((el) => {
                    const icon = el.querySelector('i');
                    return icon && icon.classList.contains('fa-eye');
                }) || null;
            }
            if (pod) {
                ulpSetTelemetryPodCount(pod, viewsVal, 'fas fa-eye');
            }
        });
    }

    socket.on('forum_topic_like_update', (data) => {
        ulpApplyForumTopicLikeListUpdate(data);
    });

    function ulpRenderForumTopicReplyMeta(topicCard, opts = {}) {
        if (!topicCard) return;
        let replyCt = opts.replyCt;
        if (replyCt === undefined || replyCt === null || Number.isNaN(Number(replyCt))) {
            const cc = topicCard.querySelector('.comment-count');
            if (cc) {
                const parsed = parseInt(String(cc.textContent || '').replace(/[^\d]/g, ''), 10);
                replyCt = Number.isFinite(parsed) ? parsed : 0;
            } else {
                replyCt = 0;
            }
        } else {
            replyCt = Math.max(0, Number(replyCt));
        }
        const activityCompact = String(opts.activityCompact || '');
        const activityTitle = String(opts.activityTitle || '');
        const activityTs = opts.activityTs || opts.activity_ts || null;
        const author = opts.author || opts.last_reply_author || null;
        const bumpKind = String(opts.bump_kind || '').toLowerCase();
        const bumpDate = String(opts.bump_date || opts.activityCompact || '');
        const bumpTitle = String(opts.bump_precise || opts.activityTitle || '');
        const bumpTs = opts.bump_at || opts.activityTs || opts.activity_ts || null;
        const showBumpTime =
            replyCt === 0 && !!(opts.is_bumped && bumpTs && (bumpKind === 'manual' || bumpKind === 'owner'));
        const showReplyTime = replyCt > 0 && activityCompact;
        const showNoReplies = replyCt === 0 && !showBumpTime;

        const lastReplyCell = topicCard.querySelector('.forum-topic-meta-cell.forum-topic-meta-last-reply');
        const lastReplyBody = lastReplyCell
            ? (lastReplyCell.querySelector('.forum-topic-meta-last-reply-body') || lastReplyCell)
            : null;
        if (lastReplyCell) {
            lastReplyCell.classList.toggle('is-empty', !showNoReplies && !(replyCt > 0 && author && author.username));
        }
        if (lastReplyBody) {
            if (replyCt > 0 && author && author.username) {
                const avatarUrl = author.avatar
                    ? `/static/uploads/profiles/${author.avatar}`
                    : window.ulpResolveAvatarUrl(author);
                const verifiedHtml = author.is_verified ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>' : '';
                let groupsHtml = '';
                const _gs = author.groups || [];
                if (typeof window.formatGroupBadgePileHtml === 'function') {
                    groupsHtml = window.formatGroupBadgePileHtml(_gs) || '';
                } else {
                    _gs.forEach((g) => {
                        const iconCls =
                            typeof window.normalizeFaIconClass === 'function'
                                ? window.normalizeFaIconClass(g.icon || 'fas fa-star')
                                : (g.icon || 'fas fa-star');
                        const iconColor = g.icon_color || '#f5f8ff';
                        const gColor = g.color || '#333';
                        groupsHtml += `<span class="group-badge" title="${g.name || ''}" style="--badge-bg: ${gColor}; --badge-icon-color: ${iconColor}; background-color: var(--badge-bg);"><i class="${iconCls}"></i></span>`;
                    });
                    if (groupsHtml) groupsHtml = `<span class="group-badge-pile" aria-hidden="true">${groupsHtml}</span>`;
                }
                lastReplyBody.innerHTML = sanitizeRichHtml(`
                    <span class="forum-topic-meta-person forum-topic-meta-person-last-reply">
                        <span class="forum-topic-meta-label" title="Last reply"><i class="fas fa-reply"></i></span>
                        <a href="/user/${encodeURIComponent(author.username || '')}" class="username-tag ${author.role || ''} forum-user-tag forum-topic-last-reply-link" style="display:inline-flex;align-items:center;text-decoration:none;">
                            <span class="user-avatar-slot"><img src="${avatarUrl}" class="user-avatar-circle" alt=""></span>
                            ${author.username || ''}${verifiedHtml}${groupsHtml}
                        </a>
                    </span>`);
            } else if (showNoReplies) {
                lastReplyBody.innerHTML = `<span class="forum-topic-meta-person forum-topic-meta-person-last-reply"><span class="telemetry-pod forum-topic-no-replies" title="No replies yet"><i class="far fa-comment-dots"></i> No replies</span></span>`;
            } else {
                lastReplyBody.innerHTML = '';
            }
        }

        const activityCell = topicCard.querySelector('.forum-topic-meta-cell.forum-topic-meta-activity');
        if (activityCell) {
            if (showReplyTime) {
                activityCell.classList.remove('is-empty');
                activityCell.innerHTML = `<span class="telemetry-pod forum-topic-activity-at" title="${escapeHtml(activityTitle)}"${activityTs ? ` data-ulp-time-ts="${escapeHtml(String(activityTs))}"` : ''}><i class="far fa-clock"></i> <span class="ulp-live-time">${escapeHtml(activityCompact)}</span></span>`;
            } else if (showBumpTime) {
                activityCell.classList.remove('is-empty');
                activityCell.innerHTML = `<span class="telemetry-pod forum-topic-activity-at forum-topic-bump-at" title="${escapeHtml(bumpTitle)}" data-activity-kind="${escapeHtml(bumpKind)}"${bumpTs ? ` data-ulp-time-ts="${escapeHtml(String(bumpTs))}"` : ''}><i class="fas fa-level-up-alt" aria-hidden="true"></i> <span class="ulp-live-time">${escapeHtml(bumpDate)}</span></span>`;
            } else {
                activityCell.classList.add('is-empty');
                activityCell.innerHTML = '';
            }
            if (typeof window.ulpUpdateLiveTimes === 'function') {
                window.ulpUpdateLiveTimes(activityCell);
            }
        }
    }

    function ulpApplyForumTopicBumpListUpdate(data) {
        if (!data || data.topic_id == null) return;
        const topicId = String(data.topic_id);
        const topicCard = document.querySelector(`.forum-topic-list-card[data-topic-id="${topicId}"]`);
        if (!topicCard) return;
        const sortTs = parseFloat(data.sort_ts != null ? data.sort_ts : data.bumped_at);
        if (Number.isFinite(sortTs)) {
            topicCard.dataset.bumpedAt = String(sortTs);
            topicCard.setAttribute('data-bumped-at', String(sortTs));
        }
        const replyCtRaw = data.topic_reply_count != null ? data.topic_reply_count : data.reply_count;
        const replyCt = replyCtRaw != null && replyCtRaw !== '' ? Number(replyCtRaw) : undefined;
        ulpRenderForumTopicReplyMeta(topicCard, {
            replyCt: Number.isFinite(replyCt) ? replyCt : undefined,
            activityCompact: data.activity_compact || data.bump_date || '',
            activityTitle: data.activity_title || data.bump_precise || '',
            activityTs: data.activity_ts || data.bump_at || null,
            author: data.last_reply_author || data.author || null,
            bump_actor: data.bump_actor || null,
            bump_kind: data.bump_kind,
            is_bumped: data.is_bumped,
            bump_icon: data.bump_icon,
            bump_precise: data.bump_precise,
            bump_date: data.bump_date,
            bump_at: data.bump_at,
        });
        const list = topicCard.parentElement;
        if (!list || !list.classList.contains('forum-topic-list')) return;
        const pinned = Array.from(list.querySelectorAll('.forum-topic-list-card')).filter((card) => {
            return !!card.querySelector('.forum-topic-status-pin');
        });
        const unpinned = Array.from(list.querySelectorAll('.forum-topic-list-card')).filter((card) => {
            return !card.querySelector('.forum-topic-status-pin');
        });
        unpinned.sort((a, b) => {
            const ta = parseFloat(a.getAttribute('data-bumped-at') || '0');
            const tb = parseFloat(b.getAttribute('data-bumped-at') || '0');
            return (Number.isFinite(tb) ? tb : 0) - (Number.isFinite(ta) ? ta : 0);
        });
        [...pinned, ...unpinned].forEach((card) => list.appendChild(card));
    }
    window.ulpApplyForumTopicBumpListUpdate = ulpApplyForumTopicBumpListUpdate;

    socket.on('forum_topic_bumped', (data) => {
        if (typeof window.ulpApplyForumTopicBumpListUpdate === 'function') {
            window.ulpApplyForumTopicBumpListUpdate(data);
        }
    });

    // --- GLOBAL COMMENT & CONTENT REMOVAL HANDLERS (SPA Optimized) ---
    
    socket.on('new_comment', (data) => {
        const list = document.getElementById('comments-list');
        if (!list) {
            return;
        }

        // Check if this comment belongs to the current page (data-page-id attribute on list)
        // We set this attribute in templates
        const currentPageId = list.getAttribute('data-page-id'); // e.g. "file_123" or "resource_456"
        const targetPageId = data.file_id ? `file_${data.file_id}` : `resource_${data.listing_id}`;
        
        if (currentPageId && currentPageId !== targetPageId) {
            return;
        }

        if (!mayViewPendingModerationPayload(data)) {
            return;
        }

        const existingRow = document.getElementById('comment-' + data.id);
        if (existingRow) {
            const me = window.__ulpDiscussionCurrentUserId;
            if (
                me &&
                String(data.user_id) === String(me) &&
                typeof window.__ulpScrollToDiscussionComment === 'function'
            ) {
                window.__ulpScrollToDiscussionComment(existingRow, { smooth: true });
            }
            // Moderation: pending row already in DOM; approve re-emits `new_comment` with same id.
            if (data.is_approved) {
                const actions = existingRow.querySelector('.comment-actions');
                if (actions) {
                    actions.querySelectorAll('span.adm-badge-yellow').forEach((el) => {
                        if ((el.textContent || '').trim().toUpperCase() === 'PENDING') {
                            el.remove();
                        }
                    });
                }
                const timeEl = existingRow.querySelector('.comment-shown-time');
                if (timeEl && (data.created_at != null || data.timestamp != null)) {
                    const label =
                        data.created_at != null && String(data.created_at).trim() !== ''
                            ? String(data.created_at)
                            : String(data.timestamp || '');
                    if (data.created_at_precise != null) {
                        timeEl.title = String(data.created_at_precise);
                    }
                    timeEl.replaceChildren();
                    const ic = document.createElement('i');
                    ic.className = 'far fa-clock';
                    timeEl.appendChild(ic);
                    timeEl.appendChild(document.createTextNode(` ${label}`));
                    if (data.created_at_ts) timeEl.setAttribute('data-ulp-time-ts', String(data.created_at_ts));
                }
            }
            return;
        }

        // Use the specialized render function from the template if available, 
        // else fallback to basic (though usually the template defines it)
        if (window.appendCommentToDOM) {
            window.appendCommentToDOM(data);
        } else {
            console.warn('Realtime: window.appendCommentToDOM not found.');
        }
    });

    socket.on('comment_updated', (payload) => {
        const id = payload && payload.id;
        if (!id) return;
        const row = document.getElementById('comment-' + id);
        if (!row) return;
        const body = row.querySelector('.discussion-message-body');
        if (!body) return;
        body.innerHTML = sanitizeRichHtml(payload.content_html || '');
    });

    socket.on('new_forum_post', (data) => {
        // Must run before any early `return` (e.g. paginated topic + reply composer focus),
        // so every visible row for this author gets the same counters/animations.
        const nfAst = data && (data.author_stats ?? data.authorStats);
        if (data && data.user_id != null && nfAst && typeof nfAst === 'object') {
            ulpApplyForumAuthorStatsForUser(data.user_id, nfAst);
        }
        if (data && data.topic_id != null) {
            const hdrPatch = {};
            if (data.topic_reply_count !== undefined && data.topic_reply_count !== null) {
                hdrPatch.replyCount = Number(data.topic_reply_count);
            }
            if (data.topic_participant_count !== undefined && data.topic_participant_count !== null) {
                hdrPatch.participants = Number(data.topic_participant_count);
            }
            if (data.topic_views !== undefined && data.topic_views !== null) {
                hdrPatch.views = Number(data.topic_views);
            }
            if (Object.keys(hdrPatch).length) {
                ulpPatchForumTopicPageStatsStrip(data.topic_id, hdrPatch);
            }
        }

        const list = document.getElementById('forum-posts-list');
        if (list) {
            const currentPageId = list.getAttribute('data-page-id');
            const targetId = data.topic_id ? `forum_topic_${data.topic_id}` : '';
            if (!(currentPageId && targetId && currentPageId !== targetId)) {
                const isPaginatedTopic = list.getAttribute('data-paginated') === '1';
                if (isPaginatedTopic) {
                    const currentPage = parseInt(list.getAttribute('data-page') || '1', 10) || 1;
                    const perPage = parseInt(list.getAttribute('data-per-page') || '0', 10) || 0;
                    const replyCount = Number(data.topic_reply_count);
                    let targetPage = currentPage;
                    if (perPage > 0 && Number.isFinite(replyCount)) {
                        targetPage = Math.max(1, Math.ceil(Math.max(replyCount, 0) / perPage));
                    }
                    ulpPatchForumTopicReplyPaginationMeta(list, replyCount);
                    // New reply is on another page (e.g. last page) — do not SPA-reload; that resets the reply editor.
                    if (targetPage !== currentPage) {
                        ulpForumTopicToastNewRepliesOnOtherPage();
                    } else if (
                        mayViewPendingModerationPayload(data) &&
                        !document.getElementById('forum-post-' + data.id) &&
                        window.appendForumPostToDOM
                    ) {
                        window.appendForumPostToDOM(data);
                    }
                } else if (
                    mayViewPendingModerationPayload(data) &&
                    !document.getElementById('forum-post-' + data.id) &&
                    window.appendForumPostToDOM
                ) {
                    window.appendForumPostToDOM(data);
                    if (data && data.user_id != null && nfAst && typeof nfAst === 'object') {
                        ulpApplyForumAuthorStatsForUser(data.user_id, nfAst);
                    }
                }
            }
        }

        if (data && data.topic_id != null && !mayViewForumTopicListCard(data)) {
            ulpRemoveForumTopicListCards(data.topic_id);
        } else if (typeof ulpStripNonPublicForumTopicCards === 'function') {
            ulpStripNonPublicForumTopicCards();
        }

        // Update topic card in category list in realtime (last replier + counters + activity).
        const topicCard = data && data.topic_id
            ? document.querySelector(`.forum-topic-list-card[data-topic-id="${data.topic_id}"]`)
            : null;
        if (topicCard && data.is_approved !== false && mayViewForumTopicListCard(data)) {
            const replyCt = Number(data.topic_reply_count || 0);
            const postsEl = topicCard.querySelector('.telemetry-pod[title="Posts in thread"]');
            if (postsEl) {
                ulpSetTelemetryPodCount(postsEl, replyCt, 'fas fa-comments');
            }
            const commentsEl =
                topicCard.querySelector('.telemetry-pod[title="Comments"]') ||
                Array.from(topicCard.querySelectorAll('.forum-topic-stats .telemetry-pod')).find((el) => {
                    const icon = el.querySelector('i');
                    return icon && (icon.classList.contains('fa-comment') || icon.classList.contains('fa-comments'));
                });
            if (commentsEl) {
                ulpSetTelemetryPodCount(commentsEl, replyCt, 'fas fa-comment');
            }

            const repliesEl = topicCard.querySelector('.telemetry-pod[title="Replies"]');
            if (repliesEl) {
                ulpSetTelemetryPodCount(repliesEl, replyCt, 'fas fa-reply');
            }
            const author = {
                username: data.username || '',
                role: data.role || '',
                is_verified: !!data.is_verified,
                avatar: data.avatar || null,
                groups: data.groups || [],
            };
            ulpRenderForumTopicReplyMeta(topicCard, {
                replyCt,
                activityCompact: data.topic_activity_compact || data.topic_last_comment_time || '',
                activityTitle: data.topic_activity_title || '',
                activityTs: data.topic_activity_ts || data.created_at_ts || null,
                author,
                is_bumped: true,
                bump_kind: 'comment',
                bump_icon: 'fas fa-comment',
                bump_precise: data.topic_activity_title ? ('Commented: ' + data.topic_activity_title) : '',
                bump_date: data.topic_activity_compact || data.topic_last_comment_time || '',
                bump_at: data.topic_activity_ts || data.created_at_ts || null,
            });

            if (Number.isFinite(parseFloat(data.topic_activity_ts || data.created_at_ts))) {
                topicCard.dataset.bumpedAt = String(data.topic_activity_ts || data.created_at_ts);
                topicCard.setAttribute('data-bumped-at', String(data.topic_activity_ts || data.created_at_ts));
            }

            // keep active topics visible on top as replies arrive (respect pinned rows)
            if (topicCard.parentElement && !topicCard.querySelector('.forum-topic-status-pin')) {
                const list = topicCard.parentElement;
                const firstUnpinned = Array.from(list.querySelectorAll('.forum-topic-list-card')).find((card) => !card.querySelector('.forum-topic-status-pin'));
                if (firstUnpinned && firstUnpinned !== topicCard) {
                    list.insertBefore(topicCard, firstUnpinned);
                }
            }
        }

        // Update category card on Discussions index: last replier + where replied.
        const categoryCard = data && data.topic_category_id
            ? document.querySelector(`.forum-category-card[data-category-id="${data.topic_category_id}"]`)
            : null;
        if (categoryCard) {
            const meta = categoryCard.querySelector('.forum-category-card-meta');
            if (meta) {
                // Update last activity time pod
                const timePod = meta.querySelector('.telemetry-pod .fa-clock')?.closest('.telemetry-pod');
                if (timePod) {
                    const nextTimeHtml = `<i class="far fa-clock"></i> ${escapeHtml(data.topic_activity_compact || '')}`;
                    if (timePod.innerHTML !== nextTimeHtml) {
                        ulpAttachRealtimeStatPulse(timePod);
                    }
                    timePod.setAttribute('title', data.topic_activity_title || '');
                    if (data.topic_activity_ts || data.created_at_ts) {
                        timePod.setAttribute('data-ulp-time-ts', String(data.topic_activity_ts || data.created_at_ts));
                    }
                    timePod.innerHTML = nextTimeHtml;
                }

                // Increment posts count for category stats
                const postsPod = Array.from(meta.querySelectorAll('.telemetry-group .telemetry-pod')).find((el) => {
                    const icon = el.querySelector('i');
                    return icon && icon.classList.contains('fa-comments');
                });
                if (postsPod) {
                    const current = Number(postsPod.getAttribute('data-count') || 0);
                    const next = Number.isFinite(current) ? current + 1 : 1;
                    postsPod.setAttribute('data-count', String(next));
                    ulpSetTelemetryPodCount(postsPod, next, 'fas fa-comments');
                }

                const avatarUrl = data.avatar
                    ? `/static/uploads/profiles/${data.avatar}`
                    : window.ulpResolveAvatarUrl(data);
                const verifiedHtml = data.is_verified ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>' : '';
                let groupsHtml = '';
                const _gs2 = data.groups || [];
                if (typeof window.formatGroupBadgePileHtml === 'function') {
                    groupsHtml = window.formatGroupBadgePileHtml(_gs2) || '';
                } else {
                    _gs2.forEach((g) => {
                        const iconCls =
                            typeof window.normalizeFaIconClass === 'function'
                                ? window.normalizeFaIconClass(g.icon || 'fas fa-star')
                                : (g.icon || 'fas fa-star');
                        const iconColor = g.icon_color || '#f5f8ff';
                        const gColor = g.color || '#333';
                        groupsHtml += `<span class="group-badge" title="${g.name || ''}" style="--badge-bg: ${gColor}; --badge-icon-color: ${iconColor}; background-color: var(--badge-bg);"><i class="${iconCls}"></i></span>`;
                    });
                    if (groupsHtml) groupsHtml = `<span class="group-badge-pile" aria-hidden="true">${groupsHtml}</span>`;
                }

                let lastUser = meta.querySelector('.forum-last-reply-user');
                if (!lastUser) {
                    const spacer = document.createElement('span');
                    spacer.className = 'forum-topic-list-meta-spacer';
                    meta.appendChild(spacer);
                    lastUser = document.createElement('span');
                    meta.appendChild(lastUser);
                }
                if (lastUser) {
                    lastUser.className = `username-tag ${data.role || ''} forum-user-tag forum-last-reply-user`;
                    lastUser.style.display = 'inline-flex';
                    lastUser.style.alignItems = 'center';
                    lastUser.innerHTML = sanitizeRichHtml(`<span class="user-avatar-slot"><img src="${avatarUrl}" class="user-avatar-circle" alt=""></span>${data.username || ''}${verifiedHtml}${groupsHtml}`);
                }

                let topicPod = meta.querySelector('.forum-last-reply-topic');
                if (!topicPod) {
                    topicPod = document.createElement('span');
                    topicPod.className = 'telemetry-pod forum-last-reply-topic';
                    meta.appendChild(topicPod);
                }
                const topicLabel = data.topic_display_title || data.topic_title || (data.topic_id ? `Topic #${data.topic_id}` : 'Topic');
                const nextTopicInner = `<i class="fas fa-reply"></i><span class="forum-last-reply-topic-text">${escapeHtml(topicLabel)}</span>`;
                if (topicPod.innerHTML !== nextTopicInner) {
                    ulpAttachRealtimeStatPulse(topicPod);
                }
                topicPod.setAttribute('title', `Last reply in: ${topicLabel}`);
                topicPod.innerHTML = nextTopicInner;
            }
        }
    });

    socket.on('forum_topics_bulk_moved', () => {
        const currentPath = window.location.pathname || '';
        if (
            (currentPath === '/discussions' || currentPath.startsWith('/discussions/c/')) &&
            typeof window.loadPage === 'function'
        ) {
            setTimeout(() => {
                window.loadPage(window.location.pathname + window.location.search, true);
            }, 120);
        }
    });

    socket.on('forum_topic_settings_update', (data) => {
        if (!data || data.id == null) return;
        const currentPath = window.location.pathname || '';
        const onDiscussions = currentPath === '/discussions';
        const onCategoryList = /^\/discussions\/c\//i.test(currentPath);
        const onTopicView =
            /^\/discussions\/t\//i.test(currentPath) &&
            currentPath.indexOf(`/discussions/t/${data.id}/`) !== -1;
        if (
            (onDiscussions || onCategoryList || onTopicView) &&
            typeof window.loadPage === 'function'
        ) {
            setTimeout(() => {
                window.loadPage(window.location.pathname + window.location.search, true, {
                    showLoader: false,
                });
            }, 160);
        }
    });

    socket.on('new_forum_topic', (data) => {
        const openingOk = data && (data.opening_post_approved !== false && data.is_approved !== false);
        if (!openingOk && !mayViewPendingModerationPayload({ is_approved: false, user_id: data && data.user_id })) {
            return;
        }
        const currentPath = window.location.pathname || '';
        // Discussions index cards aggregate category stats. Re-sync the page to avoid
        // stale counters/last-reply chips when a new topic appears in any category.
        if (currentPath === '/discussions' && window.loadPage) {
            setTimeout(() => {
                window.loadPage(window.location.pathname + window.location.search, true);
            }, 180);
            return;
        }

        let list = document.querySelector('.forum-topic-list');
        const slugFromPath = (() => {
            const m = window.location.pathname.match(/^\/discussions\/c\/([^\/?#]+)/i);
            return m ? decodeURIComponent(m[1]) : '';
        })();
        if (!slugFromPath || !data || !data.category_slug) return;
        if (slugFromPath !== String(data.category_slug)) return;
        if (document.querySelector(`.forum-topic-list-card[data-topic-id="${data.id}"]`)) return;

        const noTopics = document.querySelector('.cyber-card');
        if (noTopics && /No topics in this category yet\./i.test(noTopics.textContent || '')) {
            noTopics.remove();
        }
        if (!list) {
            const forumPage = document.querySelector('.forum-page');
            if (!forumPage) return;
            list = document.createElement('div');
            list.className = 'forum-topic-list';
            forumPage.appendChild(list);
        }

        const author = data.author || {};
        const avatarUrl = author.avatar
            ? `/static/uploads/profiles/${author.avatar}`
            : window.ulpResolveAvatarUrl(author);
        let groupsHtml = '';
        const _gs3 = author.groups || [];
        if (typeof window.formatGroupBadgePileHtml === 'function') {
            groupsHtml = window.formatGroupBadgePileHtml(_gs3) || '';
        } else {
            _gs3.forEach((g) => {
                const iconCls =
                    typeof window.normalizeFaIconClass === 'function'
                        ? window.normalizeFaIconClass(g.icon || 'fas fa-star')
                        : (g.icon || 'fas fa-star');
                const iconColor = g.icon_color || '#f5f8ff';
                const gColor = g.color || '#333';
                groupsHtml += `<span class="group-badge" title="${g.name || ''}" style="--badge-bg: ${gColor}; --badge-icon-color: ${iconColor}; background-color: var(--badge-bg);"><i class="${iconCls}"></i></span>`;
            });
            if (groupsHtml) groupsHtml = `<span class="group-badge-pile" aria-hidden="true">${groupsHtml}</span>`;
        }
        const authorTagHtml =
            typeof window.formatUsernameTagChipHtml === 'function'
                ? window.formatUsernameTagChipHtml({
                      username: author.username || '',
                      role: author.role || 'user',
                      avatarUrl: avatarUrl,
                      groups: author.groups || [],
                      verified: !!author.is_verified,
                      extraClass: 'forum-topic-author-link',
                  })
                : `<a href="/user/${encodeURIComponent(author.username || '')}" class="username-tag ${author.role || ''} forum-user-tag forum-topic-author-link" style="display:inline-flex;align-items:center;text-decoration:none;"><span class="user-avatar-slot"><img src="${avatarUrl}" class="user-avatar-circle" alt=""></span>${author.username || ''}${author.is_verified ? ' <i class="fas fa-check-circle verified-badge" title="Verified"></i>' : ''}${groupsHtml}</a>`;
        const chatW = (typeof window.__ulpGetFloatingChatRoot === 'function' && window.__ulpGetFloatingChatRoot())
            || document.querySelector('body > #chat-widget-container')
            || document.getElementById('chat-widget-container');
        const userRole = chatW ? chatW.getAttribute('data-user-role') : (document.body && document.body.getAttribute('data-user-role')) || '';
        const isAdmin = userRole === 'admin';
        const canModerate = userRole === 'admin' || userRole === 'moderator';
        const openingPending = data.opening_post_approved === false;
        const pendingBadge =
            canModerate && openingPending
                ? '<span class="status-badge badge status-badge-pending" title="Pending moderation">PENDING</span>'
                : '';
        const actionsColHtml =
            typeof window.ulpForumTopicListActionsHtml === 'function'
                ? window.ulpForumTopicListActionsHtml(data.id, data.user_id, {
                      canModerate: canModerate,
                      isAdmin: isAdmin,
                      openingPending: openingPending,
                      openingPostId: data.opening_post_id,
                  })
                : '';
        let categoryRowHtml = '';
        const catName = data.category_name ? String(data.category_name).trim() : '';
        const catSlug = data.category_slug ? String(data.category_slug).trim() : '';
        if (catName && catSlug) {
            const catIconRaw = (data.category_icon || 'fas fa-folder-open')
                .replace(/[^a-z0-9\s\-]/gi, '')
                .trim()
                .slice(0, 80);
            const safeCatName = catName.replace(/&/g, '&amp;').replace(/</g, '&lt;');
            const catHref = `/discussions?category=${encodeURIComponent(catSlug)}`;
            categoryRowHtml = `<div class="forum-topic-list-card-category-row"><a href="${catHref}" class="telemetry-pod forum-topic-category-pill"><i class="${catIconRaw}" aria-hidden="true"></i> ${safeCatName}</a></div>`;
        }
        const createdTitleEsc = data.created_title ? String(data.created_title).replace(/"/g, '&quot;') : '';
        const createdTsAttr = data.created_ts ? ` data-ulp-time-ts="${data.created_ts}"` : '';
        const sortTs = data.activity_ts || data.created_ts;
        const scope = (data.pin_scope || '').trim();
        const showPin =
            scope === 'global' || scope === 'category' || (data.is_pinned && !scope);
        let pinTitle = '';
        if (scope === 'global') pinTitle = 'Pinned — all topics';
        else if (scope === 'category') pinTitle = 'Pinned — this category';
        else if (showPin) pinTitle = 'Pinned';
        const pinHtml = showPin
            ? `<i class="fas fa-thumbtack forum-topic-title-w-prefix-ico forum-topic-status-pin" style="color: var(--primary-color);" title="${pinTitle}"></i>`
            : '';
        const lockHtml = data.is_locked
            ? '<i class="fas fa-lock forum-topic-title-w-prefix-ico forum-topic-status-lock" title="Locked" aria-label="Locked"></i>'
            : '';

        let prefixLinkHtml = '';
        const rawPrefixes = Array.isArray(data.prefixes) && data.prefixes.length
            ? data.prefixes
            : (data.prefix ? [data.prefix] : []);
        const validPrefixes = rawPrefixes.filter((pfx) => pfx && pfx.label);
        const hexOk = (c) => c && /^#[0-9a-fA-F]{3,8}$/.test(String(c).trim());
        const prefixItems = validPrefixes.map((pfx) => {
                const safeLabel = String(pfx.label)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/"/g, '&quot;');
                const accent = hexOk(pfx.color) ? `--forum-prefix-accent:${String(pfx.color).trim()};` : '';
                const col = accent ? ` style="${accent}"` : '';
                const icRaw = (pfx.icon || '').replace(/[^a-z0-9\s\-]/gi, '').trim().slice(0, 80);
                const ic = icRaw ? `<i class="${icRaw}" aria-hidden="true"></i> ` : '';
                const slug = String(pfx.slug || '').trim();
                let filterHref = '';
                if (slug) {
                    try {
                        const u = new URL(`${window.location.origin}/discussions`);
                        u.searchParams.set('prefix', slug);
                        const catSlug = data.category_slug ? String(data.category_slug).trim() : '';
                        if (catSlug) u.searchParams.set('category', catSlug);
                        filterHref = u.pathname + u.search;
                    } catch (e) {
                        filterHref = '';
                    }
                }
                if (filterHref) {
                    const escHref = filterHref.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
                    return `<a href="${escHref}" class="forum-topic-prefix-chip forum-topic-prefix-chip--link forum-topic-prefix-chip--seg"${col}>${ic}<span class="forum-topic-prefix-label">${safeLabel}</span></a>`;
                }
                return `<span class="forum-topic-prefix-chip forum-topic-prefix-chip--seg"${col}>${ic}<span class="forum-topic-prefix-label">${safeLabel}</span></span>`;
            });
        if (prefixItems.length) {
            prefixLinkHtml = `<span class="forum-topic-prefix-pack">${prefixItems.join('')}</span>`;
        }

        const decodePlain = typeof window.decodePlainTextField === 'function'
            ? window.decodePlainTextField
            : (s) => (s == null ? '' : String(s));
        const safeNewTopicTitle = esc(decodePlain(String(data.title || '')));

        const bulkCol = isAdmin
            ? `<div class="list-bulk-checkbox-cell"><label><input type="checkbox" class="cyber-checkbox forum-topic-checkbox" value="${data.id}" aria-label="Select topic for bulk delete"></label></div>`
            : '';

        const item = document.createElement('div');
        item.className = 'forum-topic-list-card';
        item.setAttribute('data-topic-id', data.id);
        if (openingPending) item.setAttribute('data-opening-pending', '1');
        item.setAttribute('data-list-public', openingPending ? '0' : '1');
        if (sortTs) item.setAttribute('data-bumped-at', String(sortTs));
        item.style.animation = 'fadeIn 0.25s ease';
        item.innerHTML = sanitizeRichHtml(`
            <a href="${data.url}" class="forum-topic-list-card-hit" tabindex="-1" aria-hidden="true"></a>
            <div class="forum-topic-list-card-main">
            <div class="item-main-row list-card-vstack">
            <div class="list-card-title-actions-row">
                <div class="forum-topic-list-card-title-row forum-topic-list-card-title-row--split list-card-title-row">
                    ${bulkCol}
                    ${pinHtml || lockHtml ? `<a href="${data.url}" class="forum-topic-status-lead forum-topic-status-lead--topic-link" tabindex="-1" aria-hidden="true">${pinHtml}${lockHtml}</a>` : ''}${prefixLinkHtml}
                    <a href="${data.url}" class="forum-topic-list-title"><span class="forum-topic-list-title-core"><span class="forum-topic-list-heading-text">${safeNewTopicTitle}</span></span></a>${pendingBadge}
                </div>
                ${actionsColHtml}
            </div>
            <div class="forum-topic-list-card-body list-card-body-rows">
                ${categoryRowHtml}
                <div class="file-meta forum-topic-list-meta forum-topic-list-meta-row">
                        <div class="forum-topic-meta-primary">
                        <div class="forum-topic-meta-cell forum-topic-meta-creator">
                            <span class="forum-topic-meta-person forum-topic-meta-person-creator">
                                ${authorTagHtml}
                            </span>
                        </div>
                        <div class="forum-topic-meta-cell forum-topic-meta-created">
                            <span class="telemetry-pod forum-topic-created-at" title="${createdTitleEsc ? `Created: ${createdTitleEsc}` : ''}"${createdTsAttr}><i class="far fa-clock"></i> ${data.created_compact || ''}</span>
                        </div>
                        <div class="forum-topic-meta-cell forum-topic-meta-stats-wrap">
                            <div class="telemetry-group forum-topic-stats">
                                <span class="telemetry-pod"><i class="fas fa-eye"></i> ${formatCompactCount(data.views || 0)}</span>
                                <span class="telemetry-pod like-btn-container forum-topic-like-indicator ${Number(data.topic_likes || 0) > 0 ? 'has-likes' : ''}" data-topic-id="${data.id}"><i class="like-icon far fa-heart"></i> <span class="like-count forum-topic-like-count">${formatCompactCount(data.topic_likes || 0)}</span></span>
                                <span class="telemetry-pod"><i class="fas fa-comment"></i> <span class="comment-count">${formatCompactCount(data.reply_count || 0)}</span></span>
                            </div>
                        </div>
                        </div>
                        <div class="forum-topic-meta-reply-rail">
                        <div class="forum-topic-meta-cell forum-topic-meta-last-reply">
                            <span class="forum-topic-meta-last-reply-row">
                                <span class="forum-topic-meta-last-reply-body">
                                <span class="forum-topic-meta-person forum-topic-meta-person-last-reply">
                                    <span class="telemetry-pod forum-topic-no-replies" title="No replies yet"><i class="far fa-comment-dots"></i> No replies</span>
                                </span>
                                </span>
                            </span>
                        </div>
                        <div class="forum-topic-meta-cell forum-topic-meta-activity is-empty"></div>
                        </div>
                </div>
            </div>
            </div>
            </div>`);
        list.prepend(item);
        if (isAdmin && typeof window.updateForumTopicSelection === 'function') window.updateForumTopicSelection();
    });

    socket.on('forum_topic_deleted', (data) => {
        const id = data && data.id;
        if (!id) return;
        const card = document.querySelector(`.forum-topic-list-card[data-topic-id="${id}"]`);
        if (card) {
            card.style.transition = 'all 0.25s ease';
            card.style.opacity = '0';
            card.style.transform = 'scale(0.98)';
            setTimeout(() => card.remove(), 250);
        }

        const currentPath = window.location.pathname || '';
        if (currentPath.startsWith('/discussions/t/') && currentPath.includes(`/discussions/t/${id}`)) {
            const redirectUrl = data.redirect_url || (data.category_slug ? `/discussions/c/${data.category_slug}` : '/discussions');
            setTimeout(() => {
                if (window.loadPage) window.loadPage(redirectUrl, true, { showLoader: false });
                else window.location.href = redirectUrl;
            }, 700);
            return;
        }

        if ((currentPath.startsWith('/discussions/c/') || currentPath === '/discussions') && window.loadPage) {
            // Strong sync fallback for tabs where DOM update may be missed.
            setTimeout(() => {
                window.loadPage(window.location.pathname + window.location.search, true);
            }, 180);
        }
    });

    socket.on('forum_post_approved', (payload) => {
        const id = payload && payload.id;
        if (!id) return;
        const row = document.getElementById('forum-post-' + id);
        if (row) row.querySelectorAll('.adm-badge-yellow').forEach((b) => b.remove());
        if (!payload || !payload.topic_id || payload.opening_post_approved !== true) return;
        const tid = String(payload.topic_id);
        document.querySelectorAll(`.forum-topic-list-card[data-topic-id="${tid}"]`).forEach((card) => {
            card.setAttribute('data-list-public', '1');
            card.removeAttribute('data-opening-pending');
            card.querySelectorAll('.status-badge-pending').forEach((b) => b.remove());
            const actions = card.querySelector('.file-actions-container[data-topic-id]');
            if (actions) {
                actions.querySelectorAll('.action-icon-btn.approve').forEach((btn) => btn.remove());
            }
        });
    });

    socket.on('forum_post_updated', (payload) => {
        const id = payload && payload.id;
        if (!id) return;
        const row = document.getElementById('forum-post-' + id);
        if (!row) return;
        const body = row.querySelector('.forum-post-body');
        if (!body) return;
        body.innerHTML = sanitizeRichHtml(payload.content_html || '');
    });

    // --- PHASE 4: LIVE DASHBOARD ---

    socket.on('admin_update', (data) => {
        if (data && typeof data.pending_count !== 'undefined' && typeof applyPendingModerationCount === 'function') {
            applyPendingModerationCount(data.pending_count);
        }
        if (data && (data.type === 'chat_message_approved' || data.type === 'chat_message_deleted') && data.id) {
            const row = document.querySelector(`.adm-mod-panel[data-mod-section="chat"] tr[data-id="${data.id}"]`);
            if (row) row.remove();
            if (typeof window.refreshModerationTabCount === 'function') {
                window.refreshModerationTabCount('chat');
            }
        }
        if (data.type === 'new_user') {
            const el = document.getElementById('stat-total-users');
            if (el) {
                // Extract number, increment, preserve suffix
                const currentText = el.innerText;
                const num = parseInt(currentText);
                if (!isNaN(num)) {
                    el.innerHTML = `${num + 1} <span style="font-size: 0.9rem; color: var(--text-secondary);">Users</span>`;
                    // Flash effect
                    el.style.color = '#00ff9d';
                    setTimeout(() => el.style.color = '', 1000);

                    if (typeof window.showToast === 'function') {
                        window.showToast('New User', `Welcome ${data.username}!`, `/user/${data.username}`, 'fas fa-user-plus', null, 'info');
                    }
                }
            }
        } else if (data.type === 'new_file') {
            const el = document.getElementById('stat-total-files');
            if (el) {
                const currentText = el.innerText;
                const num = parseInt(currentText);
                if (!isNaN(num)) {
                    el.innerHTML = `${num + 1} <span style="font-size: 0.9rem; color: var(--text-secondary);">Files</span>`;
                    el.style.color = '#ff00ff';
                    setTimeout(() => el.style.color = '', 1000);

                    if (typeof window.showToast === 'function') {
                        window.showToast('New File Uploaded', data.title, `/file/${data.id}`, 'fas fa-file-upload', null, 'info');
                    }
                }
            }
        }
    });

    // --- UI INTERACTION ---
    document.addEventListener('click', (e) => {
        const clearBtn = e.target && e.target.closest && e.target.closest('#clear-notifications-btn');
        if (!clearBtn) return;
        const sock = (typeof window.getSharedSocket === 'function' && window.getSharedSocket()) || window.socket;
        if (sock && sock.connected) {
            sock.emit('clear_all_notifications');
        }
        sessionStorage.removeItem('active_announcements');
        applyNotificationBadgeCount(0);
        clearBtn.classList.add('hidden');
        clearBtn.style.display = 'none';
        const list = document.getElementById('user-notifications-list');
        if (list) {
            list.innerHTML = '<div class="empty-notif" role="status"><i class="far fa-bell" aria-hidden="true"></i><div>No new alerts</div></div>';
        }
    });

    // --- Persistence & SPA Sync ---


    // v74: Payment Detected (Mempool)
    socket.on('payment_detected', (data) => {
        window.showToast(
            'PAYMENT DETECTED',
            data.message,
            null,
            'fas fa-sync fa-spin',
            null,
            'payment'
        );

        // Update Profile/Modal Invoice Status if present
        patchOrderStatus(data.order_id, 'processing');
    });

    socket.on('invoice_status_updated', (data) => {
        patchOrderStatus(data.order_id, data.status);
    });

    // v107: File Stats Update (Real-time Views/Downloads)
    // Match likes.js: any [data-file-id] root (file-item, pods, or telemetry-group) — SPA cards from
    // listings.js put data-file-id on .file-item and pods, not on .telemetry-group.
    function __ulpOnFileUpdate(data) {
        if (!data || data.file_id == null) return;
        const fid = data.file_id;
        if (data.views !== undefined) {
            document.querySelectorAll(`[data-file-id="${fid}"] .views-count`).forEach((el) => {
                ulpPulseIfNumericCountChanged(el, data.views, '.telemetry-pod');
                el.innerText = data.views;
            });
        }
        if (data.downloads !== undefined) {
            document.querySelectorAll(`[data-file-id="${fid}"] .downloads-count`).forEach((el) => {
                ulpPulseIfNumericCountChanged(el, data.downloads, '.telemetry-pod');
                el.innerText = data.downloads;
            });
        }
        if (data.likes !== undefined) {
            const likeNum = Number(data.likes);
            document
                .querySelectorAll(`[data-file-id="${fid}"] .like-count:not(.discussion-like-count)`)
                .forEach((el) => {
                    ulpPulseIfNumericCountChanged(el, data.likes, '.telemetry-pod, .file-likes-stat');
                    el.innerText = data.likes;
                });
            if (Number.isFinite(likeNum)) {
                document.querySelectorAll(`[data-file-id="${fid}"] .file-likes-stat, .like-btn-container[data-file-id="${fid}"]`).forEach((container) => {
                    container.classList.toggle('has-likes', likeNum > 0);
                });
            }
        }
        if (data.price !== undefined || data.is_vip_section !== undefined) {
            const priceNum = Number(data.price);
            const hasPaidPrice = Number.isFinite(priceNum) && priceNum > 0;
            const priceText = hasPaidPrice ? formatUsdPrice(priceNum) : '';

            document.querySelectorAll(`[data-file-id="${fid}"] .file-price-pod`).forEach((pod) => {
                pod.style.display = hasPaidPrice ? '' : 'none';
                const amount = pod.querySelector('.price-amount');
                if (amount) amount.innerText = priceText;
            });

            document.querySelectorAll(`.file-item[data-file-id="${fid}"]`).forEach((item) => {
                const icon = item.querySelector('.file-title .file-icon, .file-title > i');
                if (!icon) return;
                const isVip = data.is_vip_section !== undefined
                    ? !!data.is_vip_section
                    : icon.classList.contains('fa-gem');

                if (isVip) {
                    icon.className = 'file-icon fas fa-gem icon-gem-gradient';
                    icon.style.removeProperty('color');
                } else if (hasPaidPrice) {
                    icon.className = 'file-icon fas fa-coins';
                    icon.style.color = 'var(--primary-color)';
                } else {
                    icon.className = 'file-icon fas fa-gift';
                    icon.style.color = 'var(--text-secondary)';
                }
                icon.style.fontSize = '0.9rem';
                icon.style.flexShrink = '0';
            });

            const params = new URLSearchParams(window.location.search || '');
            const activeFilter = params.get('filter') || 'all';
            if (activeFilter === 'free' && hasPaidPrice) {
                document.querySelectorAll(`.file-item[data-file-id="${fid}"]`).forEach((item) => item.remove());
            } else if (activeFilter === 'paid' && !hasPaidPrice) {
                document.querySelectorAll(`.file-item[data-file-id="${fid}"]`).forEach((item) => item.remove());
            }
        }
    }

    // v107: Resource Stats Update (same pattern as file cards / likes.js)
    function __ulpOnResourceUpdate(data) {
        if (!data || data.listing_id == null) return;
        const lid = data.listing_id;
        if (data.views !== undefined) {
            document.querySelectorAll(`[data-listing-id="${lid}"] .views-count`).forEach((el) => {
                ulpPulseIfNumericCountChanged(el, data.views, '.telemetry-pod');
                el.innerText = data.views;
            });
        }
        if (data.clicks !== undefined) {
            document.querySelectorAll(`[data-listing-id="${lid}"] .clicks-count`).forEach((el) => {
                ulpPulseIfNumericCountChanged(el, data.clicks, '.telemetry-pod');
                el.innerText = data.clicks;
            });
        }
        if (data.upvotes !== undefined) {
            const upNum = Number(data.upvotes);
            document
                .querySelectorAll(`[data-listing-id="${lid}"] .like-count:not(.discussion-like-count)`)
                .forEach((el) => {
                    ulpPulseIfNumericCountChanged(el, data.upvotes, '.like-btn-container');
                    el.innerText = data.upvotes;
                });
            if (Number.isFinite(upNum)) {
                document.querySelectorAll(`.like-btn-container[data-listing-id="${lid}"]`).forEach((container) => {
                    container.classList.toggle('has-likes', upNum > 0);
                });
            }
        }
    }

    /** Re-bind counter handlers after reconnect / long idle (same pattern as initializeLikes). */
    window.__ulpBindStatsSocketHandlers = function (sock) {
        if (!sock || typeof sock.on !== 'function') return;
        sock.off('file_stats_update', __ulpOnFileStatsUpdate);
        sock.off('resource_stats_update', __ulpOnResourceStatsUpdate);
        sock.off('file_update', __ulpOnFileUpdate);
        sock.off('resource_update', __ulpOnResourceUpdate);
        sock.off('forum_topic_update', __ulpOnForumTopicUpdate);
        sock.on('file_stats_update', __ulpOnFileStatsUpdate);
        sock.on('resource_stats_update', __ulpOnResourceStatsUpdate);
        sock.on('file_update', __ulpOnFileUpdate);
        sock.on('resource_update', __ulpOnResourceUpdate);
        sock.on('forum_topic_update', __ulpOnForumTopicUpdate);
    };
    window.initializeFileStatsRealtime = function () {
        const s = (typeof window.getSharedSocket === 'function' && window.getSharedSocket())
            || window._realtimeSocket
            || null;
        if (s) window.__ulpBindStatsSocketHandlers(s);
    };
    window.ulpEnsureRealtimeSocketBindings = function ulpEnsureRealtimeSocketBindings(sock) {
        if (!sock || typeof sock.on !== 'function') return;
        bindPendingCountSocketHandlers(sock);
        bindCoreRealtimeSocketHandlers(sock);
        if (typeof window.__ulpBindStatsSocketHandlers === 'function') {
            window.__ulpBindStatsSocketHandlers(sock);
        }
        if (typeof window.initializeLikes === 'function') {
            window.initializeLikes();
        }
        if (typeof window.__ulpBindIndexFeedSocketHandlers === 'function') {
            window.__ulpBindIndexFeedSocketHandlers(sock);
        }
        if (window._chatCurrentRoom && typeof window.initializeFileRoom === 'function') {
            const r = window._chatCurrentRoom;
            window.initializeFileRoom(r.type, r.id);
        }
    };

    function ulpRunForumListVisibilityCleanup() {
        if (typeof ulpStripNonPublicForumTopicCards === 'function') {
            ulpStripNonPublicForumTopicCards();
        }
    }
    if (!window.__ulpForumListVisibilityBound) {
        window.__ulpForumListVisibilityBound = true;
        document.addEventListener('DOMContentLoaded', ulpRunForumListVisibilityCleanup);
        document.addEventListener('pageLoaded', (ev) => {
            const url = (ev && ev.detail && ev.detail.url) || window.location.href || '';
            let path = '';
            try {
                path = new URL(url, window.location.origin).pathname || '';
            } catch (e) {
                path = window.location.pathname || '';
            }
            if (path === '/discussions' || /^\/discussions\/c\//i.test(path)) {
                ulpRunForumListVisibilityCleanup();
            }
        });
    }

    if (socket) {
        window.ulpEnsureRealtimeSocketBindings(socket);
        if (typeof window.ulpConnectSharedSocketOnce === 'function') {
            window.ulpConnectSharedSocketOnce(true);
        }
        ulpRunForumListVisibilityCleanup();

        // Handle generic server-side toasts (v42); `type` mirrors HTTP flash categories
        socket.on('show_toast', (data) => {
        if (!data) return;
        const slowTitle = String(data.title || '').toLowerCase();
        const slowMsg = String(data.message || '');
        if (slowTitle === 'slow down' && slowMsg.indexOf('2 seconds') !== -1) {
            const now = Date.now();
            if (window.__ulpSlowDownToastAt && now - window.__ulpSlowDownToastAt < 2000) return;
            window.__ulpSlowDownToastAt = now;
        }
        const rawType = String(data.notif_type || data.type || '').toLowerCase();
        const nt = rawType === 'danger' ? 'error' : rawType;
        const isErr = nt === 'error';
        const isOk = nt === 'success';
        const isWarn = nt === 'warning';
        const defaultIcon = isErr ? 'fas fa-circle-exclamation' : isOk ? 'fas fa-check-circle' : isWarn ? 'fas fa-triangle-exclamation' : 'fas fa-info-circle';
        window.showToast(
            data.title || (isErr ? 'Error' : isOk ? 'Success' : isWarn ? 'Notice' : 'Attention'),
            data.message || '',
            data.link || null,
            data.icon || defaultIcon,
            data.id || null,
            nt && ['error', 'success', 'warning', 'info', 'system'].includes(nt) ? nt : (isErr ? 'error' : null)
        );
        });

    } // if (socket): remaining realtime handlers (init bindings + show_toast)

    } // if (socket): forum / notifications / payment socket handlers

})();
