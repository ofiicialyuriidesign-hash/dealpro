document.addEventListener('DOMContentLoaded', () => {
    initializeLikes();
});

/** Named handlers so socket.off() only removes our listener (Socket.IO removes ALL handlers if no fn passed). */
function __ulpSocketLikeUpdate(data) {
    updateLikeCount(data);
}
function __ulpSocketLikeStatus(data) {
    syncLikeButtonState(data);
}

function initializeLikes() {
    const socket = window.getSharedSocket ? window.getSharedSocket() : (window.socket || null);

    if (socket) {
        socket.off('like_update', __ulpSocketLikeUpdate);
        socket.on('like_update', __ulpSocketLikeUpdate);

        socket.off('like_status', __ulpSocketLikeStatus);
        socket.on('like_status', __ulpSocketLikeStatus);
    }
    normalizeLikeIcons();
}

function ulpQueryLikeContainers(type, id) {
    const sid = String(id == null ? '' : id).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    if (type === 'file') {
        return document.querySelectorAll(
            `.like-btn-container[data-file-id="${sid}"], .file-likes-stat[data-file-id="${sid}"]`
        );
    }
    if (type === 'listing') {
        return document.querySelectorAll(`.like-btn-container[data-listing-id="${sid}"]`);
    }
    return [];
}

function ulpApplyLikeContainerState(container, liked, count) {
    const icon = container.querySelector('.fa-heart');
    const countSpan = container.querySelector('.like-count');
    if (countSpan && typeof count === 'number') {
        if (typeof window.__ulpPulseIfStatCountChanged === 'function') {
            window.__ulpPulseIfStatCountChanged(countSpan, count, '.like-btn-container, .file-likes-stat');
        }
        countSpan.innerText = count;
    }
    if (typeof count === 'number') {
        container.classList.toggle('has-likes', count > 0);
    }
    container.classList.toggle('is-liked', !!liked);
    if (!icon) return;
    if (liked) {
        icon.classList.remove('far');
        icon.classList.add('fas');
    } else {
        icon.classList.remove('fas');
        icon.classList.add('far');
    }
}

function normalizeLikeIcons() {
    document.querySelectorAll('.like-btn-container, .file-likes-stat[data-file-id]').forEach(container => {
        const icon = container.querySelector('.fa-heart');
        if (!icon) return;
        const isLikedByMe = container.classList.contains('is-liked');
        container.classList.toggle('is-liked', !!isLikedByMe);
        if (isLikedByMe) {
            icon.classList.remove('far');
            icon.classList.add('fas');
            return;
        }
        icon.classList.remove('fas');
        icon.classList.add('far');
    });
}

function syncLikeButtonState(data) {
    // data: { file_id, listing_id, liked, count? } — server → actor only; count mirrors DB after toggle.
    let containers = [];
    if (data.file_id) {
        containers = Array.from(ulpQueryLikeContainers('file', data.file_id));
    } else if (data.listing_id) {
        containers = Array.from(ulpQueryLikeContainers('listing', data.listing_id));
    }

    containers.forEach(container => {
        ulpApplyLikeContainerState(
            container,
            !!data.liked,
            typeof data.count === 'number' ? data.count : undefined
        );
    });
}

// Throttle state to prevent race conditions/spam clicking
const likeThrottles = {};
if (!window.__ulpLikeEmitGuard) window.__ulpLikeEmitGuard = {};

function ulpShowSlowDownOnce() {
    const now = Date.now();
    if (window.__ulpSlowDownToastAt && now - window.__ulpSlowDownToastAt < 2000) return;
    window.__ulpSlowDownToastAt = now;
    if (window.showToast) {
        window.showToast('Slow down', 'Please wait 2 seconds before toggling like again.', null, 'fas fa-triangle-exclamation', null, 'warning');
    } else if (window.createFlash) {
        window.createFlash('Please wait 2 seconds before toggling like again.', 'error');
    }
}

function toggleLike(element, type, id) {
    const socket = window.getSharedSocket ? window.getSharedSocket() : (window.socket || null);
    if (!socket) return;

    // Authentication Check
    const isAuthenticated = document.body.getAttribute('data-is-authenticated') === 'true';
    if (!isAuthenticated) {
        if (window.requireLogin) {
            window.requireLogin('Please login or register to like content.', window.location.pathname + window.location.search);
        } else if (window.showToast) {
            const loginLink = `<a href="/login" class="spa-link" style="color: var(--primary-color); text-decoration: underline; font-weight: 700;">Login</a>`;
            const registerLink = `<a href="/register" class="spa-link" style="color: var(--primary-color); text-decoration: underline; font-weight: 700;">Register</a>`;
            window.showToast(
                'Login Required',
                `Please login or register to like content. ${loginLink} or ${registerLink}`,
                null,
                'fas fa-user-lock',
                null,
                'system'
            );
        } else {
            if (window.createFlash) {
                window.createFlash('Please login or register to like content.', 'error');
            }
        }
        return;
    }

    const itemId = `${type}_${id}`;
    const now = Date.now();

    // Collapse duplicate handlers on the same click (delegation + legacy listeners).
    if (window.__ulpLikeEmitGuard[itemId] && now - window.__ulpLikeEmitGuard[itemId] < 500) {
        return;
    }
    window.__ulpLikeEmitGuard[itemId] = now;

    // 2s throttle per specific item (matches backend cooldown) — server also emits show_toast.
    if (likeThrottles[itemId] && now - likeThrottles[itemId] < 2000) {
        ulpShowSlowDownOnce();
        return;
    }

    // 1. Identify all containers for this item on the page
    const containers = type === 'file'
        ? ulpQueryLikeContainers('file', id)
        : ulpQueryLikeContainers('listing', id);
    if (containers.length === 0) return;

    likeThrottles[itemId] = now;

    const payload = {
        file_id: type === 'file' ? id : null,
        listing_id: type === 'listing' ? id : null
    };
    const csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

    // HTTP is the source of truth; socket broadcasts still update other open tabs.
    fetch('/api/toggle_like', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
            'X-Requested-With': 'XMLHttpRequest',
            Accept: 'application/json',
        },
        body: JSON.stringify(payload),
    })
        .then(async (response) => {
            const data = await response.json().catch(() => ({}));
            if (!response.ok || !data.success) {
                throw new Error(data.message || 'Could not update like.');
            }
            syncLikeButtonState({
                file_id: data.file_id,
                listing_id: data.listing_id,
                liked: !!data.liked,
                count: Number(data.count) || 0,
            });
            updateLikeCount({
                file_id: data.file_id,
                listing_id: data.listing_id,
                count: Number(data.count) || 0,
                user_id: Number((document.body && document.body.getAttribute('data-user-id')) || 0) || undefined,
                user_liked: !!data.liked,
                recent_likers: data.recent_likers,
                likers_total: data.likers_total,
            });
        })
        .catch((err) => {
            likeThrottles[itemId] = 0;
            if (window.showToast) {
                window.showToast('Error', err.message || 'Could not update like.', null, 'fas fa-triangle-exclamation', null, 'error');
            }
        });
}

(function () {
    function _ulpEscAttr(text) {
        return String(text == null ? '' : text)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    function _ulpFacepileRoleSuffix(roleRaw) {
        const r = String(roleRaw || '')
            .toLowerCase()
            .trim();
        if (r === 'admin') return '--admin';
        if (r === 'moderator') return '--moderator';
        if (r === 'vip') return '--vip';
        return '--user';
    }

    function _ulpLikeTooltip(recentArr, total) {
        const t = Number(total) || 0;
        const roster = Array.isArray(recentArr) ? recentArr.length : 0;
        const names = (recentArr || [])
            .map((x) => (x && x.username ? String(x.username) : ''))
            .filter(Boolean)
            .slice(0, 12);
        const ov = Math.max(0, t - roster);
        const head = names.join(', ');
        if (!t) return '';
        if (ov > 0) return head ? `${head} · +${ov} · ${t} total` : `${t} total (+${ov} more)`;
        if (!head) return `${t} total`;
        return `${head} · ${t} total`;
    }

    function _ulpReadStripCtx(el) {
        if (!el || !el.getAttribute) return null;
        return {
            interactive: el.getAttribute('data-interactive-heart') === '1',
            kind: el.getAttribute('data-likers-kind') || '',
            viewerLiked: el.getAttribute('data-viewer-liked') === '1',
            fileId: el.getAttribute('data-file-id') || '',
            listingId: el.getAttribute('data-listing-id') || '',
            postId: el.getAttribute('data-post-id') || '',
        };
    }

    /** Heart button beside facepile — matches Django partial when data-interactive-heart=1. */
    function _ulpRenderInteractiveHeartFromCtx(ctx, total) {
        if (!ctx || !ctx.interactive) return '';
        const t = Number(total) || 0;
        const liked = !!ctx.viewerLiked;
        const ic = liked ? 'fas' : 'far';
        const has = t > 0 ? ' has-likes' : '';
        const lk = liked ? ' is-liked' : '';
        const titleFile = liked ? 'Unlike' : 'Like';

        if (ctx.kind === 'file' && ctx.fileId) {
            const rid = String(ctx.fileId).replace(/'/g, "\\'");
            const ida = _ulpEscAttr(ctx.fileId);
            return `<button type="button" class="ulp-like-likers__heart-hit telemetry-pod like-btn-container${has}${lk}" data-file-id="${ida}" title="${titleFile}"><span class="ulp-like-likers__heart-slot"><i class="${ic} fa-heart like-btn" aria-hidden="true"></i></span></button>`;
        }
        if (ctx.kind === 'listing' && ctx.listingId) {
            const rid = String(ctx.listingId).replace(/'/g, "\\'");
            const ida = _ulpEscAttr(ctx.listingId);
            return `<button type="button" class="ulp-like-likers__heart-hit telemetry-pod like-btn-container${has}${lk}" data-listing-id="${ida}" title="${titleFile}"><span class="ulp-like-likers__heart-slot"><i class="${ic} fa-heart like-btn" aria-hidden="true"></i></span></button>`;
        }
        if (ctx.kind === 'forum_post' && ctx.postId) {
            const ida = _ulpEscAttr(ctx.postId);
            const authed =
                typeof document !== 'undefined' &&
                document.body &&
                document.body.getAttribute('data-is-authenticated') === 'true';
            const act = authed ? 'like' : 'like-login';
            const ttl = liked ? 'Unlike' : 'Like';
            return `<button type="button" class="ulp-like-likers__heart-hit telemetry-pod like-btn-container forum-post-like-toggle${has}${lk}" data-post-id="${ida}" data-ulp-forum-action="${act}" title="${ttl}"><span class="ulp-like-likers__heart-slot"><i class="${ic} fa-heart like-btn" aria-hidden="true"></i></span></button>`;
        }
        return '';
    }

    /** Build inner HTML — pass stripEl to preserve interactive heart + viewer-liked sync. */
    function _ulpRenderFacesInnerHtml(recentArr, total, stripEl) {
        const t = Number(total) || 0;
        const rec = Array.isArray(recentArr) ? recentArr.slice(0, 24) : [];
        const ctx = stripEl ? _ulpReadStripCtx(stripEl) : null;

        const faces = rec
            .map((x) => {
                const uid = x && x.id != null ? String(x.id) : '';
                if (!uid) return '';
                const un = x && x.username ? String(x.username) : '';
                const rs = _ulpFacepileRoleSuffix(x && x.role);
                const img =
                    x.avatar_url ?
                        `<img src="${_ulpEscAttr(x.avatar_url)}" alt="" class="ulp-like-likers__img" loading="lazy" width="20" height="20">`
                        : `<img src="${_ulpEscAttr(window.ulpResolveAvatarUrl({ username: un, avatar: x.avatar_filename, avatar_color: x.avatar_color, size: 64 }))}" alt="" class="ulp-like-likers__img" loading="lazy" width="20" height="20">`;
                if (!un) {
                    return `<span class="ulp-like-likers__face ulp-like-likers__face--placeholder" data-user-id="${_ulpEscAttr(
                        uid,
                    )}" title="Member" role="img" aria-label="Member">${img}</span>`;
                }
                const ua = `/user/${encodeURIComponent(un)}`;
                return `<a href="${ua}" class="ulp-like-likers__face ulp-like-likers__face${rs} ulp-spa-ignore-like-bubble" data-user-id="${_ulpEscAttr(
                    uid,
                )}" title="@${_ulpEscAttr(un)}" data-ulp-stop-propagation>${img}</a>`;
            })
            .filter(Boolean)
            .join('');

        const rendered = rec.filter((x) => x && x.id != null).length;
        const ov = Math.max(0, t - rendered);
        let more = '';
        if (ov > 0) {
            const tip = _ulpEscAttr(_ulpLikeTooltip(rec, t));
            more = `<span class="ulp-like-likers__more" title="${tip}">+${ov}</span>`;
        } else if (!faces && t > 0) {
            const tip = _ulpEscAttr(_ulpLikeTooltip(rec, t));
            more = `<span class="ulp-like-likers__more" title="${tip}">+${t}</span>`;
        }

        let heartBlock = '';
        if (ctx && ctx.interactive) {
            heartBlock = _ulpRenderInteractiveHeartFromCtx(ctx, t);
            if (!heartBlock) return '';
        } else if (t > 0) {
            heartBlock = `<span class="ulp-like-likers__heart" aria-hidden="true"><i class="fas fa-heart"></i></span>`;
        } else if (!ctx || !ctx.interactive) {
            return '';
        }

        let tail = '';
        if (t > 0) {
            tail = `<span class="ulp-like-likers__sep" aria-hidden="true">&middot;</span><span class="ulp-like-likers__faces">${faces}${more}</span>`;
        }
        return heartBlock + tail;
    }

    function _ulpEnrichLikerRows(rows) {
        if (!Array.isArray(rows)) return [];
        return rows.map((row) => {
            if (!row || typeof row !== 'object') return row;
            const af = row.avatar_filename && String(row.avatar_filename).trim();
            const avatar_url =
                typeof window.ulpResolveAvatarUrl === 'function'
                    ? window.ulpResolveAvatarUrl({
                          username: row.username,
                          avatar: af || row.avatar,
                          avatar_color: row.avatar_color,
                          size: 64,
                      })
                    : row.avatar_url;
            return Object.assign({}, row, { avatar_url });
        });
    }

    window.__ulpPatchLikeLikersFromPayload = function (data) {
        if (!data || data.recent_likers == null || data.likers_total == null) return;
        let sel = '';
        if (data.file_id != null && data.file_id !== '')
            sel = `.ulp-like-likers[data-likers-kind="file"][data-file-id="${data.file_id}"]`;
        else if (data.listing_id != null && data.listing_id !== '')
            sel = `.ulp-like-likers[data-likers-kind="listing"][data-listing-id="${data.listing_id}"]`;
        if (!sel) return;
        const total = Number(data.likers_total);
        const recent = _ulpEnrichLikerRows(data.recent_likers);
        const tip = _ulpLikeTooltip(recent, total);
        document.querySelectorAll(sel).forEach((el) => {
            el.setAttribute('data-likers-total', String(total));
            const interactive = el.getAttribute('data-interactive-heart') === '1';
            const meId = Number((document.body && document.body.getAttribute('data-user-id')) || '0') || 0;
            const actorId = parseInt(String(data.user_id || '0'), 10) || 0;
            if (actorId && meId && actorId === meId && data.user_liked !== undefined) {
                el.setAttribute('data-viewer-liked', data.user_liked ? '1' : '0');
            }
            const ctx = _ulpReadStripCtx(el);
            if (!Number.isFinite(total) || total < 1) {
                if (!interactive) {
                    el.classList.add('ulp-like-likers--empty');
                    el.innerHTML = '';
                    el.removeAttribute('title');
                    el.removeAttribute('aria-label');
                    el.setAttribute('aria-hidden', 'true');
                    return;
                }
                el.classList.remove('ulp-like-likers--empty');
                el.innerHTML = _ulpRenderFacesInnerHtml(recent, total, el);
                el.removeAttribute('title');
                el.removeAttribute('aria-label');
                el.removeAttribute('aria-hidden');
                return;
            }
            el.classList.remove('ulp-like-likers--empty');
            el.innerHTML = _ulpRenderFacesInnerHtml(recent, total, el);
            if (tip) {
                el.setAttribute('title', tip);
                el.setAttribute('aria-label', tip);
                el.removeAttribute('aria-hidden');
            }
        });
    };

    window.__ulpPatchForumPostLikeLikers = function (payload) {
        if (!payload || payload.recent_likers == null || payload.likers_total == null) return;
        const pid = payload.post_id != null ? String(payload.post_id) : '';
        if (!pid) return;
        const total = Number(payload.likers_total);
        const recent = _ulpEnrichLikerRows(payload.recent_likers);
        const tip = _ulpLikeTooltip(recent, total);
        document
            .querySelectorAll(`.ulp-like-likers[data-likers-kind="forum_post"][data-post-id="${pid}"]`)
            .forEach((el) => {
                el.setAttribute('data-likers-total', String(total));
                const meId = Number((document.body && document.body.getAttribute('data-user-id')) || '0') || 0;
                const actorId = parseInt(String(payload.user_id || '0'), 10) || 0;
                if (actorId && meId && actorId === meId && payload.user_liked !== undefined) {
                    el.setAttribute('data-viewer-liked', payload.user_liked ? '1' : '0');
                }
                const interactive = el.getAttribute('data-interactive-heart') === '1';
                if (!Number.isFinite(total) || total < 1) {
                    if (!interactive) {
                        el.classList.add('ulp-like-likers--empty');
                        el.innerHTML = '';
                        el.removeAttribute('title');
                        el.removeAttribute('aria-label');
                        el.setAttribute('aria-hidden', 'true');
                        return;
                    }
                    el.classList.remove('ulp-like-likers--empty');
                    el.innerHTML = _ulpRenderFacesInnerHtml(recent, total, el);
                    el.removeAttribute('title');
                    el.removeAttribute('aria-label');
                    el.removeAttribute('aria-hidden');
                    return;
                }
                el.classList.remove('ulp-like-likers--empty');
                el.innerHTML = _ulpRenderFacesInnerHtml(recent, total, el);
                if (tip) {
                    el.setAttribute('title', tip);
                    el.setAttribute('aria-label', tip);
                    el.removeAttribute('aria-hidden');
                }
            });
    };
})();

function updateLikeCount(data) {
    // data: { file_id, listing_id, count, user_liked (optional, to sync active user state if broadcasted) }

    let containers = [];
    if (data.file_id != null && data.file_id !== '') {
        containers = Array.from(ulpQueryLikeContainers('file', data.file_id));
    } else if (data.listing_id != null && data.listing_id !== '') {
        containers = Array.from(ulpQueryLikeContainers('listing', data.listing_id));
    }

    if (containers.length) {
        const bodyUserId = Number(
            (document.body && document.body.getAttribute && document.body.getAttribute('data-user-id')) || 0
        ) || 0;
        const payloadUserId = Number(data && data.user_id || 0) || 0;
        const payloadUserLiked = !!(data && data.user_liked);
        const forceClearLiked = !!(data && data.reset_like_ui);
        containers.forEach(container => {
            let likedByMe = container.classList.contains('is-liked');
            if (forceClearLiked) {
                likedByMe = false;
            } else if (bodyUserId && payloadUserId && bodyUserId === payloadUserId) {
                likedByMe = payloadUserLiked;
            }
            const cnt = data.count != null ? Number(data.count) : undefined;
            ulpApplyLikeContainerState(
                container,
                likedByMe,
                Number.isFinite(cnt) ? cnt : undefined
            );
        });
        const fidRaw = data.file_id != null && String(data.file_id) !== '' ? String(data.file_id) : '';
        const lidRaw = data.listing_id != null && String(data.listing_id) !== '' ? String(data.listing_id) : '';
        if (bodyUserId && payloadUserId && bodyUserId === payloadUserId) {
            if (fidRaw) {
                document.querySelectorAll(`.ulp-like-likers[data-interactive-heart="1"][data-likers-kind="file"][data-file-id="${fidRaw.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"]`).forEach((el) => {
                    el.setAttribute('data-viewer-liked', payloadUserLiked ? '1' : '0');
                });
            }
            if (lidRaw) {
                document.querySelectorAll(`.ulp-like-likers[data-interactive-heart="1"][data-likers-kind="listing"][data-listing-id="${lidRaw.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"]`).forEach((el) => {
                    el.setAttribute('data-viewer-liked', payloadUserLiked ? '1' : '0');
                });
            }
        }
    }

    if (
        typeof window.__ulpPatchLikeLikersFromPayload === 'function' &&
        data.recent_likers != null &&
        data.likers_total != null
    ) {
        window.__ulpPatchLikeLikersFromPayload(data);
    }
}

// file_update / resource_update: handled in realtime.js (views, downloads, price, feed filters).
// Do NOT socket.off('file_update') here — it removes all listeners and broke the full realtime handler.

// Re-initialize on SPA navigation (if SPA uses a custom event)
document.addEventListener('pageLoaded', () => {
    initializeLikes();
});

/** Chat reconnect / resume: re-bind like listeners (same pattern as like_update / like_status). */
window.initializeLikes = initializeLikes;

/** Click delegation — replaces onclick on .like-btn-container (CSP script-src-attr hardening). */
(function () {
    if (window.__ulpLikeContainerDeleg) return;
    window.__ulpLikeContainerDeleg = true;
    document.addEventListener('click', function (e) {
        if (e.__ulpLikeDelegHandled) return;
        const container = e.target.closest('.like-btn-container[data-file-id], .like-btn-container[data-listing-id], .file-likes-stat[data-file-id]');
        if (!container || e.target.closest('a')) return;
        if (container.closest('.discussion-like-toggle, .forum-post-like-toggle, [data-ulp-discussion-action]')) return;
        e.__ulpLikeDelegHandled = true;
        e.stopImmediatePropagation();
        const btn = container.querySelector('.like-btn') || container.querySelector('.fa-heart');
        if (!btn) return;
        const fileId = container.getAttribute('data-file-id');
        const listingId = container.getAttribute('data-listing-id');
        if (fileId) toggleLike(btn, 'file', fileId);
        else if (listingId) toggleLike(btn, 'listing', listingId);
    });
})();
