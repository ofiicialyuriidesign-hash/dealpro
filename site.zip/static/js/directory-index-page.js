/**
 * Resources directory index — bulk, realtime feed.
 */
(function () {
    'use strict';
    function readConfig() {
        var el = document.getElementById('ulp-directory-index-page-config');
        if (!el) return {};
        try { return JSON.parse(el.textContent || '{}'); } catch (e) { return {}; }
    }
    var cfg = readConfig();

// Initialize selection logic directly (SPA will re-execute this)
        updateListingSelectionMain();
        // Real-time Resources Feed (v42)
        // Expose liked resource IDs to JS for robust real-time state preservation (Phase 8)
        window.likedListingIds = new Set(cfg.likedListings || []);
        window.readListingIds = new Set(cfg.readListingIds || []);
        var socket = window.getSharedSocket ? window.getSharedSocket() : (window.socket || null);
        if (socket) {
            window.__directorySocketHandlers = window.__directorySocketHandlers || {};
            const h = window.__directorySocketHandlers;

            if (h.connectResFeed) socket.off('connect', h.connectResFeed);
            h.connectResFeed = () => {
                if (socket.connected) socket.emit('join_resources_feed');
            };
            socket.on('connect', h.connectResFeed);
            if (socket.connected) socket.emit('join_resources_feed');

            if (h.newResourceNotification) socket.off('new_resource_notification', h.newResourceNotification);
            if (h.listingBumped) socket.off('listing_bumped', h.listingBumped);

            h.newResourceNotification = (data) => {
                var urlParams = new URLSearchParams(window.location.search);
                if ((urlParams.get('page') || '1') !== '1') return;
                if (urlParams.get('q')) return;
                var category = urlParams.get('category') || '';
                if (category && category !== data.category) return;

                var resourceList = document.querySelector('#ajax-resource-list');
                if (!resourceList) return;

                var chatWidget = document.getElementById('chat-widget-container');
                var currentUserRole = (chatWidget && chatWidget.getAttribute('data-user-role')) || (document.body && document.body.getAttribute('data-user-role')) || '';
                var canModerate = ['admin', 'moderator'].includes(currentUserRole);
                var isAdmin = currentUserRole === 'admin';

                var div = window.renderResourceItem(data, {
                    badge: !data.is_active ? 'pending' : 'new',
                    isLiked: window.likedListingIds ? window.likedListingIds.has(data.id) : false,
                    isRead: window.readListingIds ? window.readListingIds.has(data.id) : false,
                    canModerate: canModerate,
                    isAdmin: isAdmin,
                    onCheckboxChange: null
                });

                var emptyMsg = resourceList.querySelector('.text-center');
                if (emptyMsg) emptyMsg.remove();

                var children = Array.from(resourceList.children);
                var inserted = false;
                var newBumped = parseFloat(data.bumped_at);
                for (var i = 0; i < children.length; i++) {
                    var itemBumped = parseFloat(children[i].getAttribute('data-bumped-at'));
                    if (!isNaN(itemBumped) && newBumped > itemBumped) {
                        resourceList.insertBefore(div, children[i]);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted) resourceList.appendChild(div);
            };

            h.listingBumped = (data) => {
                var list = document.querySelector('#ajax-resource-list') || document.querySelector('#ajax-file-list') || document.querySelector('.file-list');
                if (!list) return;
                if (window.readListingIds) window.readListingIds.delete(data.id);

                var urlParams = new URLSearchParams(window.location.search);
                if ((urlParams.get('page') || '1') !== '1') return;
                if (urlParams.get('q')) return;

                var urlCategory = (urlParams.get('category') || '').trim().toLowerCase();
                var dataCat = (data.category != null ? String(data.category) : '').trim().toLowerCase();
                if (urlCategory && dataCat && urlCategory !== dataCat) {
                    var staleCat = list.querySelector(':scope > .file-item[data-listing-id="' + data.id + '"]');
                    if (staleCat) staleCat.remove();
                    return;
                }

                var chatWidget = document.getElementById('chat-widget-container');
                var currentUserRole = chatWidget ? chatWidget.getAttribute('data-user-role') : (document.body.getAttribute('data-user-role') || '');
                var canModerate = ['admin', 'moderator'].includes(currentUserRole);
                var isAdmin = currentUserRole === 'admin';

                var oldRow = list.querySelector(':scope > .file-item[data-listing-id="' + data.id + '"]');
                var wasLiked = !!(oldRow && oldRow.querySelector('.like-btn-container.is-liked'));
                var newBumped = parseFloat(data.bumped_at);
                if (!Number.isFinite(newBumped)) newBumped = Date.now() / 1000;
                var insertBefore = (typeof window.__ulpFindFeedInsertBefore === 'function')
                    ? window.__ulpFindFeedInsertBefore(list, newBumped, data.id, 'resource')
                    : null;

                var isLiked = wasLiked || (window.likedListingIds && window.likedListingIds.has(data.id));

                if (oldRow && typeof window.patchResourceItemFromBumpData === 'function') {
                    window.patchResourceItemFromBumpData(oldRow, data, {
                        isLiked: isLiked,
                        isRead: window.readListingIds ? window.readListingIds.has(data.id) : false,
                    });
                    if (insertBefore) {
                        list.insertBefore(oldRow, insertBefore);
                    } else {
                        list.appendChild(oldRow);
                    }
                    return;
                }

                var div = window.renderResourceItem(data, {
                    isLiked: isLiked,
                    isRead: window.readListingIds ? window.readListingIds.has(data.id) : false,
                    canModerate: canModerate,
                    isAdmin: isAdmin,
                    onCheckboxChange: null
                });

                var children = Array.from(list.children);
                var inserted = false;
                for (var i = 0; i < children.length; i++) {
                    var itemBumped = parseFloat(children[i].getAttribute('data-bumped-at'));
                    if (!isNaN(itemBumped) && newBumped > itemBumped) {
                        list.insertBefore(div, children[i]);
                        inserted = true;
                        break;
                    }
                }
                if (!inserted) list.appendChild(div);
            };

            socket.on('new_resource_notification', h.newResourceNotification);
            socket.on('listing_bumped', h.listingBumped);
        }



        function updateListingSelectionMain() {
            var checkboxes = document.querySelectorAll('.listing-checkbox-main:checked');
            var count = checkboxes.length;

            var countEl = document.getElementById('selection-count-listings-main');
            if (countEl) countEl.textContent = `${count} SELECTED`;

            var approveBtn = document.getElementById('approve-selected-listings-main-btn');
            var deleteBtn = document.getElementById('delete-selected-listings-main-btn');

            var bulkBar = document.getElementById('bulk-action-bar-listings');
            if (count > 0) {
                if (approveBtn) { approveBtn.disabled = false; approveBtn.style.opacity = '1'; }
                if (deleteBtn) { deleteBtn.disabled = false; deleteBtn.style.opacity = '1'; }
                if (bulkBar) bulkBar.classList.add('active');
            } else {
                if (approveBtn) { approveBtn.disabled = true; approveBtn.style.opacity = '0.5'; }
                if (deleteBtn) { deleteBtn.disabled = true; deleteBtn.style.opacity = '0.5'; }
                if (bulkBar) bulkBar.classList.remove('active');
            }

            // Update select all checkbox state
            var allCheckboxes = document.querySelectorAll('.listing-checkbox-main');
            var selectAllCheckbox = document.getElementById('select-all-listings');
            if (allCheckboxes.length > 0 && selectAllCheckbox) {
                selectAllCheckbox.checked = (count === allCheckboxes.length && allCheckboxes.length > 0);
            } else if (selectAllCheckbox) {
                selectAllCheckbox.checked = false;
            }
        }

        function toggleSelectAllListingsMain(checkbox) {
            var checkboxes = document.querySelectorAll('.listing-checkbox-main');
            checkboxes.forEach(cb => {
                cb.checked = checkbox.checked;
            });
            updateListingSelectionMain();
        }

        function bulkApproveListingsMain() {
            var checkboxes = document.querySelectorAll('.listing-checkbox-main:checked');
            var ids = Array.from(checkboxes).map(function (cb) { return cb.value; });
            if (!ids.length || !window.runBulkModerationForm) return;
            window.runBulkModerationForm({
                endpoint: cfg.bulkApproveUrl,
                fieldName: 'listing_ids[]',
                ids: ids,
                confirmMessage: 'Approve ' + ids.length + ' resource(s)?',
                entity: 'listing',
                verb: 'approve',
                checkboxSelector: '.listing-checkbox-main',
                selectAllId: 'select-all-listings',
                onSelectionReset: updateListingSelectionMain,
            });
        }

        function bulkDeleteListingsMain() {
            var checkboxes = document.querySelectorAll('.listing-checkbox-main:checked');
            var ids = Array.from(checkboxes).map(function (cb) { return cb.value; });
            if (!ids.length || !window.runBulkModerationForm) return;
            window.runBulkModerationForm({
                endpoint: cfg.bulkDeleteUrl,
                fieldName: 'listing_ids[]',
                ids: ids,
                confirmMessage: 'DELETE ' + ids.length + ' resource(s)? This action cannot be undone!',
                entity: 'listing',
                verb: 'delete',
                checkboxSelector: '.listing-checkbox-main',
                selectAllId: 'select-all-listings',
                onSelectionReset: updateListingSelectionMain,
            });
        }

    window.updateListingSelectionMain = updateListingSelectionMain;
    window.toggleSelectAllListingsMain = toggleSelectAllListingsMain;
    window.bulkApproveListingsMain = bulkApproveListingsMain;
    window.bulkDeleteListingsMain = bulkDeleteListingsMain;
})();
