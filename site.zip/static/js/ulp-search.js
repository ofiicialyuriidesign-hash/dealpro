/**
 * Header search (SPA-aware). Extracted from templates/base.html.
 */
(function () {
    'use strict';

    const SEARCH_MIN_LEN = 2;

// Expandable Search Logic (Global Delegation for SPA Compatibility)
window.updateHeaderSearchClearVisibility = function () {
    const input = document.getElementById('header-search-input');
    const btn = document.getElementById('header-search-clear-btn');
    if (!input || !btn) return;
    btn.hidden = input.value.trim() === '';
};

function clearHeaderSearch(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    const input = document.getElementById('header-search-input');
    const url = new URL(window.location.href);
    if (url.searchParams.get('q')) {
        url.searchParams.delete('q');
        url.searchParams.delete('page');
        const qs = url.searchParams.toString();
        const next = url.pathname + (qs ? '?' + qs : '');
        if (window.loadPage) window.loadPage(next, true);
        else window.location.href = next;
    } else {
        if (input) input.value = '';
        window.updateHeaderSearchClearVisibility();
        if (input) input.focus({ preventScroll: true });
    }
}

document.addEventListener('click', (e) => {
    const clearBtn = e.target.closest('#header-search-clear-btn');
    if (clearBtn) {
        clearHeaderSearch(e);
        return;
    }

    const toggle = e.target.closest('#search-toggle-btn');
    if (toggle) {
        e.preventDefault();
        const form = document.getElementById('header-search-form');
        const input = document.getElementById('header-search-input');
        if (form && input) {
            if (!form.classList.contains('active')) {
                form.classList.add('active');
                input.focus({ preventScroll: true });
            } else if (input.value.trim().length >= SEARCH_MIN_LEN) {
                triggerSearch(input.value.trim());
            } else {
                form.classList.remove('active');
            }
            window.updateHeaderSearchClearVisibility();
        }
        return;
    }

    // Close if clicked outside
    const form = document.getElementById('header-search-form');
    const input = document.getElementById('header-search-input');
    if (form && input && !form.contains(e.target) && form.classList.contains('active') && input.value.trim() === '') {
        form.classList.remove('active');
    }
});

document.addEventListener('input', (e) => {
    if (e.target && e.target.id === 'header-search-input') {
        window.updateHeaderSearchClearVisibility();
    }
});

document.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && e.target.id === 'header-search-input') {
        const query = e.target.value.trim();
        if (query.length >= SEARCH_MIN_LEN) {
            e.preventDefault();
            triggerSearch(query);
        }
    }
});

function getSearchListPath() {
    var allowed = { '/': true, '/discussions': true, '/resources': true };
    var locPath = (window.location.pathname || '/').split('?')[0];
    if (locPath.length > 1 && locPath.endsWith('/')) locPath = locPath.slice(0, -1);
    if (!locPath) locPath = '/';
    if (locPath.startsWith('/admin')) return '/';

    var form = document.getElementById('header-search-form');
    if (form && form.action) {
        try {
            var au = new URL(form.action, window.location.origin);
            var ap = au.pathname || '/';
            if (ap.length > 1 && ap.endsWith('/')) ap = ap.slice(0, -1);
            if (allowed[ap]) return ap;
        } catch (e) { /* ignore */ }
    }
    var mainEl = document.querySelector('main');
    var dataAct = mainEl && mainEl.getAttribute('data-search-action');
    if (dataAct) {
        try {
            var du = new URL(dataAct.trim(), window.location.origin);
            var dp = du.pathname || '/';
            if (dp.length > 1 && dp.endsWith('/')) dp = dp.slice(0, -1);
            if (allowed[dp]) return dp;
        } catch (e2) { /* ignore */ }
    }
    if (locPath.startsWith('/discussions')) return '/discussions';
    if (locPath.startsWith('/resources')) return '/resources';
    return '/';
}

function triggerSearch(query) {
    const term = (query || '').trim();
    if (term.length < SEARCH_MIN_LEN) return;

    const isAuth = document.body.getAttribute('data-is-authenticated') === 'true';
    if (!isAuth) {
        if (window.requireLogin) {
            window.requireLogin('Please login to use search.', window.location.pathname + window.location.search);
        }
        return;
    }
    const baseUrl = getSearchListPath();
    const url = new URL(baseUrl, window.location.origin);
    const cur = new URL(window.location.href);
    cur.searchParams.forEach((val, key) => {
        if (key !== 'q' && key !== 'page') url.searchParams.append(key, val);
    });
    url.searchParams.set('q', term);
    url.searchParams.delete('page');
    const next = url.pathname + (url.search ? url.search : '');
    const currentPath = cur.pathname + (cur.search || '');
    if (next === currentPath) {
        window.updateHeaderSearchClearVisibility();
        return;
    }
    if (window.loadPage) window.loadPage(next, true);
    else window.location.href = next;
    window.updateHeaderSearchClearVisibility();
}

// Auto-expand on load if query exists
document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('header-search-input');
    const form = document.getElementById('header-search-form');
    if (input && form && input.value.trim() !== '') {
        form.classList.add('active');
    }
    window.updateHeaderSearchClearVisibility();
});
})();
