/**
 * Login/register Turnstile — explicit render (no declarative data-callback).
 * Load after ulp-site-globals.js (onTurnstileSuccess / onTurnstileExpired).
 */
(function () {
    'use strict';

    function getMountEl() {
        return document.querySelector('[data-ulp-turnstile-sitekey]');
    }

    function showTurnstileHint(msg) {
        const el = document.getElementById('ulp-turnstile-hint');
        if (el) {
            el.textContent = msg;
            el.hidden = false;
        }
    }

    function mountTurnstile() {
        const el = getMountEl();
        if (!el || el.getAttribute('data-ulp-turnstile-mounted') === '1') {
            return true;
        }
        if (!window.turnstile || typeof window.turnstile.render !== 'function') {
            return false;
        }
        if (el.querySelector('iframe')) {
            el.setAttribute('data-ulp-turnstile-mounted', '1');
            return true;
        }
        const sitekey = el.getAttribute('data-ulp-turnstile-sitekey');
        if (!sitekey) {
            return false;
        }
        const theme = el.getAttribute('data-ulp-turnstile-theme') || 'dark';
        try {
            const wid = window.turnstile.render(el, {
                sitekey,
                theme,
                appearance: 'always',
                callback: typeof window.onTurnstileSuccess === 'function' ? window.onTurnstileSuccess : undefined,
                'expired-callback': typeof window.onTurnstileExpired === 'function' ? window.onTurnstileExpired : undefined,
                'error-callback': function () {
                    if (typeof window.onTurnstileExpired === 'function') {
                        window.onTurnstileExpired();
                    }
                    try {
                        window.turnstile.reset(el);
                    } catch (e) { /* ignore */ }
                },
            });
            if (wid != null && wid !== '') {
                window.__ulpTurnstileWidgetId = wid;
                el.setAttribute('data-ulp-turnstile-mounted', '1');
                const hint = document.getElementById('ulp-turnstile-hint');
                if (hint) hint.hidden = true;
                return true;
            }
        } catch (e) {
            console.warn('auth-turnstile: render failed', e);
        }
        return false;
    }

    function ulpTurnstileApiOnLoad() {
        function attempt() {
            if (mountTurnstile()) {
                return;
            }
            let tries = 0;
            const retry = setInterval(function () {
                if (mountTurnstile() || tries > 60) {
                    clearInterval(retry);
                    if (tries > 60) {
                        const mount = getMountEl();
                        if (mount && mount.getAttribute('data-ulp-turnstile-mounted') !== '1') {
                            showTurnstileHint(
                                'Captcha did not load. Hard-refresh or pause AdGuard on this site, then try again.'
                            );
                        }
                    }
                }
                tries += 1;
            }, 200);
        }
        setTimeout(attempt, 50);
    }

    window.ulpTurnstileApiOnLoad = ulpTurnstileApiOnLoad;

    function boot() {
        if (!getMountEl()) return;
        if (window.turnstile) {
            ulpTurnstileApiOnLoad();
            return;
        }
        const apiScript = document.querySelector('script[data-ulp-cf-turnstile-api]');
        if (apiScript) {
            apiScript.addEventListener('load', ulpTurnstileApiOnLoad, { once: true });
            apiScript.addEventListener('error', function () {
                showTurnstileHint('Captcha script blocked. Check extensions or network.');
            }, { once: true });
        }
        let tries = 0;
        const poll = setInterval(function () {
            if (window.turnstile) {
                clearInterval(poll);
                ulpTurnstileApiOnLoad();
            } else if (tries++ > 120) {
                clearInterval(poll);
            }
        }, 50);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
