/**
 * Profile page UI — tabs, media upload triggers, admin actions (CSP script-src-attr).
 */
(function () {
    'use strict';

    if (window.__ulpProfileDeleg) return;
    window.__ulpProfileDeleg = true;

    function readConfig() {
        var el = document.getElementById('ulp-profile-page-config');
        if (!el) return {};
        try {
            return JSON.parse(el.textContent || '{}');
        } catch (e) {
            return {};
        }
    }

    document.addEventListener('click', function (e) {
        var actEl = e.target.closest('[data-ulp-profile-action]');
        if (!actEl) return;

        var action = actEl.getAttribute('data-ulp-profile-action');
        var cfg = readConfig();

        if (action === 'trigger-input') {
            var id = actEl.getAttribute('data-input-id');
            if (id) {
                var inp = document.getElementById(id);
                if (inp) inp.click();
            }
            return;
        }
        if (action === 'media-delete' && typeof window.profileMediaDelete === 'function') {
            e.stopPropagation();
            window.profileMediaDelete(actEl.getAttribute('data-media-kind'));
            return;
        }
        if (action === 'switch-tab' && typeof window.switchPageTab === 'function') {
            window.switchPageTab(actEl.getAttribute('data-tab'), actEl);
            return;
        }
        if (action === 'clean-spam' && typeof window.openCleanSpamModal === 'function') {
            window.openCleanSpamModal(actEl.getAttribute('data-user-id'), actEl.getAttribute('data-username'));
            return;
        }
        if (action === 'open-ban-modal' && typeof window.openBanModal === 'function') {
            var form = actEl.closest('form');
            if (form) window.openBanModal(form, actEl.getAttribute('data-username'));
        }
    });

    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form || !form.getAttribute || !form.getAttribute('data-ulp-confirm-submit')) return;
        if (!confirm(form.getAttribute('data-ulp-confirm-submit'))) {
            e.preventDefault();
        }
    });

    document.addEventListener('change', function (e) {
        var t = e.target;
        if (!t || t.tagName !== 'INPUT' || t.type !== 'file') return;
        if (t.id !== 'direct-bg-input' && t.id !== 'direct-avatar-input') return;
        var loader = document.getElementById('global-loader');
        if (loader) loader.style.display = 'flex';
        var formId = t.id === 'direct-bg-input' ? 'direct-bg-form' : 'direct-avatar-form';
        var form = document.getElementById(formId);
        if (form) form.submit();
    });
})();
