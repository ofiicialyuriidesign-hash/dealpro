/**
 * Site-wide globals (Turnstile login/register, SPA back navigation).
 * External file — no inline script (CSP hardening).
 */
(function () {
    'use strict';

    window.__ulpTurnstileEnableSubmit = function (enabled) {
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const targets = [loginBtn, registerBtn].filter(Boolean);
        targets.forEach((btn) => {
            if (enabled) {
                btn.disabled = false;
                btn.removeAttribute('disabled');
                btn.classList.remove('disabled');
                btn.style.pointerEvents = 'auto';
                btn.style.cursor = 'pointer';
                const isRegister = btn.id === 'register-btn';
                btn.title = isRegister ? 'Click to register' : 'Click to login';
                btn.setAttribute('data-tooltip', isRegister ? 'Click to register' : 'Click to login');
            } else {
                btn.disabled = true;
                btn.title = 'Detecting humanity...';
                btn.style.cursor = 'not-allowed';
            }
        });
        if (enabled && targets.length) {
            void targets[0].offsetWidth;
            const tooltip = document.querySelector('.modern-tooltip');
            if (tooltip) {
                tooltip.style.display = 'none';
                tooltip.classList.remove('active');
                if (tooltip.textContent.includes('Detecting')) {
                    const t0 = targets[0];
                    tooltip.textContent =
                        t0 && t0.id === 'register-btn' ? 'Click to register' : 'Click to login';
                }
            }
        }
    };

    window.onTurnstileSuccess = function (_token) {
        window.__ulpTurnstileEnableSubmit(true);
    };

    window.onTurnstileExpired = function () {
        window.__ulpTurnstileEnableSubmit(false);
    };

    window.goBack = function (event, fallbackUrl) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        const referrer = document.referrer;
        const currentOrigin = window.location.origin;
        if (referrer && referrer.startsWith(currentOrigin) && referrer !== window.location.href) {
            window.history.back();
        } else if (window.loadPage) {
            window.loadPage(fallbackUrl);
        } else {
            window.location.href = fallbackUrl;
        }
    };

    function ulpSpaNavigate(url) {
        if (!url) return;
        if (window.loadPage) {
            /* loadPage returns false when superseded (rapid tab clicks) — not an error.
               Real fetch failures already trigger window.location inside loadPage. */
            void window.loadPage(url);
        } else {
            window.location.href = url;
        }
    }

    window.navigateBackToList = function (event, fallbackUrl, expectedType) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        try {
            let anchor = null;
            const raw = sessionStorage.getItem('spa_list_return_anchor');
            if (raw) anchor = JSON.parse(raw);
            if (!anchor && history && history.state && typeof history.state === 'object') {
                anchor = history.state.__ulpListReturnAnchor || null;
            }
            const typeOk = !expectedType || (anchor && anchor.type === expectedType);
            if (anchor && typeOk && anchor.listPath) {
                const targetUrl = `${anchor.listPath}${anchor.listQuery || ''}`;
                ulpSpaNavigate(targetUrl);
                return;
            }
        } catch (e) { /* fall through */ }
        ulpSpaNavigate(fallbackUrl || '/');
    };

    if (!window.__ulpSiteGlobalsDeleg) {
        window.__ulpSiteGlobalsDeleg = true;
        document.addEventListener('click', function (e) {
            if (e.target.closest('[data-ulp-stop-propagation]')) {
                e.stopPropagation();
            }
            var histBack = e.target.closest('[data-ulp-history-back]');
            if (histBack) {
                e.preventDefault();
                if (window.history.length > 1) window.history.back();
                else if (window.loadPage) window.loadPage(histBack.getAttribute('data-fallback-href') || '/');
                else window.location.href = histBack.getAttribute('data-fallback-href') || '/';
            }
        }, true);
    }

    /** Capture phase — must run before spa.js generic <a> handler to avoid double nav / full reload. */
    document.addEventListener('click', function (e) {
        var back = e.target.closest('[data-ulp-nav-back]');
        if (back) {
            e.preventDefault();
            e.stopImmediatePropagation();
            var listType = back.getAttribute('data-list-type') || 'file';
            window.navigateBackToList(e, back.getAttribute('href'), listType);
            return;
        }
        var spaLink = e.target.closest('[data-ulp-spa-link]');
        if (!spaLink) return;
        var href = (spaLink.getAttribute('href') || '').trim();
        if (!href || href === '#') return;
        e.preventDefault();
        e.stopImmediatePropagation();
        window.ulpNavigateHref(href);
    }, true);

    /** Escape text before inserting into HTML (XSS hardening). */
    window.ulpEscapeHtml = function (value) {
        var d = document.createElement('div');
        d.textContent = value == null ? '' : String(value);
        return d.innerHTML;
    };

    var ULP_SITE_HOSTS = Object.freeze({
        'ulp.email': 1,
        'www.ulp.email': 1,
        localhost: 1,
        '127.0.0.1': 1
    });

    function ulpNormalizeSiteHostname(host) {
        host = (host || '').toLowerCase();
        return host.indexOf('www.') === 0 ? host.slice(4) : host;
    }

    function ulpHostnameIsSite(host) {
        host = (host || '').toLowerCase();
        if (!host) return false;
        if (ULP_SITE_HOSTS[host]) return true;
        var bare = ulpNormalizeSiteHostname(host);
        if (ULP_SITE_HOSTS[bare] || ULP_SITE_HOSTS['www.' + bare]) return true;
        try {
            var pageHost = (window.location.hostname || '').toLowerCase();
            if (pageHost && ulpNormalizeSiteHostname(host) === ulpNormalizeSiteHostname(pageHost)) {
                return true;
            }
        } catch (e) { /* ignore */ }
        return false;
    }

    function ulpParseSiteHref(href) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return null;
        if (safe.charAt(0) === '/' && safe.charAt(1) !== '/') {
            return safe;
        }
        var low = safe.toLowerCase();
        if (low.indexOf('mailto:') === 0 || low.indexOf('tel:') === 0) return null;
        try {
            if (low.indexOf('http://') === 0 || low.indexOf('https://') === 0) {
                var absolute = new URL(safe, window.location.origin);
                if (absolute.origin === 'null' || !ulpHostnameIsSite(absolute.hostname)) return null;
                return absolute;
            }
            if (/^(www\.)?[a-z0-9.-]+\.[a-z]{2,}/i.test(safe)) {
                var bare = new URL(safe.indexOf('//') === 0 ? safe : 'https://' + safe, window.location.origin);
                if (bare.origin === 'null' || !ulpHostnameIsSite(bare.hostname)) return null;
                return bare;
            }
        } catch (e) { /* ignore */ }
        return null;
    }

    /** Block javascript/data URLs and protocol-relative // links. */
    window.ulpSanitizeNotificationHref = function (href) {
        if (href == null) return '';
        var s = String(href).trim();
        if (!s || s === '#') return '';
        var low = s.toLowerCase();
        if (low.indexOf('javascript:') === 0 || low.indexOf('vbscript:') === 0 || low.indexOf('data:') === 0) {
            return '';
        }
        if (s.indexOf('//') === 0) return '';
        return s;
    };

    window.ulpIsInternalHref = function (href) {
        return !!ulpParseSiteHref(href);
    };

    window.ulpResolveInternalHref = function (href) {
        var parsed = ulpParseSiteHref(href);
        if (!parsed) return '';
        if (typeof parsed === 'string') return parsed;
        var dest = parsed.pathname || '/';
        if (parsed.search) dest += parsed.search;
        if (parsed.hash) dest += parsed.hash;
        return dest;
    };

    /** Internal → SPA; external → confirm + new tab. */
    window.ulpIsExternalNavHref = function (href) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe || window.ulpIsInternalHref(safe)) return false;
        var low = safe.toLowerCase();
        if (low.indexOf('mailto:') === 0 || low.indexOf('tel:') === 0) return false;
        if (safe.indexOf('www.') === 0) return true;
        return /^https?:\/\//i.test(safe);
    };

    window.ulpNormalizeExternalOpenHref = function (href) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return '';
        if (safe.indexOf('www.') === 0) return 'https://' + safe;
        return safe;
    };

    window.ulpFormatExternalLinkDisplay = function (href) {
        return window.ulpNormalizeExternalOpenHref(href) || window.ulpSanitizeNotificationHref(href) || '';
    };

    window.ulpFormatExternalLinkLabel = function (href) {
        var full = window.ulpFormatExternalLinkDisplay(href);
        if (!full) return '';
        try {
            var url = new URL(full, window.location.origin);
            return url.hostname || full;
        } catch (e) {
            return full;
        }
    };

    var _ulpExtConfirmPending = null;

    window.ulpConfirmExternalLink = function (href) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return Promise.resolve(false);
        if (_ulpExtConfirmPending) return _ulpExtConfirmPending;

        _ulpExtConfirmPending = new Promise(function (resolve) {
            var openHref = window.ulpFormatExternalLinkDisplay(href);
            if (!openHref) {
                _ulpExtConfirmPending = null;
                resolve(false);
                return;
            }
            var overlay = document.createElement('div');
            overlay.className = 'ulp-extlink-overlay';
            overlay.setAttribute('role', 'dialog');
            overlay.setAttribute('aria-modal', 'true');
            overlay.setAttribute('aria-labelledby', 'ulp-extlink-title');

            var card = document.createElement('div');
            card.className = 'ulp-extlink-card cyber-card';
            card.innerHTML =
                '<div class="ulp-extlink-header">' +
                '<h3 id="ulp-extlink-title" class="ulp-extlink-title">' +
                '<i class="fas fa-up-right-from-square" aria-hidden="true"></i>' +
                '<span>External link</span></h3>' +
                '<button type="button" class="ulp-extlink-close" aria-label="Close">' +
                '<i class="fas fa-times" aria-hidden="true"></i></button></div>' +
                '<div class="ulp-extlink-body">' +
                '<p class="ulp-extlink-lead">You are leaving <strong>ulp.email</strong>. We do not control external websites — proceed only if you trust this destination.</p>' +
                '<div class="ulp-extlink-url-label">Destination URL</div>' +
                '<div class="ulp-extlink-url" role="text">' + window.ulpEscapeHtml(openHref) + '</div>' +
                '<div class="ulp-extlink-actions">' +
                '<button type="button" class="btn btn-toolbar ulp-extlink-cancel">Stay here</button>' +
                '<button type="button" class="btn btn-toolbar ulp-extlink-confirm">' +
                '<span>Continue</span><i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i></button>' +
                '</div></div>';
            overlay.appendChild(card);
            document.body.appendChild(overlay);

            var done = function (value) {
                _ulpExtConfirmPending = null;
                overlay.remove();
                resolve(!!value);
            };

            card.querySelector('.ulp-extlink-cancel').addEventListener('click', function () { done(false); });
            card.querySelector('.ulp-extlink-confirm').addEventListener('click', function () { done(true); });
            card.querySelector('.ulp-extlink-close').addEventListener('click', function () { done(false); });
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) done(false);
            });
            card.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') done(false);
            });

            setTimeout(function () {
                var btn = card.querySelector('.ulp-extlink-confirm');
                if (btn) btn.focus();
            }, 30);
        });

        return _ulpExtConfirmPending;
    };

    window.ulpOpenExternalHref = function (href) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return Promise.resolve(false);
        if (window.ulpIsInternalHref(safe)) {
            return Promise.resolve(window.ulpNavigateHref(safe));
        }
        return window.ulpConfirmExternalLink(safe).then(function (ok) {
            if (ok) {
                var openHref = window.ulpNormalizeExternalOpenHref(safe);
                window.open(openHref, '_blank', 'noopener,noreferrer');
            }
            return ok;
        });
    };

    /** Internal → SPA; external → confirm + new tab. Returns false when href is unsafe/empty. */
    window.ulpNavigateHref = function (href, opts) {
        opts = opts || {};
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return false;
        if (typeof opts.beforeNavigate === 'function') opts.beforeNavigate();

        if (window.ulpIsInternalHref(safe)) {
            var dest = window.ulpResolveInternalHref(safe);
            if (!dest) return false;
            try {
                var dl = new URL(dest, window.location.origin);
                if (dl.pathname.indexOf('/download/') === 0) {
                    window.location.assign(dl.href);
                    return true;
                }
            } catch (e) { /* fall through to SPA */ }
            if (typeof window.loadPage === 'function') {
                document.body.style.cursor = 'wait';
                void window.loadPage(dest);
            } else {
                window.location.assign(dest);
            }
            return true;
        }

        void window.ulpOpenExternalHref(safe);
        return true;
    };

    window.ulpBuildInlineLinkHtml = function (href, label, linkStyle) {
        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return window.ulpEscapeHtml(label);
        var escLabel = window.ulpEscapeHtml(label);
        var style = linkStyle || 'color: var(--primary-color); text-decoration: underline;';
        if (window.ulpIsInternalHref(safe)) {
            var path = window.ulpResolveInternalHref(safe) || safe;
            var escPath = window.ulpEscapeHtml(path).replace(/"/g, '&quot;');
            return '<a href="' + escPath + '" class="external-link" style="' + style + '">' + escLabel + '</a>';
        }
        var escHref = window.ulpEscapeHtml(safe).replace(/"/g, '&quot;');
        return '<a href="' + escHref + '" class="external-link" target="_blank" rel="noopener noreferrer" style="' + style + '">' + escLabel + '</a>';
    };

    window.ulpWireInlineContentLinks = function (root) {
        if (!root) return;
        root.querySelectorAll('.ulp-toast-message a[href], .ulp-site-banner-msg a[href]').forEach(function (a) {
            if (a.dataset.ulpInlineLinkBound === '1') return;
            a.dataset.ulpInlineLinkBound = '1';
            a.addEventListener('click', function (e) {
                e.stopPropagation();
                var href = (a.getAttribute('href') || '').trim();
                if (!href || href === '#') return;
                if (window.ulpIsExternalNavHref && window.ulpIsExternalNavHref(href)) return;
                e.preventDefault();
                window.ulpNavigateHref(href);
            });
        });
    };

    function ulpInterceptConfirmedVisitLink(e) {
        var a = e.target.closest && e.target.closest('a[data-ulp-confirm-external]');
        if (!a) return false;
        var externalUrl = (a.getAttribute('data-ulp-confirm-external') || '').trim();
        var visitHref = (a.getAttribute('href') || '').trim();
        if (!externalUrl || !visitHref) return false;
        e.preventDefault();
        e.stopPropagation();
        if (window.ulpIsInternalHref(externalUrl)) {
            fetch(visitHref, { credentials: 'same-origin' }).catch(function () {});
            window.ulpNavigateHref(externalUrl);
            return true;
        }
        window.ulpConfirmExternalLink(externalUrl).then(function (ok) {
            if (!ok) return;
            window.open(visitHref, '_blank', 'noopener,noreferrer');
        });
        return true;
    }

    function ulpInterceptExternalLinkInteraction(e) {
        if (e.defaultPrevented) return;
        if (ulpInterceptConfirmedVisitLink(e)) return;
        var a = e.target.closest && e.target.closest('a[href]');
        if (!a) return;
        if (a.hasAttribute('data-ulp-skip-external-confirm')) return;
        if (a.closest('[data-ulp-skip-external-confirm]')) return;
        if (a.hasAttribute('download')) return;
        var href = (a.getAttribute('href') || '').trim();
        if (!href || href.charAt(0) === '#') return;
        if (window.ulpIsInternalHref(href)) {
            e.preventDefault();
            e.stopPropagation();
            window.ulpNavigateHref(href);
            return;
        }
        if (!window.ulpIsExternalNavHref(href)) return;

        var safe = window.ulpSanitizeNotificationHref(href);
        if (!safe) return;

        e.preventDefault();
        e.stopPropagation();

        window.ulpConfirmExternalLink(safe).then(function (ok) {
            if (!ok) return;
            var openHref = window.ulpNormalizeExternalOpenHref(safe);
            window.open(openHref, '_blank', 'noopener,noreferrer');
        });
    }

    document.addEventListener('click', ulpInterceptExternalLinkInteraction, true);
    document.addEventListener('auxclick', function (e) {
        if (e.button !== 1) return;
        ulpInterceptExternalLinkInteraction(e);
    }, true);
})();
