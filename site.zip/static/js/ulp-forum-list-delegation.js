/**
 * Forum category/index lists — bulk + card hit (CSP script-src-attr).
 */
(function () {
    'use strict';

    if (window.__ulpForumListDeleg) return;
    window.__ulpForumListDeleg = true;

    function spaNavigate(url, e) {
        if (!url) return;
        if (e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }
        }
        if (typeof window.ulpNavigateHref === 'function') {
            window.ulpNavigateHref(url);
            return;
        }
        if (window.loadPage) {
            void window.loadPage(url);
            return;
        }
        window.location.href = url;
    }

    document.addEventListener('click', function (e) {
        if (e.target.closest('.list-bulk-checkbox-cell')) {
            e.stopPropagation();
        }

        var actEl = e.target.closest('[data-ulp-forum-list-action]');
        if (!actEl) return;

        var action = actEl.getAttribute('data-ulp-forum-list-action');
        if (action === 'bulk-delete-cat' && typeof window.bulkDeleteForumTopics === 'function') {
            e.preventDefault();
            window.bulkDeleteForumTopics();
            return;
        }
        if (action === 'bulk-delete-index' && typeof window.bulkDeleteForumTopicsIndex === 'function') {
            e.preventDefault();
            window.bulkDeleteForumTopicsIndex();
            return;
        }
        if (action === 'bulk-move-index' && typeof window.bulkMoveForumTopicsIndex === 'function') {
            e.preventDefault();
            window.bulkMoveForumTopicsIndex();
        }
    });

    document.addEventListener('change', function (e) {
        var t = e.target;
        if (!t) return;

        if (t.id === 'select-all-forum-topics' && typeof window.toggleSelectAllForumTopics === 'function') {
            window.toggleSelectAllForumTopics(t);
            return;
        }
        if (t.id === 'select-all-forum-topics-index' && typeof window.toggleSelectAllForumTopicsIndex === 'function') {
            window.toggleSelectAllForumTopicsIndex(t);
            return;
        }
        if (t.id === 'bulk-move-forum-category-index' && typeof window.updateForumTopicSelectionIndex === 'function') {
            window.updateForumTopicSelectionIndex();
            return;
        }
        if (t.classList && t.classList.contains('forum-topic-checkbox') && typeof window.updateForumTopicSelection === 'function') {
            window.updateForumTopicSelection();
            return;
        }
        if (t.classList && t.classList.contains('forum-topic-checkbox-index') && typeof window.updateForumTopicSelectionIndex === 'function') {
            window.updateForumTopicSelectionIndex();
        }
    });

    document.addEventListener('click', function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

        var card = e.target.closest('.forum-topic-list-card[data-topic-id]');
        if (!card) return;
        if (
            e.target.closest(
                'button, input, label, select, textarea, .list-bulk-checkbox-cell, ' +
                    '[data-ulp-forum-list-action], a.username-tag, .forum-topic-category-pill, ' +
                    '.forum-topic-mgmt-edit, .forum-topic-mod-apply, .forum-topic-cat-flydown-link, ' +
                    '.forum-prefix-filter-banner__clear, .like-btn-container, .forum-topic-inline-bump-btn'
            )
        ) {
            return;
        }

        var clickedLink = e.target.closest('a[href]');
        if (clickedLink) {
            var linkHref = (clickedLink.getAttribute('href') || '').trim();
            if (linkHref && linkHref !== '#') return;
        }

        var hit = card.querySelector(':scope > .forum-topic-list-card-hit');
        var url = hit ? (hit.getAttribute('href') || '').trim() : '';
        if (!url || url === '#') return;

        spaNavigate(url, e);
    });
})();
