/**
 * Login/register pages: mobile menu + press feedback (no SPA bundle).
 */
(function () {
    'use strict';

    function bindMobileMenuLight() {
        var t = document.getElementById('mobile-menu-toggle');
        var m = document.getElementById('mobile-menu');
        var c = document.getElementById('close-mobile-btn');
        if (!t || !m || m.getAttribute('data-ulp-light-menu') === '1') return;
        m.setAttribute('data-ulp-light-menu', '1');
        t.addEventListener('click', function () {
            m.classList.add('active');
            t.classList.add('open');
        });
        if (c) {
            c.addEventListener('click', function (e) {
                e.stopPropagation();
                m.classList.remove('active');
                t.classList.remove('open');
            });
        }
        m.addEventListener('click', function (e) {
            if (e.target === m) {
                m.classList.remove('active');
                t.classList.remove('open');
            }
        });
    }

    function bindPressFeedbackLight() {
        if (window.__ulpAuthPressFxBound) return;
        window.__ulpAuthPressFxBound = true;

        var selector = [
            '.nav-item',
            '.logo-link',
            '.filter-chip',
            '.btn',
            'a.btn',
            'button.btn',
            '.nav-btn-icon',
            '.mobile-nav-item',
            '.mobile-toggle',
            '.auth-form-submit',
            '.auth-card-alt-link'
        ].join(', ');

        var pressedEl = null;
        var pressedSurfaceEl = null;
        var releaseTimer = null;

        function skipInlinePressFx(el) {
            return el && el.matches(
                '.ulp-press-soft, .auth-form-submit, .auth-card-alt-link'
            );
        }

        function applyPressInlineStyle(el) {
            if (!el) return;
            el.style.setProperty(
                'transition',
                'transform var(--ulp-press-ms, 125ms) var(--ulp-press-ease, cubic-bezier(0.33, 1, 0.68, 1))',
                'important'
            );
            el.style.setProperty('transform', 'var(--ulp-press-transform, scale(0.982))', 'important');
        }

        function clearPressInlineStyle(el) {
            if (!el) return;
            el.style.removeProperty('transform');
            el.style.removeProperty('transition');
        }

        function clearPressed() {
            if (releaseTimer) {
                clearTimeout(releaseTimer);
                releaseTimer = null;
            }
            if (pressedSurfaceEl) {
                clearPressInlineStyle(pressedSurfaceEl);
                pressedSurfaceEl = null;
            }
            if (pressedEl) {
                pressedEl.classList.remove('press-feedback');
                pressedEl = null;
            }
        }

        function applyPressed(el) {
            if (!el || el.disabled || el.getAttribute('aria-disabled') === 'true') return;
            clearPressed();
            pressedEl = el;
            pressedSurfaceEl = el;
            pressedEl.classList.add('press-feedback');
            if (!skipInlinePressFx(pressedEl)) {
                applyPressInlineStyle(pressedSurfaceEl);
            }
            releaseTimer = setTimeout(clearPressed, 220);
        }

        function onPointerRelease() {
            if (pressedSurfaceEl) {
                clearPressInlineStyle(pressedSurfaceEl);
                pressedSurfaceEl = null;
            }
        }

        document.addEventListener('pointerdown', function (e) {
            if (e.target.closest('.cyber-checkbox')) return;
            var nested = e.target.closest('a, button, .filter-chip, .nav-btn-icon, .mobile-nav-item, .mobile-toggle');
            var target = nested && nested.matches(selector) ? nested : e.target.closest(selector);
            if (!target) return;
            applyPressed(target);
        }, true);

        document.addEventListener('pointerup', onPointerRelease, true);
        document.addEventListener('pointercancel', clearPressed, true);
        document.addEventListener('visibilitychange', clearPressed, true);
    }

    function initAuthLight() {
        bindMobileMenuLight();
        bindPressFeedbackLight();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAuthLight);
    } else {
        initAuthLight();
    }
})();
