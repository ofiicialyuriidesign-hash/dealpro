/**
 * Files / resources list pages — row nav, bulk, admin ajax (CSP script-src-attr).
 */
(function () {
    'use strict';

    if (window.__ulpListDeleg) return;
    window.__ulpListDeleg = true;

    function spaNavigate(url, e) {
        if (!url) return;
        if (e) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }
        }
        if (typeof window.ulpNavigateHref === 'function') {
            window.ulpNavigateHref(url);
            return;
        }
        if (window.loadPage) {
            void window.loadPage(url);
            return;
        }
        window.location.href = url;
    }

    document.addEventListener('click', function (e) {
        if (e.target.closest('.list-bulk-checkbox-cell')) {
            // Bulk-select controls must never trigger row navigation.
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }
            return;
        }

        var ajaxBtn = e.target.closest('[data-ulp-ajax-action]');
        if (ajaxBtn && typeof window.ajaxAction === 'function') {
            e.preventDefault();
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') {
                e.stopImmediatePropagation();
            }
            window.ajaxAction(ajaxBtn.getAttribute('data-ulp-ajax-action'));
            return;
        }

        var actEl = e.target.closest('[data-ulp-list-action]');
        if (actEl) {
            e.preventDefault();
            var action = actEl.getAttribute('data-ulp-list-action');
            if (action === 'bulk-approve-files' && typeof window.bulkApproveMain === 'function') {
                window.bulkApproveMain();
            } else if (action === 'bulk-delete-files' && typeof window.bulkDeleteMain === 'function') {
                window.bulkDeleteMain();
            } else if (action === 'bulk-vip-free' && typeof window.bulkVipToFreeMain === 'function') {
                window.bulkVipToFreeMain();
            } else if (action === 'bulk-approve-listings' && typeof window.bulkApproveListingsMain === 'function') {
                window.bulkApproveListingsMain();
            } else if (action === 'bulk-delete-listings' && typeof window.bulkDeleteListingsMain === 'function') {
                window.bulkDeleteListingsMain();
            }
            return;
        }

        if (e.target.closest('input, label, select, textarea')) return;

        var row = e.target.closest('.file-item[data-url], .resource-item[data-url]');
        if (!row) return;
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

        var clickedLink = e.target.closest('a[href]');
        if (clickedLink) {
            var linkHref = (clickedLink.getAttribute('href') || '').trim();
            if (linkHref && linkHref !== '#') return;
        }

        spaNavigate(row.getAttribute('data-url'), e);
    });

    document.addEventListener('change', function (e) {
        var t = e.target;
        if (!t) return;

        if (t.id === 'select-all-files' && typeof window.toggleSelectAllFiles === 'function') {
            window.toggleSelectAllFiles(t);
            return;
        }
        if (t.id === 'select-all-listings' && typeof window.toggleSelectAllListingsMain === 'function') {
            window.toggleSelectAllListingsMain(t);
            return;
        }
        if (t.id === 'bulk-move-forum-category-index') return;

        if (t.classList && t.classList.contains('file-checkbox-main') && typeof window.updateSelectionMain === 'function') {
            window.updateSelectionMain();
            return;
        }
        if (t.classList && t.classList.contains('listing-checkbox-main') && typeof window.updateListingSelectionMain === 'function') {
            window.updateListingSelectionMain();
        }
    });
})();
