(function (w) {
  'use strict';

  function csrfHeaders() {
    var t = w.__CSRF_TOKEN__ || '';
    if (!t) return {};
    return { 'X-CSRFToken': t, 'X-CSRF-Token': t };
  }

  var INLINE_IMAGES_PER_MESSAGE_LIMIT = 6;

  function showEditorToast(title, message) {
    if (typeof w.showToast === 'function') {
      w.showToast(title, message, null, 'fas fa-circle-exclamation', null, 'error');
      return;
    }
    if (typeof w.createFlash === 'function') {
      w.createFlash(message, 'error');
      return;
    }
    try {
      w.alert(message);
    } catch (e) {}
  }

  function getInlineImageCount(quill) {
    if (!quill || !quill.root || !quill.root.querySelectorAll) return 0;
    return quill.root.querySelectorAll('img[src]').length;
  }

  function resolveImageLimit(opts) {
    var n = Number((opts && opts.maxImagesPerMessage) || INLINE_IMAGES_PER_MESSAGE_LIMIT);
    if (!Number.isFinite(n) || n < 1) return INLINE_IMAGES_PER_MESSAGE_LIMIT;
    return Math.floor(n);
  }

  function uploadInlineImage(file, uploadUrl) {
    var fd = new FormData();
    fd.append('image', file);
    return fetch(uploadUrl || '/api/upload/inline-image', {
      method: 'POST',
      body: fd,
      headers: csrfHeaders(),
      credentials: 'same-origin',
    }).then(function (r) {
      return r.json().then(function (data) {
        return { ok: r.ok, data: data || {} };
      });
    });
  }

  function inlineImageUploadErrorMeta(err) {
    var code = '';
    if (typeof err === 'string') {
      code = err;
    } else if (err && typeof err.code === 'string') {
      code = err.code;
    } else if (err && typeof err.message === 'string') {
      code = err.message;
    }
    code = String(code || '').trim().toLowerCase();
    if (code === 'too large' || code === 'too_large') {
      return {
        title: 'Image too large',
        message: 'Image is too large. Maximum size is 3 MB.',
      };
    }
    if (code === 'not an image' || code === 'invalid image' || code === 'unsupported type') {
      return {
        title: 'Unsupported image',
        message: 'Only valid JPG, PNG, GIF, or WEBP images are allowed.',
      };
    }
    if (code === 'forbidden') {
      return {
        title: 'Upload blocked',
        message: 'Your account cannot upload images right now.',
      };
    }
    if (code === 'no file') {
      return {
        title: 'No image selected',
        message: 'Please choose an image and try again.',
      };
    }
    return {
      title: 'Upload failed',
      message: 'Could not upload one or more images.',
    };
  }

  w.describeInlineImageUploadError = inlineImageUploadErrorMeta;

  function readFileAsDataUrl(file) {
    return new Promise(function (resolve, reject) {
      try {
        var reader = new FileReader();
        reader.onload = function () {
          resolve(String(reader.result || ''));
        };
        reader.onerror = function () {
          reject(new Error('file_read_failed'));
        };
        reader.readAsDataURL(file);
      } catch (_e) {
        reject(new Error('file_read_failed'));
      }
    });
  }

  /** Max edge (px) for pasted/picked image preview in the editor; original File uploads only on send. */
  var INLINE_PREVIEW_MAX_EDGE = 300;
  var INLINE_PREVIEW_JPEG_QUALITY = 0.82;

  /**
   * Build a small JPEG data URL for display in Quill. Maps preview URL -> original File in __inlinePendingFiles.
   * Falls back to full readFileAsDataUrl if decode/canvas fails (display still capped by CSS).
   */
  function downscaleImageFileToPreviewDataUrl(file, maxEdge, quality) {
    maxEdge = maxEdge || INLINE_PREVIEW_MAX_EDGE;
    quality = typeof quality === 'number' ? quality : INLINE_PREVIEW_JPEG_QUALITY;
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\//i.test(file.type || '')) {
        readFileAsDataUrl(file).then(resolve).catch(reject);
        return;
      }
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        try {
          URL.revokeObjectURL(url);
          var w = img.naturalWidth || img.width || 1;
          var h = img.naturalHeight || img.height || 1;
          var scale = Math.min(1, maxEdge / Math.max(w, h));
          var cw = Math.max(1, Math.round(w * scale));
          var ch = Math.max(1, Math.round(h * scale));
          var canvas = document.createElement('canvas');
          canvas.width = cw;
          canvas.height = ch;
          var ctx = canvas.getContext('2d');
          if (!ctx) {
            readFileAsDataUrl(file).then(resolve).catch(reject);
            return;
          }
          if (/image\/png|image\/webp/i.test(file.type || '')) {
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, cw, ch);
          }
          ctx.drawImage(img, 0, 0, cw, ch);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } catch (_e) {
          readFileAsDataUrl(file).then(resolve).catch(reject);
        }
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        readFileAsDataUrl(file).then(resolve).catch(reject);
      };
      img.src = url;
    });
  }

  /**
   * After setContents([]) or an empty doc, Quill selection index 0 can render the caret
   * flush with the container edge (misaligned vs padded placeholder). Collapse the
   * native selection inside the first block so the caret matches text flow.
   */
  function placeQuillCaretAtFirstContentPosition(quill) {
    if (!quill || !quill.root) return;
    try {
      var root = quill.root;
      var p = root.querySelector('p');
      if (!p) {
        quill.setSelection(0, 0, 'silent');
        return;
      }
      quill.focus();
      var r = document.createRange();
      var first = p.firstChild;
      if (first && first.nodeType === Node.TEXT_NODE) {
        r.setStart(first, 0);
        r.collapse(true);
      } else if (first && first.nodeName === 'BR') {
        r.setStartBefore(first);
        r.collapse(true);
      } else {
        r.setStart(p, 0);
        r.collapse(true);
      }
      var sel = w.getSelection && w.getSelection();
      if (!sel || typeof sel.removeAllRanges !== 'function') {
        quill.setSelection(0, 0, 'silent');
        return;
      }
      sel.removeAllRanges();
      sel.addRange(r);
    } catch (e) {
      try {
        quill.setSelection(0, 0, 'silent');
      } catch (e2) {}
    }
  }

  /** Move caret to the end of the document (e.g. after seeding an edit). */
  function placeQuillCaretAtDocumentEnd(quill) {
    if (!quill) return;
    try {
      var len = quill.getLength();
      if (len <= 1) {
        placeQuillCaretAtFirstContentPosition(quill);
        return;
      }
      quill.setSelection(len - 1, 0, 'silent');
      quill.focus();
    } catch (e) {
      try {
        placeQuillCaretAtFirstContentPosition(quill);
      } catch (e2) {}
    }
  }

  w.placeQuillCaretAtFirstContentPosition = placeQuillCaretAtFirstContentPosition;
  w.placeQuillCaretAtDocumentEnd = placeQuillCaretAtDocumentEnd;

  function insertImageDataUrl(quill, file) {
    return downscaleImageFileToPreviewDataUrl(file, INLINE_PREVIEW_MAX_EDGE, INLINE_PREVIEW_JPEG_QUALITY).then(
      function (src) {
        if (!src) return;
        if (!quill.__inlinePendingFiles) quill.__inlinePendingFiles = {};
        quill.__inlinePendingFiles[src] = file;
        var range = quill.getSelection(true);
        var idx = range ? range.index : quill.getLength();
        quill.insertEmbed(idx, 'image', src, 'user');
        quill.setSelection(idx + 1, 0);
      }
    );
  }

  function bindImageHandler(quill, uploadUrl, opts) {
    opts = opts || {};
    var toolbar = quill.getModule('toolbar');
    if (!toolbar) return;
    if (opts.disableImageUpload) {
      toolbar.addHandler('image', function () {
        if (typeof w.requireLogin === 'function') {
          var nextUrl = w.location.pathname + w.location.search;
          w.requireLogin(
            opts.disableImageUploadMessage || 'Please login or register to upload images.',
            nextUrl
          );
        }
      });
      return;
    }
    toolbar.addHandler('image', function () {
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.name = 'quill_inline_image';
      input.id =
        'quill-inline-image-' +
        String((opts && opts.containerId) || 'editor').replace(/[^a-z0-9_-]/gi, '_') +
        '-' +
        Date.now();
      input.click();
      input.onchange = function () {
        var file = input.files && input.files[0];
        if (!file) return;
        var maxImages = resolveImageLimit(opts);
        if (getInlineImageCount(quill) >= maxImages) {
          showEditorToast('Limit reached', 'Max ' + maxImages + ' images per message.');
          return;
        }
        insertImageDataUrl(quill, file)
          .catch(function () {
            showEditorToast('Insert failed', 'Unable to add image.');
          });
      };
    });
  }

  function bindClipboardImagePaste(quill, uploadUrl, opts) {
    opts = opts || {};
    if (!quill || !quill.root || quill.__clipboardImagePasteBound) return;
    if (opts.disableImageUpload) return;
    quill.__clipboardImagePasteBound = true;

    quill.root.addEventListener('paste', function (e) {
      if (!e || !e.clipboardData || !e.clipboardData.items) return;
      var items = Array.prototype.slice.call(e.clipboardData.items || []);
      var imageFiles = items
        .filter(function (item) {
          return item && item.kind === 'file' && /^image\//i.test(item.type || '');
        })
        .map(function (item) {
          return item.getAsFile ? item.getAsFile() : null;
        })
        .filter(Boolean);
      if (!imageFiles.length) return;

      var maxImages = resolveImageLimit(opts);
      var existing = getInlineImageCount(quill);
      var freeSlots = Math.max(0, maxImages - existing);
      if (freeSlots <= 0) {
        e.preventDefault();
        showEditorToast('Limit reached', 'Max ' + maxImages + ' images per message.');
        return;
      }
      e.preventDefault();
      var toUpload = imageFiles.slice(0, freeSlots);
      var dropped = imageFiles.length - toUpload.length;
      var insertAt = (quill.getSelection(true) || quill.__lastUserRange || quill.__lastRange || { index: quill.getLength() }).index;
      if (!Number.isFinite(insertAt) || insertAt < 0) insertAt = quill.getLength();

      var chain = Promise.resolve();
      toUpload.forEach(function (file) {
        chain = chain.then(function () {
          return downscaleImageFileToPreviewDataUrl(
            file,
            INLINE_PREVIEW_MAX_EDGE,
            INLINE_PREVIEW_JPEG_QUALITY
          ).then(function (src) {
            if (!src) return;
            if (!quill.__inlinePendingFiles) quill.__inlinePendingFiles = {};
            quill.__inlinePendingFiles[src] = file;
            quill.insertEmbed(insertAt, 'image', src, 'user');
            insertAt += 1;
            quill.insertText(insertAt, '\n', 'user');
            insertAt += 1;
            quill.setSelection(insertAt, 0, 'silent');
          });
        });
      });
      chain.catch(function () {}).finally(function () {
        if (dropped > 0) {
          showEditorToast('Limit reached', 'Only ' + freeSlots + ' image(s) inserted. Max ' + maxImages + ' per message.');
        }
      });
    });
  }

  function defaultToolbar() {
    return [
      ['bold', 'italic', 'underline'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      ['link', 'image'],
      ['clean'],
    ];
  }

  function descriptionToolbar() {
    return [
      ['bold', 'italic', 'underline'],
      [{ list: 'ordered' }, { list: 'bullet' }],
      ['link'],
      ['clean'],
    ];
  }

  /** Block inline images in description editors (paste, drag, HTML). */
  function bindBlockImagesInQuill(quill, message) {
    if (!quill || quill.__blockImagesBound) return;
    quill.__blockImagesBound = true;
    var Delta = Quill.import('delta');
    var blockedMsg = message || 'Images cannot be added to descriptions. Upload a screenshot separately.';

    function stripImageOps(delta) {
      if (!delta || !delta.ops) return delta;
      var ops = delta.ops.filter(function (op) {
        return !(op.insert && typeof op.insert === 'object' && op.insert.image);
      });
      return new Delta(ops);
    }

    if (typeof Node !== 'undefined') {
      quill.clipboard.addMatcher(Node.ELEMENT_NODE, function (node, delta) {
        if (node && node.tagName === 'IMG') return new Delta();
        return stripImageOps(delta);
      });
    }

    quill.root.addEventListener('paste', function (e) {
      if (!e || !e.clipboardData) return;
      var items = Array.prototype.slice.call(e.clipboardData.items || []);
      var hasImage = items.some(function (item) {
        return item && item.kind === 'file' && /^image\//i.test(item.type || '');
      });
      if (!hasImage) return;
      e.preventDefault();
      e.stopPropagation();
      showEditorToast('Not allowed', blockedMsg);
    });
  }

  function normalizePlainText(text) {
    return String(text || '')
      .replace(/\uFEFF/g, '')
      .replace(/[\u200B-\u200D\u2060]/g, '')
      .normalize('NFKC');
  }

  /** One line that is only http(s) URL — used when pasting from address bar / "copy link". */
  function clipboardLooksLikeSingleHttpUrl(text) {
    var t = String(text || '').trim();
    if (!t || /[\n\r]/.test(t)) return '';
    if (!/^https?:\/\/\S+$/i.test(t)) return '';
    try {
      var u = new URL(t);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
      return t;
    } catch (e) {
      return '';
    }
  }

  /**
   * Telegram-like paste: strip foreign bold/colors/layout, but keep hyperlinks only.
   * Plain http(s) paste (no HTML link op) is handled by bindPastePlainUrlAsLink.
   */
  function bindPlainTextPaste(quill) {
    if (!quill || !quill.clipboard || quill.__plainPasteBound) return;
    quill.__plainPasteBound = true;
    var Delta = Quill.import('delta');
    var normalizeOps = function (delta) {
      if (!delta || !delta.ops) return delta;
      var nextOps = delta.ops.map(function (op) {
        if (op.insert !== null && typeof op.insert === 'object') {
          return { insert: op.insert, attributes: op.attributes };
        }
        var next = { insert: op.insert };
        if (typeof next.insert === 'string') {
          next.insert = normalizePlainText(next.insert);
        }
        var link = op.attributes && op.attributes.link;
        if (typeof link === 'string' && link.trim() && typeof next.insert === 'string') {
          next.attributes = { link: link.trim() };
        }
        return next;
      });
      return new Delta(nextOps);
    };
    if (typeof Node !== 'undefined') {
      quill.clipboard.addMatcher(Node.ELEMENT_NODE, function (_node, delta) {
        return normalizeOps(delta);
      });
      quill.clipboard.addMatcher(Node.TEXT_NODE, function (_node, delta) {
        return normalizeOps(delta);
      });
    }

    bindPastePlainUrlAsLink(quill);
  }

  /** When clipboard is a single URL string (no HTML link op), insert as Quill link format. */
  function bindPastePlainUrlAsLink(quill) {
    if (!quill || !quill.root || quill.__pastePlainUrlBound) return;
    quill.__pastePlainUrlBound = true;
    quill.root.addEventListener(
      'paste',
      function (e) {
        if (!e.clipboardData) return;
        var url = clipboardLooksLikeSingleHttpUrl(e.clipboardData.getData('text/plain'));
        if (!url) return;
        e.preventDefault();
        e.stopPropagation();
        var range = quill.getSelection(true);
        var idx = range ? range.index : Math.max(0, quill.getLength() - 1);
        var len = range && range.length ? range.length : 0;
        if (len > 0) {
          quill.deleteText(idx, len, 'user');
        }
        quill.insertText(idx, url, { link: url }, 'user');
        quill.setSelection(idx + url.length, 0, 'user');
        quill.focus();
      },
      true
    );
  }

  function bindStableRangeTracking(quill) {
    if (!quill || !quill.root || quill.__stableRangeBound) return;
    quill.__stableRangeBound = true;

    var remember = function () {
      try {
        var r = quill.getSelection();
        if (r) quill.__lastRange = r;
      } catch (e) {}
    };

    quill.on('selection-change', function (range, oldRange, source) {
      if (range) quill.__lastRange = range;
      if (range && source === 'user') quill.__lastUserRange = range;
    });
    quill.root.addEventListener('mouseup', remember);
    quill.root.addEventListener('keyup', remember);
    quill.root.addEventListener('focus', remember, true);
    quill.root.addEventListener('touchend', remember);
  }

  // Focus when clicking true dead space on the host (outside Quill's document surface).
  // Important: clicks on .ql-container but outside .ql-editor (padding, empty min-height)
  // must use native behaviour — otherwise preventDefault + setSelection(len-1) with len===1
  // forces index 0 and the caret jumps to the top-left (placeholder state).
  function bindContainerClickFocus(quill) {
    if (!quill || quill.__containerFocusBound) return;
    var container = quill.container;
    if (!container || !container.addEventListener) return;
    quill.__containerFocusBound = true;

    container.addEventListener('mousedown', function (e) {
      if (!e) return;
      var raw = e.target;
      if (!raw) return;
      var el = raw.nodeType === 3 ? raw.parentElement : raw;
      if (!el || typeof el.closest !== 'function') return;
      // Don't steal focus from toolbar controls.
      if (el.closest('.ql-toolbar') || el.closest('button') || el.closest('.ql-picker')) return;

      var qlDoc = container.querySelector('.ql-container');
      if (qlDoc && (el === qlDoc || qlDoc.contains(el))) return;

      var editor = container.querySelector('.ql-editor');
      if (editor && (el === editor || editor.contains(el))) return;

      e.preventDefault();
      quill.focus();
      var len = quill.getLength();
      if (len <= 1) {
        w.requestAnimationFrame(function () {
          placeQuillCaretAtFirstContentPosition(quill);
        });
      } else {
        quill.setSelection(len - 1, 0, 'silent');
      }
    });
  }

  /**
   * Quill adds contenteditable surfaces (.ql-editor, .ql-clipboard) and tooltip inputs
   * without id/name; Chrome DevTools flags them. Assign stable identifiers per instance.
   */
  function patchQuillFormFieldIds(quill, opts) {
    if (!quill || !quill.container) return;
    var base = (opts && opts.containerId) ? String(opts.containerId) : 'quill';
    var n = 0;
    function nextSlug() {
      n += 1;
      return base + '-ff-' + n;
    }
    function ensure(el) {
      if (!el || el.nodeType !== 1) return;
      var tag = (el.tagName || '').toLowerCase();
      var isCe = el.getAttribute && el.getAttribute('contenteditable') === 'true';
      if (tag !== 'input' && tag !== 'textarea' && tag !== 'select' && !isCe) return;
      if (el.id || el.getAttribute('name')) return;
      var slug = nextSlug();
      el.id = slug;
      el.setAttribute('name', slug.replace(/-/g, '_'));
    }
    function run() {
      quill.container.querySelectorAll('input,textarea,select,[contenteditable="true"]').forEach(ensure);
    }
    run();
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(function () {
        requestAnimationFrame(run);
      });
    }
  }

  w.initQuillRichEditor = function (opts) {
    if (typeof Quill === 'undefined') return null;
    opts = opts || {};
    var container = document.getElementById(opts.containerId);
    if (!container) return null;
    var quill = new Quill(container, {
      theme: 'snow',
      modules: {
        toolbar: opts.toolbar || defaultToolbar(),
      },
      placeholder: opts.placeholder || '',
    });
    quill.__lastRange = { index: Math.max(0, quill.getLength() - 1), length: 0 };
    bindStableRangeTracking(quill);
    if (opts.plainTextPaste !== false) {
      bindPlainTextPaste(quill);
    }
    bindContainerClickFocus(quill);
    bindImageHandler(quill, opts.uploadUrl, {
      containerId: opts.containerId,
      disableImageUpload: !!opts.disableImageUpload,
      disableImageUploadMessage: opts.disableImageUploadMessage || '',
      maxImagesPerMessage: opts.maxImagesPerMessage || INLINE_IMAGES_PER_MESSAGE_LIMIT,
    });
    bindClipboardImagePaste(quill, opts.uploadUrl, {
      disableImageUpload: !!opts.disableImageUpload,
      maxImagesPerMessage: opts.maxImagesPerMessage || INLINE_IMAGES_PER_MESSAGE_LIMIT,
    });
    if (opts.disableImageUpload) {
      bindBlockImagesInQuill(quill, opts.disableImageUploadMessage);
    }
    if (opts.initialHtml) {
      quill.clipboard.dangerouslyPasteHTML(0, opts.initialHtml, 'silent');
    }
    if (opts.hiddenInputId) {
      var hid = document.getElementById(opts.hiddenInputId);
      var sync = function () {
        if (!hid) return;
        hid.value = quill.getText().replace(/\uFEFF/g, '').replace(/\s+$/, '').length
          ? quill.root.innerHTML
          : '';
        hid.dispatchEvent(new Event('input', { bubbles: true }));
      };
      quill.on('text-change', sync);
      sync();
    }

    patchQuillFormFieldIds(quill, opts);

    return quill;
  };

  w.initQuillSyncOnSubmit = function (formSelector, quill, hiddenFieldId, syncOpts) {
    syncOpts = syncOpts || {};
    var form = document.querySelector(formSelector);
    if (!form || !quill) return;
    if (form.dataset.quillSyncBound === '1') return;
    form.dataset.quillSyncBound = '1';
    form.addEventListener('submit', function (e) {
      if (form.__richSubmitPending) {
        e.preventDefault();
        return;
      }
      e.preventDefault();
      var check;
      if (syncOpts.isDescription) {
        check = w.validateDescriptionQuill(quill);
        if (!check.ok) {
          w.notifyDescriptionValidation(check);
          return;
        }
      } else {
        check = w.validateRichMessageQuill(quill);
        if (!check.ok) {
          if (syncOpts.allowEmpty && check.reason === 'empty') {
            check = { ok: true };
          } else {
            w.notifyRichMessageValidation(check);
            return;
          }
        }
      }
      var el = document.getElementById(hiddenFieldId);
      form.__richSubmitPending = true;
      w
        .resolveQuillHtmlForSubmit(quill)
        .then(function (html) {
          if (el) {
            var plain = richEditorPlainTrim(quill);
            el.value = plain.length ? html : '';
          }
          if (form.getAttribute('data-spa-submit') === '1' && typeof w.ulpSubmitFormSpa === 'function') {
            w.ulpSubmitFormSpa(form).finally(function () {
              form.__richSubmitPending = false;
            });
            return;
          }
          /*
           * HTMLFormElement.submit() bypasses the submit event — avoids re-entrancy.
           * requestSubmit() from inside the first submit's async continuation is flaky on WebKit
           * (often requires a second click / no navigation).
           * Constraint validation already passed before we called preventDefault() on that gesture.
           */
          if (typeof HTMLFormElement !== 'undefined' && HTMLFormElement.prototype && HTMLFormElement.prototype.submit) {
            HTMLFormElement.prototype.submit.call(form);
          } else {
            form.submit();
          }
        })
        .catch(function (err) {
          form.__richSubmitPending = false;
          var details = inlineImageUploadErrorMeta(err);
          showEditorToast(details.title, details.message);
        });
    });
  };

  function dataUrlToFile(dataUrl) {
    var m = String(dataUrl || '').match(/^data:([^;,]+)?(;base64)?,(.*)$/i);
    if (!m) throw new Error('bad_data_url');
    var mime = m[1] || 'image/png';
    var isBase64 = !!m[2];
    var payload = m[3] || '';
    var bytes;
    if (isBase64) {
      var binary = atob(payload);
      bytes = new Uint8Array(binary.length);
      for (var i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    } else {
      var txt = decodeURIComponent(payload);
      bytes = new TextEncoder().encode(txt);
    }
    var ext = (mime.split('/')[1] || 'png').replace(/[^a-z0-9]/gi, '') || 'png';
    return new File([bytes], 'inline.' + ext, { type: mime });
  }

  function richMessageBlockIsEmpty(el) {
    if (!el || el.nodeType !== 1) return false;
    var tag = (el.tagName || '').toLowerCase();
    if (tag !== 'p' && tag !== 'div' && tag !== 'li' && tag !== 'blockquote') return false;
    if (el.querySelector('img, video, iframe, table, ul, ol, pre, blockquote, a[href]')) {
      return false;
    }
    var inner = (el.innerHTML || '')
      .replace(/\uFEFF/g, '')
      .replace(/<br\s*\/?>/gi, '')
      .replace(/&nbsp;/gi, '')
      .replace(/\s+/g, '');
    if (inner.length) return false;
    return !(el.textContent || '').replace(/\uFEFF/g, '').replace(/\s+/g, '').length;
  }

  /** Strip editor noise: trailing/leading empty blocks, collapse consecutive blank lines. */
  w.normalizeRichMessageHtmlForSubmit = function (html) {
    var wrap = document.createElement('div');
    wrap.innerHTML = String(html || '').replace(/\uFEFF/g, '');

    var nodes = [];
    for (var i = 0; i < wrap.childNodes.length; i += 1) {
      nodes.push(wrap.childNodes[i]);
    }

    wrap.innerHTML = '';
    var prevEmpty = false;
    nodes.forEach(function (node) {
      if (node.nodeType === 3) {
        var t = (node.textContent || '').replace(/\s+/g, ' ');
        if (!t.trim()) return;
        wrap.appendChild(document.createTextNode(t));
        prevEmpty = false;
        return;
      }
      if (node.nodeType !== 1) return;
      var empty = richMessageBlockIsEmpty(node);
      if (empty) {
        if (prevEmpty) return;
        prevEmpty = true;
      } else {
        prevEmpty = false;
      }
      wrap.appendChild(node.cloneNode(true));
    });

    while (wrap.lastElementChild && richMessageBlockIsEmpty(wrap.lastElementChild)) {
      wrap.removeChild(wrap.lastElementChild);
    }
    while (wrap.firstElementChild && richMessageBlockIsEmpty(wrap.firstElementChild)) {
      wrap.removeChild(wrap.firstElementChild);
    }

    return (wrap.innerHTML || '').trim();
  };

  function finishQuillHtmlForSubmit(quill) {
    var html = (quill && quill.root && quill.root.innerHTML) || '';
    return typeof w.normalizeRichMessageHtmlForSubmit === 'function'
      ? w.normalizeRichMessageHtmlForSubmit(html)
      : html;
  }

  w.resolveQuillHtmlForSubmit = function (quill, uploadUrl, opts) {
    opts = opts || {};
    var onProgress = typeof opts.onProgress === 'function' ? opts.onProgress : null;
    if (!quill || !quill.root) return Promise.resolve('');
    var pending = Array.prototype.slice.call(quill.root.querySelectorAll('img[src^="data:image/"]'));
    if (!pending.length) return Promise.resolve(finishQuillHtmlForSubmit(quill));
    if (onProgress) {
      onProgress({
        phase: 'uploading',
        total: pending.length,
        done: 0,
        percent: 0,
      });
    }
    var doneCount = 0;
    var chain = Promise.resolve();
    pending.forEach(function (imgEl) {
      chain = chain.then(function () {
        var src = (imgEl.getAttribute('src') || '').trim();
        if (!src || src.indexOf('data:image/') !== 0) return;
        var file =
          (quill.__inlinePendingFiles && quill.__inlinePendingFiles[src]) || dataUrlToFile(src);
        return uploadInlineImage(file, uploadUrl)
          .then(function (resp) {
            if (!resp || !resp.ok || !resp.data || !resp.data.url) {
              var code = (resp && resp.data && (resp.data.error || resp.data.message)) || 'upload_failed';
              var uploadErr = new Error(String(code));
              uploadErr.code = String(code);
              throw uploadErr;
            }
            imgEl.setAttribute('src', resp.data.url);
            if (quill.__inlinePendingFiles && quill.__inlinePendingFiles[src]) {
              delete quill.__inlinePendingFiles[src];
            }
            doneCount += 1;
            if (onProgress) {
              var pct = Math.max(0, Math.min(100, Math.round((doneCount / pending.length) * 100)));
              onProgress({
                phase: 'uploading',
                total: pending.length,
                done: doneCount,
                percent: pct,
              });
            }
          });
      });
    });
    return chain.then(function () {
      if (onProgress) {
        onProgress({
          phase: 'uploaded',
          total: pending.length,
          done: doneCount,
          percent: 100,
        });
      }
      return finishQuillHtmlForSubmit(quill);
    });
  };

  function richEditorPlainTrim(quill) {
    if (!quill || typeof quill.getText !== 'function') return '';
    return String(quill.getText() || '')
      .replace(/\uFEFF/g, '')
      .trim();
  }

  function richEditorHasInlineImage(quill) {
    if (!quill || !quill.root || !quill.root.querySelector) return false;
    return !!quill.root.querySelector('img[src]');
  }

  w.DESCRIPTION_MAX_PLAIN_CHARS = 2000;
  w.FORUM_MAX_PLAIN_CHARS = 10000;
  w.FORUM_MAX_HTML_CHARS = 32000;

  /**
   * Optional description editor: allow empty, block images, enforce plain-text length.
   * @returns {{ ok: true } | { ok: false, reason: 'empty' | 'image_only' | 'too_long', max?: number, length?: number }}
   */
  w.validateDescriptionQuill = function (quill, maxPlain) {
    maxPlain = maxPlain || w.DESCRIPTION_MAX_PLAIN_CHARS;
    if (!quill) return { ok: true };
    if (richEditorHasInlineImage(quill)) return { ok: false, reason: 'image_only' };
    var plain = richEditorPlainTrim(quill);
    if (!plain.length) return { ok: true };
    if (plain.length > maxPlain) {
      return { ok: false, reason: 'too_long', max: maxPlain, length: plain.length };
    }
    return { ok: true };
  };

  w.notifyDescriptionValidation = function (result) {
    if (!result || result.ok) return;
    var title = 'Description';
    var message;
    var icon = 'fas fa-align-left';
    if (result.reason === 'image_only') {
      title = 'Image not allowed';
      message = 'Images cannot be added to descriptions. Upload a screenshot or preview image separately.';
      icon = 'fas fa-image';
    } else if (result.reason === 'too_long') {
      message =
        'Description is too long (' +
        (result.length || '?') +
        '/' +
        (result.max || w.DESCRIPTION_MAX_PLAIN_CHARS) +
        ' characters).';
    } else {
      message = 'Invalid description.';
    }
    if (typeof w.showToast === 'function') {
      w.showToast(title, message, null, icon, null, 'error');
    } else {
      showEditorToast(title, message);
    }
  };

  function bindQuillPlainLengthLimit(quill, maxPlain, label) {
    if (!quill || quill.__plainLengthBound) return;
    quill.__plainLengthBound = true;
    var limitToastAt = 0;
    var toastLabel = label || 'Message';
    quill.on('text-change', function (_delta, _old, source) {
      if (source !== 'user') return;
      var plain = richEditorPlainTrim(quill);
      if (plain.length <= maxPlain) return;
      var over = plain.length - maxPlain;
      var len = quill.getLength();
      var deleteFrom = Math.max(0, len - 1 - over);
      quill.deleteText(deleteFrom, over, 'user');
      var now = Date.now();
      if (now - limitToastAt > 2500) {
        limitToastAt = now;
        showEditorToast(
          'Limit reached',
          toastLabel + ' cannot exceed ' + maxPlain + ' characters.'
        );
      }
    });
  }

  function bindDescriptionLengthLimit(quill, maxPlain) {
    bindQuillPlainLengthLimit(quill, maxPlain, 'Description');
  }

  function findDescriptionQuillByEditorId(editorId) {
    var host = document.getElementById(editorId);
    if (!host) return null;
    var editorRoot = host.querySelector('.ql-editor');
    if (!editorRoot || typeof Quill === 'undefined' || typeof Quill.find !== 'function') return null;
    return Quill.find(editorRoot);
  }

  w.readDescriptionQuillHtml = function (editorId) {
    return new Promise(function (resolve, reject) {
      var quill = findDescriptionQuillByEditorId(editorId);
      if (!quill) return resolve('');
      var check = w.validateDescriptionQuill(quill);
      if (!check.ok) {
        w.notifyDescriptionValidation(check);
        reject(new Error(check.reason || 'invalid'));
        return;
      }
      if (typeof w.resolveQuillHtmlForSubmit !== 'function') {
        var plain = richEditorPlainTrim(quill);
        resolve(plain.length ? quill.root.innerHTML || '' : '');
        return;
      }
      w.resolveQuillHtmlForSubmit(quill)
        .then(function (html) {
          var plain = richEditorPlainTrim(quill);
          resolve(plain.length ? html : '');
        })
        .catch(reject);
    });
  };

  function createDescriptionQuillEditor(el) {
    if (!el || el.classList.contains('ql-container')) return null;
    var id = el.id;
    if (!id) return null;
    var hiddenId = el.getAttribute('data-hidden-field') || 'description-field';
    var placeholder = el.getAttribute('data-placeholder') || 'Description (optional)…';
    var initial = readDescriptionEditorInitial(id);
    var blockedMsg =
      'Images cannot be added to descriptions. Upload a screenshot or preview image separately.';
    var q = w.initQuillRichEditor({
      containerId: id,
      initialHtml: initial || undefined,
      placeholder: placeholder,
      plainTextPaste: true,
      toolbar: descriptionToolbar(),
      disableImageUpload: true,
      disableImageUploadMessage: blockedMsg,
      hiddenInputId: hiddenId,
    });
    if (q) bindDescriptionLengthLimit(q, w.DESCRIPTION_MAX_PLAIN_CHARS);
    return q;
  }

  w.initDescriptionEditorsInRoot = function (root, selector) {
    root = root || document;
    var sel = selector || '[data-description-editor], [data-upload-description-editor]';
    var nodes = root.querySelectorAll(sel);
    nodes.forEach(function (el) {
      createDescriptionQuillEditor(el);
    });
  };

  /**
   * Require visible text (Quill plain), not image-only or empty.
   * @returns {{ ok: true } | { ok: false, reason: 'empty' | 'image_only' | 'too_long', max?: number, length?: number }}
   */
  w.validateRichMessageQuill = function (quill) {
    if (!quill) return { ok: false, reason: 'empty' };
    var plain = richEditorPlainTrim(quill);
    if (plain.length > w.FORUM_MAX_PLAIN_CHARS) {
      return {
        ok: false,
        reason: 'too_long',
        max: w.FORUM_MAX_PLAIN_CHARS,
        length: plain.length,
      };
    }
    if (plain.length > 0) return { ok: true };
    if (richEditorHasInlineImage(quill)) return { ok: false, reason: 'image_only' };
    return { ok: false, reason: 'empty' };
  };

  /** Same styling path as realtime toasts (system tone + icon). */
  w.notifyRichMessageValidation = function (result) {
    if (!result || result.ok) return;
    var title;
    var message;
    var icon = 'fas fa-comment-slash';
    if (result.reason === 'image_only') {
      title = 'Image only';
      message = 'Add some text — messages cannot contain only an image without words.';
      icon = 'fas fa-image';
    } else if (result.reason === 'too_long') {
      title = 'Message too long';
      message =
        'Please shorten your message (' +
        (result.length || '?') +
        '/' +
        (result.max || w.FORUM_MAX_PLAIN_CHARS) +
        ' characters).';
      icon = 'fas fa-compress-alt';
    } else {
      title = 'Empty message';
      message = 'Write something before sending.';
    }
    if (typeof w.showToast === 'function') {
      w.showToast(title, message, null, icon, null, 'error');
    } else {
      showEditorToast(title, message);
    }
  };

  w.insertAtRichCursor = function (quill, text) {
    if (!quill || text == null) return;
    var range = quill.getSelection(true);
    var idx = range ? range.index : Math.max(0, quill.getLength() - 1);
    quill.insertText(idx, text, 'user');
    quill.setSelection(idx + text.length, 0);
    quill.focus();
  };

  w.clearQuillEditor = function (quill) {
    if (!quill) return;

    var editor = quill.root;
    var dockEl =
      quill.container &&
      quill.container.closest &&
      quill.container.closest('.discussion-composer-input-dock');
    var frame =
      quill.container &&
      quill.container.closest &&
      quill.container.closest('.discussion-composer-frame');

    if (frame) {
      frame.classList.remove('discussion-composer-frame--toolbar-open');
      frame.classList.add('discussion-composer-frame--toolbar-collapsed');
      var fmtToggle = frame.querySelector('.discussion-composer-format-toggle');
      if (fmtToggle) fmtToggle.setAttribute('aria-expanded', 'false');
    }

    quill.setContents([{ insert: '\n' }], 'silent');

    if (editor) {
      editor.style.height = '';
      editor.style.minHeight = '';
      editor.style.maxHeight = '';
      editor.style.overflowY = '';
      editor.scrollTop = 0;
    }

    if (dockEl) {
      dockEl.classList.remove('discussion-composer-input-dock--multiline');
      dockEl.classList.add('discussion-composer-input-dock--single-line');
    }

    quill.focus();
    setTimeout(function () {
      placeQuillCaretAtFirstContentPosition(quill);
      if (typeof quill.__discussionComposerSync === 'function') {
        quill.__discussionComposerSync();
        if (typeof requestAnimationFrame === 'function') {
          requestAnimationFrame(quill.__discussionComposerSync);
        }
      }
    }, 0);
  };

  /** Mobile breakpoint: in-flow sticky wrap + viewport pin when scrolled past. */
  function useMobileDiscussionComposerSticky() {
    return window.matchMedia('(max-width: 768px)').matches;
  }

  function getDiscussionComposerPinBounds(wrap) {
    if (wrap) {
      var row = wrap.querySelector('.discussion-composer-row');
      var measureEl = row || wrap;
      var rect = measureEl.getBoundingClientRect();
      if (rect.width > 0) {
        return { left: rect.left, width: rect.width };
      }
    }
    var anchor =
      (wrap && wrap.closest && wrap.closest('.file-discussion-shell')) ||
      (wrap && wrap.closest && wrap.closest('.forum-topic-body-card')) ||
      (wrap && wrap.closest && wrap.closest('.cyber-card.detail-main-card')) ||
      (wrap && wrap.closest && wrap.closest('main.container')) ||
      document.querySelector('main.container');
    if (!anchor) {
      return { left: 0, width: window.innerWidth };
    }
    var anchorRect = anchor.getBoundingClientRect();
    return { left: anchorRect.left, width: anchorRect.width };
  }

  /** Pin only when the composer slot is fully off-screen (not when partially visible at the bottom). */
  function composerShouldViewportPin(wrap, vh) {
    if (!wrap) return false;
    if (wrap.closest && wrap.closest('.forum-topic-page')) return false;
    var rect = wrap.getBoundingClientRect();
    return rect.bottom <= 0 || rect.top >= vh;
  }

  function getMobileVisibleViewportBottom() {
    var vv = window.visualViewport;
    if (vv) return vv.offsetTop + vv.height;
    return window.innerHeight;
  }

  function getDiscussionComposerKeyboardInset() {
    var vv = window.visualViewport;
    if (!vv) return 0;
    var gap = Math.max(0, window.innerHeight - vv.offsetTop - vv.height);
    /* Ignore browser-chrome jitter; keyboard inset is typically well above ~80px. */
    if (!Number.isFinite(gap) || gap < 80 || gap > 320) return 0;
    return gap;
  }

  function syncDiscussionComposerBarKeyboardDock(bar) {
    if (!bar || !useMobileDiscussionComposerSticky()) {
      if (bar) bar.style.removeProperty('bottom');
      return;
    }
    var focused =
      document.activeElement && bar.contains(document.activeElement);
    var gap = focused ? getDiscussionComposerKeyboardInset() : 0;
    /* Lift fixed composer only while the editor is focused (keyboard open). */
    if (focused && gap > 0 && bar.classList.contains('is-viewport-pinned')) {
      bar.style.bottom = gap + 'px';
    } else {
      bar.style.removeProperty('bottom');
    }
  }

  var ulpComposerKeyboardDockRaf = null;
  function scheduleDiscussionComposerKeyboardDock(bar) {
    if (ulpComposerKeyboardDockRaf) return;
    ulpComposerKeyboardDockRaf = requestAnimationFrame(function () {
      ulpComposerKeyboardDockRaf = null;
      if (bar) {
        syncDiscussionComposerBarKeyboardDock(bar);
        return;
      }
      document.querySelectorAll('.discussion-composer-bar').forEach(function (b) {
        var focused =
          document.activeElement && b.contains(document.activeElement);
        if (focused) syncDiscussionComposerBarKeyboardDock(b);
        else b.style.removeProperty('bottom');
      });
    });
  }

  w.__ulpScheduleDiscussionComposerKeyboardDock = scheduleDiscussionComposerKeyboardDock;

  function scrollMobileDiscussionComposerIntoView(wrap, bar, dock) {
    if (!useMobileDiscussionComposerSticky()) return;
    var target = dock || bar || wrap;
    if (!target) return;

    function align() {
      var visibleBottom = getMobileVisibleViewportBottom();
      var rect = target.getBoundingClientRect();
      var margin = 12;
      if (rect.bottom > visibleBottom - margin) {
        if (typeof target.scrollIntoView === 'function') {
          try {
            target.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
          } catch (e) {
            try {
              target.scrollIntoView(false);
            } catch (e2) { /* ignore */ }
          }
        }
        var rectAfter = target.getBoundingClientRect();
        var overflow = rectAfter.bottom - visibleBottom + margin;
        if (overflow > 0 && typeof window.scrollBy === 'function') {
          window.scrollBy({ top: overflow, left: 0, behavior: 'smooth' });
        }
      }
      if (bar) syncDiscussionComposerBarKeyboardDock(bar);
    }

    requestAnimationFrame(function () {
      requestAnimationFrame(align);
    });
    setTimeout(align, 100);
    setTimeout(align, 280);
  }

  w.__ulpScrollDiscussionComposerForKeyboard = function (wrapEl) {
    wrapEl =
      wrapEl ||
      (document.activeElement &&
        document.activeElement.closest &&
        document.activeElement.closest('.discussion-composer-wrap')) ||
      document.querySelector('.discussion-composer-wrap');
    if (!wrapEl) return;
    var bar = wrapEl.querySelector('.discussion-composer-bar');
    var dock = wrapEl.querySelector('.discussion-composer-input-dock');
    scrollMobileDiscussionComposerIntoView(wrapEl, bar, dock);
    scheduleDiscussionComposerKeyboardDock(bar);
  };

  /** Mobile: stable FAB stack height (no scroll toggles). */
  function syncMobileDiscussionComposerStack() {
    var root = document.documentElement;
    if (!root || !useMobileDiscussionComposerSticky()) {
      if (root) root.style.removeProperty('--ulp-discussion-composer-stack');
      return;
    }
    if (!document.querySelector('.discussion-composer-wrap')) {
      root.style.removeProperty('--ulp-discussion-composer-stack');
      return;
    }
    var maxH = 0;
    document.querySelectorAll('.discussion-composer-wrap .discussion-composer-bar').forEach(function (bar) {
      var h = Math.ceil(bar.getBoundingClientRect().height);
      if (h > maxH) maxH = h;
    });
    root.style.setProperty(
      '--ulp-discussion-composer-stack',
      Math.max(maxH, 48) + 'px'
    );
  }

  /** Desktop: lift chat FAB above pinned composer. Mobile uses sticky + row gutter only. */
  function syncGlobalDiscussionComposerPinState() {
    var root = document.documentElement;
    if (!root) return;
    if (useMobileDiscussionComposerSticky()) {
      root.classList.remove('ulp-discussion-composer-pinned');
      root.style.removeProperty('--ulp-pinned-composer-height');
      syncMobileDiscussionComposerStack();
      return;
    }
    root.style.removeProperty('--ulp-discussion-composer-stack');
    var pinnedBars = document.querySelectorAll('.discussion-composer-bar.is-viewport-pinned');
    var pinned = pinnedBars.length > 0;
    root.classList.toggle('ulp-discussion-composer-pinned', pinned);
    if (!pinned) {
      root.style.removeProperty('--ulp-pinned-composer-height');
      return;
    }
    var maxH = 0;
    pinnedBars.forEach(function (bar) {
      var h = Math.ceil(bar.getBoundingClientRect().height);
      if (h > maxH) maxH = h;
    });
    root.style.setProperty('--ulp-pinned-composer-height', Math.max(maxH, 48) + 'px');
  }

  w.__ulpSyncDiscussionComposerPinState = syncGlobalDiscussionComposerPinState;

  if (!w.__ulpComposerMobileLayoutMqBound) {
    w.__ulpComposerMobileLayoutMqBound = true;
    var composerLayoutMq = window.matchMedia('(max-width: 768px)');
    var onComposerLayoutMqChange = function () {
      window.dispatchEvent(new Event('resize'));
      if (typeof w.__ulpSyncDiscussionComposerPinState === 'function') {
        w.__ulpSyncDiscussionComposerPinState();
      }
      if (typeof w.__ulpScheduleDiscussionComposerKeyboardDock === 'function') {
        w.__ulpScheduleDiscussionComposerKeyboardDock();
      }
    };
    if (typeof composerLayoutMq.addEventListener === 'function') {
      composerLayoutMq.addEventListener('change', onComposerLayoutMqChange);
    } else if (typeof composerLayoutMq.addListener === 'function') {
      composerLayoutMq.addListener(onComposerLayoutMqChange);
    }
  }

  if (!w.__ulpComposerVvBound) {
    w.__ulpComposerVvBound = true;
    var onComposerVvChange = function () {
      if (typeof w.__ulpScheduleDiscussionComposerKeyboardDock === 'function') {
        w.__ulpScheduleDiscussionComposerKeyboardDock();
      }
    };
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', onComposerVvChange, { passive: true });
      window.visualViewport.addEventListener('scroll', onComposerVvChange, { passive: true });
    }
    window.addEventListener('resize', onComposerVvChange);
  }

  function restoreDiscussionComposerSendInDock(cluster, row) {
    if (!cluster || !row) return;
    var sendSlot = row.querySelector('.discussion-composer-send-outside');
    var sendBtn =
      (sendSlot &&
        sendSlot.querySelector(
          '.rich-editor-send-btn, .forum-reply-send-integrated, .btn-send'
        )) ||
      cluster.querySelector(
        '.rich-editor-send-btn, .forum-reply-send-integrated, .btn-send, .discussion-composer-send-btn'
      );
    if (!sendBtn) return;
    sendBtn.classList.add('discussion-composer-send-btn');
    if (sendBtn.parentElement !== cluster) {
      cluster.appendChild(sendBtn);
    }
    if (sendSlot) sendSlot.remove();
  }

  /** Docked input, toolbar on demand, send inside dock, viewport pin for the bar. */
  function setupDiscussionComposerLayout(quill) {
    try {
    if (!quill || !quill.container) return;
    var frame =
      quill.container.closest && quill.container.closest('.discussion-composer-frame');
    if (!frame) return;

    var composer =
      frame.closest && frame.closest('.rich-editor-composer, .forum-reply-composer');
    var wrap =
      frame.closest && frame.closest('.discussion-composer-wrap');
    if (!composer || !wrap) return;

    var cluster = frame.querySelector('.discussion-composer-action-cluster');
    if (!cluster) return;
    if (cluster.closest('.discussion-composer-input-dock')) {
      cluster.classList.add('discussion-composer-action-cluster--in-dock');
    }

    var row = composer.querySelector('.discussion-composer-row');
    if (row) restoreDiscussionComposerSendInDock(cluster, row);

    if (frame.dataset.composerLayoutBound === '1') return;

    frame.dataset.composerLayoutBound = '1';
    frame.classList.add(
      'discussion-composer-frame--docked-input',
      'discussion-composer-frame--toolbar-collapsed'
    );

    var toolbar = frame.querySelector('.ql-toolbar.ql-snow');
    if (toolbar) toolbar.classList.add('discussion-composer-toolbar');

    if (!row) {
      row = document.createElement('div');
      row.className = 'discussion-composer-row';
      composer.insertBefore(row, frame);
      row.appendChild(frame);
    }

    var bar = composer.querySelector('.discussion-composer-bar');
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'discussion-composer-bar';
      row.insertBefore(bar, frame);
      bar.appendChild(frame);
    }

    restoreDiscussionComposerSendInDock(cluster, row);

    var dock = frame.querySelector('.discussion-composer-input-dock');
    if (!dock) {
      dock = document.createElement('div');
      dock.className = 'discussion-composer-input-dock';
      var container = quill.container;
      var parent = container.parentNode;
      if (!parent) return;
      parent.insertBefore(dock, container);
      dock.appendChild(container);
      dock.appendChild(cluster);
      cluster.classList.add('discussion-composer-action-cluster--in-dock');
    }

    if (!dock.querySelector('.discussion-composer-format-toggle')) {
      var toggle = document.createElement('button');
      toggle.type = 'button';
      toggle.className = 'discussion-composer-format-toggle';
      toggle.setAttribute('aria-label', 'Formatting');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('title', 'Formatting');
      toggle.innerHTML = '<i class="fas fa-font" aria-hidden="true"></i>';
      toggle.addEventListener('click', function (e) {
        e.preventDefault();
        var open = frame.classList.toggle('discussion-composer-frame--toolbar-open');
        frame.classList.toggle('discussion-composer-frame--toolbar-collapsed', !open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open && toolbar) {
          var firstBtn = toolbar.querySelector('button');
          if (firstBtn) firstBtn.focus();
        }
        if (typeof quill.__discussionComposerSync === 'function') {
          if (typeof requestAnimationFrame === 'function') {
            requestAnimationFrame(quill.__discussionComposerSync);
          } else {
            quill.__discussionComposerSync();
          }
        }
      });
      dock.insertBefore(toggle, dock.firstChild);
    }

    if (!quill.__discussionMobileKeyboardBound) {
      quill.__discussionMobileKeyboardBound = true;
      quill.root.addEventListener(
        'focus',
        function () {
          scrollMobileDiscussionComposerIntoView(wrap, bar, dock);
          scheduleDiscussionComposerKeyboardDock(bar);
        },
        true
      );
      quill.root.addEventListener(
        'blur',
        function () {
          setTimeout(function () {
            if (bar.contains(document.activeElement)) return;
            if (bar.classList.contains('is-viewport-pinned')) {
              syncDiscussionComposerBarKeyboardDock(bar);
            } else {
              bar.style.removeProperty('bottom');
            }
          }, 120);
        },
        true
      );
    }

    if (wrap.dataset.viewportPinBound === '1') return;
    wrap.dataset.viewportPinBound = '1';

    var spacer = wrap.querySelector('.discussion-composer-pin-spacer');
    if (!spacer) {
      spacer = document.createElement('div');
      spacer.className = 'discussion-composer-pin-spacer';
      spacer.setAttribute('aria-hidden', 'true');
      /* row lives under .rich-editor-composer, not a direct child of .discussion-composer-wrap */
      var spacerAnchor = row.parentNode === wrap ? row : wrap.firstChild;
      wrap.insertBefore(spacer, spacerAnchor);
    }

    function measureBarHeight() {
      var wasPinned = bar.classList.contains('is-viewport-pinned');
      if (wasPinned) bar.classList.remove('is-viewport-pinned');
      spacer.style.height = '0';
      var h = Math.ceil(bar.getBoundingClientRect().height);
      if (wasPinned) bar.classList.add('is-viewport-pinned');
      return Math.max(h, 48);
    }

    var pinTicking = false;
    function syncPin() {
      pinTicking = false;

      var mobileSticky = useMobileDiscussionComposerSticky();
      wrap.classList.toggle('discussion-composer-wrap--mobile-sticky', mobileSticky);
      bar.classList.toggle('discussion-composer-bar--mobile-sticky', mobileSticky);

      var bounds = getDiscussionComposerPinBounds(wrap);
      bar.style.setProperty('--composer-pin-left', bounds.left + 'px');
      bar.style.setProperty('--composer-pin-width', bounds.width + 'px');

      /* Mobile: sticky in-flow + fixed pin only when slot is fully off-screen. */
      if (mobileSticky) {
        var vh = window.innerHeight;
        var pin = composerShouldViewportPin(wrap, vh);
        var barHeight = measureBarHeight();
        bar.classList.toggle('is-viewport-pinned', pin);
        bar.classList.toggle('discussion-composer-bar--mobile-pinned', pin);
        spacer.style.height = pin ? barHeight + 'px' : '0';
        if (!pin) bar.style.removeProperty('bottom');
        return;
      }

      var vh = window.innerHeight;
      var pin = composerShouldViewportPin(wrap, vh);
      var barHeight = measureBarHeight();

      if (pin) {
        bar.classList.add('is-viewport-pinned');
        spacer.style.height = barHeight + 'px';
      } else {
        bar.classList.remove('is-viewport-pinned');
        spacer.style.height = '0';
      }
    }

    function syncPinAndGlobal() {
      syncPin();
      syncGlobalDiscussionComposerPinState();
      syncMobileDiscussionComposerStack();
      scheduleDiscussionComposerKeyboardDock(bar);
    }

    function schedulePin() {
      if (pinTicking) return;
      pinTicking = true;
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(syncPinAndGlobal);
      } else {
        syncPinAndGlobal();
      }
    }

    syncPinAndGlobal();
    window.addEventListener('scroll', schedulePin, { passive: true });
    window.addEventListener('resize', schedulePin, { passive: true });
    if (typeof ResizeObserver !== 'function') return;
    var ro = new ResizeObserver(schedulePin);
    ro.observe(wrap);
    ro.observe(bar);
    ro.observe(frame);
    } catch (layoutErr) {
      console.warn('Discussion composer layout failed (non-fatal):', layoutErr);
      try {
        if (frame && frame.dataset) {
          delete frame.dataset.composerLayoutBound;
        }
        if (wrap && wrap.dataset) {
          delete wrap.dataset.viewportPinBound;
        }
      } catch (e) { /* ignore */ }
    }
  }

  w.setupDiscussionComposerLayout = setupDiscussionComposerLayout;
  w.bindDiscussionComposerInputDock = setupDiscussionComposerLayout;
  w.bindDiscussionComposerViewportPin = setupDiscussionComposerLayout;

  /** Discussion reply composers: one line by default, grow with content (Enter adds lines). */
  function bindDiscussionComposerAutoGrow(quill) {
    if (!quill || !quill.root || !quill.container) return;
    var dockEl =
      quill.container.closest &&
      quill.container.closest('.discussion-composer-input-dock');
    if (!dockEl) return;
    if (quill.__discussionAutoGrowBound) return;
    quill.__discussionAutoGrowBound = true;

    var editorMin = 38;
    try {
      var raw = getComputedStyle(dockEl)
        .getPropertyValue('--discussion-composer-action-size')
        .trim();
      var n = parseFloat(raw);
      if (Number.isFinite(n)) {
        if (/rem$/i.test(raw)) {
          var rootFs = parseFloat(getComputedStyle(document.documentElement).fontSize);
          editorMin = Math.round(n * (Number.isFinite(rootFs) ? rootFs : 16));
        } else {
          editorMin = Math.round(n);
        }
      }
    } catch (e) {
      editorMin = 38;
    }

    function isMultiline() {
      try {
        return quill.getLines().length > 1;
      } catch (e) {
        return false;
      }
    }

    function readEditorMaxPx() {
      var editor = quill.root;
      void editor.offsetHeight;
      var px = parseFloat(getComputedStyle(editor).maxHeight);
      if (Number.isFinite(px) && px > 0) {
        return Math.round(px);
      }
      var vh =
        window.innerHeight ||
        (document.documentElement && document.documentElement.clientHeight) ||
        640;
      return Math.round(Math.min(vh * 0.36, 280));
    }

    function clearInlineEditorBox() {
      var editor = quill.root;
      editor.style.height = '';
      editor.style.minHeight = '';
      editor.style.maxHeight = '';
      editor.style.overflowY = '';
    }

    /** Keep caret visible when the editor scrolls; only scroll down (never jump to top). */
    function scrollComposerCaretIntoView() {
      var editor = quill.root;
      if (!editor || !isMultiline()) return;
      if (editor.scrollHeight <= editor.clientHeight + 1) {
        editor.scrollTop = 0;
        return;
      }

      var pad = 10;
      try {
        var nativeSel = w.getSelection && w.getSelection();
        if (!nativeSel || !nativeSel.rangeCount) return;
        var range = nativeSel.getRangeAt(0);
        if (!editor.contains(range.startContainer)) return;

        var caretRect = range.getBoundingClientRect();
        if (!caretRect.height && caretRect.top === 0 && caretRect.left === 0) return;

        var editorRect = editor.getBoundingClientRect();
        var lineH = parseFloat(getComputedStyle(editor).lineHeight) || 20;
        var relTop = caretRect.top - editorRect.top + editor.scrollTop;
        var relBottom =
          relTop + Math.max(caretRect.height, caretRect.width ? 1 : lineH);
        var viewBottom = editor.scrollTop + editor.clientHeight;

        if (relBottom > viewBottom - pad) {
          editor.scrollTop = Math.max(0, relBottom - editor.clientHeight + pad);
        }
      } catch (e) { /* ignore */ }
    }

    var caretScrollQueued = false;
    function queueCaretScroll() {
      if (caretScrollQueued) return;
      caretScrollQueued = true;
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(function () {
          caretScrollQueued = false;
          scrollComposerCaretIntoView();
        });
      } else {
        caretScrollQueued = false;
        scrollComposerCaretIntoView();
      }
    }

    function syncComposerLayout() {
      var editor = quill.root;
      var multiline = isMultiline();
      var wasMultiline = dockEl.classList.contains(
        'discussion-composer-input-dock--multiline'
      );

      dockEl.classList.toggle('discussion-composer-input-dock--multiline', multiline);
      dockEl.classList.toggle('discussion-composer-input-dock--single-line', !multiline);

      if (!multiline) {
        clearInlineEditorBox();
        editor.scrollTop = 0;
        return;
      }

      if (!wasMultiline) {
        clearInlineEditorBox();
      }

      var prevScroll = editor.scrollTop;
      editor.style.height = 'auto';
      void editor.offsetHeight;
      var maxPx = readEditorMaxPx();
      var contentH = editor.scrollHeight;
      var target = Math.min(maxPx, Math.max(editorMin, contentH));
      editor.style.height = target + 'px';
      var needsScroll = editor.scrollHeight > editor.clientHeight + 1;
      editor.style.overflowY = needsScroll ? 'auto' : 'hidden';
      if (!needsScroll) {
        editor.scrollTop = 0;
      } else {
        editor.scrollTop = Math.min(
          prevScroll,
          Math.max(0, editor.scrollHeight - editor.clientHeight)
        );
        queueCaretScroll();
      }
    }

    quill.__discussionComposerSync = syncComposerLayout;

    quill.on('text-change', function (_delta, _old, source) {
      if (source === 'api') return;
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(syncComposerLayout);
      } else {
        syncComposerLayout();
      }
    });

    window.addEventListener('resize', function () {
      if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(syncComposerLayout);
      } else {
        syncComposerLayout();
      }
    });

    dockEl.classList.add('discussion-composer-input-dock--single-line');
    syncComposerLayout();
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(syncComposerLayout);
    }
  }

  w.bindDiscussionComposerAutoGrow = bindDiscussionComposerAutoGrow;

  /** Cmd+Enter (macOS) / Ctrl+Enter (Windows & Linux) — same as typical chat composer */
  function bindModEnterSubmit(quill, submitFn) {
    if (!quill || typeof submitFn !== 'function') return;
    if (quill.__modEnterBound) return;
    quill.__modEnterBound = true;

    // Primary path: Quill shortcut API (shortKey = Cmd on macOS, Ctrl elsewhere)
    if (quill.keyboard && typeof quill.keyboard.addBinding === 'function') {
      quill.keyboard.addBinding({ key: 13, shortKey: true }, function () {
        submitFn();
        return false;
      });
    }

    // Fallback: raw keydown listener for environments where binding is swallowed
    if (quill.root && quill.root.addEventListener) {
      quill.root.addEventListener('keydown', function (e) {
        var isEnter = e && (e.key === 'Enter' || e.keyCode === 13);
        var hasMod = !!(e && (e.metaKey || e.ctrlKey));
        if (!isEnter || !hasMod) return;
        e.preventDefault();
        e.stopPropagation();
        submitFn();
      });
    }
  }

  /**
   * Before SPA replaces <main>: remove Quill Snow tooltips/pickers that may be reparented to <body>.
   * Otherwise a transparent layer can sit above the header (e.g. after file page → login while Turnstile runs).
   */
  w.ulpTeardownRichEditorsBeforeSpaSwap = function () {
    ['__fileCommentQuill', '__forumReplyQuill', '__resourceCommentQuill', '__topicBodyQuill'].forEach(function (name) {
      var q = w[name];
      if (!q) {
        w[name] = null;
        return;
      }
      try {
        var tip = q.theme && q.theme.tooltip;
        if (tip && tip.root && tip.root.parentNode) {
          tip.root.parentNode.removeChild(tip.root);
        }
      } catch (e) { /* ignore */ }
      try {
        if (typeof q.disable === 'function') q.disable();
      } catch (e) { /* ignore */ }
      w[name] = null;
    });
    try {
      document.querySelectorAll('.ql-tooltip, .ql-picker-options, .ql-clipboard').forEach(function (el) {
        el.remove();
      });
    } catch (e) { /* ignore */ }
    try {
      document.querySelectorAll('body > [class*="ql-"]').forEach(function (el) {
        if (el.closest && (el.closest('[data-ulp-floating-chat]') || el.closest('#chat-widget-container'))) return;
        el.remove();
      });
    } catch (e) { /* ignore */ }
  };

  /**
   * Re-run after SPA swaps <main> (DOMContentLoaded does not fire again).
   * Quill must be loaded globally (base.html) so this is synchronous.
   */
  w.bootRichEditors = function () {
    var isAuthenticated =
      !!document.body && document.body.getAttribute('data-is-authenticated') === 'true';

    if (typeof Quill === 'undefined') return;
    var meta = document.querySelector('meta[name="csrf-token"]');
    w.__CSRF_TOKEN__ = meta ? meta.getAttribute('content') || '' : '';

    var topicEl = document.getElementById('topic-body-editor');
    if (topicEl && !topicEl.classList.contains('ql-container')) {
      var initial =
        typeof w.__RICH_TOPIC_BODY_INITIAL__ !== 'undefined' ? w.__RICH_TOPIC_BODY_INITIAL__ : '';
      delete w.__RICH_TOPIC_BODY_INITIAL__;
      var tq = w.initQuillRichEditor({
        containerId: 'topic-body-editor',
        initialHtml: initial || undefined,
        placeholder: 'Your opening post…',
        plainTextPaste: true,
      });
      if (tq) {
        bindQuillPlainLengthLimit(tq, w.FORUM_MAX_PLAIN_CHARS, 'Message');
        w.__topicBodyQuill = tq;
        w.initQuillSyncOnSubmit('form.cyber-card', tq, 'topic-body-field');
        bindModEnterSubmit(tq, function () {
          var form = document.querySelector('form.cyber-card');
          if (!form) return;
          if (typeof form.requestSubmit === 'function') form.requestSubmit();
          else form.submit();
        });
      }
    }

    var forumEl = document.getElementById('forum-reply-editor');
    if (forumEl && !forumEl.classList.contains('ql-container')) {
      w.__forumReplyQuill = w.initQuillRichEditor({
        containerId: 'forum-reply-editor',
        placeholder: 'Type your message...',
        // Paste as plain text: copying a “link” from a page usually puts HTML (nav labels, layout) in the clipboard —
        // rich paste looked broken (huge underlines, foreign styles). Seeded edits use dangerouslyPasteHTML(), not clipboard.
        plainTextPaste: true,
        disableImageUpload: !isAuthenticated,
        disableImageUploadMessage:
          'Please login or register to upload images in replies.',
      });
      if (w.__forumReplyQuill) {
        bindQuillPlainLengthLimit(w.__forumReplyQuill, w.FORUM_MAX_PLAIN_CHARS, 'Message');
        setupDiscussionComposerLayout(w.__forumReplyQuill);
        bindDiscussionComposerAutoGrow(w.__forumReplyQuill);
      }
      bindModEnterSubmit(w.__forumReplyQuill, function () {
        if (typeof w.sendForumReply === 'function') w.sendForumReply();
      });
    }

    var fileEl = document.getElementById('file-comment-editor');
    if (fileEl && !fileEl.classList.contains('ql-container')) {
      var fileOpts = {
        containerId: 'file-comment-editor',
        placeholder: 'Type your message...',
        plainTextPaste: true,
        disableImageUpload: !isAuthenticated,
        disableImageUploadMessage:
          'Please login or register to add images to comments.',
      };
      if (isAuthenticated) {
        fileOpts.hiddenInputId = 'comment-input';
      }
      w.__fileCommentQuill = w.initQuillRichEditor(fileOpts);
      if (w.__fileCommentQuill) {
        bindQuillPlainLengthLimit(w.__fileCommentQuill, w.FORUM_MAX_PLAIN_CHARS, 'Message');
        setupDiscussionComposerLayout(w.__fileCommentQuill);
        bindDiscussionComposerAutoGrow(w.__fileCommentQuill);
      }
      bindModEnterSubmit(w.__fileCommentQuill, function () {
        if (typeof w.sendComment === 'function') w.sendComment();
      });
    }

    var resEl = document.getElementById('resource-comment-editor');
    if (resEl && !resEl.classList.contains('ql-container')) {
      var resOpts = {
        containerId: 'resource-comment-editor',
        placeholder: 'Type your message...',
        plainTextPaste: true,
        disableImageUpload: !isAuthenticated,
        disableImageUploadMessage:
          'Please login or register to add images to comments.',
      };
      if (isAuthenticated) {
        resOpts.hiddenInputId = 'comment-input';
      }
      w.__resourceCommentQuill = w.initQuillRichEditor(resOpts);
      if (w.__resourceCommentQuill) {
        bindQuillPlainLengthLimit(w.__resourceCommentQuill, w.FORUM_MAX_PLAIN_CHARS, 'Message');
        setupDiscussionComposerLayout(w.__resourceCommentQuill);
        bindDiscussionComposerAutoGrow(w.__resourceCommentQuill);
      }
      bindModEnterSubmit(w.__resourceCommentQuill, function () {
        if (typeof w.sendComment === 'function') w.sendComment();
      });
    }

    [w.__forumReplyQuill, w.__fileCommentQuill, w.__resourceCommentQuill].forEach(function (q) {
      if (q) setupDiscussionComposerLayout(q);
    });

    bootDescriptionEditors();
  };

  function readDescriptionEditorInitial(editorId) {
    var script = document.getElementById(editorId + '-initial');
    if (!script) return '';
    try {
      return JSON.parse(script.textContent || '""');
    } catch (e) {
      return '';
    }
  }

  function bootDescriptionEditors() {
    var nodes = document.querySelectorAll('[data-description-editor]');
    if (!nodes.length) return;

    nodes.forEach(function (el) {
      var q = createDescriptionQuillEditor(el);
      if (!q) return;
      var hiddenId = el.getAttribute('data-hidden-field') || 'description-field';
      var formSel = el.getAttribute('data-form') || '.edit-content-form';
      var formEl = document.querySelector(formSel);
      var skipQuillFormSubmit =
        formEl &&
        formEl.closest('.upload-page-shell') &&
        formEl.querySelector('input[name="file"]');
      if (!skipQuillFormSubmit) {
        w.initQuillSyncOnSubmit(formSel, q, hiddenId, { allowEmpty: true, isDescription: true });
      }
    });
  }

  function scheduleRichEditorBoot() {
    if (typeof w.bootRichEditors === 'function') w.bootRichEditors();
    if (typeof w.bootThreadWindows === 'function') w.bootThreadWindows();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleRichEditorBoot);
  } else {
    scheduleRichEditorBoot();
  }
  document.addEventListener('pageLoaded', scheduleRichEditorBoot);

  // No public debug API in production flow.

  function setupThreadWindow(list, itemSelector, opts) {
    function scrollToLatest() {
      if (!list) return;
      var top = list.scrollHeight;
      if (typeof list.scrollTo === 'function') {
        try {
          list.scrollTo({ top: top, left: 0, behavior: 'instant' });
          return;
        } catch (e) {
          try {
            list.scrollTo({ top: top, left: 0, behavior: 'auto' });
            return;
          } catch (e2) { /* fall through */ }
        }
      }
      list.scrollTop = top;
    }

    if (!list || list.dataset.threadBooted === '1') return;
    opts = opts || {};
    var initialVisible = opts.initialVisible || 16;
    var chunkSize = opts.chunkSize || 14;
    var topThreshold = opts.topThreshold || 40;

    list.classList.add('thread-window--booting');

    function items() {
      return Array.prototype.slice.call(list.querySelectorAll(itemSelector));
    }

    function hiddenItems() {
      return items().filter(function (el) {
        return el.classList.contains('thread-item-hidden');
      });
    }

    function collapseInitial() {
      var all = items();
      var keepFrom = Math.max(0, all.length - initialVisible);
      all.forEach(function (el, idx) {
        if (idx < keepFrom) el.classList.add('thread-item-hidden');
        else el.classList.remove('thread-item-hidden');
      });
    }

    function revealOlderBatch() {
      var hidden = hiddenItems();
      if (!hidden.length) return;
      var before = list.scrollHeight;
      var take = hidden.slice(Math.max(0, hidden.length - chunkSize));
      take.forEach(function (el) {
        el.classList.remove('thread-item-hidden');
      });
      var after = list.scrollHeight;
      list.scrollTop += after - before;
    }

    list.querySelectorAll('.thread-window-hint').forEach(function (hint) {
      hint.remove();
    });

    list.addEventListener('scroll', function () {
      if (list.scrollTop <= topThreshold) revealOlderBatch();
    });

    /* At scroll edges, wheel over a message must scroll the page (not stop). */
    list.addEventListener(
      'wheel',
      function (e) {
        if (e.ctrlKey || e.metaKey) return;
        var delta = e.deltaY;
        if (!delta) return;
        var maxScroll = list.scrollHeight - list.clientHeight;
        if (maxScroll <= 1) return;
        var atTop = list.scrollTop <= 0;
        var atBottom = list.scrollTop >= maxScroll - 1;
        if ((delta < 0 && atTop) || (delta > 0 && atBottom)) {
          e.preventDefault();
          window.scrollBy({ top: delta, left: 0, behavior: 'auto' });
        }
      },
      { passive: false }
    );

    collapseInitial();
    scrollToLatest();
    list.classList.remove('thread-window--booting');
    list.dataset.threadBooted = '1';

    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(scrollToLatest);
    }
    setTimeout(scrollToLatest, 120);
  }

  w.bootThreadWindows = function () {
    var commentsList = document.getElementById('comments-list');
    if (commentsList) {
      setupThreadWindow(commentsList, '.comment-item', {
        initialVisible: 18,
        chunkSize: 12,
      });
    }
    var forumList = document.getElementById('forum-posts-list');
    if (forumList) {
      setupThreadWindow(forumList, '.forum-post-item', {
        initialVisible: 20,
        chunkSize: 14,
      });
    }
  };

  /* Thumbnails: click to view full size (forum / discussion rich-body only) */
  function ensureRichImageLightbox() {
    var lb = document.getElementById('rich-img-lightbox');
    if (lb) return lb;
    lb = document.createElement('div');
    lb.id = 'rich-img-lightbox';
    lb.className = 'rich-img-lightbox';
    lb.setAttribute('role', 'dialog');
    lb.setAttribute('aria-modal', 'true');
    lb.innerHTML =
      '<button type="button" class="rich-img-lightbox-close" aria-label="Close">&times;</button><img src="" alt="">';
    document.body.appendChild(lb);
    var img = lb.querySelector('img');
    var closeBtn = lb.querySelector('.rich-img-lightbox-close');
    function closeLb() {
      lb.classList.remove('is-open');
      if (img) img.removeAttribute('src');
    }
    lb.addEventListener('click', function (e) {
      if (e.target === lb) closeLb();
    });
    if (closeBtn) closeBtn.addEventListener('click', closeLb);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && lb.classList.contains('is-open')) closeLb();
    });
    return lb;
  }

  document.addEventListener(
    'click',
    function (e) {
      var t = e.target;
      if (!t || t.tagName !== 'IMG') return;
      if (t.closest('.ql-editor')) return;
      var body = t.closest('.rich-body');
      if (!body) return;
      e.preventDefault();
      var lb = ensureRichImageLightbox();
      var full = lb.querySelector('img');
      if (!full) return;
      full.src = t.getAttribute('src') || '';
      full.alt = t.getAttribute('alt') || '';
      lb.classList.add('is-open');
    },
    true
  );
})(window);
