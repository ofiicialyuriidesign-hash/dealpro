// Singleton protection to prevent multiple initializations during SPA navigation
if (window.chatInitialized) {
} else {
    window.chatInitialized = true;
    window.__ulpPageUnloading = false;
    window.__ulpPageLoadAt = Date.now();

    /**
     * Same-tab full navigation (e.g. public site ↔ /admin): close Socket.IO before the document unloads.
     * WebKit often logs "WebSocket is closed due to suspension" if the socket is still active when the
     * page tears down — this runs synchronously on link click, earlier than pagehide.
     */
    window.disconnectSocketBeforeFullPageNavigation = function () {
        const s = window.chatSocket;
        if (!s || !s.connected) return;
        try {
            // Emit leave_file / leave_resource while the socket is still up so Redis piles update
            // before /admin (or any full navigation) tears the page down.
            if (typeof window.cleanupChatRoom === 'function') {
                window.cleanupChatRoom();
            }
        } catch (e) { /* ignore */ }
        try {
            window._chatIntentionalReconnect = true;
            s.disconnect();
        } catch (e) { /* ignore */ }
    };

    function ulpIsWebKitSafari() {
        const ua = navigator.userAgent || '';
        return /AppleWebKit/i.test(ua) && !/Chrom(e|ium)|CriOS|Edg|OPR|FxiOS/i.test(ua);
    }

    function ulpCfBotChallengeLikely() {
        try {
            return /__CF\$cv\$params/.test(document.documentElement.innerHTML);
        } catch (e) {
            return false;
        }
    }

    function ulpRecentReloadGraceActive() {
        try {
            if (typeof window.__ulpInReloadGrace === 'function' && window.__ulpInReloadGrace()) return true;
        } catch (e) { /* ignore */ }
        try {
            const ts = Number(sessionStorage.getItem('ulp_eio_unload_ts') || 0);
            if (ts > 0 && Date.now() - ts < 6500) return true;
        } catch (e) { /* ignore */ }
        try {
            const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
            if (nav && nav.type === 'reload' && Date.now() - (window.__ulpPageLoadAt || 0) < 6500) return true;
        } catch (e) { /* ignore */ }
        return false;
    }

    function ulpSocketConnectDelayMs() {
        let ms = ulpIsWebKitSafari() ? 400 : 150;
        if (ulpCfBotChallengeLikely()) {
            ms = Math.max(ms, 2800);
        }
        try {
            const gap = typeof window.__ulpReloadGapMs === 'function' ? window.__ulpReloadGapMs() : 99999;
            const streak = typeof window.__ulpRapidReloadStreak === 'function' ? window.__ulpRapidReloadStreak() : 0;
            const unloadTs = Number(sessionStorage.getItem('ulp_eio_unload_ts') || 0);
            if (unloadTs > 0 && Date.now() - unloadTs < 6500) {
                ms = Math.max(ms, ulpIsWebKitSafari() ? 2600 : 1200);
            }
            const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
            if (nav && nav.type === 'reload') {
                ms = Math.max(ms, ulpIsWebKitSafari() ? 2600 : 900);
            }
            if (gap < 2500) {
                ms = Math.max(ms, ulpIsWebKitSafari() ? 3000 + streak * 450 : 1500 + streak * 250);
            }
            if (gap < 1200) {
                ms = Math.max(ms, ulpIsWebKitSafari() ? 3600 + streak * 500 : 1800 + streak * 300);
            }
        } catch (e) { /* ignore */ }
        return ms;
    }

    function ulpSocketConnectDelayElapsed() {
        return Date.now() - (window.__ulpPageLoadAt || 0) >= ulpSocketConnectDelayMs();
    }

    function ulpSocketTransportOptions() {
        // Same origin through Cloudflare: long-polling only (avoids WS upgrade noise + CF timeouts).
        return { transports: ['polling'], upgrade: false };
    }

    /** Drop stale Engine.IO sid (deploy/restart, sleep) and open a fresh handshake. */
    window.ulpForceNewSocketHandshake = function ulpForceNewSocketHandshake() {
        if (window.__ulpPageUnloading || window._chatIntentionalReconnect) return;
        const s = window.chatSocket;
        if (!s || !s.io) return;
        const now = Date.now();
        const last = Number(window.__ulpLastForceHandshakeAt || 0);
        if (now - last < 2500) return;
        window.__ulpLastForceHandshakeAt = now;
        window._chatIntentionalReconnect = true;
        try {
            const eng = s.io.engine;
            if (eng && typeof eng.close === 'function') {
                eng.close();
            }
            s.io.disconnect();
        } catch (e) { /* ignore */ }
        setTimeout(() => {
            try {
                if (window.__ulpPageUnloading) {
                    window._chatIntentionalReconnect = false;
                    return;
                }
                const s2 = window.chatSocket;
                if (!s2 || !s2.io) {
                    window._chatIntentionalReconnect = false;
                    return;
                }
                s2.io.open();
            } catch (e) {
                window._chatIntentionalReconnect = false;
                try {
                    if (window.chatSocket) window.chatSocket.connect();
                } catch (e2) { /* ignore */ }
            }
        }, 200);
    };

    function ulpBindEngineStaleSessionRecovery(socket) {
        if (!socket || !socket.io) return;
        const bind = () => {
            const eng = socket.io.engine;
            if (!eng || eng.__ulpStaleRecoveryBound) return;
            eng.__ulpStaleRecoveryBound = true;
            eng.on('close', (reason) => {
                if (window._chatIntentionalReconnect || window.__ulpPageUnloading) return;
                const r = String(reason || '').toLowerCase();
                if (
                    r === 'transport error' ||
                    r === 'transport close' ||
                    r === 'ping timeout' ||
                    r === 'forced close'
                ) {
                    if (document.visibilityState === 'visible') {
                        ulpForceNewSocketHandshake();
                    }
                }
            });
        };
        socket.io.on('open', bind);
        if (socket.io.engine) bind();
    }

    /** Buffer global chat history until the floating widget registers its processor. */
    function ulpCaptureChatHistoryEvent(data) {
        if (typeof window._chatHistoryProcessor === 'function') {
            window._chatHistoryProcessor(data);
            return;
        }
        window._chatHistoryBuffer = data;
    }

    function ulpAttachChatHistoryCapture(sock) {
        if (!sock || typeof sock.on !== 'function' || sock.__ulpChatHistoryCaptureAttached) return;
        sock.__ulpChatHistoryCaptureAttached = true;
        sock.on('history', ulpCaptureChatHistoryEvent);
    }

    function ulpRequestGlobalChatHistory(sock) {
        const s = sock || window.chatSocket;
        if (s && s.connected) {
            try {
                s.emit('request_chat_history');
            } catch (e) { /* ignore */ }
        }
    }
    window.ulpRequestGlobalChatHistory = ulpRequestGlobalChatHistory;

    function ulpFetchGlobalChatHistoryHttp() {
        return fetch('/api/global-chat/history', { credentials: 'same-origin', cache: 'no-store' })
            .then((r) => (r.ok ? r.json() : null))
            .then((data) => (data && Array.isArray(data.messages) ? data.messages : null))
            .catch(() => null);
    }
    window.ulpFetchGlobalChatHistoryHttp = ulpFetchGlobalChatHistoryHttp;

    // --- GLOBAL SOCKET HELPER ---
    window.getSharedSocket = function () {
        if (typeof io === 'undefined') {
            console.error('Chat: socket.io.js not loaded!');
            return null;
        }
        if (!window.chatSocket) {
            const ioOpts = {
                path: '/socket.io/',
                // Same-origin: cookies still attach; withCredentials:true makes WebKit treat polls as
                // credentialed CORS and log aborted handshakes as "access control checks" on refresh.
                withCredentials: false,
                ...ulpSocketTransportOptions(),
                reconnection: true,
                reconnectionAttempts: Infinity,
                reconnectionDelay: 800,
                reconnectionDelayMax: 10000,
                randomizationFactor: 0.4,
                timeout: 20000,
                autoConnect: false,
                forceNew: true,
                // Must stay below Cloudflare ~100s origin read timeout (server ping_timeout is 55s).
                pingInterval: 25000,
                pingTimeout: 55000,
            };
            window.chatSocket = io(ioOpts);
            window.socket = window.chatSocket; // Standardize global access
            ulpAttachChatHistoryCapture(window.chatSocket);
            if (typeof window.__ulpBindCoreRealtimeSocketHandlers === 'function') {
                window.__ulpBindCoreRealtimeSocketHandlers(window.chatSocket);
            }
            if (ulpIsWebKitSafari()) {
                try {
                    window.chatSocket.io.reconnection(false);
                    const enableReconnection = () => {
                        try {
                            if (window.chatSocket && window.chatSocket.io) {
                                window.chatSocket.io.reconnection(true);
                            }
                        } catch (e) { /* ignore */ }
                    };
                    window.chatSocket.once('connect', enableReconnection);
                    setTimeout(enableReconnection, 6000);
                } catch (e) { /* ignore */ }
            }

            // Track last successful Engine.IO handshake; helps detect "connected but stale" after sleep.
            window.__ulpSocketHandshakeAt = Date.now();
            let ulpResyncTimer = null;
            function scheduleUlpRealtimeResync() {
                window.__ulpSocketHandshakeAt = Date.now();
                if (ulpResyncTimer) clearTimeout(ulpResyncTimer);
                // Re-join rooms immediately so likes/presence work before the next delayed pass (races after ping-timeout).
                try {
                    if (typeof window.__ulpResyncRealtimeSubscriptions === 'function') {
                        window.__ulpResyncRealtimeSubscriptions();
                    }
                } catch (e) { /* ignore */ }
                try {
                    if (typeof window.initializeLikes === 'function') {
                        window.initializeLikes();
                    }
                } catch (e) { /* ignore */ }
                try {
                    if (typeof window.initializeFileStatsRealtime === 'function') {
                        window.initializeFileStatsRealtime();
                    }
                } catch (e) { /* ignore */ }
                ulpResyncTimer = setTimeout(() => {
                    ulpResyncTimer = null;
                    try {
                        if (typeof window.__ulpResyncRealtimeSubscriptions === 'function') {
                            window.__ulpResyncRealtimeSubscriptions();
                        }
                    } catch (e) { /* ignore */ }
                    try {
                        if (typeof window.initializeLikes === 'function') {
                            window.initializeLikes();
                        }
                    } catch (e) { /* ignore */ }
                    try {
                        if (typeof window.initializeFileStatsRealtime === 'function') {
                            window.initializeFileStatsRealtime();
                        }
                    } catch (e) { /* ignore */ }
                }, 160);
            }

            window.chatSocket.on('connect', () => {
                window._chatIntentionalReconnect = false;
                window._presenceIdleSessionEnded = false;
                if (typeof window.ulpEnsureRealtimeSocketBindings === 'function') {
                    window.ulpEnsureRealtimeSocketBindings(window.chatSocket);
                }
                ulpRequestGlobalChatHistory(window.chatSocket);
                if (window._chatCurrentRoom && typeof window.initializeFileRoom === 'function') {
                    const r = window._chatCurrentRoom;
                    window.initializeFileRoom(r.type, r.id);
                }
                try {
                    sessionStorage.removeItem('ulp_eio_unload_ts');
                    sessionStorage.removeItem('ulp_rapid_reload_streak');
                } catch (e) { /* ignore */ }
                if (window.__ulpConnectCfRetryTimer) {
                    clearTimeout(window.__ulpConnectCfRetryTimer);
                    window.__ulpConnectCfRetryTimer = null;
                }
                if (typeof window.__ulpBindPendingCountSocketHandlers === 'function') {
                    window.__ulpBindPendingCountSocketHandlers(window.chatSocket);
                }
                if (typeof window.__ulpBindIndexFeedSocketHandlers === 'function') {
                    window.__ulpBindIndexFeedSocketHandlers(window.chatSocket);
                }
                if (typeof window.requestPendingCountRefresh === 'function') {
                    window.requestPendingCountRefresh();
                }
                if (typeof window.refreshHeaderAccountState === 'function') {
                    window.refreshHeaderAccountState();
                }
                scheduleUlpRealtimeResync();
            });
            window.chatSocket.on('reconnect', () => {
                window._presenceIdleSessionEnded = false;
                if (typeof window.ulpEnsureRealtimeSocketBindings === 'function') {
                    window.ulpEnsureRealtimeSocketBindings(window.chatSocket);
                }
                ulpRequestGlobalChatHistory(window.chatSocket);
                if (typeof window.__ulpBindPendingCountSocketHandlers === 'function') {
                    window.__ulpBindPendingCountSocketHandlers(window.chatSocket);
                }
                if (typeof window.__ulpBindIndexFeedSocketHandlers === 'function') {
                    window.__ulpBindIndexFeedSocketHandlers(window.chatSocket);
                }
                if (typeof window.requestPendingCountRefresh === 'function') {
                    window.requestPendingCountRefresh();
                }
                if (typeof window.refreshHeaderAccountState === 'function') {
                    window.refreshHeaderAccountState();
                }
                scheduleUlpRealtimeResync();
            });
            let lastConnectErrLog = 0;
            function isTransientConnectError(err) {
                const msg = String((err && err.message) || '').toLowerCase();
                return (
                    msg.includes('xhr poll error') ||
                    msg.includes('transport error') ||
                    msg.includes('websocket') ||
                    msg.includes('access control')
                );
            }
            function isPollSessionError(err) {
                const msg = String((err && err.message) || '').toLowerCase();
                return (
                    msg.includes('xhr poll') ||
                    msg.includes('poll error') ||
                    msg.includes('invalid session') ||
                    msg.includes('access control')
                );
            }
            window.chatSocket.on('connect_error', (err) => {
                if (window._chatIntentionalReconnect) return;
                const s = window.chatSocket;
                const msg = String((err && err.message) || '').toLowerCase();
                // Safari refresh: aborted long-poll often surfaces as "access control checks" — not a real CORS failure.
                if (msg.includes('access control') && ulpRecentReloadGraceActive()) return;
                // Stale sid after deploy/restart: polls 400 while socket still looks "connected".
                if (s && isPollSessionError(err) && document.visibilityState === 'visible') {
                    ulpForceNewSocketHandshake();
                    return;
                }
                // Fast tab switches / page lifecycle can produce benign transport churn.
                if (document.visibilityState !== 'visible' || isTransientConnectError(err)) {
                    return;
                }
                const now = Date.now();
                if (now - lastConnectErrLog > 12000) {
                    lastConnectErrLog = now;
                    console.warn('Chat: socket connect_error (further errors throttled ~12s)', err && err.message);
                }
            });
            window.chatSocket.on('disconnect', (reason) => {
                if (window._chatIntentionalReconnect || window._presenceIdleSessionEnded) return;
                const r = String(reason || '').toLowerCase();
                // Server rejected connect (ban, policy) — do not hammer new handshakes.
                if (r === 'io server disconnect') return;
                if (r === 'ping timeout' || r === 'transport error' || r === 'transport close') {
                    if (document.visibilityState === 'visible' && !window.__ulpPageUnloading) {
                        ulpForceNewSocketHandshake();
                    }
                }
            });
            ulpBindEngineStaleSessionRecovery(window.chatSocket);

            // After sleep / long backgrounding, Engine.IO may keep a dead sid → polling 400 + WS spam.
            // Force a fresh handshake instead of retrying the stale session.
            (function setupResumeHardReconnect() {
                // Safari/macOS often keep visibility "visible" while the machine sleeps — rely on focus + resume too.
                // ulp.email: aggressively hard-reconnect on resume — we've seen "connected but dead" sessions after backgrounding.
                const MIN_REPEAT_MS = 8000;
                let debounceTimer = null;
                let lastFocusRecover = 0;
                let lastResumeHardReconnectAt = 0;

                /** If the full handshake was skipped (cooldown), still re-join rooms — cheap on the server. */
                function scheduleResyncIfConnectedSoon() {
                    setTimeout(() => {
                        try {
                            const s = window.chatSocket;
                            if (s && s.connected && typeof window.__ulpResyncRealtimeSubscriptions === 'function') {
                                window.__ulpResyncRealtimeSubscriptions();
                            }
                        } catch (e) { /* ignore */ }
                    }, 450);
                }

                function shouldRecoverSocketNow() {
                    const s = window.chatSocket;
                    if (!s) return false;
                    if (!s.connected) return true;
                    const eng = s.io && s.io.engine;
                    if (eng && eng.readyState && eng.readyState !== 'open') return true;
                    const hs = Number(window.__ulpSocketHandshakeAt || 0);
                    if (!Number.isFinite(hs) || hs <= 0) return true;
                    // Fresh live session: do not churn transport on quick tab hopping.
                    // After a couple minutes in the background, reconnect/resync on return.
                    return Date.now() - hs > 2 * 60 * 1000;
                }

                function hardReconnect() {
                    const s = window.chatSocket;
                    if (!s) return;
                    if (!shouldRecoverSocketNow()) return;
                    const now = Date.now();
                    if (now - lastResumeHardReconnectAt < MIN_REPEAT_MS && s.connected) return;
                    lastResumeHardReconnectAt = now;
                    if (debounceTimer) clearTimeout(debounceTimer);
                    debounceTimer = setTimeout(() => {
                        debounceTimer = null;
                        ulpForceNewSocketHandshake();
                    }, 120);
                }

                document.addEventListener('visibilitychange', () => {
                    if (document.visibilityState !== 'visible') return;
                    // Fast tab switches are common; reconnect only when stale/disconnected.
                    if (shouldRecoverSocketNow()) hardReconnect();
                    scheduleResyncIfConnectedSoon();
                });

                window.addEventListener('online', () => {
                    if (document.visibilityState !== 'visible') return;
                    const s = window.chatSocket;
                    if (s && !s.connected) {
                        hardReconnect();
                    }
                    scheduleResyncIfConnectedSoon();
                });

                window.addEventListener('pageshow', (ev) => {
                    if (shouldRecoverSocketNow()) hardReconnect();
                    scheduleResyncIfConnectedSoon();
                    if (ev.persisted) {
                        scheduleResyncIfConnectedSoon();
                    }
                });

                // Tab/window focused again (common path after sleep with this tab active — no visibility flip).
                window.addEventListener('focus', () => {
                    if (document.visibilityState !== 'visible') return;
                    const now = Date.now();
                    if (now - lastFocusRecover < 2500) return;
                    const s = window.chatSocket;
                    if (!s) return;
                    const hs = Number(window.__ulpSocketHandshakeAt || 0);
                    const staleConnected = !!(s.connected && hs > 0 && (now - hs > 2 * 60 * 1000));
                    if (!s.connected || staleConnected) {
                        lastFocusRecover = now;
                        hardReconnect();
                    }
                    scheduleResyncIfConnectedSoon();
                });

                // Page Lifecycle (Chrome; Safari where supported): tab thawed after freeze/sleep-style suspension.
                document.addEventListener('resume', () => {
                    hardReconnect();
                    scheduleResyncIfConnectedSoon();
                });
            })();

            // Full page unload (e.g. /discussions → /admin): close Socket.IO cleanly so WebKit/Safari
            // is less likely to log "WebSocket closed due to suspension" during navigation.
            window.addEventListener('pagehide', (ev) => {
                if (ev.persisted) return;
                const s = window.chatSocket;
                if (!s) return;
                try {
                    if (s.connected && typeof window.cleanupChatRoom === 'function') {
                        window.cleanupChatRoom();
                    }
                } catch (e) { /* ignore */ }
                try {
                    window._chatIntentionalReconnect = true;
                    if (s.io && s.io.engine) s.io.engine.close();
                    s.disconnect();
                } catch (e) { /* ignore */ }
            });

            // Safari refresh/close: abort in-flight polls without closing engine → red "access control checks".
            window.addEventListener('beforeunload', () => {
                const s = window.chatSocket;
                if (!s) return;
                try {
                    window._chatIntentionalReconnect = true;
                    if (s.io && s.io.engine) s.io.engine.close();
                    s.disconnect();
                } catch (e) { /* ignore */ }
            });
        }
        window.socket = window.chatSocket; // Ensure exposure
        return window.chatSocket;
    };

    /** One handshake at a time — parallel connect() causes duplicate polls and Safari console noise. */
    window.ulpConnectSharedSocketOnce = function ulpConnectSharedSocketOnce(force) {
        try {
            if (typeof io === 'undefined') return;
            if (!force && !ulpSocketConnectDelayElapsed()) {
                ulpConnectSharedSocketWhenReady();
                return;
            }
            const s = window.getSharedSocket();
            if (!s) return;
            if (s.connected) return;
            if (window.__ulpSocketConnectInFlight) return;
            const eng = s.io && s.io.engine;
            if (eng && (eng.readyState === 'opening' || eng.readyState === 'open')) return;

            window.__ulpSocketConnectInFlight = true;
            const clearInFlight = () => {
                window.__ulpSocketConnectInFlight = false;
            };
            s.once('connect', clearInFlight);
            s.once('connect_error', clearInFlight);
            setTimeout(clearInFlight, 25000);
            s.connect();
        } catch (e) {
            window.__ulpSocketConnectInFlight = false;
            console.error('Chat: socket connect failed.', e);
        }
    };

    /**
     * Wait until the shared socket is connected (or fail after timeout).
     * Used before comment/forum emits so actions are not silently dropped on a stale session.
     */
    window.ulpEnsureSharedSocketConnected = function ulpEnsureSharedSocketConnected(timeoutMs) {
        const limit = Math.max(2000, Number(timeoutMs) || 8000);
        return new Promise((resolve, reject) => {
            window._presenceIdleSessionEnded = false;
            if (typeof io === 'undefined' || typeof window.getSharedSocket !== 'function') {
                reject(new Error('Socket unavailable'));
                return;
            }
            const s = window.getSharedSocket();
            if (!s) {
                reject(new Error('Socket unavailable'));
                return;
            }
            if (s.connected) {
                resolve(s);
                return;
            }
            if (typeof window.ulpConnectSharedSocketOnce === 'function') {
                window.ulpConnectSharedSocketOnce(true);
            } else {
                try {
                    s.connect();
                } catch (e) { /* ignore */ }
            }
            const deadline = Date.now() + limit;
            let settled = false;
            const finish = (fn, val) => {
                if (settled) return;
                settled = true;
                cleanup();
                fn(val);
            };
            const onConnect = () => finish(resolve, s);
            const onError = () => {
                if (Date.now() >= deadline) {
                    finish(reject, new Error('Could not connect to live updates. Try refreshing the page.'));
                }
            };
            const timer = setInterval(() => {
                if (s.connected) {
                    finish(resolve, s);
                    return;
                }
                if (Date.now() >= deadline) {
                    finish(reject, new Error('Could not connect to live updates. Try refreshing the page.'));
                }
            }, 150);
            const cleanup = () => {
                clearInterval(timer);
                try {
                    s.off('connect', onConnect);
                    s.off('connect_error', onError);
                } catch (e) { /* ignore */ }
            };
            s.on('connect', onConnect);
            s.on('connect_error', onError);
        });
    };

    // Defer connect until the document is fully loaded — Safari often aborts in-flight polls during
    // parser/CF challenge churn and logs them as "access control checks".
    function ulpConnectSharedSocketWhenReady() {
        if (window.__ulpConnectDelayTimer) clearTimeout(window.__ulpConnectDelayTimer);
        if (window.__ulpConnectCfRetryTimer) clearTimeout(window.__ulpConnectCfRetryTimer);
        const delayMs = ulpSocketConnectDelayMs();
        window.__ulpConnectDelayTimer = setTimeout(() => {
            window.__ulpConnectDelayTimer = null;
            window.ulpConnectSharedSocketOnce();
        }, delayMs);
        if (ulpCfBotChallengeLikely()) {
            window.__ulpConnectCfRetryTimer = setTimeout(() => {
                window.__ulpConnectCfRetryTimer = null;
                window.ulpConnectSharedSocketOnce();
            }, delayMs + 3500);
        }
    }
    function ulpScheduleSharedSocketConnect() {
        if (document.readyState === 'complete') {
            ulpConnectSharedSocketWhenReady();
        } else {
            window.addEventListener('load', ulpConnectSharedSocketWhenReady, { once: true });
        }
    }
    ulpScheduleSharedSocketConnect();

    // --- HISTORY BUFFER ---
    window._chatHistoryBuffer = null;
    try {
        if (window.chatSocket) {
            ulpAttachChatHistoryCapture(window.chatSocket);
        }
    } catch (e) {
        console.error('Chat: failed to attach early history buffer listener.', e);
    }

    document.addEventListener('DOMContentLoaded', () => {
        if (typeof window.__ulpGetFloatingChatRoot !== 'function') {
            window.__ulpGetFloatingChatRoot = function () {
                try {
                    const pickOutsideMain = (el) => {
                        if (!el || typeof el.closest !== 'function') return null;
                        return el.closest('main') ? null : el;
                    };
                    const remember = (el) => {
                        if (el) window.__ulpFloatingChatRootEl = el;
                        return el;
                    };
                    const memo = window.__ulpFloatingChatRootEl;
                    if (memo && memo.isConnected) {
                        const ok = pickOutsideMain(memo);
                        if (ok) return ok;
                        if (memo.hasAttribute && memo.hasAttribute('data-ulp-floating-chat')) return memo;
                        window.__ulpFloatingChatRootEl = null;
                    }
                    const allMarked = document.querySelectorAll('[data-ulp-floating-chat]');
                    if (allMarked.length === 1 && allMarked[0]) {
                        return remember(allMarked[0]);
                    }
                    for (let i = 0; i < allMarked.length; i += 1) {
                        const hit = pickOutsideMain(allMarked[i]);
                        if (hit) return remember(hit);
                    }
                    const bodyMarked = document.querySelector('body > [data-ulp-floating-chat]');
                    const b0 = pickOutsideMain(bodyMarked);
                    if (b0) return remember(b0);
                    const direct = document.querySelector('body > #chat-widget-container');
                    const d2 = pickOutsideMain(direct);
                    if (d2) return remember(d2);
                    const byId = document.getElementById('chat-widget-container');
                    if (byId) {
                        const d3 = pickOutsideMain(byId);
                        if (d3) return remember(d3);
                        if (byId.querySelector && byId.querySelector('#chat-window')) {
                            return remember(byId);
                        }
                    }
                    window.__ulpFloatingChatRootEl = null;
                    return null;
                } catch (e) {
                    return null;
                }
            };
        }

        if (typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
            window.__ulpRelocateFloatingChatShellOutOfMain();
        }
        const chatContainer = window.__ulpGetFloatingChatRoot();
        const expectShell = document.body && document.body.getAttribute('data-ulp-expect-floating-chat-shell') === 'true';
        window.__ulpExpectFloatingChatShell = expectShell;

        if (!chatContainer) {
            if (expectShell) {
                console.warn('Chat: floating shell not found (expected #chat-widget-container with data-ulp-floating-chat).');
            }
            return;
        }

        if (typeof io === 'undefined') {
            console.warn('Chat: Socket.IO not loaded; skipping chat bootstrap.');
            return;
        }

        window.__ulpFloatingChatRootEl = chatContainer;

        /* Scope to the floating widget root so stray duplicate ids inside <main> cannot steal getElementById. */
        const chatBackdrop = chatContainer.querySelector('#chat-backdrop');
        const chatWindow = chatContainer.querySelector('#chat-window');
        const toggleBtn = chatContainer.querySelector('#chat-toggle-btn');
        const closeBtn = chatContainer.querySelector('#chat-close-btn');
        const messagesDiv = chatContainer.querySelector('#chat-messages');
        const input = chatContainer.querySelector('#chat-input');
        const sendBtn = chatContainer.querySelector('#chat-send-btn');
        const badge = chatContainer.querySelector('#chat-unread-badge');

        // Emoji Elements
        const emojiBtn = chatContainer.querySelector('#chat-emoji-btn');
        const emojiPicker = chatContainer.querySelector('#emoji-picker');

        let unreadCount = 0;
        let editingMessageId = null;
        const userRole = chatContainer ? chatContainer.getAttribute('data-user-role') : '';
        const isAdminOrMod = ['admin', 'moderator'].includes(userRole);
        const chatCanWrite = chatContainer.getAttribute('data-chat-can-write') === 'true';
        let chatContextMenu = null;
        let longPressTimer = null;
        const LONG_PRESS_MS = 550;

        // Auth info: Use specific nav class to avoid picking up file authors from the list
        const myUsername = document.querySelector('.nav-btn-profile')?.textContent.trim() || 'Guest';

        // LocalStorage Keys
        const LAST_READ_KEY = 'textshare_chat_last_read';
        const CHAT_STATE_KEY = 'textshare_chat_is_open';

        // Helper to detect mobile (v108)
        const isMobile = () => /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

        /**
         * Pin the floating chat shell to the bottom of the *visual* viewport (not only the layout viewport).
         * Mobile WebKit often desyncs these after long backgrounding / dynamic toolbar changes; the FAB can then
         * appear to drift upward while scrolling until the next full reload.
         */
        let ulpChatVvDockRaf = null;
        function scheduleChatVisualViewportDock() {
            if (!window.__ulpGetFloatingChatRoot || !window.__ulpGetFloatingChatRoot()) return;
            if (ulpChatVvDockRaf) cancelAnimationFrame(ulpChatVvDockRaf);
            ulpChatVvDockRaf = requestAnimationFrame(() => {
                ulpChatVvDockRaf = null;
                syncChatWidgetVisualViewportDock();
            });
        }

        function syncChatWidgetVisualViewportDock() {
            // Always resolve live nodes (SPA touches ids on the active document; closures must not drift).
            const el = window.__ulpGetFloatingChatRoot ? window.__ulpGetFloatingChatRoot() : null;
            if (!el || !window.matchMedia('(max-width: 768px)').matches) {
                if (el) el.style.removeProperty('bottom');
                return;
            }
            const win = el.querySelector('#chat-window');
            if (win && win.classList.contains('hidden')) {
                el.style.removeProperty('bottom');
                return;
            }
            const vv = window.visualViewport;
            if (!vv) {
                el.style.removeProperty('bottom');
                return;
            }
            let gap = Math.max(0, window.innerHeight - vv.offsetTop - vv.height);
            if (!Number.isFinite(gap) || gap > 220) gap = 0;
            const nextBottom = `${gap}px`;
            if (el.style.bottom !== nextBottom) {
                el.style.bottom = nextBottom;
            }
        }

        /** Move focus out of the chat subtree before it gets display:none — avoids WebKit leaving the URL bar expanded until a full reload. */
        function blurFocusInsideChat() {
            if (!chatWindow) return;
            const ae = document.activeElement;
            if (ae && chatWindow.contains(ae) && typeof ae.blur === 'function') {
                ae.blur();
            }
            if (input) input.blur();
        }

        /**
         * iOS Safari: nudge focus/scroll/resize after closing the sheet (primary fix is bottom sheet + backdrop, not full-viewport layer).
         */
        function afterChatClosedMobile() {
            if (!isMobile()) return;

            function nudgeSafariChrome() {
                const root = document.scrollingElement || document.documentElement;
                const yDoc = root.scrollTop;
                const yWin = window.pageYOffset || window.scrollY || 0;

                if (toggleBtn) {
                    try {
                        toggleBtn.focus({ preventScroll: true });
                    } catch (e) {
                        try {
                            toggleBtn.focus();
                        } catch (e2) { /* ignore */ }
                    }
                    toggleBtn.blur();
                }

                root.scrollTop = yDoc + 1;
                root.scrollTop = yDoc;
                window.scrollTo(0, yWin + 1);
                window.scrollTo(0, yWin);
                window.dispatchEvent(new Event('resize'));
            }

            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    nudgeSafariChrome();
                    scheduleChatVisualViewportDock();
                    setTimeout(nudgeSafariChrome, 50);
                    setTimeout(scheduleChatVisualViewportDock, 50);
                    setTimeout(nudgeSafariChrome, 180);
                    setTimeout(scheduleChatVisualViewportDock, 180);
                    setTimeout(nudgeSafariChrome, 420);
                    setTimeout(scheduleChatVisualViewportDock, 420);
                });
            });
        }

        let chatBackgroundScrollY = 0;
        let chatScrollLockTouchBlock = null;
        const isListRestoreActive = () => {
            const until = Number(window.__ulpListRestoreInProgressUntil || 0);
            return Number.isFinite(until) && Date.now() < until;
        };

        function clearMobileChatScrollLockStyles(restoreScroll) {
            const html = document.documentElement;
            const body = document.body;
            if (!body) return;
            if (chatScrollLockTouchBlock) {
                document.removeEventListener('touchmove', chatScrollLockTouchBlock, { capture: true });
                chatScrollLockTouchBlock = null;
            }
            html.classList.remove('ulp-chat-mobile-scroll-lock');
            body.classList.remove('ulp-chat-mobile-scroll-lock');
            body.style.position = '';
            body.style.top = '';
            body.style.left = '';
            body.style.right = '';
            body.style.width = '';
            if (restoreScroll && !isListRestoreActive()) {
                window.scrollTo(0, chatBackgroundScrollY);
            }
        }

        /** Match CSS mobile sheet breakpoint; freeze page scroll without body position:fixed (breaks fixed header on iOS). */
        function setMobileChatBackgroundScrollLock(locked) {
            if (!window.matchMedia('(max-width: 768px)').matches) return;
            const html = document.documentElement;
            const body = document.body;
            if (locked) {
                chatBackgroundScrollY = window.scrollY || document.documentElement.scrollTop || 0;
                try {
                    body.dataset.ulpScrollLockY = String(chatBackgroundScrollY);
                } catch (e) { /* ignore */ }
                html.classList.add('ulp-chat-mobile-scroll-lock');
                body.classList.add('ulp-chat-mobile-scroll-lock');
                if (!chatScrollLockTouchBlock) {
                    chatScrollLockTouchBlock = (e) => {
                        const t = e.target;
                        if (!t || !t.closest) return;
                        if (t.closest('#site-header-wrapper')) return;
                        if (t.closest('#chat-widget-container')) return;
                        if (t.closest('#chat-window')) return;
                        e.preventDefault();
                    };
                    document.addEventListener('touchmove', chatScrollLockTouchBlock, { passive: false, capture: true });
                }
                return;
            }
            clearMobileChatScrollLockStyles(true);
        }

        /**
         * SPA / route churn: if chat scroll-lock stayed on while the panel was force-closed,
         * fixed header + FAB docking can drift until a full reload.
         */
        window.__ulpUnlockChatMobileBodyIfChatLocked = function () {
            try {
                if (!window.matchMedia('(max-width: 768px)').matches) return;
                const html = document.documentElement;
                const body = document.body;
                if (!body) return;
                const hadClassLock = html.classList.contains('ulp-chat-mobile-scroll-lock');
                const hadLegacyFixed = body.style.position === 'fixed' && body.style.width === '100%';
                if (!hadClassLock && !hadLegacyFixed) return;
                if (hadLegacyFixed) {
                    const topStr = String(body.style.top || '').trim();
                    const m = /^-(\d+(?:\.\d+)?)px$/.exec(topStr);
                    if (m) {
                        chatBackgroundScrollY = Math.max(0, Math.round(parseFloat(m[1])));
                    }
                } else {
                    try {
                        const stored = parseInt(body.dataset.ulpScrollLockY || '', 10);
                        if (Number.isFinite(stored) && stored >= 0) chatBackgroundScrollY = stored;
                    } catch (e) { /* ignore */ }
                }
                clearMobileChatScrollLockStyles(true);
                if (typeof window.__ulpSyncMobileHeaderWrapState === 'function') {
                    window.__ulpSyncMobileHeaderWrapState();
                }
            } catch (e) { /* ignore */ }
        };

        function syncChatChrome() {
            const liveContainer = window.__ulpGetFloatingChatRoot ? window.__ulpGetFloatingChatRoot() : null;
            if (!liveContainer) {
                // If resolver briefly fails while the panel was open, the FAB can stay `display:none` forever.
                if (window.__ulpExpectFloatingChatShell) {
                    try {
                        const fb = document.querySelector('body > [data-ulp-floating-chat]')
                            || document.querySelector('body > #chat-widget-container');
                        if (fb) {
                            const w = fb.querySelector('#chat-window');
                            const t = fb.querySelector('#chat-toggle-btn') || fb.querySelector('.chat-btn');
                            const hidden = !w || w.classList.contains('hidden');
                            if (t && hidden) t.style.removeProperty('display');
                        }
                    } catch (e) { /* ignore */ }
                }
                return;
            }
            const liveWin = liveContainer.querySelector('#chat-window');
            const liveToggle = liveContainer.querySelector('#chat-toggle-btn')
                || liveContainer.querySelector('.chat-btn');
            const liveBackdrop = liveContainer.querySelector('#chat-backdrop');
            const isHidden = !liveWin || liveWin.classList.contains('hidden');
            if (liveToggle) {
                if (isHidden) liveToggle.style.removeProperty('display');
                else liveToggle.style.display = 'none';
            }
            if (liveBackdrop) liveBackdrop.classList.toggle('hidden', isHidden);
            if (liveWin) {
                setMobileChatBackgroundScrollLock(!isHidden);
                if (isHidden) liveContainer.style.removeProperty('bottom');
            } else {
                setMobileChatBackgroundScrollLock(false);
                liveContainer.style.removeProperty('bottom');
            }
            scheduleChatVisualViewportDock();
        }

        window.__ulpSyncChatChrome = syncChatChrome;

        /**
         * SPA: DOMContentLoaded runs only on full reload. Each soft navigation dispatches `pageLoaded` —
         * re-apply shell state so FAB/backdrop/mobile lock match the route (same work F5 did implicitly).
         */
        window.__ulpRepairFloatingChatShell = function __ulpRepairFloatingChatShell(_detail) {
            if (!window.__ulpExpectFloatingChatShell) {
                return;
            }
            if (typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
                window.__ulpRelocateFloatingChatShellOutOfMain();
            }
            try {
                let root = window.__ulpGetFloatingChatRoot ? window.__ulpGetFloatingChatRoot() : null;
                if (!root && typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
                    window.__ulpRelocateFloatingChatShellOutOfMain();
                    root = window.__ulpGetFloatingChatRoot ? window.__ulpGetFloatingChatRoot() : null;
                }
                if (!root) {
                    return;
                }
                const win = root.querySelector('#chat-window');
                const tgl = root.querySelector('#chat-toggle-btn');
                const bd = root.querySelector('#chat-backdrop');
                let wantOpen = false;
                try {
                    wantOpen = localStorage.getItem(CHAT_STATE_KEY) === 'true';
                } catch (e) { /* private mode */ }
                if (win) {
                    if (wantOpen) win.classList.remove('hidden');
                    else win.classList.add('hidden');
                }
                if (bd) {
                    const panelOpen = !!(win && !win.classList.contains('hidden'));
                    bd.classList.toggle('hidden', !panelOpen);
                }
                if (tgl) {
                    tgl.style.removeProperty('display');
                    tgl.style.removeProperty('visibility');
                    tgl.style.removeProperty('opacity');
                }
                root.style.removeProperty('bottom');
                root.style.removeProperty('transform');
                root.style.removeProperty('display');
                root.style.removeProperty('visibility');
                root.style.removeProperty('opacity');
                if (typeof window.__ulpUnlockChatMobileBodyIfChatLocked === 'function' && !wantOpen) {
                    window.__ulpUnlockChatMobileBodyIfChatLocked();
                }
                if (typeof window.__ulpSyncChatChrome === 'function') {
                    window.__ulpSyncChatChrome();
                }
            } catch (e) {
                /* avoid console noise on SPA transitions */
            }
        };

        let __ulpChatShellRepairTimer = null;
        document.addEventListener('pageLoaded', (ev) => {
            const d = ev && ev.detail;
            window.__ulpRepairFloatingChatShell(d);
            if (__ulpChatShellRepairTimer) clearTimeout(__ulpChatShellRepairTimer);
            __ulpChatShellRepairTimer = setTimeout(() => {
                __ulpChatShellRepairTimer = null;
                window.__ulpRepairFloatingChatShell(d);
            }, 320);
        });

        function closeChatPanel() {
            blurFocusInsideChat();
            chatWindow.classList.add('hidden');
            localStorage.setItem(CHAT_STATE_KEY, 'false');
            syncChatChrome();
            if (emojiPicker) emojiPicker.classList.add('hidden');
            afterChatClosedMobile();
        }

        syncChatChrome();
        scheduleChatVisualViewportDock();
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', scheduleChatVisualViewportDock, { passive: true });
        }
        window.addEventListener('resize', scheduleChatVisualViewportDock);
        window.addEventListener('orientationchange', scheduleChatVisualViewportDock);
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState !== 'visible') return;
            scheduleChatVisualViewportDock();
            setTimeout(scheduleChatVisualViewportDock, 160);
        });
        window.addEventListener('pageshow', () => {
            if (typeof window.__ulpUnlockChatMobileBodyIfChatLocked === 'function') {
                window.__ulpUnlockChatMobileBodyIfChatLocked();
            }
            scheduleChatVisualViewportDock();
        });

        if (chatWindow && window.MutationObserver) {
            const mo = new MutationObserver(() => syncChatChrome());
            mo.observe(chatWindow, { attributes: true, attributeFilter: ['class'] });
        }

        // FAB opens chat only; when open it hides so it does not overlay the panel.
        toggleBtn.addEventListener('click', () => {
            chatWindow.classList.remove('hidden');
            localStorage.setItem(CHAT_STATE_KEY, 'true');
            syncChatChrome();

            unreadCount = 0;
            updateBadge();
            markAsRead();

            ulpEnsureGlobalChatHistoryLoaded(false);
            scrollToBottom();
            if (input && !isMobile()) input.focus();
        });

        window.setChatReply = function (username) {
            if (input) {
                input.value = `@${username}, ` + input.value;
                if (!isMobile()) input.focus();
            }
        };

        closeBtn.addEventListener('click', () => closeChatPanel());

        if (chatBackdrop) {
            chatBackdrop.addEventListener('click', () => closeChatPanel());
        }

        // Restore State
        const wasOpen = localStorage.getItem(CHAT_STATE_KEY) === 'true';
        if (wasOpen) {
            chatWindow.classList.remove('hidden');
            scrollToBottom();
            syncChatChrome();
        }

        // --- Emoji Logic ---
        if (emojiBtn && emojiPicker && input) {
            const emojis = [
                '😀', '😂', '😍', '😎', '😭', '😡', '👍', '👎', '🔥', '✨',
                '❤️', '💔', '🤝', '👀', '🚀', '💻', '🤖', '👽', '👻', '💀',
                '🎉', '🎈', '💡', '✅', '❌', '❓', '❗', '💯', '💪', '🙏',
                '👋', '🤔', '🙄', '🤢', '🤮', '🤯', '🥳', '🤨', '🤫', '🤐'
            ];

            // Populate picker
            emojis.forEach(char => {
                const btn = document.createElement('button');
                btn.className = 'emoji-btn';
                btn.textContent = char;
                btn.onclick = () => {
                    input.value += char;
                    if (!isMobile()) input.focus();
                    emojiPicker.classList.add('hidden');
                };
                emojiPicker.appendChild(btn);
            });

            // Toggle picker
            emojiBtn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent closing immediately
                emojiPicker.classList.toggle('hidden');
            });

            // Close picker when clicking outside
            document.addEventListener('click', (e) => {
                if (!emojiPicker.contains(e.target) && e.target !== emojiBtn) {
                    emojiPicker.classList.add('hidden');
                }
            });
        }

        // Helper to clear "Connection lost" notifications
        const clearConnectionLostMessages = () => {
            if (!messagesDiv) return;
            const lostMsgs = messagesDiv.querySelectorAll('.chat-system-msg-lost');
            if (lostMsgs.length > 0) {
                lostMsgs.forEach(m => m.remove());
            }
        };

        // Connectivity - Use shared socket
        var socket = window.getSharedSocket();

        socket.on('connect', () => {
            clearConnectionLostMessages();
            ulpRequestGlobalChatHistory(socket);

            // --- FIX: Re-join File Room on Reconnect ---
            if (window._chatCurrentRoom) {
                if (window._chatCurrentRoom.type === 'file') {
                    socket.emit('join_file', { file_id: window._chatCurrentRoom.id });
                } else if (window._chatCurrentRoom.type === 'resource') {
                    socket.emit('join_resource', { listing_id: window._chatCurrentRoom.id });
                }
            }
        });

        socket.on('disconnect', (reason) => {
            if (window._chatIntentionalReconnect) {
                return;
            }
            if (window._presenceIdleSessionEnded) {
                return;
            }
            const reasonStr = String(reason || '');
            if (
                reasonStr === 'transport error'
                || reasonStr === 'ping timeout'
                || reasonStr === 'forced close'
                || reasonStr === 'io client disconnect'
            ) {
                return;
            }
            const now = Date.now();
            if (!window._lastChatDisconnectLog) window._lastChatDisconnectLog = 0;
            if (now - window._lastChatDisconnectLog > 12000) {
                window._lastChatDisconnectLog = now;
                console.warn('Chat: socket disconnected (reason:', reason + '; further disconnect logs throttled ~12s)');
            }

            // Prevent duplicate lost messages
            if (!messagesDiv.querySelector('.chat-system-msg-lost')) {
                const div = document.createElement('div');
                div.className = 'chat-system-msg chat-system-msg-lost';
                div.innerText = 'Connection lost. Reconnecting...';
                messagesDiv.appendChild(div);
                scrollToBottom();
            }
        });

        socket.on('error', (data) => {
            console.error('Socket Error:', data);
            if (window.showToast) {
                window.showToast('Error', data.message || 'An error occurred.', null, 'fas fa-circle-exclamation', null, 'error');
            } else {
                alert(data.message || 'An error occurred.');
            }
        });

        let historyLoaded = false;

        function processHistory(history) {
            if (!Array.isArray(history)) return;
            clearConnectionLostMessages();

            // PREVENT BLINK: If we already have history loaded, don't clear and re-render
            // because we are just reconnecting or transitioning.
            if (historyLoaded && messagesDiv && messagesDiv.querySelector('.chat-msg')) {
                return;
            }

            messagesDiv.innerHTML = ''; // Clear initial loader message only once

            // Calculate initial unread
            const lastRead = getLastReadTime();
            let initialUnread = 0;

            history.forEach(msg => {
                appendMessage(msg);
                if (msg.timestamp_raw && msg.timestamp_raw > lastRead && msg.username !== myUsername) {
                    initialUnread++;
                }
            });

            historyLoaded = true;

            // If chat is currently visible, ignore accumulated. Otherwise set.
            if (chatWindow.classList.contains('hidden')) {
                unreadCount = initialUnread;
                updateBadge();
            } else {
                markAsRead();
            }

            scrollToBottom();
        }

        function ulpEnsureGlobalChatHistoryLoaded(force) {
            if (!force && historyLoaded && messagesDiv && messagesDiv.querySelector('.chat-msg')) {
                return Promise.resolve();
            }
            return ulpFetchGlobalChatHistoryHttp().then((messages) => {
                if (messages && messages.length) {
                    processHistory(messages);
                    return;
                }
                if (socket && socket.connected) {
                    ulpRequestGlobalChatHistory(socket);
                }
            });
        }
        window.ulpEnsureGlobalChatHistoryLoaded = ulpEnsureGlobalChatHistoryLoaded;

        window._chatHistoryProcessor = processHistory;
        socket.off('history', ulpCaptureChatHistoryEvent);
        socket.on('history', processHistory);

        // Replay buffered history that arrived before DOMContentLoaded
        if (window._chatHistoryBuffer) {
            processHistory(window._chatHistoryBuffer);
            window._chatHistoryBuffer = null;
        }
        ulpEnsureGlobalChatHistoryLoaded(false);


        function markChatMessageApproved(msgId) {
            const existing = document.getElementById(`msg-${msgId}`);
            if (!existing) return;
            existing.classList.remove('chat-msg-pending');
            existing.dataset.pending = 'false';
            existing.querySelector('.chat-msg-pending-badge')?.remove();
            existing.querySelector('[data-ulp-chat-action="approve"]')?.remove();
        }

        socket.on('message', (data) => {
            clearConnectionLostMessages();
            const existing = document.getElementById(`msg-${data.id}`);
            if (existing) {
                markChatMessageApproved(data.id);
                scrollToBottom();
                return;
            }
            appendMessage(data);

            // Increment unread if chat is hidden and msg is not mine
            if (chatWindow.classList.contains('hidden') && data.username !== myUsername) {
                unreadCount++;
                updateBadge();
            } else {
                scrollToBottom();
                // If visible, update read time
                if (!chatWindow.classList.contains('hidden')) {
                    markAsRead();
                }
            }
        });

        // Handle deletion
        socket.on('message_deleted', (data) => {
            const msgElement = document.getElementById(`msg-${data.id}`);
            if (msgElement) {
                msgElement.style.opacity = '0';
                setTimeout(() => msgElement.remove(), 300); // Smooth removal
            }
        });

        socket.on('message_edited', (data) => {
            const msgElement = document.getElementById(`msg-${data.id}`);
            if (!msgElement) return;
            const contentEl = msgElement.querySelector('.comment-content');
            if (!contentEl) return;
            const safeHtml = (typeof window.ulpSanitizeRichHtml === 'function')
                ? window.ulpSanitizeRichHtml(data.msg || '')
                : (data.msg || '');
            contentEl.innerHTML = safeHtml;
            msgElement.classList.add('chat-msg-edited');
            setTimeout(() => msgElement.classList.remove('chat-msg-edited'), 700);
        });

        // --- Real-time File Updates ---
        socket.on('new_file_notification', (file) => {
            // Admin Dashboard: Reload on ANY new file (to show pending or approved)
            const pendingList = document.querySelector('.pending-files-container');
            if (pendingList) {
                setTimeout(() => location.reload(), 500);
                return;
            }

            if (typeof window.applyNewFileToIndexFeed === 'function') {
                window.applyNewFileToIndexFeed(file);
            }
            if (typeof window.bumpVipNewBadgeIfNeeded === 'function') {
                window.bumpVipNewBadgeIfNeeded(file);
            }
        });

        // --- REAL-TIME COUNTERS & TYPING ---

        // 1. Footer activity count (~15m registered + guests; same pill for all roles)
        socket.on('update_global_online', (data) => {
            if (!data) return;
            if (data.widget_activity_total != null) {
                const actEl = document.getElementById('ulp-activity-count');
                if (actEl) actEl.textContent = String(Number(data.widget_activity_total) || 0);
            }
        });


        // 3. Typing Indicator (Receiving)
        socket.on('user_typing', (data) => {
            let container;
            if (data.file_id === 'global_chat') {
                container = chatContainer.querySelector('#chat-typing-indicator');
            } else {
                container = document.getElementById('typing-indicator-container');
            }

            if (!container) return;

            if (data.is_typing) {
                // Determine ID for this user's typing bubble
                const bubbleId = `typing-${data.username}`;
                let bubble = document.getElementById(bubbleId);

                if (!bubble) {
                    bubble = document.createElement('div');
                    bubble.id = bubbleId;
                    bubble.className = 'typing-bubble';
                    bubble.innerHTML = `
                        <span class="typing-name">${data.username}</span> is typing
                        <div class="typing-dots">
                            <span></span><span></span><span></span>
                        </div>
                    `;
                    container.appendChild(bubble);
                }
            } else {
                const bubble = document.getElementById(`typing-${data.username}`);
                if (bubble) bubble.remove();
            }
        });

        // 4. Typing Emitter (Sending)
        const commentInput = document.getElementById('comment-input');
        if (commentInput) {
            let typingTimeout;
            let isTyping = false;
            const ROOM_ID = commentInput.getAttribute('data-room-id');
            const roomPayload = (() => {
                if (!ROOM_ID) return {};
                if (ROOM_ID.startsWith('file_')) {
                    return { file_id: ROOM_ID.replace('file_', '') };
                }
                if (ROOM_ID.startsWith('resource_')) {
                    return { listing_id: ROOM_ID.replace('resource_', '') };
                }
                return {};
            })();

            const stopTyping = () => {
                if (isTyping) {
                    socket.emit('typing_end', roomPayload);
                    isTyping = false;
                }
                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = null;
            };

            commentInput.addEventListener('input', () => {
                if (!isTyping) {
                    socket.emit('typing_start', roomPayload);
                    isTyping = true;
                }

                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = setTimeout(stopTyping, 2000);
            });

            commentInput.addEventListener('blur', stopTyping);
        }

        socket.on('file_status_update', (data) => {
            const feedRefresh = data.status === 'approved' || data.status === 'published'
                || data.status === 'pending' || data.status === 'scheduled';
            if (feedRefresh) {
                const pendingList = document.querySelector('.pending-files-container');
                if (pendingList && (data.status === 'approved' || data.status === 'published')) {
                    location.reload(); // Reload dashboard to update list
                    return;
                }

                if (data.feed_item && typeof window.applyNewFileToIndexFeed === 'function') {
                    window.applyNewFileToIndexFeed(data.feed_item);
                }
                if (data.feed_item && typeof window.bumpVipNewBadgeIfNeeded === 'function') {
                    window.bumpVipNewBadgeIfNeeded(data.feed_item);
                }
                if (data.status === 'approved' || data.status === 'published') {
                    document.querySelectorAll('[data-file-id="' + String(data.id) + '"]').forEach((item) => {
                        const publishIcon = item.querySelector('.file-publish-status-icon');
                        if (publishIcon) publishIcon.classList.add('hidden');
                    });
                }
            }
            if (data.status === 'approved') {

                // Update Header Notification Count (Decremet)
                const badges = document.querySelectorAll('.notification-header .badge');
                badges.forEach(b => {
                    let count = parseInt(b.textContent);
                    if (!isNaN(count) && count > 0) {
                        count--;
                        b.textContent = count;
                        // Hide badge if 0?
                    }
                });
            }
        });

        function updateBadge() {
            if (badge) {
                if (unreadCount > 0) {
                    badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
                    badge.classList.remove('hidden');
                } else {
                    badge.classList.add('hidden');
                }
            }
        }

        function ensureChatContextMenu() {
            if (chatContextMenu) return chatContextMenu;
            chatContextMenu = document.createElement('div');
            chatContextMenu.id = 'chat-context-menu';
            chatContextMenu.className = 'chat-context-menu hidden';
            document.body.appendChild(chatContextMenu);
            return chatContextMenu;
        }

        function hideChatContextMenu() {
            if (!chatContextMenu) return;
            chatContextMenu.classList.add('hidden');
            chatContextMenu.innerHTML = '';
        }

        function showChatContextMenu(x, y, msgData) {
            if (!chatCanWrite && !isAdminOrMod) return;
            const menu = ensureChatContextMenu();
            const actions = [];
            if (chatCanWrite) {
                actions.push({
                    id: 'reply',
                    label: `Reply to @${msgData.username}`,
                    icon: 'fas fa-reply',
                    onClick: () => window.setChatReply(msgData.username)
                });
            }

            if (isAdminOrMod) {
                const pendingRow = document.getElementById(`msg-${msgData.id}`);
                const isPendingRow = pendingRow && pendingRow.dataset.pending === 'true';
                if (isPendingRow) {
                    actions.push({
                        id: 'approve',
                        label: 'Approve message',
                        icon: 'fas fa-check',
                        onClick: () => window.requestApproveChatMessage(msgData.id)
                    });
                }
                actions.push({
                    id: 'delete',
                    label: 'Delete message',
                    icon: 'fas fa-trash',
                    danger: true,
                    onClick: () => window.requestDelete(msgData.id)
                });
            }

            if (!actions.length) return;

            menu.innerHTML = actions.map(action => `
                <button type="button" class="chat-context-action ${action.danger ? 'danger' : ''}" data-action-id="${action.id}">
                    <i class="${action.icon}"></i>
                    <span>${action.label}</span>
                </button>
            `).join('');

            menu.querySelectorAll('.chat-context-action').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const actionId = btn.getAttribute('data-action-id');
                    const action = actions.find(a => a.id === actionId);
                    if (action) action.onClick();
                    hideChatContextMenu();
                });
            });

            menu.classList.remove('hidden');
            const menuRect = menu.getBoundingClientRect();
            const maxLeft = window.innerWidth - menuRect.width - 8;
            const maxTop = window.innerHeight - menuRect.height - 8;
            menu.style.left = `${Math.max(8, Math.min(x, maxLeft))}px`;
            menu.style.top = `${Math.max(8, Math.min(y, maxTop))}px`;
        }

        function getLastReadTime() {
            const stored = localStorage.getItem(LAST_READ_KEY);
            // If never read, default to now (so old history isn't all unread on first visit)
            return stored ? parseFloat(stored) : Date.now() / 1000;
        }

        function markAsRead() {
            // Save current timestamp (backend sends seconds, so match that)
            localStorage.setItem(LAST_READ_KEY, Date.now() / 1000);
        }

        // Sending
        if (input && sendBtn) {
            let cancelEditBtn = chatContainer.querySelector('#chat-cancel-edit-btn');
            if (!cancelEditBtn) {
                cancelEditBtn = document.createElement('button');
                cancelEditBtn.id = 'chat-cancel-edit-btn';
                cancelEditBtn.className = 'chat-action-btn chat-cancel-edit-btn hidden';
                cancelEditBtn.type = 'button';
                cancelEditBtn.innerHTML = '<i class="fas fa-times"></i>';
                sendBtn.parentElement.appendChild(cancelEditBtn);
            }

            const setComposeMode = () => {
                editingMessageId = null;
                input.placeholder = 'Type a message…';
                sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
                cancelEditBtn.classList.add('hidden');
            };

            const setEditMode = (msgId, msgText) => {
                editingMessageId = msgId;
                input.value = msgText || '';
                input.placeholder = 'Edit message...';
                sendBtn.innerHTML = '<i class="fas fa-check"></i>';
                cancelEditBtn.classList.remove('hidden');
                if (!isMobile()) input.focus();
                input.setSelectionRange(input.value.length, input.value.length);
            };

            cancelEditBtn.addEventListener('click', () => {
                setComposeMode();
                input.value = '';
            });

            const sendMessage = () => {
                const msg = input.value.trim();
                if (msg) {
                    if (editingMessageId) {
                        socket.emit('edit_message', { id: editingMessageId, msg: msg });
                        setComposeMode();
                    } else {
                        socket.emit('message', { msg: msg });
                    }
                    input.value = '';
                    if (!isMobile()) input.focus();
                    if (emojiPicker) emojiPicker.classList.add('hidden');
                }
            };

            sendBtn.addEventListener('click', sendMessage);
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });

            // Typing Indicator Emission (v38: Optimized)
            let typingTimeout = null;
            let isTyping = false;

            const stopTypingGlobal = () => {
                if (isTyping) {
                    socket.emit('typing_end', { file_id: window.currentFileId || 'global_chat' });
                    isTyping = false;
                }
                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = null;
            };

            input.addEventListener('input', () => {
                if (!isTyping && input.value.length > 0) {
                    socket.emit('typing_start', { file_id: 'global_chat' });
                    isTyping = true;
                }

                if (input.value.length === 0) {
                    stopTypingGlobal();
                    return;
                }

                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = setTimeout(stopTypingGlobal, 2000);
            });

            input.addEventListener('blur', stopTypingGlobal);
        }

        // Helpers
        function normalizeChatMessageHtml(rawHtml) {
            if (!rawHtml) return '';
            const wrapper = document.createElement('div');
            wrapper.innerHTML = rawHtml;

            // Convert legacy mention markup:
            // <span class="mention ..."><a class="username-tag ..."><img ...>name...</a></span>
            // into compact new format:
            // <a class="mention mention-link ...">@name,</a>
            wrapper.querySelectorAll('.mention a.username-tag').forEach((legacyAnchor) => {
                const href = legacyAnchor.getAttribute('href') || '#';
                const roleClass = (legacyAnchor.className || '')
                    .split(' ')
                    .find((c) => ['admin', 'moderator', 'user'].includes(c)) || '';
                const username = (legacyAnchor.textContent || '').trim();
                const cleanName = username.replace(/^@/, '').replace(/:$/, '');
                const replacement = document.createElement('a');
                replacement.href = href;
                replacement.className = `mention mention-link${roleClass ? ' ' + roleClass : ''}`;
                replacement.textContent = `@${cleanName},`;
                const legacyWrap = legacyAnchor.closest('.mention');
                if (legacyWrap) {
                    legacyWrap.replaceWith(replacement);
                }
            });

            // Normalize mention chips to keep comma INSIDE and remove accidental extra comma after it.
            wrapper.querySelectorAll('a.mention.mention-link').forEach((mentionAnchor) => {
                const current = (mentionAnchor.textContent || '').trim();
                const clean = current.replace(/^@/, '').replace(/,+\s*$/, '');
                mentionAnchor.textContent = `@${clean},`;
                const next = mentionAnchor.nextSibling;
                if (next && next.nodeType === Node.TEXT_NODE) {
                    next.textContent = (next.textContent || '').replace(/^\s*,\s*/, ' ');
                }
            });

            return wrapper.innerHTML;
        }

        function formatChatTimeHtml(data) {
            const label = escapeHtml(data.time || '');
            const title = escapeHtml(data.time_precise || '');
            const ts = data.timestamp_raw;
            if (ts != null && ts !== '') {
                return `<time class="chat-msg-time telemetry-pod" title="${title}" data-ulp-time-ts="${escapeHtml(String(ts))}"><i class="far fa-clock" aria-hidden="true"></i> <span class="ulp-live-time">${label}</span></time>`;
            }
            return `<time class="chat-msg-time telemetry-pod" title="${title}"><i class="far fa-clock" aria-hidden="true"></i> ${label}</time>`;
        }

        function appendMessage(data) {
            const div = document.createElement('div');
            div.className = 'chat-msg';
            if (data.is_pending || data.is_approved === false) {
                div.classList.add('chat-msg-pending');
                div.dataset.pending = 'true';
            }
            div.id = `msg-${data.id}`;
            div.dataset.msgId = String(data.id);
            div.dataset.username = data.username || '';

            const role = (data.role || '').toLowerCase();
            const roleSuffix =
                role === 'admin' || role === 'moderator' || role === 'vip' || role === 'user' ? role : 'user';
            const usernameClass = `username-tag ${roleSuffix}`;
            const avatarUrl = data.avatar
                ? `/static/uploads/profiles/${data.avatar}`
                : window.ulpResolveAvatarUrl(data);

            const avatarHtml = `<span class="user-avatar-slot"><img src="${avatarUrl}" class="user-avatar-circle" alt=""></span>`;

            // data.msg comes from backend mention_to_link() which already HTML-escapes and link-converts.
            // Do NOT re-process through parseLinks here — that would double-escape the HTML.
            const msgHtml = normalizeChatMessageHtml(data.msg || '');

            let groupsHtml = '';
            try {
                let groupsArr = [];
                if (Array.isArray(data.groups)) {
                    groupsArr = data.groups;
                } else if (typeof data.groups === 'string') {
                    try { groupsArr = JSON.parse(data.groups); } catch (e) { groupsArr = []; }
                    if (!Array.isArray(groupsArr)) groupsArr = [];
                } else if (data.groups) {
                    groupsArr = [data.groups];
                }

                if (groupsArr.length > 0) {
                    if (typeof window.formatGroupBadgePileHtml === 'function') {
                        groupsHtml = window.formatGroupBadgePileHtml(groupsArr) || '';
                    } else {
                        groupsArr.forEach(g => {
                            const safeName = escapeHtml(g?.name || '');
                            const iconRaw = (g?.icon || 'fas fa-star') + '';
                            const norm =
                                typeof window.normalizeFaIconClass === 'function'
                                    ? window.normalizeFaIconClass(iconRaw)
                                    : (function () {
                                          const m = iconRaw.match(/fa-(?!solid\b|regular\b|brands\b)[a-z0-9-]+/i);
                                          let tok = m ? m[0] : 'fa-star';
                                          if (['fa-shield-alt', 'fa-shield-halved'].includes(tok.toLowerCase())) {
                                              tok = 'fa-shield';
                                          }
                                          return `fa-solid ${tok}`;
                                      })();
                            const safeIcon = escapeHtml(norm);
                            const safeColor = escapeHtml(g?.color || '#00ff9d');
                            const safeIconColor = escapeHtml(g?.icon_color || '#f5f8ff');
                            groupsHtml += `<span class="group-badge" title="${safeName}" style="--badge-bg: ${safeColor}; --badge-icon-color: ${safeIconColor}; background-color: var(--badge-bg);"><i class="${safeIcon}"></i></span>`;
                        });
                        if (groupsHtml.trim()) {
                            groupsHtml = `<span class="group-badge-pile" aria-hidden="true">${groupsHtml.trim()}</span>`;
                        }
                    }
                }
            } catch (e) {
                console.warn('Chat: groups render failed, continuing without group icons.', e);
            }

            const verifiedHtml = data.is_verified ? `<i class="fas fa-check-circle verified-badge" title="Verified"></i>` : '';
            const isOwner = (data.username || '').toLowerCase() === (myUsername || '').toLowerCase();
            const isPending = data.is_pending || data.is_approved === false;
            const canManage = chatCanWrite && (isOwner || isAdminOrMod);
            const pendingBadge = isPending
                ? '<span class="chat-msg-pending-badge telemetry-pod" title="Awaiting moderator approval"><i class="fas fa-hourglass-half" aria-hidden="true"></i> pending</span>'
                : '';
            const staffApproveBtn = (isAdminOrMod && isPending)
                ? `<button type="button" class="chat-msg-act-btn chat-msg-act-btn--approve" title="Approve message" data-ulp-chat-action="approve" data-msg-id="${escapeHtml(data.id)}">
                        <i class="fas fa-check"></i>
                    </button>`
                : '';
            const showActions = chatCanWrite || (isAdminOrMod && isPending);
            const actionsHtml = showActions ? `
                <div class="chat-msg-actions">
                    ${chatCanWrite ? `
                    <button type="button" class="chat-msg-act-btn" title="Mention user" data-ulp-chat-action="reply" data-username="${escapeHtml(data.username)}">
                        <i class="fas fa-at"></i>
                    </button>` : ''}
                    ${staffApproveBtn}
                    ${canManage ? `
                    <button type="button" class="chat-msg-act-btn" title="Edit message" data-ulp-chat-action="edit" data-msg-id="${escapeHtml(data.id)}">
                        <i class="fas fa-pen"></i>
                    </button>` : ''}
                    ${canManage || (isAdminOrMod && isPending) ? `
                    <button type="button" class="chat-msg-act-btn chat-msg-act-btn--danger" title="Delete message" data-ulp-chat-action="delete" data-msg-id="${escapeHtml(data.id)}">
                        <i class="fas fa-trash"></i>
                    </button>` : ''}
                </div>
            ` : '';
            const safeMsgHtml = (typeof window.ulpSanitizeRichHtml === 'function')
                ? window.ulpSanitizeRichHtml(msgHtml)
                : msgHtml;
            div.innerHTML = `
                <div class="chat-msg-top">
                    <a href="/user/${encodeURIComponent(data.username || '')}" class="chat-msg-author ${usernameClass}">
                        ${avatarHtml}${escapeHtml(data.username)}${verifiedHtml}${groupsHtml}
                    </a>
                    ${pendingBadge}
                    ${formatChatTimeHtml(data)}
                    ${actionsHtml}
                </div>
                <div class="chat-msg-body">
                    <div class="comment-content">${safeMsgHtml}</div>
                </div>`;

            messagesDiv.appendChild(div);
            if (typeof window.ulpUpdateLiveTimes === 'function') {
                window.ulpUpdateLiveTimes(div);
            }
        }

        function addSystemMessage(text) {
            const div = document.createElement('div');
            div.className = 'chat-system-msg';
            div.innerText = text;
            messagesDiv.appendChild(div);
            scrollToBottom();
        }

        function scrollToBottom() {
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function escapeHtml(text) {
            if (text == null) return '';
            const s = String(text);
            return s
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#039;');
        }

        // Make delete request global so onclick works
        window.requestDelete = async function (msgId) {
            const msgEl = document.getElementById(`msg-${msgId}`);
            const msgAuthor = (msgEl && msgEl.dataset.username) || '';
            const isOwner = msgAuthor.toLowerCase() === (myUsername || '').toLowerCase();
            const staffDeletingOther = isAdminOrMod && !isOwner;
            const payload = { id: msgId };

            if (staffDeletingOther) {
                if (typeof window.promptDeletionReason === 'function') {
                    const reason = await window.promptDeletionReason({
                        title: 'Delete chat message',
                        confirmLabel: 'Delete message',
                    });
                    if (reason === null) return;
                    if (reason) payload.deletion_reason = reason;
                } else if (!confirm('Delete this message?')) {
                    return;
                }
            } else if (!confirm('Delete this message?')) {
                return;
            }

            socket.emit('delete_message', payload);
        };

        window.requestApproveChatMessage = function (msgId) {
            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
            fetch(`/admin/approve_chat_message/${msgId}?ajax=true`, {
                method: 'POST',
                headers: { 'X-CSRFToken': csrf, 'X-Requested-With': 'XMLHttpRequest' },
            })
                .then(async (r) => {
                    let data;
                    try {
                        data = await r.json();
                    } catch (_) {
                        data = { status: 'error', message: 'Invalid server response.' };
                    }
                    return data;
                })
                .then((data) => {
                    if (data.status === 'success' || data.status === 'info') {
                        markChatMessageApproved(msgId);
                        if (typeof window.applyPendingFromModerationResponse === 'function') {
                            window.applyPendingFromModerationResponse(data);
                        }
                        if (typeof window.showToast === 'function') {
                            window.showToast('Approved', data.message || 'Chat message approved.', null, 'fas fa-check', null, 'success');
                        }
                    } else if (typeof window.showToast === 'function') {
                        window.showToast('Error', data.message || 'Could not approve message.', null, 'fas fa-times', null, 'error');
                    }
                })
                .catch(() => {
                    if (typeof window.showToast === 'function') {
                        window.showToast('Error', 'Connection error. Try again.', null, 'fas fa-times', null, 'error');
                    }
                });
        };

        window.requestEdit = function (msgId) {
            const msgElement = document.getElementById(`msg-${msgId}`);
            if (!msgElement) return;
            const contentEl = msgElement.querySelector('.comment-content');
            if (!contentEl) return;
            const currentText = (contentEl.textContent || '').trim();
            const cancelEditBtn = chatContainer.querySelector('#chat-cancel-edit-btn');
            editingMessageId = msgId;
            input.value = currentText;
            input.placeholder = 'Edit message...';
            sendBtn.innerHTML = '<i class="fas fa-check"></i>';
            if (cancelEditBtn) cancelEditBtn.classList.remove('hidden');
            if (!isMobile()) input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
        };

        messagesDiv.addEventListener('contextmenu', (e) => {
            const msgEl = e.target.closest('.chat-msg');
            if (!msgEl) return;
            e.preventDefault();
            const msgId = msgEl.dataset.msgId;
            const username = msgEl.dataset.username;
            if (!msgId || !username) return;
            showChatContextMenu(e.clientX, e.clientY, { id: msgId, username });
        });

        messagesDiv.addEventListener('touchstart', (e) => {
            const msgEl = e.target.closest('.chat-msg');
            if (!msgEl) return;
            const touch = e.touches && e.touches[0];
            if (!touch) return;
            const msgId = msgEl.dataset.msgId;
            const username = msgEl.dataset.username;
            if (!msgId || !username) return;
            longPressTimer = setTimeout(() => {
                showChatContextMenu(touch.clientX, touch.clientY, { id: msgId, username });
            }, LONG_PRESS_MS);
        }, { passive: true });

        const cancelLongPress = () => {
            if (longPressTimer) {
                clearTimeout(longPressTimer);
                longPressTimer = null;
            }
        };
        messagesDiv.addEventListener('touchend', cancelLongPress, { passive: true });
        messagesDiv.addEventListener('touchmove', cancelLongPress, { passive: true });
        messagesDiv.addEventListener('touchcancel', cancelLongPress, { passive: true });

        if (!window.__ulpChatMsgControlsDeleg) {
            window.__ulpChatMsgControlsDeleg = true;
            document.addEventListener('click', (e) => {
                const btn = e.target.closest('[data-ulp-chat-action]');
                if (!btn) return;
                const action = btn.getAttribute('data-ulp-chat-action');
                if (action === 'reply') {
                    const un = btn.getAttribute('data-username');
                    if (un && typeof window.setChatReply === 'function') window.setChatReply(un);
                } else if (action === 'edit') {
                    const id = btn.getAttribute('data-msg-id');
                    if (id && typeof window.requestEdit === 'function') window.requestEdit(id);
                } else if (action === 'approve') {
                    const id = btn.getAttribute('data-msg-id');
                    if (id && typeof window.requestApproveChatMessage === 'function') window.requestApproveChatMessage(id);
                } else if (action === 'delete') {
                    const id = btn.getAttribute('data-msg-id');
                    if (id && typeof window.requestDelete === 'function') window.requestDelete(id);
                }
            });
        }

        document.addEventListener('click', (e) => {
            if (!chatContextMenu || chatContextMenu.classList.contains('hidden')) return;
            if (!e.target.closest('#chat-context-menu')) {
                hideChatContextMenu();
            }
        });
        window.addEventListener('scroll', hideChatContextMenu, { passive: true });

        // --- Clear Chat Logic ---
        const clearBtn = chatContainer.querySelector('#chat-clear-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                if (confirm('Are you sure you want to CLEAR ALL chat history? This cannot be undone.')) {
                    socket.emit('clear_chat');
                }
            });
        }

        socket.on('chat_cleared', () => {
            messagesDiv.innerHTML = '';
            addSystemMessage('Chat history has been cleared by an administrator.');
        });

        // Initial scroll to bottom
        scrollToBottom();
    });

    // --- SPA Helper for File Rooms ---
    window._chatCurrentRoom = null; // Track specific room (file/resource) global-style for reliability

    window.cleanupChatRoom = function () {
        if (typeof io === 'undefined' || !window.getSharedSocket) return;
        const socket = window.getSharedSocket();

        if (!window._chatCurrentRoom) {
            return;
        }

        const room = window._chatCurrentRoom;
        if (room.type === 'file') {
            socket.emit('leave_file', { file_id: room.id });
        } else if (room.type === 'resource') {
            socket.emit('leave_resource', { listing_id: room.id });
        }
        window._chatCurrentRoom = null;
    };

    window.initializeFileRoom = function (type, id) {
        if (typeof io === 'undefined' || !window.getSharedSocket) return;
        if (!type || !id) {
            console.warn('Chat: initializeFileRoom called without type or id');
            return;
        }

        const socket = window.getSharedSocket();
        const prev = window._chatCurrentRoom;
        // Critical: resync runs on connect + delayed debounce. Re-calling cleanup+join for the SAME
        // room emitted leave_file and briefly (or permanently if a race hit) evicted the viewer pile.
        if (prev && prev.type === type && String(prev.id) === String(id)) {
            if (type === 'file') {
                socket.emit('join_file', { file_id: id });
            } else if (type === 'resource') {
                socket.emit('join_resource', { listing_id: id });
            }
            return;
        }

        window.cleanupChatRoom();
        window._chatCurrentRoom = { type: type, id: id };

        if (type === 'file') {
            socket.emit('join_file', { file_id: id });
        } else if (type === 'resource') {
            socket.emit('join_resource', { listing_id: id });
        }

        // 2. Setup Typing Emitters if input exists
        const commentInput = document.getElementById('comment-input');
        if (commentInput) {
            let typingTimeout = null;
            let isTyping = false;

            const stopTypingFile = () => {
                if (isTyping) {
                    const emitData = type === 'file' ? { file_id: id } : { listing_id: id };
                    socket.emit('typing_end', emitData);
                    isTyping = false;
                }
                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = null;
            };

            commentInput.addEventListener('input', () => {
                if (!isTyping && commentInput.value.length > 0) {
                    const emitData = type === 'file' ? { file_id: id } : { listing_id: id };
                    socket.emit('typing_start', emitData);
                    isTyping = true;
                }

                if (commentInput.value.length === 0) {
                    stopTypingFile();
                    return;
                }

                if (typingTimeout) clearTimeout(typingTimeout);
                typingTimeout = setTimeout(stopTypingFile, 2000);
            });

            commentInput.addEventListener('blur', stopTypingFile);
        }

        // 3. Tab Close Fallback
        window.addEventListener('beforeunload', () => {
            if (window._chatCurrentRoom) window.cleanupChatRoom();
        }, { once: true });
    };
}
