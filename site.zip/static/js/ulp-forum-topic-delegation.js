/**
 * Forum topic page UI — data-attribute delegation (CSP script-src-attr).
 */
(function () {
    'use strict';

    if (window.__ulpForumTopicDeleg) return;
    window.__ulpForumTopicDeleg = true;

    document.addEventListener('click', function (e) {
        if (e.target.closest('.ulp-stop-propagation, .list-bulk-checkbox-cell')) {
            e.stopPropagation();
        }

        var actEl = e.target.closest('[data-ulp-forum-action]');
        if (!actEl) return;

        var action = actEl.getAttribute('data-ulp-forum-action');
        var postId = actEl.getAttribute('data-post-id');

        if (action === 'reply-jump') {
            if (actEl.disabled || actEl.getAttribute('aria-disabled') === 'true') return;
            if (typeof window.jumpToForumReplyEditor === 'function') {
                e.preventDefault();
                window.jumpToForumReplyEditor(e);
            }
            return;
        }
        if (action === 'send-reply' && typeof window.sendForumReply === 'function') {
            e.preventDefault();
            window.sendForumReply();
            return;
        }
        if (action === 'cancel-inline-edit' && typeof window.cancelForumInlineEdit === 'function') {
            e.preventDefault();
            window.cancelForumInlineEdit();
            return;
        }
        if (action === 'close-edit-modal' && typeof window.closeForumEditModal === 'function') {
            e.preventDefault();
            window.closeForumEditModal();
            return;
        }
        if (action === 'submit-edit' && typeof window.submitForumPostEdit === 'function') {
            e.preventDefault();
            window.submitForumPostEdit();
            return;
        }
        if (action === 'edit' && postId && typeof window.editForumPost === 'function') {
            e.preventDefault();
            window.editForumPost(postId);
            return;
        }
        if (action === 'delete' && postId && typeof window.deleteForumPost === 'function') {
            e.preventDefault();
            window.deleteForumPost(postId);
            return;
        }
        if (action === 'reply') {
            var user = actEl.getAttribute('data-reply-user');
            if (user && typeof window.setForumReply === 'function') {
                e.preventDefault();
                window.setForumReply(user);
            }
            return;
        }
        if (action === 'like' && postId && typeof window.toggleForumPostLike === 'function') {
            e.preventDefault();
            window.toggleForumPostLike(postId);
            return;
        }
        if (action === 'like-login' && typeof window.requireLogin === 'function') {
            e.preventDefault();
            window.requireLogin(
                'Please login or register to like forum posts.',
                window.location.pathname + window.location.search
            );
            return;
        }
        if (action === 'bulk-approve' && typeof window.bulkApproveForumPosts === 'function') {
            e.preventDefault();
            window.bulkApproveForumPosts();
            return;
        }
        if (action === 'bulk-delete' && typeof window.bulkDeleteForumPosts === 'function') {
            e.preventDefault();
            window.bulkDeleteForumPosts();
            return;
        }
    });

    document.addEventListener('change', function (e) {
        var t = e.target;
        if (!t || t.tagName !== 'INPUT') return;
        if (t.id === 'select-all-forum-posts' && typeof window.toggleSelectAllForumPosts === 'function') {
            window.toggleSelectAllForumPosts(t);
            return;
        }
        if (t.classList && t.classList.contains('forum-post-checkbox') && typeof window.updateForumPostSelection === 'function') {
            window.updateForumPostSelection();
        }
    });
})();
