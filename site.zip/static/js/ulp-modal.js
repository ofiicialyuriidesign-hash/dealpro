/**
 * Universal modal, logout, requireLogin, flash helpers.
 * Extracted from templates/base.html (CSP hardening).
 */
(function () {
    'use strict';

try {
    // Universal Modal Logic
    const modal = document.getElementById('universal-modal');
    const modalContent = document.getElementById('modal-content-area');

    if (!modal) console.error('Critical: Modal container not found!');

    /** Always resolve live nodes (SPA swaps must never leave us pointing at detached subtrees). */
    function getUniversalModalElements() {
        return {
            modalEl: document.getElementById('universal-modal'),
            contentEl: document.getElementById('modal-content-area')
        };
    }

    window.ulpCspNonce = function () {
        const nm = document.querySelector('meta[name="csp-nonce"]');
        return (nm && nm.content) ? nm.content : '';
    };

    function ulpIsExecutableScriptType(scriptEl) {
        const type = (scriptEl.getAttribute('type') || '').trim().toLowerCase();
        if (!type) return true;
        return type === 'text/javascript' || type === 'application/javascript' || type === 'module';
    }

    // Helper to execute scripts in injected content (modal / SPA fragments).
    // Always use the live document nonce — fetched HTML may carry a stale per-response nonce.
    function executeScripts(container) {
        if (typeof window.ulpRunPageScripts === 'function') {
            window.ulpRunPageScripts(container);
            return;
        }
        const nonce = window.ulpCspNonce();
        container.querySelectorAll('script').forEach((script) => {
            if (!ulpIsExecutableScriptType(script)) return;
            const newScript = document.createElement('script');
            Array.from(script.attributes).forEach((attr) => {
                if (attr.name === 'nonce') return;
                newScript.setAttribute(attr.name, attr.value);
            });
            if (nonce) newScript.setAttribute('nonce', nonce);
            newScript.text = script.text;
            document.body.appendChild(newScript);
            document.body.removeChild(newScript);
            script.remove();
        });
    }

    // Helper to just show the modal with content
    window.showModalContent = function (html) {
        const { modalEl, contentEl } = getUniversalModalElements();
        if (!contentEl || !modalEl) return;

        // Apply Cyber Card styling to ALL modals
        const container = document.querySelector('.modal-container');
        if (container) {
            container.classList.add('cyber-card');
        }

        contentEl.innerHTML = html;
        modalEl.setAttribute('aria-hidden', 'false');
        modalEl.classList.add('active');
        document.body.style.overflow = 'hidden';
        executeScripts(contentEl);
    };

    // Unified Ban Modal (RESTRICTION EXECUTION)
    window.openBanModal = function (target, username = 'Identity') {
        let formAction = '';
        if (typeof target === 'object' && target !== null && target.tagName === 'FORM') {
            formAction = target.action;
        } else {
            formAction = `/admin/ban_user/${target}`;
        }

        const container = document.querySelector('.modal-container');
        if (container) {
            container.classList.remove('auth-modal');
            container.classList.add('auth-modal');
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

        const modalHtml = `
            <div class="modal-header" style="border-bottom: 2px solid var(--adm-border, #333); padding: 1.5rem; margin: 0 -1.5rem 1.5rem -1.5rem;">
                <h2 style="color: var(--adm-danger, #ff4757); margin: 0; font-family: var(--font-mono); font-size: 1.1rem; text-transform: uppercase; letter-spacing: 2px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-slash"></i> RESTRICTION EXECUTION
                </h2>
            </div>
            <div class="modal-body" style="padding: 0;">
                <p style="margin-bottom: 2rem; color: #e0e0e0; line-height: 1.6; font-size: 0.95rem;">Initiate security lockdown for identity: <strong style="color: var(--adm-danger);">${username}</strong>?</p>
                <form action="${formAction}" method="POST" data-ulp-modal-ban-form="1">
                    <input type="hidden" name="csrf_token" value="${csrfToken}">
                    <div style="margin-bottom: 2.5rem;">
                        <label for="modal-ban-reason" style="display:block; margin-bottom:0.75rem; color: #888; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 1.5px; font-family: var(--font-mono);">Violation Code / Reason</label>
                        <input type="text" id="modal-ban-reason" name="reason" class="cyber-input" placeholder="e.g. Terms Violation, Spamming..." required
                               style="width: 100%; border-color: var(--adm-border); background: rgba(0,0,0,0.3); color: #fff; padding: 12px; font-family: var(--font-mono);">
                    </div>
                    <div style="display: flex; gap: 15px;">
                        <button type="submit" class="btn btn-danger" style="flex: 2; background: rgba(255, 71, 87, 0.1); border: 1px solid var(--adm-danger); color: var(--adm-danger); font-family: var(--font-mono); font-weight: bold; text-transform: uppercase; letter-spacing: 1px; padding: 12px;">Execute</button>
                        <button type="button" class="btn" data-modal-close style="flex: 1; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.1); color: #fff; font-family: var(--font-mono); font-weight: bold; text-transform: uppercase; letter-spacing: 1px; padding: 12px;">Abort</button>
                    </div>
                </form>
            </div>
        `;

        if (window.showModalContent) {
            window.showModalContent(modalHtml);
            // Force re-padding for cyber-card content within auth-modal context if needed
            const contentArea = document.getElementById('modal-content-area');
            if (contentArea) {
                contentArea.style.padding = '1.5rem';
            }
            // Focus reason input
            setTimeout(() => {
                const input = document.querySelector('input[name="reason"]');
                if (input) input.focus();
            }, 50);
        }
    };

    // Helper to fetch content from URL
    window.openModal = function (url) {
        // Profile pages should always open as full pages, not in modal.
        if (url && (url.includes('/user/') || url.includes('/profile/'))) {
            if (window.loadPage) {
                window.loadPage(url);
            } else {
                window.location.href = url;
            }
            return;
        }

        // Reset modal classes
        const container = document.querySelector('.modal-container');
        if (container) {
            container.classList.remove('auth-modal');
            // Apply Cyber Card styling to ALL modals
            container.classList.add('cyber-card');

            // Check if auth url to make it narrower
            if (url.includes('login') || url.includes('register')) {
                container.classList.add('auth-modal');
            }
        }

        const { modalEl: openModalEl, contentEl: openContentEl } = getUniversalModalElements();
        if (openModalEl) {
            openModalEl.setAttribute('aria-hidden', 'false');
            openModalEl.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        if (openContentEl && openModalEl) {
            // Smooth transition: if modal is already open, just dim it. Otherwise show spinner.
            if (openModalEl.classList.contains('active')) {
                openContentEl.style.opacity = '0.5';
            } else {
                openContentEl.innerHTML = '<div style="flex: 1; display: flex; align-items: center; justify-content: center; height: 300px; color: var(--primary-color);"><i class="fas fa-spinner fa-spin fa-3x"></i></div>';
            }
        }

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-Modal': 'true'
            }
        })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.text();
            })
            .then(html => {
                // If we got a full page (likely a redirect to login), reload top level
                if (html.includes('id="chat-widget-container"')) {
                    window.location.href = url;
                    return;
                }

                const { contentEl: fetchedContentEl } = getUniversalModalElements();
                if (fetchedContentEl) {
                    fetchedContentEl.innerHTML = html;
                    fetchedContentEl.style.opacity = '1';
                    executeScripts(fetchedContentEl);
                    if (window.initFlashAutoHide) window.initFlashAutoHide();
                }
            })
            .catch(err => {
                console.error('Modal Fetch Error:', err);
                const { contentEl: errContentEl } = getUniversalModalElements();
                if (errContentEl) errContentEl.innerHTML = '<div class="text-error text-center p-4">Error loading content. Check your connection.</div>';
            });
    };

    window.closeModal = function () {
        const { modalEl: closeModalEl, contentEl: closeContentEl } = getUniversalModalElements();
        if (!closeModalEl) return;
        closeModalEl.classList.remove('active');
        document.body.style.overflow = '';
        setTimeout(() => {
            if (closeContentEl) closeContentEl.innerHTML = '';
            const container = document.querySelector('.modal-container');
            if (container) {
                // Reset all specialized sizing classes
                container.className = 'modal-container cyber-card';
            }
            closeModalEl.setAttribute('aria-hidden', 'true');
        }, 300);
    };

    /** When spa.js intercepts /logout but spaLogout is not yet defined, POST (never GET). */
    window.__ulpPostLogoutFallback = function (logoutUrl) {
        var u = String(logoutUrl || '/logout');
        var t = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
        var f = document.createElement('form');
        f.method = 'POST';
        f.action = u;
        var h = document.createElement('input');
        h.type = 'hidden';
        h.name = 'csrf_token';
        h.value = t;
        f.appendChild(h);
        document.body.appendChild(f);
        f.submit();
    };

    window.spaLogout = function (logoutUrl) {
        const targetUrl = String(logoutUrl || '/logout');
        const csrfToken = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
        const navigateAfter = function (nextUrl) {
            const safeUrl = nextUrl || '/';
            if (window.closeModal) window.closeModal();
            if (window.loadPage) {
                window.loadPage(safeUrl);
            } else {
                window.location.href = safeUrl;
            }
        };
        fetch(targetUrl, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRFToken': csrfToken
            }
        })
            .then(async (response) => {
                const ctype = (response.headers.get('content-type') || '').toLowerCase();
                if (ctype.includes('application/json')) {
                    const data = await response.json();
                    if (data && data.success) {
                        navigateAfter(data.redirect_url || '/');
                        return;
                    }
                } else if (response.redirected) {
                    navigateAfter(response.url);
                    return;
                } else if (response.ok) {
                    navigateAfter('/');
                    return;
                }
                throw new Error('logout failed');
            })
            .catch(() => {
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = targetUrl;
                var hid = document.createElement('input');
                hid.type = 'hidden';
                hid.name = 'csrf_token';
                hid.value = csrfToken;
                form.appendChild(hid);
                document.body.appendChild(form);
                form.submit();
            });
    };

    window.confirmLogout = function (logoutUrl) {
        const safeUrl = String(logoutUrl || '/logout').replace(/"/g, '&quot;');
        const modalHtml = `
            <div class="modal-header logout-modal-header">
                <h2 class="logout-modal-title">
                    <i class="fas fa-right-from-bracket" aria-hidden="true"></i>
                    <span>Sign out</span>
                </h2>
                <button type="button" class="modal-close-btn" data-modal-close="1" aria-label="Close">
                    <i class="fas fa-times" aria-hidden="true"></i>
                </button>
            </div>
            <div class="modal-body logout-modal-body">
                <p class="logout-modal-text">Are you sure you want to sign out of your account?</p>
                <div class="logout-modal-actions">
                    <button type="button" data-modal-close="1" class="btn btn-toolbar logout-modal-cancel">Cancel</button>
                    <button type="button" data-spa-logout-confirm="1" data-logout-url="${safeUrl}" class="btn btn-toolbar logout-modal-signout">
                        <i class="fas fa-power-off" aria-hidden="true"></i>
                        <span>Sign out</span>
                    </button>
                </div>
            </div>
        `;
        if (window.showModalContent) {
            const container = document.querySelector('.modal-container');
            if (container) {
                container.classList.remove(
                    'auth-modal',
                    'upload-modal-container',
                    'upload-modal-container--bulk',
                    'crypto-checkout-modal',
                    'crypto-checkout-modal--vip'
                );
                container.classList.add('cyber-card', 'logout-modal');
            }
            window.showModalContent(modalHtml);
        } else if (confirm('Sign out of your account?')) {
            window.spaLogout(logoutUrl);
        }
    };

    // Unified login-required UX: show toast with direct auth links
    window.requireLogin = function (message = 'Please login to continue.', nextUrl = null) {
        const loginTarget = nextUrl ? `/login?next=${encodeURIComponent(nextUrl)}` : '/login';
        const registerTarget = nextUrl ? `/register?next=${encodeURIComponent(nextUrl)}` : '/register';
        const esc = typeof window.ulpEscapeHtml === 'function' ? window.ulpEscapeHtml : function (s) { return String(s == null ? '' : s); };
        const authLinks = `<a href="${loginTarget}" class="spa-link" style="color: var(--primary-color); text-decoration: underline; font-weight: 700;">Login</a> or <a href="${registerTarget}" class="spa-link" style="color: var(--primary-color); text-decoration: underline; font-weight: 700;">Register</a>`;
        const fullMessage = `${esc(message)} ${authLinks}`;
        if (window.showToast) {
            window.showToast('Login Required', fullMessage, null, 'fas fa-user-lock', null, 'system');
        } else if (window.createFlash) {
            window.createFlash(fullMessage, 'error');
        }
    };

    // Link Parsing Helper
    window.parseLinks = function (text) {
        if (!text) return '';
        // 1. Escape HTML
        let div = document.createElement('div');
        div.textContent = text;
        let escaped = div.innerHTML;

        // 2. Regex for URLs
        const urlPattern = /(https?:\/\/[^\s<>"]+|www\.[^\s<>"]+)/g;
        return escaped.replace(urlPattern, function (url) {
            let fullUrl = url;
            if (url.startsWith('www.')) fullUrl = 'http://' + url;

            let displayUrl = url;
            if (displayUrl.length > 50) displayUrl = displayUrl.substring(0, 47) + '...';

            return `<a href="${fullUrl}" target="_blank" rel="noopener noreferrer" class="external-link" style="color: var(--primary-color); text-decoration: underline;">${displayUrl}</a>`;
        });
    };

    // Global handler for modal forms
    window.handleModalFormSubmit = function (event, form) {
        event.preventDefault();
        const formData = new FormData(form);
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : '';

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        }

        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
        const modalHeaders = { 'X-Requested-With': 'XMLHttpRequest' };
        if (csrfToken) modalHeaders['X-CSRFToken'] = csrfToken;

        fetch(form.action, {
            method: 'POST',
            body: formData,
            headers: modalHeaders
        })
            .then(response => {
                if (response.redirected) {
                    if (window.loadPage) {
                        window.loadPage(response.url);
                    } else {
                        window.location.href = response.url;
                    }
                    return null;
                }
                return response.text();
            })
            .then(html => {
                if (html && html.trim() !== "") {
                    const contentArea = document.getElementById('modal-content-area');
                    if (contentArea) {
                        contentArea.innerHTML = html;
                        executeScripts(contentArea);
                    }
                } else {
                    if (window.closeModal) window.closeModal();
                    if (window.loadPage) {
                        window.loadPage(window.location.pathname + window.location.search, false);
                    } else {
                        window.location.reload();
                    }
                }
            })
            .catch(err => {
                console.error('Modal Form Submit Error:', err);
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
                alert('A transmission error occurred. Please check your connection.');
            });

        return false;
    };

    if (!window.__ulpModalBanFormDeleg) {
        window.__ulpModalBanFormDeleg = true;
        document.addEventListener('submit', (e) => {
            const form = e.target;
            if (!form || !form.getAttribute || form.getAttribute('data-ulp-modal-ban-form') !== '1') return;
            if (typeof window.handleModalFormSubmit === 'function') {
                window.handleModalFormSubmit(e, form);
            }
        });
    }

    // Modal interactions
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) window.closeModal();
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal && modal.classList.contains('active')) window.closeModal();
    });

    // Initialize listeners when DOM is fully ready
    document.addEventListener('DOMContentLoaded', () => {
        try {
            // Use document body or document to catch bubbled events
            var delegationRoot = document.body || document;
            // Event Delegation for Links
            delegationRoot.addEventListener('click', (e) => {
                // 1. File View Buttons - INTERCEPTION REMOVED
                // Standard navigation will occur

                // 2. Profile Links (General)
                var anyLink = e.target.closest('a');
                if (anyLink && !anyLink.classList.contains('no-spa')) {
                    var href = anyLink.getAttribute('href') || '';
                    // Check if it's a profile link by path
                    if (href.startsWith('/user/') || href.startsWith('/profile/')) {
                        e.preventDefault();
                        if (window.closeModal) {
                            window.closeModal();
                        }
                        if (window.loadPage) {
                            window.loadPage(anyLink.href);
                        } else {
                            window.location.href = anyLink.href;
                        }
                        return;
                    }
                }

                // 3. Auto-close Modal on regular navigation clicks inside
                var anyLink = e.target.closest('a');
                var modalEl = document.getElementById('universal-modal');
                if (anyLink && modalEl && modalEl.classList.contains('active') && modalEl.contains(anyLink)) {
                    if (!anyLink.classList.contains('no-spa')) {
                        window.closeModal();
                    }
                }
            });

            // Flash messages fadeout
            window.initFlashAutoHide = function () {
                var flashes = document.querySelectorAll('.flash-message:not(.manual-close)');
                flashes.forEach(flash => {
                    if (flash.dataset.autoHideInit) return;
                    flash.dataset.autoHideInit = 'true';
                    setTimeout(() => {
                        if (flash.classList.contains('manual-close')) return;
                        flash.style.opacity = '0';
                        flash.style.transition = 'opacity 0.5s ease-out';
                        setTimeout(() => flash.remove(), 500);
                    }, 8000);
                });
            };

            // Global Flash Function (Renamed to avoid conflict with realtime.js)
            window.createFlash = function (message, category = 'error') {
                var msg = String(message == null ? '' : message);
                var cat = String(category || 'error').toLowerCase();
                if (typeof window.showToast === 'function') {
                    var notif = 'error';
                    var head = 'Error';
                    var icon = 'fas fa-circle-exclamation';
                    if (cat === 'success') {
                        notif = 'success';
                        head = 'Success';
                        icon = 'fas fa-check-circle';
                    } else if (cat === 'warning') {
                        notif = 'warning';
                        head = 'Notice';
                        icon = 'fas fa-triangle-exclamation';
                    } else if (cat === 'info' || cat === 'message') {
                        notif = 'info';
                        head = 'Notice';
                        icon = 'fas fa-info-circle';
                    } else if (cat === 'error' || cat === 'danger') {
                        notif = 'error';
                        head = 'Error';
                        icon = 'fas fa-circle-exclamation';
                    }
                    window.showToast(head, msg, null, icon, null, notif);
                    return null;
                }
                var flashes = document.querySelector('.flashes');
                if (!flashes) {
                    flashes = document.createElement('div');
                    flashes.className = 'flashes';
                    document.body.appendChild(flashes);
                }
                var toast = document.createElement('div');
                toast.className = 'flash-message ' + cat;
                var iconCls = 'fa-info-circle';
                if (cat === 'success') iconCls = 'fa-check-circle';
                else if (cat === 'error' || cat === 'danger') iconCls = 'fa-circle-exclamation';
                else if (cat === 'warning') iconCls = 'fa-triangle-exclamation';
                toast.innerHTML = '<i class="fas ' + iconCls + ' icon"></i><span class="flash-message__body"></span>';
                toast.querySelector('.flash-message__body').textContent = msg;
                flashes.appendChild(toast);
                if (window.initFlashAutoHide) window.initFlashAutoHide();
                if (!toast.classList.contains('manual-close')) {
                    setTimeout(function () {
                        if (toast && toast.parentElement && !toast.classList.contains('manual-close')) {
                            toast.style.opacity = '0';
                            toast.style.transition = 'opacity 0.5s ease-out';
                            setTimeout(function () { toast.remove(); }, 500);
                        }
                    }, 8000);
                }
                return toast;
            }; // End createFlash

        } catch (e) {
            console.error('CRITICAL JS ERROR:', e);
        }

        // Initialize flash auto-hide
        if (window.initFlashAutoHide) window.initFlashAutoHide();
    });
} catch (e) {
    console.error('Global Script Error:', e);
}
})();
