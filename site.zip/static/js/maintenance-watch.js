/**
 * Polls /api/health on live app pages. After deploy/restart, redirects open tabs to
 * the static maintenance page (nginx-served, no Gunicorn). Maintenance page polls
 * health and returns users automatically (see maintenance.html).
 */
(function () {
    if (window.__ulpMaintenanceWatch) return;
    window.__ulpMaintenanceWatch = true;

    var MAINT_PATH = '/static/errors/maintenance.html';
    var MAINT_REV = '10';
    var MAINT_URL = MAINT_PATH + '?v=' + MAINT_REV;
    var HEALTH_URL = '/api/health';
    var RETURN_KEY = 'ulp_post_maintenance_return';
    var GRACE_KEY = 'ulp_maintenance_left_at';
    /** After returning from maintenance — block health-poll bounce (mobile refresh flakes). */
    var GRACE_MS = 20000;
    /** Ignore transient health/fetch failures right after navigation (mobile refresh abort noise). */
    function inReloadGrace() {
        try {
            var ts = parseInt(sessionStorage.getItem('ulp_eio_unload_ts') || '0', 10);
            if (ts > 0 && (Date.now() - ts) < 6500) return true;
            var nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
            if (nav && nav.type === 'reload' && (Date.now() - pageLoadAt) < 6500) return true;
        } catch (e) { /* ignore */ }
        return false;
    }

    function pageLoadGraceMs() {
        var base = 5500;
        try {
            if (window.matchMedia && window.matchMedia('(max-width: 768px)').matches) base = 9000;
            else if (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0) base = 8000;
            if (inReloadGrace()) base = Math.max(base, 7500);
        } catch (e) { /* ignore */ }
        return base;
    }
    var pageLoadAt = Date.now();
    var POLL_HEALTHY_MS = 3500;
    var POLL_UNHEALTHY_MS = 1200;
    var FAILS_BEFORE_MAINT = 2;

    var path = window.location.pathname || '';

    function inMaintenanceGrace() {
        try {
            var t = parseInt(sessionStorage.getItem(GRACE_KEY) || '0', 10);
            return t > 0 && (Date.now() - t) < GRACE_MS;
        } catch (e) {
            return false;
        }
    }

    function inPageLoadGrace() {
        return (Date.now() - pageLoadAt) < pageLoadGraceMs();
    }

    function isStaleMaintenanceDom() {
        if (document.body && document.body.classList.contains('ulp-maint-page')) return false;
        if (document.querySelector('main.ulp-maint-main, .ulp-maint-panel')) return true;
        return false;
    }

    function isOnMaintenanceUrl() {
        return path === MAINT_PATH || path.endsWith('/maintenance.html');
    }

    function isHealthyStatus(status) {
        return status === 204 || status === 200;
    }

    function isDeployLikeStatus(status) {
        return status === 502 || status === 503 || status === 504;
    }

    function isSameOriginReqUrl(reqUrl) {
        var url = String(reqUrl || '');
        if (!url || url.charAt(0) === '/') return true;
        try {
            return url.indexOf(window.location.origin) === 0;
        } catch (e) {
            return false;
        }
    }

    function shouldIgnoreFetchMaintSignal(reqUrl, err) {
        if (inPageLoadGrace()) return true;
        if (inReloadGrace()) return true;
        if (window.__ulpPageUnloading) return true;
        if (err) {
            var name = String((err && err.name) || '');
            var msg = String((err && err.message) || '').toLowerCase();
            if (name === 'AbortError') return true;
            if (msg.indexOf('aborted') !== -1) return true;
            if (msg.indexOf('failed to fetch') !== -1 && document.visibilityState === 'hidden') return true;
            // Safari/WebKit refresh: aborted same-origin fetch often logs "access control checks".
            if (msg.indexOf('access control') !== -1 && isSameOriginReqUrl(reqUrl)) return true;
        }
        var url = String(reqUrl || '');
        if (!url || url.indexOf(HEALTH_URL) !== -1) return true;
        // Benign presence polling — same Safari "access control checks" noise as Engine.IO on refresh.
        if (url.indexOf('/api/widget-presence') !== -1) return true;
        if (url.indexOf('/api/online-now') !== -1) return true;
        if (/\/static\//.test(url) && url.indexOf('/api/') === -1) return true;
        if (/\.(css|js|mjs|map|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|eot)(\?|#|$)/i.test(url)) return true;
        return false;
    }

    /**
     * @param {{ healthPoll?: boolean, deploySignal?: boolean }|boolean} source
     */
    function goMaintenance(source) {
        var healthPoll = source === true || !!(source && source.healthPoll);
        var deploySignal = !!(source && source.deploySignal);
        if (inPageLoadGrace() && !deploySignal) return;
        if (inMaintenanceGrace()) {
            if (healthPoll && !deploySignal) return;
            if (!healthPoll && !deploySignal) return;
        }
        try {
            if (typeof window.__ulpShowSyncLoader === 'function') {
                window.__ulpShowSyncLoader('Updating site…');
            }
        } catch (e) { /* ignore */ }
        if (typeof window.ulpGoMaintenanceFullPage === 'function') {
            window.ulpGoMaintenanceFullPage();
            return;
        }
        try {
            var returnTo = window.location.pathname + window.location.search + window.location.hash;
            if (returnTo && returnTo.charAt(0) === '/' && returnTo.indexOf('maintenance.html') === -1) {
                sessionStorage.setItem(RETURN_KEY, returnTo);
            }
        } catch (e) { /* sessionStorage blocked */ }
        window.location.replace(MAINT_URL);
    }

    function repairStaleMaintenanceUi() {
        if (inPageLoadGrace()) return;
        if (inMaintenanceGrace()) return;
        if (!isStaleMaintenanceDom()) return;
        goMaintenance({ deploySignal: true });
    }

    if (isOnMaintenanceUrl()) {
        if (isStaleMaintenanceDom() || (window.location.search || '').indexOf('v=' + MAINT_REV) === -1) {
            window.location.replace(MAINT_URL);
        }
        return;
    }

    var failStreak = 0;
    var timer = null;
    var inFlight = false;
    var fetchMaintTimer = null;
    var healthAbortCtrl = null;

    window.__ulpAbortMaintenanceHealthFetch = function () {
        if (!healthAbortCtrl) return;
        try { healthAbortCtrl.abort(); } catch (e) { /* ignore */ }
        healthAbortCtrl = null;
        inFlight = false;
    };

    function healthProbeDelayMs() {
        if (!inReloadGrace()) return 900;
        var gap = typeof window.__ulpReloadGapMs === 'function' ? window.__ulpReloadGapMs() : 99999;
        var streak = typeof window.__ulpRapidReloadStreak === 'function' ? window.__ulpRapidReloadStreak() : 0;
        if (gap < 1200) return Math.max(3400, 3000 + streak * 450);
        if (gap < 2500) return Math.max(2800, 2400 + streak * 350);
        return Math.max(2200, pageLoadGraceMs() - (Date.now() - pageLoadAt) + 300);
    }

    function scheduleHealthAfterGrace() {
        var wait = Math.max(350, healthProbeDelayMs() - (Date.now() - pageLoadAt));
        schedule(wait);
    }

    function schedule(ms) {
        if (timer) clearTimeout(timer);
        timer = setTimeout(runCheck, ms);
    }

    function noteUnhealthy(fromProbe, deploySignal) {
        if (deploySignal) {
            goMaintenance({ deploySignal: true });
            return true;
        }
        if (inPageLoadGrace()) {
            schedule(POLL_UNHEALTHY_MS);
            return false;
        }
        failStreak += 1;
        if (failStreak >= FAILS_BEFORE_MAINT) {
            goMaintenance({ healthPoll: !!fromProbe, deploySignal: false });
            return true;
        }
        schedule(POLL_UNHEALTHY_MS);
        return false;
    }

    function runCheck() {
        if (inPageLoadGrace() || inReloadGrace() || window.__ulpPageUnloading) {
            scheduleHealthAfterGrace();
            return;
        }
        if (inFlight) return;
        inFlight = true;
        if (healthAbortCtrl) {
            try { healthAbortCtrl.abort(); } catch (e) { /* ignore */ }
        }
        healthAbortCtrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var fetchOpts = {
            method: 'GET',
            cache: 'no-store',
            credentials: 'same-origin',
            headers: { Accept: 'application/json', 'Cache-Control': 'no-cache' },
        };
        if (healthAbortCtrl) fetchOpts.signal = healthAbortCtrl.signal;
        fetch(HEALTH_URL, fetchOpts)
            .then(function (res) {
                inFlight = false;
                healthAbortCtrl = null;
                if (res && isHealthyStatus(res.status)) {
                    failStreak = 0;
                    schedule(POLL_HEALTHY_MS);
                    return;
                }
                noteUnhealthy(true, false);
            })
            .catch(function (err) {
                inFlight = false;
                healthAbortCtrl = null;
                if (err && String(err.name || '') === 'AbortError') {
                    scheduleHealthAfterGrace();
                    return;
                }
                noteUnhealthy(true, false);
            });
    }

    function scheduleMaintFromFetch(reqUrl, err) {
        if (shouldIgnoreFetchMaintSignal(reqUrl, err)) return;
        if (fetchMaintTimer) clearTimeout(fetchMaintTimer);
        fetchMaintTimer = setTimeout(function () {
            fetchMaintTimer = null;
            goMaintenance({ deploySignal: true });
        }, 60);
    }

    if (!window.__ulpFetchMaintPatched && typeof window.fetch === 'function') {
        window.__ulpFetchMaintPatched = true;
        var nativeFetch = window.fetch.bind(window);
        window.fetch = function (input, init) {
            var reqUrl = '';
            try {
                reqUrl = typeof input === 'string' ? input : (input && input.url) || '';
            } catch (e) { /* ignore */ }
            return nativeFetch(input, init).then(
                function (res) {
                    if (res && !shouldIgnoreFetchMaintSignal(reqUrl, null)) {
                        if (isDeployLikeStatus(res.status)) {
                            scheduleMaintFromFetch(reqUrl, null);
                        } else {
                            try {
                                var finalUrl = res.url || reqUrl;
                                if (finalUrl.indexOf('maintenance.html') !== -1) {
                                    scheduleMaintFromFetch(reqUrl, null);
                                }
                            } catch (e2) { /* ignore */ }
                        }
                    }
                    return res;
                },
                function (err) {
                    scheduleMaintFromFetch(reqUrl, err);
                    throw err;
                }
            );
        };
    }

    function bindSocketMaintWatch() {
        var s = typeof window.getSharedSocket === 'function' ? window.getSharedSocket() : null;
        if (!s || s.__ulpMaintWatchBound) return;
        s.__ulpMaintWatchBound = true;
        s.on('disconnect', function (reason) {
            if (window.__ulpPageUnloading || window._chatIntentionalReconnect) return;
            if (inPageLoadGrace()) return;
            var r = String(reason || '').toLowerCase();
            if (r === 'io server disconnect') return;
            failStreak = Math.max(failStreak, FAILS_BEFORE_MAINT - 1);
            runCheck();
        });
        s.on('connect_error', function () {
            if (window._chatIntentionalReconnect || inPageLoadGrace() || inReloadGrace()) return;
            runCheck();
        });
    }

    var socketBindAttempts = 0;
    var socketBindTimer = setInterval(function () {
        bindSocketMaintWatch();
        socketBindAttempts += 1;
        if ((typeof window.getSharedSocket === 'function' && window.getSharedSocket()) || socketBindAttempts > 80) {
            clearInterval(socketBindTimer);
        }
    }, 250);

    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            if (!inPageLoadGrace()) {
                repairStaleMaintenanceUi();
            }
            if (!inPageLoadGrace()) {
                runCheck();
            }
        }
    });

    window.addEventListener('online', function () {
        if (inPageLoadGrace()) return;
        repairStaleMaintenanceUi();
        runCheck();
    });

    window.addEventListener('pageshow', function () {
        pageLoadAt = Date.now();
        failStreak = 0;
    });

    window.__ulpMaintenanceRecheck = function () {
        if (inPageLoadGrace()) return;
        repairStaleMaintenanceUi();
        runCheck();
    };

    window.__ulpInReloadGrace = inReloadGrace;
    window.__ulpApiFetchDelayMs = function (baseMs) {
        var ms = Math.max(0, Number(baseMs) || 0);
        if (inPageLoadGrace()) {
            ms = Math.max(ms, Math.max(0, pageLoadGraceMs() - (Date.now() - pageLoadAt) + 250));
        }
        if (inReloadGrace()) {
            ms = Math.max(ms, 1900);
        }
        try {
            var gap = typeof window.__ulpReloadGapMs === 'function' ? window.__ulpReloadGapMs() : 99999;
            var streak = typeof window.__ulpRapidReloadStreak === 'function' ? window.__ulpRapidReloadStreak() : 0;
            if (gap < 1200) ms = Math.max(ms, 3200 + streak * 400);
            else if (gap < 2500) ms = Math.max(ms, 2400 + streak * 300);
        } catch (e) { /* ignore */ }
        return ms;
    };

    schedule(healthProbeDelayMs());
})();
