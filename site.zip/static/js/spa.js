/**
 * Lightweight SPA (Single Page Application) Navigation
 * Intercepts internal links and loads content via AJAX.
 */

/** DB stores fas/far/fab; FA6 markup uses fa-solid / fa-regular / fa-brands. */
window.normalizeFaIconClass = function (iconRaw) {
    const raw = ((iconRaw || 'fas fa-star') + '').trim();
    let prefix = 'fa-solid ';
    if (/\bfab\b/i.test(raw)) prefix = 'fa-brands ';
    else if (/\bfar\b/i.test(raw)) prefix = 'fa-regular ';
    const iconTokenMatch = raw.match(/fa-(?!solid\b|regular\b|brands\b)[a-z0-9-]+/i);
    let token = iconTokenMatch ? iconTokenMatch[0] : 'fa-star';
    const t = token.toLowerCase();
    if (t === 'fa-shield-alt' || t === 'fa-shield-halved') token = 'fa-shield';
    return prefix + token;
};

/**
 * Normalize pathname for comparisons (matches SPA helpers).
 */
window.__ulpNormalizePath = function (path) {
    if (!path) return '/';
    return (path !== '/' && path.endsWith('/')) ? path.slice(0, -1) : path;
};

/**
 * After Socket.IO reconnect/resume, re-join feed rooms + presence rooms for the *current* URL.
 * This is intentionally global (loaded before chat.js) so chat bootstrap can call it on connect.
 */
window.__ulpResyncRealtimeSubscriptionsForUrl = function (targetUrl) {
    try {
        const socket = (typeof window.getSharedSocket === 'function' && window.getSharedSocket())
            || window.chatSocket
            || window.socket
            || null;
        if (!socket || !socket.connected) return;

        const href = String(targetUrl || window.location.href || '');
        // Mirrors `syncPresenceRoomsForSpaNavigation()` inside SPA, but works for full page loads too.
        try {
            const u = new URL(href, window.location.origin);
            const path = window.__ulpNormalizePath(u.pathname || '/');

            let forumTopicId = null;
            let fileId = null;
            let listingId = null;
            const mTopic = path.match(/^\/discussions\/t\/(\d+)/);
            if (mTopic) forumTopicId = mTopic[1];
            const mFile = path.match(/^\/file\/(\d+)/);
            if (mFile) fileId = mFile[1];
            const mRes = path.match(/^\/resources\/(\d+)/);
            if (mRes) listingId = mRes[1];

            const onFilesFeed = path === '/';
            const onResourcesFeed = path === '/resources';
            const onDiscussionsFeed = path === '/discussions' || /^\/discussions\/c\//i.test(path);

            socket.emit('sync_presence_route', {
                forum_topic_id: forumTopicId,
                file_id: fileId,
                listing_id: listingId,
                files_feed: onFilesFeed,
                resources_feed: onResourcesFeed,
                discussions_feed: onDiscussionsFeed,
            });

            if (onFilesFeed) socket.emit('join_files_feed');
            if (onResourcesFeed) socket.emit('join_resources_feed');
            if (onDiscussionsFeed) socket.emit('join_discussions_feed');
            if (forumTopicId) socket.emit('join_forum_topic', { topic_id: forumTopicId });
        } catch (e) {
            console.warn('ulp: sync_presence_route failed', e);
        }

        // File/resource viewer rooms (chat sidebar + viewer piles) — safe to repeat-join.
        try {
            const u2 = new URL(href, window.location.origin);
            const p = window.__ulpNormalizePath(u2.pathname || '/');
            const mf = p.match(/^\/file\/(\d+)/);
            if (mf && typeof window.initializeFileRoom === 'function') {
                window.initializeFileRoom('file', mf[1]);
            }
            const mr = p.match(/^\/resources\/(\d+)/);
            if (mr && typeof window.initializeFileRoom === 'function') {
                window.initializeFileRoom('resource', mr[1]);
            }
        } catch (e) {
            console.warn('ulp: initializeFileRoom resync failed', e);
        }
    } catch (e) {
        console.warn('ulp: __ulpResyncRealtimeSubscriptionsForUrl failed', e);
    }
};

window.__ulpResyncRealtimeSubscriptions = function () {
    window.__ulpResyncRealtimeSubscriptionsForUrl(window.location.href);
};

/** Queue navigations until DOMContentLoaded binds the real loadPage (avoids full reload on early clicks). */
(function () {
    const queue = [];
    let impl = null;

    function flush() {
        while (queue.length && impl) {
            const job = queue.shift();
            try {
                void impl(job.url, job.push, job.options);
            } catch (e) { /* ignore */ }
        }
    }

    window.loadPage = function loadPageEarly(url, push, options) {
        if (impl) return impl(url, push, options);
        queue.push({ url: url, push: push !== false, options: options || {} });
        return Promise.resolve(false);
    };

    window.__ulpSpaBindLoadPage = function (fn) {
        impl = fn;
        flush();
    };
})();

(function () {
    const STACK_CACHE_KEY = 'ulp_header_mobile_stack_h';
    let mobileHeaderWrapRaf = null;
    let lastStackH = null;

    function readCachedStackH() {
        try {
            if (!window.matchMedia('(max-width: 768px)').matches) return null;
            const n = parseInt(sessionStorage.getItem(STACK_CACHE_KEY), 10);
            return Number.isFinite(n) && n >= 70 ? n : null;
        } catch (e) {
            return null;
        }
    }

    function applyMobileHeaderStackH(root, nextStackH) {
        const prevStackH = lastStackH;
        const chatLocked = document.documentElement.classList.contains('ulp-chat-mobile-scroll-lock')
            || (document.body && document.body.style.position === 'fixed');
        if (prevStackH != null && prevStackH !== nextStackH && !chatLocked) {
            const delta = nextStackH - prevStackH;
            if (delta !== 0 && window.scrollY > 0) {
                window.scrollBy(0, delta);
            }
        }
        lastStackH = nextStackH;
        root.style.setProperty('--header-mobile-stack-h', `${nextStackH}px`);
        try {
            sessionStorage.setItem(STACK_CACHE_KEY, String(nextStackH));
        } catch (e) { /* ignore */ }
    }

    function syncMobileHeaderWrapStateCore() {
        const root = document.documentElement;
        const headerWrapper = document.getElementById('site-header-wrapper');
        const headerInner = document.querySelector('#site-header-wrapper .header-inner');
        const headerRight = headerInner ? headerInner.querySelector('.header-right') : null;
        if (!headerInner || !headerRight) return;

        const isMobile = window.matchMedia('(max-width: 768px)').matches;
        let isWrapped = false;
        if (isMobile) {
            const innerTop = headerInner.getBoundingClientRect().top;
            const rightTop = headerRight.getBoundingClientRect().top;
            isWrapped = (rightTop - innerTop) > 8;
        }
        headerInner.classList.toggle('header-mobile-actions-wrapped', isWrapped);

        if (isMobile && headerWrapper) {
            const measuredHeaderH = Math.ceil(headerWrapper.getBoundingClientRect().height);
            applyMobileHeaderStackH(root, Math.max(70, measuredHeaderH + 4));
        } else if (!isMobile) {
            lastStackH = null;
            root.style.removeProperty('--header-mobile-stack-h');
        }
    }

    function scheduleMobileHeaderWrapSync() {
        if (mobileHeaderWrapRaf != null) {
            cancelAnimationFrame(mobileHeaderWrapRaf);
        }
        mobileHeaderWrapRaf = requestAnimationFrame(() => {
            mobileHeaderWrapRaf = null;
            syncMobileHeaderWrapStateCore();
        });
    }

    window.__ulpSyncMobileHeaderWrapStateImmediate = syncMobileHeaderWrapStateCore;
    window.__ulpSyncMobileHeaderWrapState = scheduleMobileHeaderWrapSync;
    window.__ulpScheduleMobileHeaderWrapAfterFonts = function () {
        if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
            document.fonts.ready.then(() => syncMobileHeaderWrapStateCore()).catch(() => {});
        }
    };

    const cached = readCachedStackH();
    if (cached != null) {
        lastStackH = cached;
        document.documentElement.style.setProperty('--header-mobile-stack-h', `${cached}px`);
    }
})();

(function () {
    const SCROLL_KEY = 'ulp_header_right_scroll_left';
    const VIEWPORT_KEY = 'ulp_page_viewport';
    let pendingHeaderRightScrollLeft = 0;
    let pendingPageViewport = null;
    let scrollRestoreTimers = [];
    let scrollRestoreGuardTimer = null;
    let scrollRestoreScrollGuard = null;
    let scrollRestoreBlocked = false;
    const SCROLL_RESTORE_GUARD_MS = 400;

    function clearScrollRestoreTimers() {
        scrollRestoreTimers.forEach((id) => clearTimeout(id));
        scrollRestoreTimers = [];
    }

    function stopScrollRestoreGuard() {
        if (scrollRestoreScrollGuard) {
            window.removeEventListener('scroll', scrollRestoreScrollGuard, true);
            scrollRestoreScrollGuard = null;
        }
        if (scrollRestoreGuardTimer) {
            clearTimeout(scrollRestoreGuardTimer);
            scrollRestoreGuardTimer = null;
        }
    }

    function runScrollRestore(x, y, options) {
        const force = !!(options && options.force);
        const armGuard = !!(options && options.armGuard);

        clearScrollRestoreTimers();
        stopScrollRestoreGuard();
        scrollRestoreBlocked = false;

        if (armGuard && !force) {
            scrollRestoreScrollGuard = () => {
                scrollRestoreBlocked = true;
                clearScrollRestoreTimers();
                stopScrollRestoreGuard();
            };
            window.addEventListener('scroll', scrollRestoreScrollGuard, { passive: true, capture: true });
            scrollRestoreGuardTimer = setTimeout(stopScrollRestoreGuard, SCROLL_RESTORE_GUARD_MS);
        }

        const targetX = Math.max(0, Math.round(Number(x) || 0));
        const targetY = Math.max(0, Math.round(Number(y) || 0));
        const apply = () => {
            if (!force && scrollRestoreBlocked) return;
            window.scrollTo(targetX, targetY);
        };
        apply();
        requestAnimationFrame(apply);
        scrollRestoreTimers.push(setTimeout(apply, 0));
        scrollRestoreTimers.push(setTimeout(apply, 80));
        scrollRestoreTimers.push(setTimeout(apply, 200));
    }

    function readHeaderRightEl() {
        return document.querySelector('#site-header-wrapper .header-right');
    }

    function currentPagePath() {
        return (window.location.pathname || '/') + (window.location.search || '');
    }

    function savePageViewport() {
        pendingPageViewport = {
            x: Math.max(0, Math.round(window.pageXOffset || window.scrollX || 0)),
            y: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
            path: currentPagePath(),
            ts: Date.now()
        };
        try {
            sessionStorage.setItem(VIEWPORT_KEY, JSON.stringify(pendingPageViewport));
        } catch (e) { /* ignore */ }
    }

    window.__ulpRestorePageViewport = function (force) {
        let data = pendingPageViewport;
        if (!data) {
            try {
                const raw = sessionStorage.getItem(VIEWPORT_KEY);
                if (raw) data = JSON.parse(raw);
            } catch (e) { /* ignore */ }
        }
        if (!data || data.path !== currentPagePath()) return;
        if (!force && Date.now() - (data.ts || 0) > 30 * 60 * 1000) return;
        const targetX = Math.max(0, Math.round(Number(data.x) || 0));
        const targetY = Math.max(0, Math.round(Number(data.y) || 0));
        runScrollRestore(targetX, targetY, { force: force, armGuard: !force });
    };

    window.__ulpReadHeaderRightScrollLeft = function () {
        const el = readHeaderRightEl();
        return el ? Math.max(0, Math.round(el.scrollLeft || 0)) : 0;
    };

    window.__ulpRestoreHeaderRightScrollLeft = function (scrollLeft) {
        const target = Math.max(0, Math.round(Number(scrollLeft) || 0));
        if (!target) return;
        const apply = () => {
            const el = readHeaderRightEl();
            if (el) el.scrollLeft = target;
        };
        apply();
        requestAnimationFrame(apply);
        setTimeout(apply, 0);
        setTimeout(apply, 80);
    };

    window.__ulpScrollActiveToolbarTabIntoView = function (root) {
        const scope = root && root.querySelectorAll ? root : document;
        scope.querySelectorAll('.directory-tabs-scroll').forEach((scrollEl) => {
            const active = scrollEl.querySelector('.filter-chip.active, .forum-index-context.filter-chip.active');
            if (!active) return;
            const scrollRect = scrollEl.getBoundingClientRect();
            const chipRect = active.getBoundingClientRect();
            const inset = 8;
            if (chipRect.left < scrollRect.left + inset) {
                scrollEl.scrollLeft -= (scrollRect.left + inset) - chipRect.left;
            } else if (chipRect.right > scrollRect.right - inset) {
                scrollEl.scrollLeft += chipRect.right - (scrollRect.right - inset);
            }
        });
    };

    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') {
            clearScrollRestoreTimers();
            stopScrollRestoreGuard();
            scrollRestoreBlocked = false;
            savePageViewport();
            const el = readHeaderRightEl();
            pendingHeaderRightScrollLeft = el ? (el.scrollLeft || 0) : 0;
            try {
                sessionStorage.setItem(SCROLL_KEY, String(pendingHeaderRightScrollLeft));
            } catch (e) { /* ignore */ }
            return;
        }
        if (document.visibilityState === 'visible') {
            window.__ulpRestorePageViewport(false);
            let saved = pendingHeaderRightScrollLeft;
            if (!saved) {
                try {
                    saved = parseInt(sessionStorage.getItem(SCROLL_KEY), 10) || 0;
                } catch (e2) { /* ignore */ }
            }
            if (saved > 0) {
                window.__ulpRestoreHeaderRightScrollLeft(saved);
            }
        }
    });

    window.addEventListener('pageshow', (ev) => {
        if (typeof window.__ulpUnlockChatMobileBodyIfChatLocked === 'function') {
            window.__ulpUnlockChatMobileBodyIfChatLocked();
        }
        if (typeof window.__ulpSyncMobileHeaderWrapState === 'function') {
            window.__ulpSyncMobileHeaderWrapState();
        }
        if (ev && ev.persisted) {
            window.__ulpRestorePageViewport(true);
        }
    });

    document.addEventListener('pageLoaded', () => {
        if (typeof window.__ulpUnlockChatMobileBodyIfChatLocked === 'function') {
            window.__ulpUnlockChatMobileBodyIfChatLocked();
        }
        window.__ulpScrollActiveToolbarTabIntoView(document);
    });
})();

/**
 * Resolve the real floating chat shell. The canonical widget lives outside main; a duplicate
 * id+marker inside swapped main matches querySelector first — skip descendants of main.
 */
window.__ulpGetFloatingChatRoot = function __ulpGetFloatingChatRoot() {
    try {
        const pickOutsideMain = (el) => {
            if (!el || typeof el.closest !== 'function') return null;
            return el.closest('main') ? null : el;
        };
        const remember = (el) => {
            if (el) window.__ulpFloatingChatRootEl = el;
            return el;
        };
        const memo = window.__ulpFloatingChatRootEl;
        if (memo && memo.isConnected) {
            const ok = pickOutsideMain(memo);
            if (ok) return ok;
            // Broken markup (unclosed tags in huge admin pages) can nest the shell under <main>.
            if (memo.hasAttribute && memo.hasAttribute('data-ulp-floating-chat')) return memo;
            window.__ulpFloatingChatRootEl = null;
        }
        const allMarked = document.querySelectorAll('[data-ulp-floating-chat]');
        // Exactly one marker in the document — it is always the real shell (even if parser nested it under <main>).
        if (allMarked.length === 1 && allMarked[0]) {
            return remember(allMarked[0]);
        }
        // Prefer explicit marker outside <main> when duplicates exist (SPA decoys).
        for (let i = 0; i < allMarked.length; i += 1) {
            const hit = pickOutsideMain(allMarked[i]);
            if (hit) return remember(hit);
        }
        const bodyMarked = document.querySelector('body > [data-ulp-floating-chat]');
        const b0 = pickOutsideMain(bodyMarked);
        if (b0) return remember(b0);
        const direct = document.querySelector('body > #chat-widget-container');
        const d2 = pickOutsideMain(direct);
        if (d2) return remember(d2);
        const byId = document.getElementById('chat-widget-container');
        if (byId) {
            const d3 = pickOutsideMain(byId);
            if (d3) return remember(d3);
            if (byId.querySelector && byId.querySelector('#chat-window')) {
                return remember(byId);
            }
        }
        window.__ulpFloatingChatRootEl = null;
        return null;
    } catch (e) {
        return null;
    }
};

/**
 * Broken/unclosed markup (notably huge admin pages) can leave the floating chat shell parsed *inside* <main>.
 * SPA replaces `main.innerHTML` and destroys that subtree — move the shell out before any swap.
 */
window.__ulpRelocateFloatingChatShellOutOfMain = function __ulpRelocateFloatingChatShellOutOfMain() {
    try {
        const mainEl = document.querySelector('main');
        if (!mainEl) return;
        let bodyShell = null;
        try {
            bodyShell = document.body.querySelector(':scope > #chat-widget-container')
                || document.body.querySelector(':scope > [data-ulp-floating-chat]');
        } catch (e) {
            bodyShell = null;
        }
        if (bodyShell) return;
        const candidates = Array.from(mainEl.querySelectorAll('[data-ulp-floating-chat], #chat-widget-container'));
        const shell = candidates.find((el) => el && el.querySelector && el.querySelector('#chat-window'))
            || candidates[0];
        if (!shell || !shell.closest || shell.closest('main') !== mainEl) return;
        mainEl.insertAdjacentElement('afterend', shell);
    } catch (e) { /* ignore */ }
};

/** CSP: SPA/modals must run inline scripts with the nonce from the first full page load. */
window.ulpGetCspNonce = function () {
    if (typeof window.ulpCspNonce === 'function') return window.ulpCspNonce();
    const nm = document.querySelector('meta[name="csp-nonce"]');
    return (nm && nm.content) ? nm.content : '';
};

window.ulpIsExecutableScriptEl = function (scriptEl) {
    const type = (scriptEl.getAttribute('type') || '').trim().toLowerCase();
    if (!type) return true;
    return type === 'text/javascript' || type === 'application/javascript' || type === 'module';
};

window.ulpCleanScriptPath = function (src) {
    return (src || '').split('?')[0].replace(/^(?:https?:\/\/[^/]+)?\//, '');
};

window.ulpScriptGlobalReady = function (cleanPath) {
    if (!cleanPath) return false;
    if (cleanPath.includes('qrcode.min.js')) return typeof QRCode !== 'undefined';
    return false;
};

window.ulpRunInlineScriptEl = function (sourceScript, options) {
    if (!sourceScript) return null;
    const opts = options || {};
    const nonce = window.ulpGetCspNonce();
    const src = sourceScript.getAttribute('src');
    const parent = opts.parent || document.head;

    if (src) {
        const clean = window.ulpCleanScriptPath(src);
        const existing = Array.from(parent.querySelectorAll('script[src]'))
            .find((s) => window.ulpCleanScriptPath(s.getAttribute('src')) === clean);
        if (existing) {
            if (sourceScript.parentNode) sourceScript.remove();
            return existing;
        }
    }

    const el = document.createElement('script');
    Array.from(sourceScript.attributes).forEach((attr) => {
        if (attr.name === 'nonce') return;
        el.setAttribute(attr.name, attr.value);
    });
    if (nonce) el.setAttribute('nonce', nonce);
    if (src) {
        el.src = src;
        parent.appendChild(el);
        if (sourceScript.parentNode) sourceScript.remove();
        return el;
    }
    el.text = sourceScript.text;
    parent.appendChild(el);
    if (sourceScript.parentNode) sourceScript.remove();
    return el;
};

/** Load external <script src> then run inline scripts — order matters (e.g. payment QR). */
window.ulpEnsureScriptEl = function (sourceScript, options) {
    if (!sourceScript) return Promise.resolve(null);
    const opts = options || {};
    const parent = opts.parent || document.head;
    const src = sourceScript.getAttribute('src');
    if (!src) {
        window.ulpRunInlineScriptEl(sourceScript, opts);
        return Promise.resolve(null);
    }
    const clean = window.ulpCleanScriptPath(src);
    const existing = Array.from(parent.querySelectorAll('script[src]'))
        .find((s) => window.ulpCleanScriptPath(s.getAttribute('src')) === clean);
    if (existing && (existing.getAttribute('data-ulp-loaded') === '1' || window.ulpScriptGlobalReady(clean))) {
        if (sourceScript.parentNode) sourceScript.remove();
        return Promise.resolve(existing);
    }
    const attemptLoad = (retriesLeft) => new Promise((resolve, reject) => {
        const el = document.createElement('script');
        Array.from(sourceScript.attributes).forEach((attr) => {
            if (attr.name === 'nonce') return;
            el.setAttribute(attr.name, attr.value);
        });
        const nonce = window.ulpGetCspNonce();
        if (nonce) el.setAttribute('nonce', nonce);
        el.src = src;
        el.addEventListener('load', () => {
            el.setAttribute('data-ulp-loaded', '1');
            if (sourceScript.parentNode) sourceScript.remove();
            resolve(el);
        }, { once: true });
        el.addEventListener('error', () => {
            try {
                el.remove();
            } catch (e) { /* ignore */ }
            if (retriesLeft > 0) {
                setTimeout(() => {
                    attemptLoad(retriesLeft - 1).then(resolve, reject);
                }, 400);
                return;
            }
            reject(new Error('Failed to load script: ' + src));
        }, { once: true });
        parent.appendChild(el);
    });
    return attemptLoad(1);
};

window.ulpRunPageScripts = async function (root) {
    if (!root) return;
    const scripts = Array.from(root.querySelectorAll('script'));
    for (const script of scripts) {
        if (!window.ulpIsExecutableScriptEl(script)) continue;
        try {
            await window.ulpEnsureScriptEl(script);
        } catch (scriptErr) {
            console.warn('SPA: page script failed to load (continuing)', scriptErr);
        }
    }
};

/**
 * Swap <main> without innerHTML string round-trip (Safari can mishandle <script> in innerHTML).
 */
window.ulpSwapMainFromParsed = async function (mainEl, parsedMain) {
    if (!mainEl || !parsedMain) return;
    const pendingScripts = [];
    const fragment = document.createDocumentFragment();
    Array.from(parsedMain.childNodes).forEach((node) => {
        if (node.nodeName === 'SCRIPT') {
            pendingScripts.push(node);
        } else {
            fragment.appendChild(node.cloneNode(true));
        }
    });
    mainEl.replaceChildren(fragment);
    for (const src of pendingScripts) {
        if (!window.ulpIsExecutableScriptEl(src)) {
            const clone = src.cloneNode(true);
            const nonce = window.ulpGetCspNonce();
            if (nonce) clone.setAttribute('nonce', nonce);
            mainEl.appendChild(clone);
            continue;
        }
        try {
            await window.ulpEnsureScriptEl(src);
        } catch (scriptErr) {
            console.warn('SPA: page script failed to load (continuing navigation)', scriptErr);
        }
    }
};

/** Maintenance is a full document — never swap only <main> into the SPA shell. */
window.ulpIsMaintenanceDocument = function (doc) {
    if (!doc || !doc.body) return false;
    if (doc.body.classList.contains('ulp-maint-page')) return true;
    if (doc.querySelector('main.ulp-maint-main, .ulp-maint-panel')) return true;
    return false;
};

window.ulpMaintPageUrl = function () {
    return '/static/errors/maintenance.html?v=10';
};

window.ulpGoMaintenanceFullPage = function () {
    const maintUrl = window.ulpMaintPageUrl();
    try {
        if (window.location.pathname === '/static/errors/maintenance.html') {
            const q = window.location.search || '';
            if (q.indexOf('v=7') !== -1) return;
        }
    } catch (e) { /* ignore */ }
    try {
        const path = window.location.pathname + window.location.search + window.location.hash;
        if (path && path.charAt(0) === '/' && path.indexOf('maintenance.html') === -1) {
            sessionStorage.setItem('ulp_post_maintenance_return', path);
        }
    } catch (e) { /* ignore */ }
    window.location.replace(maintUrl);
};

/** Logout controls use <button> + delegation — no javascript: URLs (CSP script-src-elem). */
document.addEventListener('click', (e) => {
    const logoutTrigger = e.target.closest('[data-logout-trigger]');
    if (logoutTrigger) {
        e.preventDefault();
        const url = logoutTrigger.getAttribute('data-logout-url');
        if (url && typeof window.confirmLogout === 'function') {
            window.confirmLogout(url);
        }
        return;
    }
    const logoutConfirm = e.target.closest('[data-spa-logout-confirm]');
    if (logoutConfirm) {
        e.preventDefault();
        const url = logoutConfirm.getAttribute('data-logout-url');
        if (url && typeof window.spaLogout === 'function') {
            window.spaLogout(url);
        }
        return;
    }
    if (e.target.closest('[data-modal-close]') && typeof window.closeModal === 'function') {
        e.preventDefault();
        window.closeModal();
    }
}, false);

document.addEventListener('DOMContentLoaded', () => {
    const appContainer = document.querySelector('main'); // The container to swap
    if (!appContainer) {
        console.error('SPA: Main container not found. Aborting.');
        return;
    }
    if (typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
        window.__ulpRelocateFloatingChatShellOutOfMain();
    }

    // Helper to extract content from HTML string
    function extractContent(html, selector) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        return doc.querySelector(selector);
    }

    let isLoadingPage = false;
    /** Supersede in-flight fetch when user clicks another internal link (fixes “stuck” / slow follow-up nav). */
    let spaNavGeneration = 0;
    let activeSpaNavigationGen = 0;
    let spaFetchAbort = null;
    const LIST_RETURN_KEY = 'spa_list_return_anchor';
    /** `<style>` nodes cloned from fetched pages — replaced each SPA nav (never accumulate in <head>). */
    let ulpSpaInjectedHeadStyleNodes = [];

    function bindCategoryPressFx() {
        if (window.__ulpCategoryPressFxBound) return;
        window.__ulpCategoryPressFxBound = true;

        const selector = [
            '.nav-item',
            '.logo-link',
            '.filter-chip',
            '.detail-seg-btn',
            '.forum-cat-back',
            '.forum-topic-prefix-chip--link',
            'a.forum-topic-category-pill',
            'a.category-badge.forum-topic-category-pill',
            'a.username-tag',
            'a.forum-user-tag',
            'a.forum-topic-author-link',
            'a.forum-topic-last-reply-link',
            '.btn',
            'a.btn',
            'button.btn',
            '.nav-btn',
            '.nav-btn-icon',
            '.notification-trigger',
            '.profile-link-btn',
            '.mobile-nav-item',
            '.mobile-toggle',
            '.site-page-btn',
            '.page-jump-popover-go',
            '.action-icon-btn',
            '.action-btn',
            '.reply-btn',
            '.edit-btn',
            '.chat-action-btn',
            '.chat-btn',
            '.chat-header-btn',
            '.chat-composer-btn',
            '.chat-msg-act-btn',
            '.btn-send',
            '.btn-link',
            '.ulp-online-dot-btn',
            '.clear-all-btn',
            '.header-search-clear',
            '.like-btn-container',
            '.ulp-like-likers__heart-hit',
            '.discussion-like-toggle',
            '.forum-post-like-toggle',
            '.crypto-currency-btn',
            '.modal-close-btn',
            '.adm-btn',
            '.adm-btn-icon',
            '.adm-nav-item',
            '.adm-page-btn',
            'a.forum-category-card',
            '.list-card-hit',
            '.forum-topic-list-card-hit',
            '.forum-modern-cat-link',
            '.profile-quick-btn',
            '.profile-bg-action-btn',
            '.profile-avatar-delete-btn',
            '.profile-avatar-overlay',
            '.profile-showcase-tile',
            '.profile-tab-btn',
            '.order-item-hit',
            '.order-product-pod',
            '.file-upload-preview-remove-btn',
            '.notification-view-all-link',
            '.data-item-link',
            '.data-item',
            '.vip-plan-btn',
            '.file-custom-btn',
            '.forum-topic-mgmt-edit',
            '.forum-topic-mod-apply',
            '.forum-topic-cat-flydown-link',
            '.discussion-composer-cancel-btn',
            '.forum-new-topic-prefix-chip',
            '.forum-prefix-filter-banner__clear',
            '.rich-editor-send-btn',
            '.forum-topic-reply-btn',
            '.bulk-bar-forum-btn',
            '.forum-breadcrumb-chip',
            '.forum-topic-cat-chip'
        ].join(', ');
        let pressedEl = null;
        let pressedSurfaceEl = null;
        let releaseTimer = null;
        let pressedIconEl = null;

        const resolvePressSurface = (el) => {
            if (el && el.classList.contains('forum-topic-mgmt-edit')) {
                const cluster = el.closest('.forum-topic-management-cluster');
                if (cluster) return cluster;
            }
            return el;
        };

        const clearPressInlineStyle = (el) => {
            if (!el) return;
            el.style.removeProperty('transform');
            el.style.removeProperty('transition');
        };

        const applyPressInlineStyle = (el) => {
            if (!el) return;
            el.style.setProperty('transition', 'transform var(--ulp-press-ms, 125ms) var(--ulp-press-ease, cubic-bezier(0.33, 1, 0.68, 1))', 'important');
            el.style.setProperty('transform', 'var(--ulp-press-transform, scale(0.982))', 'important');
        };

        const clearIconInlineStyle = (iconEl) => {
            if (!iconEl) return;
            iconEl.style.removeProperty('color');
            iconEl.style.removeProperty('filter');
        };

        const applyIconInlineStyle = (iconEl) => {
            if (!iconEl) return;
            iconEl.style.removeProperty('color');
            iconEl.style.removeProperty('filter');
        };

        const clearPressed = () => {
            if (releaseTimer) {
                clearTimeout(releaseTimer);
                releaseTimer = null;
            }
            if (pressedEl) {
                pressedEl.classList.remove('press-feedback');
                pressedEl = null;
            }
            if (pressedSurfaceEl) {
                clearPressInlineStyle(pressedSurfaceEl);
                pressedSurfaceEl = null;
            }
            if (pressedIconEl) {
                clearIconInlineStyle(pressedIconEl);
                pressedIconEl = null;
            }
        };

        /** Wide/surface targets + CSS-driven press — no inline transform override. */
        const skipInlinePressFx = (el) => el && el.matches(
            '.file-content-cta, .vip-plan-btn, .notification-view-all-link, .ulp-press-soft, ' +
            '.data-item, .data-item-link, .btn, .btn.btn-toolbar, .edit-content-staff-toggle, ' +
            '.filter-chip, .group-badge, .nav-item, .nav-btn-icon, .mobile-nav-item, ' +
            '.profile-showcase-tile, .forum-topic-category-pill, .username-tag, ' +
            '.site-page-btn, .detail-seg-btn, .profile-quick-btn, .file-custom-btn'
        );

        /** Chips with custom icon colors (role, verified, group badges) — transform only, never restyle icons. */
        const skipIconPressFx = (el) => el && el.matches(
            'a.username-tag, a.forum-user-tag, a.forum-topic-author-link, a.forum-topic-last-reply-link, ' +
            'a.forum-topic-category-pill, a.category-badge.forum-topic-category-pill, ' +
            '.group-badge, .username-tag .group-badge, .group-badge-pile .group-badge'
        );

        const listDetailTitleSel =
            '.file-title .view-file-btn, .file-title .resource-title-link, .file-title .view-item-btn, ' +
            '.forum-topic-list-title, .forum-topic-status-lead--topic-link';

        const resolveListDetailTitleCardHit = (el) => {
            if (!el || !el.closest) return null;
            const titleLink = el.closest(listDetailTitleSel);
            if (!titleLink) return null;
            if (titleLink.closest('.file-actions-container, .item-actions-container')) return null;

            const listCard = titleLink.closest('.file-item[data-url], .resource-item[data-url]');
            if (listCard) return listCard.querySelector(':scope > .list-card-hit');

            const topicCard = titleLink.closest('.forum-topic-list-card');
            if (topicCard) return topicCard.querySelector(':scope > .forum-topic-list-card-hit');

            return null;
        };

        const applyPressed = (el) => {
            if (!el) return;
            clearPressed();
            pressedEl = el;
            pressedSurfaceEl = resolvePressSurface(el);
            pressedEl.classList.add('press-feedback');
            if (!skipInlinePressFx(pressedEl)) {
                applyPressInlineStyle(pressedSurfaceEl);
            }
            if (!skipIconPressFx(pressedEl)) {
                pressedIconEl = pressedEl.querySelector('i, .icon');
                applyIconInlineStyle(pressedIconEl);
            }
            // Keep visible for a short moment even when navigation starts immediately.
            releaseTimer = setTimeout(clearPressed, 260);
        };

        document.addEventListener('pointerdown', (e) => {
            if (e.target.closest('.cyber-checkbox')) return;

            const titleCardHit = resolveListDetailTitleCardHit(e.target);
            if (titleCardHit) {
                applyPressed(titleCardHit);
                return;
            }

            const profileRowAction = e.target.closest('.data-item--actions .profile-row-actions .action-icon-btn, .data-item--actions .profile-row-actions a.action-icon-btn');
            if (profileRowAction) {
                applyPressed(profileRowAction);
                return;
            }

            const profileItemLink = e.target.closest('.data-item--actions .data-item-link');
            if (profileItemLink) {
                applyPressed(profileItemLink);
                return;
            }

            const profileOrderProduct = e.target.closest('.order-item--split a.telemetry-pod.order-product-pod');
            if (profileOrderProduct) {
                applyPressed(profileOrderProduct);
                return;
            }

            const profileOrderHit = e.target.closest('.order-item--split > .order-item-hit');
            if (profileOrderHit) {
                applyPressed(profileOrderHit.closest('.order-item--split') || profileOrderHit);
                return;
            }

            const usernameBadge = e.target.closest('.username-tag .group-badge-pile .group-badge, .username-tag > .group-badge');
            if (usernameBadge) {
                applyPressed(usernameBadge);
                return;
            }

            const nestedInteractive = e.target.closest(
                'a, button, input, label, select, textarea, .filter-chip, .forum-topic-category-pill, .username-tag, .list-card-hit, .forum-topic-list-card-hit, a.forum-category-card, .forum-modern-cat-link, .data-item, .profile-showcase-tile, .file-custom-btn, .like-btn-container, .ulp-like-likers__heart-hit, .forum-topic-mgmt-edit, .forum-new-topic-prefix-chip, .forum-topic-prefix-chip--link, .forum-topic-cat-flydown-link, .forum-prefix-filter-banner__clear'
            );
            let target = nestedInteractive && nestedInteractive.matches(selector)
                ? nestedInteractive
                : e.target.closest(selector);
            if (!target) return;
            if (target.classList.contains('data-item--actions')) return;
            if (target.classList.contains('order-item--split')) return;
            if (target.classList.contains('cyber-checkbox')) return;
            const cardShell = target.closest('.file-item.list-card-shell, .forum-topic-list-card');
            if (cardShell && target === cardShell) return;
            applyPressed(target);
        }, true);

        document.addEventListener('pointerup', clearPressed, true);
        document.addEventListener('pointercancel', clearPressed, true);
        document.addEventListener('visibilitychange', clearPressed, true);
    }

    function resetSpaLoaderShell(loaderEl, showLoader) {
        if (loaderEl && showLoader) {
            loaderEl.classList.remove('active');
            loaderEl.style.display = 'none';
            const lt = loaderEl.querySelector('span');
            if (lt) lt.textContent = 'Syncing...';
        }
        if (document.body) document.body.style.cursor = '';
    }

    window.__ulpShowSyncLoader = function (message) {
        const loader = document.getElementById('global-loader');
        if (!loader) return;
        const loaderText = loader.querySelector('span');
        const text = message || 'Syncing...';
        if (loaderText) loaderText.textContent = text;
        loader.classList.add('active');
        loader.style.display = 'flex';
        if (document.body) document.body.style.cursor = 'wait';
    };

    window.__ulpHideSyncLoader = function () {
        resetSpaLoaderShell(document.getElementById('global-loader'), true);
    };

    let _ulpSyncLoaderTimer = null;
    window.__ulpShowSyncLoaderDeferred = function (message, delayMs) {
        if (_ulpSyncLoaderTimer) {
            clearTimeout(_ulpSyncLoaderTimer);
            _ulpSyncLoaderTimer = null;
        }
        const delay = delayMs == null ? 850 : Math.max(0, Number(delayMs) || 0);
        _ulpSyncLoaderTimer = setTimeout(() => {
            _ulpSyncLoaderTimer = null;
            window.__ulpShowSyncLoader(message);
        }, delay);
    };
    window.__ulpHideSyncLoaderDeferred = function () {
        if (_ulpSyncLoaderTimer) {
            clearTimeout(_ulpSyncLoaderTimer);
            _ulpSyncLoaderTimer = null;
        }
        window.__ulpHideSyncLoader();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => window.__ulpHideSyncLoaderDeferred(), { once: true });
    } else {
        window.__ulpHideSyncLoaderDeferred();
    }

    function ulpFeedFragmentSelectorForPath(path) {
        const norm = window.__ulpNormalizePath ? window.__ulpNormalizePath(path) : (path || '/');
        if (norm === '/') return '#ajax-file-list';
        if (norm === '/resources') return '#ajax-resource-list';
        if (norm === '/discussions' || /^\/discussions\/c\//i.test(norm)) return '.forum-topic-list';
        return null;
    }

    window.__ulpRefreshFeedFragment = async function (targetUrl) {
        const href = String(
            targetUrl || window.location.pathname + window.location.search + (window.location.hash || '')
        );
        let path = '/';
        try {
            path = window.__ulpNormalizePath(new URL(href, window.location.origin).pathname);
        } catch (e) { /* ignore */ }

        const selector = ulpFeedFragmentSelectorForPath(path);
        if (!selector) return true;

        const currentEl = document.querySelector(selector);
        if (!currentEl) return true;

        try {
            const response = await fetch(href, {
                headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'text/html' },
                cache: 'no-store',
                credentials: 'same-origin',
            });
            if (!response.ok) return false;

            const finPath = new URL(response.url, window.location.origin).pathname || '';
            if (finPath.indexOf('maintenance.html') !== -1) {
                window.ulpGoMaintenanceFullPage();
                return true;
            }

            const html = await response.text();
            const newDoc = new DOMParser().parseFromString(html, 'text/html');
            if (typeof window.ulpIsMaintenanceDocument === 'function' && window.ulpIsMaintenanceDocument(newDoc)) {
                window.ulpGoMaintenanceFullPage();
                return true;
            }

            const newEl = newDoc.querySelector(selector);
            if (!newEl) return false;

            try {
                const newCsrf = newDoc.querySelector('meta[name="csrf-token"]');
                const curCsrf = document.querySelector('meta[name="csrf-token"]');
                const nextTok = newCsrf && newCsrf.getAttribute('content');
                if (curCsrf && nextTok) curCsrf.setAttribute('content', nextTok);
            } catch (e) { /* ignore */ }

            currentEl.innerHTML = newEl.innerHTML;

            if (path === '/') {
                const newBadge = newDoc.querySelector('#vip-new-badge');
                const curBadge = document.querySelector('#vip-new-badge');
                if (newBadge && curBadge) {
                    curBadge.className = newBadge.className;
                    curBadge.innerHTML = newBadge.innerHTML;
                    if (newBadge.hasAttribute('hidden')) {
                        curBadge.setAttribute('hidden', '');
                    } else {
                        curBadge.removeAttribute('hidden');
                    }
                    const ariaHidden = newBadge.getAttribute('aria-hidden');
                    if (ariaHidden != null) {
                        curBadge.setAttribute('aria-hidden', ariaHidden);
                    } else {
                        curBadge.removeAttribute('aria-hidden');
                    }
                }
            }

            if (typeof window.initializeLikes === 'function') window.initializeLikes();
            if (typeof window.initializeFileStatsRealtime === 'function') window.initializeFileStatsRealtime();
            if (typeof window.ulpUpdateLiveTimes === 'function') window.ulpUpdateLiveTimes();
            if (typeof window.hideAllTooltips === 'function') window.hideAllTooltips();
            if (
                (path === '/discussions' || /^\/discussions\/c\//i.test(path)) &&
                typeof window.ulpStripNonPublicForumTopicCards === 'function'
            ) {
                window.ulpStripNonPublicForumTopicCards();
            }
            return true;
        } catch (e) {
            console.warn('SPA: feed fragment refresh failed', e);
            return false;
        }
    };

    /**
     * Remove Turnstile before replacing <main>. Otherwise Cloudflare can leave work queued / stray
     * state that makes the tab feel frozen and blocks follow-up SPA navigations (common on /login).
     */
    function ulpDisposeTurnstileWidget(container) {
        if (!container) return;
        try {
            const el = container.querySelector('[data-ulp-turnstile-sitekey]');
            const wid = window.__ulpTurnstileWidgetId;
            if (window.turnstile && typeof window.turnstile.remove === 'function' && wid != null && wid !== '') {
                try {
                    window.turnstile.remove(wid);
                } catch (e) { /* ignore */ }
            } else if (el && window.turnstile && typeof window.turnstile.reset === 'function') {
                try {
                    window.turnstile.reset(el);
                } catch (e) { /* ignore */ }
            }
            if (el) {
                el.removeAttribute('data-ulp-turnstile-mounted');
                el.innerHTML = '';
            }
        } catch (e) { /* ignore */ }
        window.__ulpTurnstileWidgetId = null;
    }

    /** Drop Turnstile JS when leaving /login|/register so /discussions etc. do not log CF iframe noise. */
    function ulpTeardownTurnstileUnlessAuthPath(pathname) {
        const p = normalizePath(pathname || window.location.pathname);
        if (p === '/login' || p === '/register') return;
        ulpDisposeTurnstileWidget(document.getElementById('app-container') || document);
        document.querySelectorAll('script[data-ulp-cf-turnstile-api], script[src*="turnstile/v0/api.js"]').forEach((s) => {
            try {
                s.remove();
            } catch (e) { /* ignore */ }
        });
        window.__ulpTurnstileApiPromise = null;
        try {
            delete window.turnstile;
        } catch (e) {
            window.turnstile = undefined;
        }
    }

    function ensureTurnstileApiLoaded() {
        if (window.turnstile) return Promise.resolve(true);
        if (window.__ulpTurnstileApiPromise) return window.__ulpTurnstileApiPromise;

        const existing = document.querySelector('script[data-ulp-cf-turnstile-api], script[src*="challenges.cloudflare.com/turnstile/v0/api.js"]');
        window.__ulpTurnstileApiPromise = new Promise((resolve) => {
            let settled = false;
            const done = (ok) => {
                if (settled) return;
                settled = true;
                resolve(!!ok);
            };

            const waitReady = () => {
                let tries = 0;
                const poll = setInterval(() => {
                    if (window.turnstile) {
                        clearInterval(poll);
                        done(true);
                        return;
                    }
                    tries += 1;
                    if (tries > 120) {
                        clearInterval(poll);
                        done(false);
                    }
                }, 50);
            };

            if (existing) {
                existing.addEventListener('load', () => done(true), { once: true });
                existing.addEventListener('error', () => done(false), { once: true });
                waitReady();
                return;
            }

            const script = document.createElement('script');
            script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
            script.async = true;
            script.setAttribute('data-ulp-cf-turnstile-api', '1');
            script.onload = () => done(true);
            script.onerror = () => done(false);
            document.head.appendChild(script);
            waitReady();
        }).finally(() => {
            if (!window.turnstile) window.__ulpTurnstileApiPromise = null;
        });

        return window.__ulpTurnstileApiPromise;
    }

    async function mountTurnstileInContainer(container, gen) {
        const turnstileEl = container
            ? container.querySelector('[data-ulp-turnstile-sitekey]')
            : null;
        if (!turnstileEl) return;
        if (activeSpaNavigationGen !== gen) return;
        if (turnstileEl.querySelector('iframe')) {
            turnstileEl.setAttribute('data-ulp-turnstile-mounted', '1');
            return;
        }
        if (turnstileEl.getAttribute('data-ulp-turnstile-mounted') === '1') return;

        const loaded = await ensureTurnstileApiLoaded();
        if (!loaded || !window.turnstile || activeSpaNavigationGen !== gen) return;

        try {
            if (typeof window.turnstile.render !== 'function') {
                return;
            }
            const sitekey = turnstileEl.getAttribute('data-ulp-turnstile-sitekey');
            if (!sitekey) return;
            const appearanceRaw = 'always';
            const renderOpts = {
                sitekey,
                theme: turnstileEl.getAttribute('data-ulp-turnstile-theme')
                    || turnstileEl.getAttribute('data-theme') || 'dark',
                appearance: ['always', 'execute', 'interaction-only'].includes(appearanceRaw) ? appearanceRaw : 'always',
                callback: typeof window.onTurnstileSuccess === 'function' ? window.onTurnstileSuccess : undefined,
                'expired-callback': typeof window.onTurnstileExpired === 'function' ? window.onTurnstileExpired : undefined,
                'error-callback': function () {
                    if (typeof window.onTurnstileExpired === 'function') {
                        window.onTurnstileExpired();
                    }
                    try {
                        window.turnstile.reset(turnstileEl);
                    } catch (e) { /* ignore */ }
                },
            };
            const wid = window.turnstile.render(turnstileEl, renderOpts);
            if (wid != null && wid !== '') {
                window.__ulpTurnstileWidgetId = wid;
                turnstileEl.setAttribute('data-ulp-turnstile-mounted', '1');
            }
        } catch (e) {
            console.warn('SPA: Turnstile render error:', e);
        }
    }

    function normalizePath(path) {
        if (!path) return '/';
        return (path !== '/' && path.endsWith('/')) ? path.slice(0, -1) : path;
    }

    function getListTypeByPath(path) {
        const p = normalizePath(path);
        if (p === '/') return 'file';
        if (p.startsWith('/resources')) return 'resource';
        if (p === '/discussions') return 'forum_category';
        if (p.startsWith('/discussions/c/')) return 'forum_topic';
        return null;
    }

    /** Files vs Resources vs Forum — used to drop return-focus anchor when switching major areas. */
    function getSectionForPath(pathname) {
        const p = normalizePath(pathname || '/');
        if (p === '/' || p.startsWith('/file/') || p.startsWith('/edit/')) return 'file';
        if (p.startsWith('/resources')) return 'resource';
        if (p.startsWith('/discussions')) return 'forum';
        return 'other';
    }

    /** Updated after each successful SPA navigation; popstate uses this as the true "from" path. */
    const navState = { spaPreviousPath: normalizePath(window.location.pathname) };

    function isAdminPath(pathname) {
        const p = normalizePath(pathname || '/');
        return p === '/admin' || p.startsWith('/admin/');
    }

    function saveListReturnAnchor(anchor) {
        persistListReturnAnchor(anchor);
    }

    function syncDetailFilterChipsFromAnchor() {
        const path = normalizePath(window.location.pathname || '/');
        const anchor = readListReturnAnchor();
        /* View-only: /file/5/edit and /resources/5/edit must not match (would run chip sync on edit shells). */
        const resourceDetail = path.match(/^\/resources\/(\d+)$/);
        const fileDetail = path.match(/^\/file\/(\d+)$/);

        if (resourceDetail) {
            const chips = document.querySelectorAll('[data-resource-category-chip]');
            if (!chips.length) return;
            const valid = new Set(['forum', 'market', 'telegram_channel', 'telegram_group', 'other']);
            let selected = 'all';
            if (anchor && anchor.type === 'resource') {
                const fromChip = (anchor.listCategory || '').trim().toLowerCase();
                if (fromChip && fromChip !== 'all' && valid.has(fromChip)) {
                    selected = fromChip;
                } else {
                    const listPath = normalizePath(anchor.listPath || '');
                    if (listPath === '/resources' || listPath.startsWith('/resources')) {
                        try {
                            const q = new URLSearchParams(String(anchor.listQuery || '').replace(/^\?/, ''));
                            const cat = (q.get('category') || '').trim().toLowerCase();
                            if (cat && cat !== 'all' && valid.has(cat)) selected = cat;
                        } catch (e) { /* ignore */ }
                    }
                }
            }
            if (selected === 'all') {
                const page = document.querySelector('.page-toolbar-page--detail-nav[data-detail-resource-category]');
                const itemCat = page
                    ? String(page.getAttribute('data-detail-resource-category') || '').trim().toLowerCase()
                    : '';
                if (valid.has(itemCat)) selected = itemCat;
            }
            chips.forEach((chip) => chip.classList.remove('active'));
            const activeChip = document.querySelector('[data-resource-category-chip="' + selected + '"]')
                || document.querySelector('[data-resource-category-chip="all"]');
            if (activeChip) activeChip.classList.add('active');
            return;
        }

        if (fileDetail) {
            const chips = document.querySelectorAll('[data-file-filter-chip]');
            if (!chips.length) return;
            const valid = new Set(['free', 'paid', 'vip']);
            let selected = 'all';
            if (anchor && anchor.type === 'file') {
                const fromChip = (anchor.listFilter || '').trim().toLowerCase();
                if (fromChip && fromChip !== 'all' && valid.has(fromChip)) {
                    selected = fromChip;
                } else if (normalizePath(anchor.listPath || '') === '/') {
                    try {
                        const q = new URLSearchParams(String(anchor.listQuery || '').replace(/^\?/, ''));
                        const filter = (q.get('filter') || 'all').trim().toLowerCase();
                        if (filter && filter !== 'all' && valid.has(filter)) selected = filter;
                    } catch (e) { /* ignore */ }
                }
            }
            if (selected === 'all') {
                const page = document.querySelector('.page-toolbar-page--detail-nav[data-detail-file-filter]');
                const itemFilter = page
                    ? String(page.getAttribute('data-detail-file-filter') || '').trim().toLowerCase()
                    : '';
                if (valid.has(itemFilter)) selected = itemFilter;
            }
            chips.forEach((chip) => chip.classList.remove('active'));
            const activeChip = document.querySelector('[data-file-filter-chip="' + selected + '"]')
                || document.querySelector('[data-file-filter-chip="all"]');
            if (activeChip) activeChip.classList.add('active');
        }
    }

    function applyDetailBackTargetFromAnchor() {
        const anchor = readListReturnAnchor();
        if (!anchor || !anchor.listPath) return;
        const returnHref = `${anchor.listPath}${anchor.listQuery || ''}`;
        if (!returnHref) return;
        const path = normalizePath(window.location.pathname || '/');
        /* Do not treat /file/…/edit or /resources/…/edit as detail — those pages use the same toolbar class as "back to item". */
        const isDetailPage =
            /^\/file\/\d+$/.test(path) ||
            /^\/resources\/\d+$/.test(path) ||
            /^\/discussions\/t\/\d+/.test(path);
        if (!isDetailPage) return;

        document.querySelectorAll('a.forum-cat-back, .forum-topic-toolbar-back').forEach((link) => {
            if (!(link instanceof HTMLAnchorElement)) return;
            link.setAttribute('href', returnHref);
            link.setAttribute('data-spa-return-href', returnHref);
            if (link.classList.contains('forum-topic-toolbar-back')) {
                const labelEl = link.querySelector('.forum-topic-toolbar-back-label');
                if (labelEl) {
                    labelEl.textContent = forumTopicBackLabelFromAnchor(anchor);
                }
            }
        });
    }

    function isRetryableSpaStatus(code) {
        return code === 408 || code === 425 || code === 429 || code === 500 || code === 502 || code === 503 || code === 504;
    }

    function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async function fetchSpaPageWithRetry(url, headersObj, externalSignal) {
        const maxAttempts = 2; // first try + one short retry
        let lastError = null;
        for (let attempt = 0; attempt < maxAttempts; attempt++) {
            let controller = null;
            let timer = null;
            let onExternal = null;
            try {
                controller = new AbortController();
                if (externalSignal) {
                    if (externalSignal.aborted) {
                        controller.abort();
                    } else {
                        onExternal = () => {
                            try { controller.abort(); } catch (e) { /* ignore */ }
                        };
                        externalSignal.addEventListener('abort', onExternal);
                    }
                }
                timer = setTimeout(() => controller.abort(), 15000);
                const response = await fetch(url, {
                    headers: headersObj,
                    signal: controller.signal
                });
                clearTimeout(timer);
                if (onExternal && externalSignal) externalSignal.removeEventListener('abort', onExternal);
                if (response.ok) return response;
                const ct = (response.headers.get('content-type') || '').toLowerCase();
                if (response.status === 403 && ct.includes('application/json')) {
                    return response;
                }
                if (attempt < maxAttempts - 1 && isRetryableSpaStatus(Number(response.status || 0))) {
                    await sleep(280 + (attempt * 300));
                    continue;
                }
                throw new Error(`HTTP ${response.status}`);
            } catch (err) {
                if (timer) clearTimeout(timer);
                if (onExternal && externalSignal) externalSignal.removeEventListener('abort', onExternal);
                lastError = err;
                if (externalSignal && externalSignal.aborted) {
                    throw err;
                }
                if (attempt < maxAttempts - 1) {
                    await sleep(280 + (attempt * 300));
                    continue;
                }
            }
        }
        throw (lastError || new Error('SPA fetch failed'));
    }

    /** Run callback after smooth scroll finishes (highlight must not run mid-scroll). */
    function ulpAfterScrollSettled(callback, maxWaitMs) {
        const maxWait = maxWaitMs != null ? maxWaitMs : 1400;
        let done = false;
        const finish = () => {
            if (done) return;
            done = true;
            window.removeEventListener('scrollend', onScrollEnd, true);
            clearTimeout(fallbackTimer);
            callback();
        };
        const onScrollEnd = () => finish();
        if ('onscrollend' in window) {
            window.addEventListener('scrollend', onScrollEnd, true);
        }
        let lastY = window.scrollY;
        let stableFrames = 0;
        const pollStart = Date.now();
        const poll = () => {
            if (done) return;
            const y = window.scrollY;
            if (Math.abs(y - lastY) < 2) stableFrames += 1;
            else {
                stableFrames = 0;
                lastY = y;
            }
            if (stableFrames >= 5) {
                finish();
                return;
            }
            if (Date.now() - pollStart < maxWait) requestAnimationFrame(poll);
        };
        requestAnimationFrame(poll);
        const fallbackTimer = setTimeout(finish, maxWait);
    }

    function tryRestoreListReturnAnchor(targetUrlObj) {
        const anchor = readListReturnAnchor();
        if (!anchor) return false;
        // Only restore scroll when returning to a specific card (from detail/back).
        // Filter/tab clicks save listQuery without id — scrollY fallback would jump to top mid-scroll.
        if (!anchor.id) return false;
        const targetPath = normalizePath(targetUrlObj.pathname);
        if (anchor.listPath !== targetPath) {
            return false;
        }

        let selector = `.file-item[data-file-id="${anchor.id}"]`;
        if (anchor.type === 'resource') {
            selector = `.resource-item[data-listing-id="${anchor.id}"]`;
        } else if (anchor.type === 'forum_category') {
            selector = `.forum-category-card[data-category-id="${anchor.id}"]`;
        } else if (anchor.type === 'forum_topic') {
            selector = `.forum-topic-list-card[data-topic-id="${anchor.id}"]`;
        }
        const scrollToAnchorTarget = (targetEl) => {
            const reducedMotion = window.matchMedia
                && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            const scrollBehavior = reducedMotion ? 'auto' : 'smooth';
            window.__ulpListRestoreInProgressUntil = Date.now() + (reducedMotion ? 600 : 1800);

            const playHighlight = () => {
                targetEl.classList.remove('return-focus-pulse');
                void targetEl.offsetWidth;
                targetEl.classList.add('return-focus-pulse');
                setTimeout(() => targetEl.classList.remove('return-focus-pulse'), 700);
            };

            targetEl.scrollIntoView({ behavior: scrollBehavior, block: 'center' });

            if (reducedMotion || scrollBehavior === 'auto') {
                requestAnimationFrame(() => requestAnimationFrame(playHighlight));
            } else {
                ulpAfterScrollSettled(playHighlight, 1400);
            }
        };

        let attemptsLeft = 28;
        const tryFindAndScroll = () => {
            const targetEl = document.querySelector(selector);
            if (targetEl) {
                scrollToAnchorTarget(targetEl);
                clearListReturnAnchor();
                return;
            }
            attemptsLeft -= 1;
            if (attemptsLeft <= 0) {
                const fallbackY = Number(anchor.scrollY);
                if (Number.isFinite(fallbackY) && fallbackY >= 0) {
                    window.__ulpListRestoreInProgressUntil = Date.now() + 900;
                    window.scrollTo({ top: Math.round(fallbackY), behavior: 'smooth' });
                    clearListReturnAnchor();
                }
                return;
            }
            setTimeout(tryFindAndScroll, 80);
        };

        setTimeout(tryFindAndScroll, 80);
        // Anchor matched the destination list, so suppress the default scrollTo(0,0)
        // while we wait for cards to render on slower/mobile layouts.
        return true;
    }

    /**
     * Before new inline scripts run (join_*), remove Socket.IO presence for rooms that
     * do not match the SPA destination. Covers topic → / where leave_forum_topic
     * may not run and join_file never fires.
     */
    function syncPresenceRoomsForSpaNavigation(targetUrl) {
        if (typeof window.__ulpResyncRealtimeSubscriptionsForUrl === 'function') {
            window.__ulpResyncRealtimeSubscriptionsForUrl(targetUrl);
            return;
        }
        const socket = window.getSharedSocket ? window.getSharedSocket() : window.socket;
        if (!socket || !socket.connected) return;
        try {
            const u = new URL(targetUrl, window.location.origin);
            const path = normalizePath(u.pathname || '/');
            let forumTopicId = null;
            let fileId = null;
            let listingId = null;
            const mTopic = path.match(/^\/discussions\/t\/(\d+)/);
            if (mTopic) forumTopicId = mTopic[1];
            const mFile = path.match(/^\/file\/(\d+)/);
            if (mFile) fileId = mFile[1];
            const mRes = path.match(/^\/resources\/(\d+)/);
            if (mRes) listingId = mRes[1];
            const onFilesFeed = path === '/';
            const onResourcesFeed = path === '/resources';
            const onDiscussionsFeed = path === '/discussions' || /^\/discussions\/c\//i.test(path);
            socket.emit('sync_presence_route', {
                forum_topic_id: forumTopicId,
                file_id: fileId,
                listing_id: listingId,
                files_feed: onFilesFeed,
                resources_feed: onResourcesFeed,
                discussions_feed: onDiscussionsFeed,
            });
            if (onFilesFeed) socket.emit('join_files_feed');
            if (onResourcesFeed) socket.emit('join_resources_feed');
            if (onDiscussionsFeed) socket.emit('join_discussions_feed');
        } catch (e) {
            console.warn('SPA: syncPresenceRoomsForSpaNavigation', e);
        }
    }

    /** Remove global chat ids from inside main so they cannot hijack getElementById / querySelector. */
    function ulpStripConflictingChatIdsFromMain(mainEl) {
        if (!mainEl || typeof mainEl.querySelectorAll !== 'function') return;
        const bad = new Set([
            'chat-widget-container',
            'chat-toggle-btn',
            'chat-backdrop',
            'chat-window',
            'chat-messages',
            'chat-input',
            'chat-send-btn',
            'chat-close-btn',
            'chat-clear-btn',
            'chat-emoji-btn',
            'chat-unread-badge',
            'chat-typing-indicator',
            'emoji-picker',
        ]);
        try {
            const shellOnBody = (() => {
                try {
                    return !!(
                        document.body
                        && (
                            document.body.querySelector(':scope > #chat-widget-container')
                            || document.body.querySelector(':scope > [data-ulp-floating-chat]')
                        )
                    );
                } catch (e) {
                    return false;
                }
            })();
            // Only <main> descendants are scanned — the real floating shell normally lives outside <main>.
            mainEl.querySelectorAll('[id]').forEach((node) => {
                if (!bad.has(node.id)) return;
                // Unclosed tags in huge admin pages can parse the real shell *inside* <main>. Never orphan it:
                // if there is no body-level shell, keep id on a complete in-main copy so getElementById still works.
                if (node.id === 'chat-widget-container' && node.closest('main') === mainEl) {
                    const looksLikeShell = !!(node.querySelector && node.querySelector('#chat-window'));
                    if (!shellOnBody && looksLikeShell) return;
                }
                node.removeAttribute('id');
            });
            // Do NOT strip `data-ulp-floating-chat` from <main> — that can hit the real shell when markup nests it
            // under <main> and makes __ulpGetFloatingChatRoot() return null after navigation.
        } catch (e) { /* ignore */ }
    }

    /**
     * SPA navigation: keep chat open/closed state; repair shell + sync chrome (do not force-close).
     */
    function ulpSyncFloatingChatForSpaNavigation() {
        try {
            if (typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
                window.__ulpRelocateFloatingChatShellOutOfMain();
            }
            if (typeof window.__ulpRepairFloatingChatShell === 'function') {
                window.__ulpRepairFloatingChatShell(null);
            } else if (typeof window.__ulpSyncChatChrome === 'function') {
                window.__ulpSyncChatChrome();
            }
        } catch (e) { /* ignore */ }
    }

    // Main Load Function
    async function loadPage(url, push = true, options = {}) {
        let showLoader = options.showLoader !== false;
        const preserveScroll = options.preserveScroll === true;
        const savedScrollX = preserveScroll
            ? Math.max(0, Math.round(window.pageXOffset || window.scrollX || 0))
            : 0;
        const savedScrollY = preserveScroll
            ? Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0))
            : 0;
        const loader = document.getElementById('global-loader');
        const gen = ++spaNavGeneration;
        activeSpaNavigationGen = gen;

        if (spaFetchAbort) {
            try { spaFetchAbort.abort(); } catch (e) { /* ignore */ }
            spaFetchAbort = null;
        }
        spaFetchAbort = new AbortController();

        if (isLoadingPage) {
            console.warn('SPA: New navigation supersedes in-flight request.');
            resetSpaLoaderShell(loader, true);
        }
        isLoadingPage = true;

        try {
            const dlPath = normalizePath(new URL(url, window.location.origin).pathname);
            if (dlPath.startsWith('/download/')) {
                isLoadingPage = false;
                spaFetchAbort = null;
                window.location.href = url;
                return true;
            }
        } catch (e) { /* ignore */ }

        const destEarly = new URL(url, window.location.origin);
        const toPathEarly = normalizePath(destEarly.pathname);
        const fromPathEarly = options.fromPopstate ? navState.spaPreviousPath : normalizePath(window.location.pathname);
        const spaLeavingAdminScope = isAdminPath(fromPathEarly) && !isAdminPath(toPathEarly);
        if (getSectionForPath(fromPathEarly) !== getSectionForPath(toPathEarly)) {
            clearListReturnAnchor();
        }

        if (!options.fromPopstate) {
            const mFileDetail = toPathEarly.match(/^\/file\/(\d+)/);
            const mResDetail = toPathEarly.match(/^\/resources\/(\d+)/);
            if (mFileDetail && fromPathEarly === '/') {
                const cur = new URL(window.location.href, window.location.origin);
                persistListReturnAnchor({
                    type: 'file',
                    id: mFileDetail[1],
                    listPath: '/',
                    listQuery: cur.search || '',
                    scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
                    ts: Date.now()
                });
            } else if (mResDetail && fromPathEarly === '/resources') {
                const cur = new URL(window.location.href, window.location.origin);
                persistListReturnAnchor({
                    type: 'resource',
                    id: mResDetail[1],
                    listPath: '/resources',
                    listQuery: cur.search || '',
                    scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
                    ts: Date.now()
                });
            }
        }

        // Only tear down admin timers/observer when leaving /admin — not when entering (that broke polling + observers).
        if (spaLeavingAdminScope && typeof window.__ulpSpaCleanupAdmin === 'function') {
            try {
                window.__ulpSpaCleanupAdmin({ fromPath: fromPathEarly, toPath: toPathEarly });
            } catch (e) {
                console.warn('SPA: __ulpSpaCleanupAdmin failed', e);
            }
        }

        // Auto-close mobile menu if open
        const mobileMenu = document.getElementById('mobile-menu');
        const mobileToggle = document.getElementById('mobile-menu-toggle');
        if (mobileMenu && mobileMenu.classList.contains('active')) {
            mobileMenu.classList.remove('active');
            if (mobileToggle) mobileToggle.classList.remove('open');
        }

        // Cleanup Chat Room (Viewers/Typing) before leaving
        if (window.cleanupChatRoom) {
            window.cleanupChatRoom();
        }

        try {
            const toNav = normalizePath(new URL(url, window.location.origin).pathname);
            ulpTeardownTurnstileUnlessAuthPath(toNav);
        } catch (e) { /* ignore */ }

        // Show loading state (optional, e.g., thin progress bar)
        if (document.body && showLoader) document.body.style.cursor = 'wait';
        // appContainer.style.opacity = '0.5'; // Removed to reduce blink

        if (loader && showLoader) {
            const loaderText = loader.querySelector('span');
            if (loaderText) {
                loaderText.textContent = 'Syncing...';
                loaderText.innerText = 'Syncing...'; // Fallback
            }
            loader.classList.add('active');
            loader.style.display = 'flex'; // Aggressive override
        }

        try {
            const response = await fetchSpaPageWithRetry(url, { 'X-Requested-With': 'XMLHttpRequest' }, spaFetchAbort.signal);

            if (activeSpaNavigationGen !== gen) {
                return false;
            }

            if (response.status === 403) {
                const ct403 = (response.headers.get('content-type') || '').toLowerCase();
                if (ct403.includes('application/json')) {
                    let deniedPayload = null;
                    try {
                        deniedPayload = await response.json();
                    } catch (e) { /* ignore */ }
                    if (deniedPayload && deniedPayload.spa_denied) {
                        if (typeof window.showToast === 'function') {
                            window.showToast(
                                'Error',
                                deniedPayload.message || 'Access denied',
                                null,
                                'fas fa-circle-exclamation',
                                null,
                                'error'
                            );
                        }
                        const redir = deniedPayload.redirect || '/';
                        return loadPage(redir, push, { ...options, showLoader: options.showLoader !== false });
                    }
                }
            }

            // Handle Redirects (if fetch followed one, update URL)
            const finalUrl = response.url;

            // Full reload only when redirected outside current origin.
            // Auth pages (/login, /register, …) render through SPA like other internal routes.
            try {
                const finalU = new URL(finalUrl, window.location.origin);
                if (finalU.origin !== window.location.origin) {
                    window.location.href = finalUrl;
                    return true;
                }
            } catch (e) {
                window.location.href = finalUrl;
                return true;
            }

            try {
                const finPath = new URL(finalUrl, window.location.origin).pathname || '';
                if (finPath.indexOf('maintenance.html') !== -1) {
                    window.ulpGoMaintenanceFullPage();
                    return true;
                }
            } catch (e) { /* ignore */ }

            // Fetch's response.url sometimes drops the query string while the HTML matches the requested URL
            // (e.g. Back from /discussions/new to /discussions?category=…). Keep the client URL in sync.
            let effectiveUrl = finalUrl;
            try {
                const reqU = new URL(url, window.location.origin);
                const finU = new URL(finalUrl, window.location.origin);
                if (
                    reqU.origin === finU.origin &&
                    reqU.pathname === finU.pathname &&
                    reqU.search &&
                    finU.search === ''
                ) {
                    effectiveUrl = reqU.pathname + reqU.search + (reqU.hash || '');
                }
            } catch (e) { /* ignore */ }

            const html = await response.text();
            if (activeSpaNavigationGen !== gen) {
                return false;
            }
            const newDoc = new DOMParser().parseFromString(html, 'text/html');
            if (window.ulpIsMaintenanceDocument(newDoc)) {
                window.ulpGoMaintenanceFullPage();
                return true;
            }
            const newContent = newDoc.querySelector('main');
            const newTitle = newDoc.querySelector('title');

            if (newContent && (newContent.classList.contains('ulp-maint-main') || newContent.querySelector('.ulp-maint-panel'))) {
                window.ulpGoMaintenanceFullPage();
                return true;
            }

            if (!newContent) {
                console.error('SPA: No <main> found in response.');
                window.location.href = url;
                return true;
            }

            const destForScroll = new URL(effectiveUrl, window.location.origin);
            let listScrollResetAtSwap = false;

            // --- 1. Dynamic Asset Sync (BEFORE SWAP) ---
            const currentHeadLinks = Array.from(document.head.querySelectorAll('link[rel="stylesheet"]'));
            const newHeadLinks = Array.from(newDoc.head.querySelectorAll('link[rel="stylesheet"]'));
            const cssPromises = [];

            // Helper for URL normalization
            const getCleanPath = (href) => (href || '').split('?')[0].replace(/^(?:https?:\/\/[^\/]+)?\//, '');

            // 1a. Identify stale styles (Identify now, remove LATER)
            const staleLinks = currentHeadLinks.filter(link => {
                const href = link.getAttribute('href');
                if (!href || href.includes('style.css') || href.includes('all.min.css')) return false;
                const cleanPath = getCleanPath(href);
                return !newHeadLinks.some(newLink => getCleanPath(newLink.getAttribute('href')) === cleanPath);
            });

            // 1b. Inject New Styles (<link>)
            newHeadLinks.forEach(newLink => {
                const href = newLink.getAttribute('href');
                if (!href) return;

                const cleanPath = getCleanPath(href);
                const alreadyPresent = currentHeadLinks.some(link => getCleanPath(link.getAttribute('href')) === cleanPath);

                if (!alreadyPresent) {
                    const linkEl = document.createElement('link');
                    linkEl.rel = 'stylesheet';
                    linkEl.href = href;

                    const p = new Promise(resolve => {
                        linkEl.onload = resolve;
                        linkEl.onerror = resolve;
                        setTimeout(resolve, 2000);
                    });
                    cssPromises.push(p);
                    document.head.appendChild(linkEl);
                }
            });

            // 1c. Inject Inline Styles (<style>) — replace prior SPA batch only (avoids megabyte admin <style> piling up).
            ulpSpaInjectedHeadStyleNodes.forEach((n) => {
                try {
                    n.remove();
                } catch (e) { /* ignore */ }
            });
            ulpSpaInjectedHeadStyleNodes = [];
            newDoc.head.querySelectorAll('style').forEach((style) => {
                const clone = style.cloneNode(true);
                document.head.appendChild(clone);
                ulpSpaInjectedHeadStyleNodes.push(clone);
            });

            // Wait for all NEW styles to load (hard cap — Safari can delay link.onload around third-party work)
            if (cssPromises.length > 0) {
                await Promise.race([
                    Promise.all(cssPromises),
                    new Promise(r => setTimeout(r, 3500)),
                ]);
                await new Promise(r => requestAnimationFrame(r));
            }
            if (activeSpaNavigationGen !== gen) {
                return false;
            }

            // --- 2. Content & Metadata Swap ---
            // Sync ALL attributes (including classes, id, data-* attributes)
            Array.from(appContainer.attributes).forEach(attr => {
                if (!newContent.hasAttribute(attr.name)) {
                    appContainer.removeAttribute(attr.name);
                }
            });
            Array.from(newContent.attributes).forEach(attr => {
                appContainer.setAttribute(attr.name, attr.value);
            });
            ulpDisposeTurnstileWidget(appContainer);
            try {
                ulpTeardownTurnstileUnlessAuthPath(window.location.pathname);
            } catch (e) { /* ignore */ }
            if (typeof window.ulpTeardownRichEditorsBeforeSpaSwap === 'function') {
                window.ulpTeardownRichEditorsBeforeSpaSwap();
            }
            if (typeof window.__ulpRelocateFloatingChatShellOutOfMain === 'function') {
                window.__ulpRelocateFloatingChatShellOutOfMain();
            }
            ulpSyncFloatingChatForSpaNavigation();
            if (typeof window.ulpSwapMainFromParsed === 'function') {
                await window.ulpSwapMainFromParsed(appContainer, newContent);
            } else {
                appContainer.innerHTML = newContent.innerHTML;
            }
            ulpStripConflictingChatIdsFromMain(appContainer);
            ulpSyncFloatingChatForSpaNavigation();
            if (
                !destForScroll.hash &&
                !options.fromPopstate &&
                !preserveScroll &&
                getListTypeByPath(normalizePath(destForScroll.pathname))
            ) {
                window.scrollTo(0, 0);
                listScrollResetAtSwap = true;
            }
            /* Chat shell repair: chat.js listens for `pageLoaded` (after reinitScripts) with a short delayed
               retry — avoid calling __ulpRepairFloatingChatShell here too (was duplicate log + work). */
            document.title = newTitle ? newTitle.innerText : 'ulp.email';

            // --- 3. Asset Cleanup (AFTER SWAP) ---
            staleLinks.forEach(link => {
                link.remove();
            });

            // Cleanup tooltips
            if (window.hideAllTooltips) window.hideAllTooltips();

            // Mount Turnstile after SPA swap if auth form is present.
            await mountTurnstileInContainer(appContainer, gen);
            if (activeSpaNavigationGen !== gen) {
                return false;
            }

            // --- 3. Header & Footer Sync (Block-level) ---
            if (newDoc) {
                // 1. Sync Header Wrapper
                const currentHeaderWrapper = document.getElementById('site-header-wrapper');
                const newHeaderWrapper = newDoc.getElementById('site-header-wrapper');
                if (currentHeaderWrapper && newHeaderWrapper) {
                    const savedHeaderRightScrollLeft = typeof window.__ulpReadHeaderRightScrollLeft === 'function'
                        ? window.__ulpReadHeaderRightScrollLeft()
                        : 0;
                    currentHeaderWrapper.innerHTML = newHeaderWrapper.innerHTML;
                    if (savedHeaderRightScrollLeft > 0 && typeof window.__ulpRestoreHeaderRightScrollLeft === 'function') {
                        window.__ulpRestoreHeaderRightScrollLeft(savedHeaderRightScrollLeft);
                    }
                    if (typeof window.__ulpSyncMobileHeaderWrapStateImmediate === 'function') {
                        window.__ulpSyncMobileHeaderWrapStateImmediate();
                    }
                    if (typeof window.__ulpScheduleMobileHeaderWrapAfterFonts === 'function') {
                        window.__ulpScheduleMobileHeaderWrapAfterFonts();
                    }
                    if (typeof window.requestPendingCountRefresh === 'function') {
                        window.requestPendingCountRefresh();
                    }
                }

                // 2. Sync Footer Wrapper
                const currentFooterWrapper = document.getElementById('site-footer-wrapper');
                const newFooterWrapper = newDoc.getElementById('site-footer-wrapper');
                if (currentFooterWrapper && newFooterWrapper) {
                    currentFooterWrapper.innerHTML = newFooterWrapper.innerHTML;
                }

                // CSRF meta must track the latest page render (SPA replaces <main> only; head meta was stale).
                try {
                    const newCsrf = newDoc.querySelector('meta[name="csrf-token"]');
                    const curCsrf = document.querySelector('meta[name="csrf-token"]');
                    const nextTok = newCsrf && newCsrf.getAttribute('content');
                    if (curCsrf && nextTok) {
                        curCsrf.setAttribute('content', nextTok);
                    }
                } catch (e) {
                    console.warn('SPA: csrf meta sync failed', e);
                }

                // 3. Authoritative Search Metadata Sync (Ensures correct label & value)
                // This must run AFTER header HTML swap so the elements exist
                const metaPlaceholder = newContent.getAttribute('data-search-placeholder');
                const metaAction = newContent.getAttribute('data-search-action');

                const performSearchSync = (targetUrl) => {
                    const searchInput = document.getElementById('header-search-input');
                    const searchForm = document.getElementById('header-search-form');

                    if (!searchInput) return;

                    const urlStr = targetUrl || window.location.href;
                    const urlObj = new URL(urlStr, window.location.origin);
                    const isRes = urlObj.pathname.startsWith('/resources');
                    const isForum = urlObj.pathname.startsWith('/discussions');
                    const query = urlObj.searchParams.get('q') || '';

                    // 1. Force Value Sync
                    searchInput.value = query;

                    // 2. Force Placeholder Sync
                    const finalPlaceholder = metaPlaceholder || (isForum ? 'Search discussions...' : (isRes ? 'Search resources...' : 'Search files...'));
                    searchInput.placeholder = finalPlaceholder;
                    searchInput.setAttribute('placeholder', finalPlaceholder);

                    // 3. Form Active State
                    if (searchForm) {
                        if (query) {
                            searchForm.classList.add('active');
                        } else if (document.activeElement !== searchInput) {
                            searchForm.classList.remove('active');
                        }
                        if (metaAction) searchForm.action = metaAction;
                    }
                    if (typeof window.updateHeaderSearchClearVisibility === 'function') {
                        window.updateHeaderSearchClearVisibility();
                    }
                };

                performSearchSync(effectiveUrl);
                // Failsafe: Repeat after a short delay
                setTimeout(() => performSearchSync(effectiveUrl), 50);
            }
            // --- 4. Dynamic Script Sync (Support for page-specific JS) ---
            const currentScripts = Array.from(document.head.querySelectorAll('script[src]'));
            const newScripts = Array.from(newDoc.head.querySelectorAll('script[src]'));
            const cleanScriptPath = (src) => (src || '').split('?')[0].replace(/^(?:https?:\/\/[^\/]+)?\//, '');
            const isCoreScript = (src) => {
                if (!src) return true;
                return (
                    src.includes('spa.js') ||
                    src.includes('challenges.cloudflare.com') ||
                    src.includes('socket.io') ||
                    src.includes('quill.min.js') ||
                    src.includes('rich-editor.js') ||
                    src.includes('upload.js') ||
                    src.includes('chat.js') ||
                    src.includes('likes.js') ||
                    src.includes('realtime.js') ||
                    src.includes('cloudflare-fallback.js') ||
                    src.includes('site-banner.js') ||
                    src.includes('listings.js') ||
                    src.includes('resource-form.js') ||
                    src.includes('group-badges.js') ||
                    src.includes('tooltips.js')
                );
            };

            const newScriptPaths = new Set(
                newScripts
                    .map((s) => s.getAttribute('src'))
                    .filter(Boolean)
                    .map(cleanScriptPath)
            );

            // Remove non-core scripts that are not needed on target page (prevents stale admin/page scripts).
            currentScripts.forEach((script) => {
                const src = script.getAttribute('src') || '';
                if (!src || isCoreScript(src)) return;
                const clean = cleanScriptPath(src);
                if (!newScriptPaths.has(clean)) {
                    script.remove();
                }
            });

            // Inject missing/changed scripts by clean path (querystring bumps won't accumulate duplicates).
            newScripts.forEach((newScript) => {
                const src = newScript.getAttribute('src');
                if (!src || isCoreScript(src)) return;
                const clean = cleanScriptPath(src);
                const existing = Array.from(document.head.querySelectorAll('script[src]'))
                    .find((s) => cleanScriptPath(s.getAttribute('src')) === clean);
                if (!existing) {
                    const scriptEl = document.createElement('script');
                    scriptEl.src = src;
                    document.head.appendChild(scriptEl);
                } else if ((existing.getAttribute('src') || '') !== src) {
                    existing.remove();
                    const scriptEl = document.createElement('script');
                    scriptEl.src = src;
                    document.head.appendChild(scriptEl);
                }
            });

            // Update History
            if (activeSpaNavigationGen !== gen) {
                return false;
            }
            if (options.replaceHistory) {
                history.replaceState({}, '', effectiveUrl);
            } else if (push) {
                history.pushState({}, '', effectiveUrl);
            }

            // Presence: must run before reinitScripts so join_* from the new page repopulates only the right room
            syncPresenceRoomsForSpaNavigation(effectiveUrl);

            // Re-initialize Scripts (any <script> left in <main>)
            await reinitScripts();

            if (window.bootRichEditors) {
                try {
                    window.bootRichEditors();
                } catch (editorBootErr) {
                    console.warn('SPA: bootRichEditors failed (non-fatal):', editorBootErr);
                }
            }

            if (typeof window.__ulpSyncDiscussionComposerPinState === 'function') {
                window.__ulpSyncDiscussionComposerPinState();
            }

            // Dispatch event for components to re-run
            document.dispatchEvent(new CustomEvent('pageLoaded', { detail: { url: effectiveUrl } }));
            applyDetailBackTargetFromAnchor();
            syncDetailFilterChipsFromAnchor();

            /* Inline page scripts may touch layout; re-apply chat chrome after they run (admin F5 → SPA home FAB bug). */
            ulpSyncFloatingChatForSpaNavigation();
            requestAnimationFrame(() => {
                requestAnimationFrame(() => {
                    ulpSyncFloatingChatForSpaNavigation();
                });
            });
            setTimeout(ulpSyncFloatingChatForSpaNavigation, 100);

            if (spaLeavingAdminScope) {
                document.documentElement.classList.add('ulp-spa-chat-fab-recover');
                ulpSyncFloatingChatForSpaNavigation();
                requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                        ulpSyncFloatingChatForSpaNavigation();
                        document.documentElement.classList.remove('ulp-spa-chat-fab-recover');
                    });
                });
                setTimeout(ulpSyncFloatingChatForSpaNavigation, 85);
                setTimeout(ulpSyncFloatingChatForSpaNavigation, 340);
            }

            // Scroll Logic
            // CRITICAL: We must use the original 'url' for the hash, because 'finalUrl'
            // (from response.url) often strips fragments.
            const urlObj = new URL(url, window.location.origin);
            const hash = urlObj.hash;
            let didScroll = false;

            if (hash) {
                const targetId = hash.substring(1);
                // Wait for layout/scripts a bit more aggressively
                setTimeout(() => {
                    const targetEl = document.getElementById(targetId);
                    if (targetEl) {
                        targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });

                        // Highlight effect
                        targetEl.style.transition = 'background 0.5s';
                        targetEl.style.backgroundColor = 'rgba(0, 255, 157, 0.2)';
                        setTimeout(() => {
                            targetEl.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
                        }, 2000);
                    } else {
                        console.warn('SPA: Anchor element NOT found:', hash);
                        window.scrollTo(0, 0);
                    }
                }, 150);

                didScroll = true;
            }

            if (!didScroll && getListTypeByPath(urlObj.pathname)) {
                didScroll = tryRestoreListReturnAnchor(urlObj);
            }

            if (!didScroll && options.scrollBehavior === 'forumReply') {
                const scrollToForumReply = () => {
                    const el = document.querySelector('.forum-topic-page .forum-reply-area');
                    if (el) el.scrollIntoView({ behavior: 'auto', block: 'end' });
                };
                scrollToForumReply();
                requestAnimationFrame(() => {
                    scrollToForumReply();
                    setTimeout(scrollToForumReply, 60);
                });
                didScroll = true;
            }

            if (!didScroll && !listScrollResetAtSwap && !preserveScroll) {
                window.scrollTo(0, 0);
            }

            if (preserveScroll) {
                runScrollRestore(savedScrollX, savedScrollY, { force: false, armGuard: true });
            }

            // Update Nav State
            updateNavState(effectiveUrl);
            navState.spaPreviousPath = normalizePath(new URL(effectiveUrl, window.location.origin).pathname);
            return true;

        } catch (err) {
            if (activeSpaNavigationGen !== gen) {
                return false;
            }
            if (err && err.name === 'AbortError') {
                return false;
            }
            console.error('SPA: Fetch error. Falling back to full reload.', err);
            window.location.href = url; // Fallback to normal load
            return false;
        } finally {
            if (activeSpaNavigationGen === gen) {
                isLoadingPage = false;
                spaFetchAbort = null;
                if (loader && showLoader) {
                    loader.classList.remove('active');
                    loader.style.display = 'none';
                    const loaderText = loader.querySelector('span');
                    if (loaderText) loaderText.textContent = 'Syncing...';
                }
                if (document.body) document.body.style.cursor = '';
                appContainer.style.opacity = '1';
            }
        }
    }

    // Update Header Navigation Active State
    function updateNavState(url) {
        try {
            var urlObj = new URL(url, window.location.origin);
            var path = urlObj.pathname;
            // Normalize path: ensure it doesn't end with slash if it's not root
            var normPath = (path !== '/' && path.endsWith('/')) ? path.slice(0, -1) : path;
            var navLinks = document.querySelectorAll('header .nav-item, header .nav-tab, .mobile-nav-item, .admin-btn');
            navLinks.forEach(function (link) {
                var linkUrl = new URL(link.href, window.location.origin);
                var linkPath = linkUrl.pathname;
                var normLinkPath = (linkPath !== '/' && linkPath.endsWith('/')) ? linkPath.slice(0, -1) : linkPath;

                var isActive = false;
                if (normLinkPath === '/') {
                    // Files tab: only active on root or specific file views
                    isActive = (normPath === '/' ||
                        normPath.startsWith('/file/') ||
                        normPath.startsWith('/edit/'));
                } else if (normLinkPath.startsWith('/resources')) {
                    // Resources tab: active on /resources and everything under it
                    isActive = normPath.startsWith('/resources');
                } else if (normLinkPath.startsWith('/discussions')) {
                    isActive = normPath.startsWith('/discussions');
                } else {
                    // Fallback to exact match (covers /upload, /admin, etc)
                    isActive = (normPath === normLinkPath);
                }

                if (isActive) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
        } catch (e) {
            console.error('SPA: Error updating nav state:', e);
        }
    }

    // Global Re-init Function
    window.reinitScripts = async function () {
        if (window.initUpload) window.initUpload();
        if (window.initFlashAutoHide) window.initFlashAutoHide();
        if (typeof window.ulpRunPageScripts === 'function') {
            await window.ulpRunPageScripts(appContainer);
        }
        if (typeof window.__ulpSyncMobileHeaderWrapState === 'function') {
            window.__ulpSyncMobileHeaderWrapState();
        }
    };

    // Handle Back/Forward Browser Buttons
    window.addEventListener('popstate', () => {
        loadPage(window.location.href, false, { showLoader: false, fromPopstate: true }).catch(err => {
            console.error('SPA: Popstate error, falling back to full reload', err);
            window.location.href = window.location.href;
        });
    });

    // Expose for external use (e.g. search)
    if (typeof window.__ulpSpaBindLoadPage === 'function') {
        window.__ulpSpaBindLoadPage(loadPage);
    } else {
        window.loadPage = loadPage;
    }

    window.ulpSubmitFormSpa = async function ulpSubmitFormSpa(form, options) {
        options = options || {};
        if (!form) return false;
        if (!window.loadPage) {
            if (typeof HTMLFormElement !== 'undefined' && HTMLFormElement.prototype.submit) {
                HTMLFormElement.prototype.submit.call(form);
            } else {
                form.submit();
            }
            return false;
        }

        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        let originalBtnHtml = '';
        if (submitBtn && submitBtn.tagName === 'BUTTON') {
            originalBtnHtml = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        }

        try {
            const formData = new FormData(form);
            const action = form.getAttribute('action') || window.location.href;
            const method = (form.getAttribute('method') || 'POST').toUpperCase();
            const csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
            const headers = {
                'X-Requested-With': 'XMLHttpRequest',
                Accept: 'text/html',
            };
            if (csrf) headers['X-CSRFToken'] = csrf;

            const response = await fetch(action, {
                method,
                body: formData,
                credentials: 'same-origin',
                redirect: 'follow',
                headers,
            });

            const targetUrl = response.url || action;
            try {
                const finU = new URL(targetUrl, window.location.origin);
                if (finU.origin !== window.location.origin) {
                    window.location.href = targetUrl;
                    return true;
                }
            } catch (e) {
                window.location.href = targetUrl;
                return true;
            }

            await window.loadPage(targetUrl, options.push !== false, {
                showLoader: options.showLoader !== false,
                preserveScroll: options.preserveScroll === true,
            });
            return true;
        } catch (err) {
            console.error('SPA form submit failed:', err);
            if (typeof window.showToast === 'function') {
                window.showToast(
                    'Error',
                    'Could not submit the form. Try again.',
                    null,
                    'fas fa-circle-exclamation',
                    null,
                    'error'
                );
            }
            return false;
        } finally {
            if (submitBtn && submitBtn.tagName === 'BUTTON') {
                submitBtn.disabled = false;
                if (originalBtnHtml) submitBtn.innerHTML = originalBtnHtml;
            }
        }
    };

    if (!window.__ulpSpaFormSubmitDeleg) {
        window.__ulpSpaFormSubmitDeleg = true;
        document.addEventListener('submit', (e) => {
            const form = e.target;
            if (!form || !form.getAttribute || form.getAttribute('data-spa-submit') !== '1') return;
            if (form.dataset.quillSyncBound === '1') return;
            if (form.__richSubmitPending) return;
            e.preventDefault();
            window.ulpSubmitFormSpa(form);
        });
    }

    // Update active state on initial load
    updateNavState(window.location.href);
    applyDetailBackTargetFromAnchor();
    syncDetailFilterChipsFromAnchor();
    if (typeof window.__ulpSyncMobileHeaderWrapStateImmediate === 'function') {
        window.__ulpSyncMobileHeaderWrapStateImmediate();
    }
    if (typeof window.__ulpSyncMobileHeaderWrapState === 'function') {
        window.__ulpSyncMobileHeaderWrapState();
    }
    if (typeof window.__ulpScheduleMobileHeaderWrapAfterFonts === 'function') {
        window.__ulpScheduleMobileHeaderWrapAfterFonts();
    }
    window.addEventListener('resize', window.__ulpSyncMobileHeaderWrapState, { passive: true });
    window.addEventListener('orientationchange', window.__ulpSyncMobileHeaderWrapState, { passive: true });
    bindCategoryPressFx();

    // Restore anchor on hard reload/back-to-list without SPA navigation.
    tryRestoreListReturnAnchor(new URL(window.location.href));
    // Safari BFCache/back-gesture often restores via pageshow without re-running the
    // regular SPA flow. Re-try anchor restoration there too.
    window.addEventListener('pageshow', () => {
        tryRestoreListReturnAnchor(new URL(window.location.href));
    });
});

const LIST_RETURN_STORAGE_KEY = 'spa_list_return_anchor';

function readListReturnAnchor() {
    try {
        const raw = sessionStorage.getItem(LIST_RETURN_STORAGE_KEY);
        if (raw) return JSON.parse(raw);
    } catch (e) {
        // fall through to history.state fallback
    }
    try {
        const st = (history && history.state && typeof history.state === 'object') ? history.state : null;
        const anchor = st && st.__ulpListReturnAnchor;
        return (anchor && typeof anchor === 'object') ? anchor : null;
    } catch (e) {
        return null;
    }
}

function clearListReturnAnchor() {
    try {
        sessionStorage.removeItem(LIST_RETURN_STORAGE_KEY);
    } catch (e) { /* ignore */ }
    try {
        const st = (history && history.state && typeof history.state === 'object') ? history.state : null;
        if (st && Object.prototype.hasOwnProperty.call(st, '__ulpListReturnAnchor')) {
            const next = Object.assign({}, st);
            delete next.__ulpListReturnAnchor;
            history.replaceState(next, '', window.location.href);
        }
    } catch (e) { /* ignore */ }
}

function normalizeListReturnPath(pathname) {
    if (!pathname) return '/';
    return (pathname !== '/' && pathname.endsWith('/')) ? pathname.slice(0, -1) : pathname;
}

function readForumDiscussionsListCategoryContext() {
    const path = normalizeListReturnPath(window.location.pathname || '/');
    if (path !== '/discussions') {
        return { categorySlug: '', categoryName: '' };
    }
    let categorySlug = '';
    let categoryName = '';
    try {
        categorySlug = (new URLSearchParams(window.location.search || '').get('category') || '').trim();
    } catch (e) { /* ignore */ }
    if (categorySlug) {
        const activeCrumb = document.querySelector('.forum-breadcrumb-nav .forum-breadcrumb-chip.active span');
        if (activeCrumb) {
            categoryName = activeCrumb.textContent.trim();
        }
        if (!categoryName) {
            const activeCat = document.querySelector('.forum-modern-cat-link.active');
            if (activeCat) {
                const nameEl = activeCat.querySelector('span:not(.telemetry-pod):not(.forum-cat-count-badge)');
                if (nameEl) categoryName = nameEl.textContent.trim();
            }
        }
        if (!categoryName) categoryName = categorySlug;
    }
    return { categorySlug, categoryName };
}

function forumListReturnAnchorExtras(fromPath) {
    const path = normalizeListReturnPath(fromPath || window.location.pathname || '/');
    if (path === '/discussions') {
        return readForumDiscussionsListCategoryContext();
    }
    const catMatch = path.match(/^\/discussions\/c\/([^/]+)/);
    if (catMatch) {
        const slug = catMatch[1];
        const titleEl = document.querySelector('.forum-cat-title');
        const categoryName = titleEl ? titleEl.textContent.trim() : slug;
        return { categorySlug: slug, categoryName };
    }
    return { categorySlug: '', categoryName: '' };
}

function forumTopicBackLabelFromAnchor(anchor) {
    if (!anchor) return 'All topics';
    const listPath = normalizeListReturnPath(anchor.listPath || '/');
    if (listPath === '/discussions') {
        let slug = String(anchor.listCategorySlug || anchor.categorySlug || '').trim();
        if (!slug) {
            try {
                slug = (new URLSearchParams(String(anchor.listQuery || '').replace(/^\?/, '')).get('category') || '').trim();
            } catch (e) { /* ignore */ }
        }
        if (!slug) return 'All topics';
        const name = String(anchor.listCategoryName || anchor.categoryName || '').trim();
        return name || slug;
    }
    const catMatch = listPath.match(/^\/discussions\/c\/([^/]+)/);
    if (catMatch) {
        const name = String(anchor.listCategoryName || anchor.categoryName || '').trim();
        return name || catMatch[1];
    }
    return 'All topics';
}

function forumTopicListReturnAnchorFields(currentPath) {
    const ctx = forumListReturnAnchorExtras(currentPath);
    return {
        listCategorySlug: ctx.categorySlug,
        listCategoryName: ctx.categoryName,
    };
}

function readActiveListFilterChip(listType) {
    const root = document.querySelector('.page-toolbar-page:not(.page-toolbar-page--detail-nav)');
    if (!root) return '';
    if (listType === 'resource') {
        const chip = root.querySelector('.directory-tabs-scroll .filter-chip.active[data-resource-category-chip]');
        return chip ? String(chip.getAttribute('data-resource-category-chip') || '').trim().toLowerCase() : '';
    }
    if (listType === 'file') {
        const chip = root.querySelector('.directory-tabs-scroll .filter-chip.active[data-file-filter-chip]');
        return chip ? String(chip.getAttribute('data-file-filter-chip') || '').trim().toLowerCase() : '';
    }
    return '';
}

function enrichListReturnAnchor(anchor) {
    if (!anchor || !anchor.type) return anchor;
    const path = normalizeListReturnPath(anchor.listPath || '/');
    const qs = String(anchor.listQuery || '').replace(/^\?/, '');
    try {
        const params = new URLSearchParams(qs);
        if (anchor.type === 'resource' && (path === '/resources' || path.startsWith('/resources'))) {
            let category = (params.get('category') || '').trim().toLowerCase();
            if (!category || category === 'all') {
                const domCategory = readActiveListFilterChip('resource');
                if (domCategory) category = domCategory;
            }
            anchor.listCategory = category || 'all';
        }
        if (anchor.type === 'file' && path === '/') {
            let filter = (params.get('filter') || 'all').trim().toLowerCase();
            if (!filter || filter === 'all') {
                const domFilter = readActiveListFilterChip('file');
                if (domFilter) filter = domFilter;
            }
            anchor.listFilter = filter || 'all';
        }
        if (anchor.type === 'forum_topic' && path === '/discussions') {
            let slug = (params.get('category') || '').trim();
            if (!slug) slug = String(anchor.listCategorySlug || '').trim();
            anchor.listCategorySlug = slug;
            if (!anchor.listCategoryName && slug) {
                anchor.listCategoryName = slug;
            }
        }
    } catch (e) { /* ignore */ }
    return anchor;
}

function persistListReturnAnchor(anchor) {
    const enriched = enrichListReturnAnchor(anchor || {});
    try {
        sessionStorage.setItem('spa_list_return_anchor', JSON.stringify(enriched));
    } catch (e) { /* ignore */ }
    try {
        const st = (history && history.state && typeof history.state === 'object') ? history.state : {};
        history.replaceState(Object.assign({}, st, { __ulpListReturnAnchor: enriched }), '', window.location.href);
    } catch (e) { /* ignore */ }
}

function ulpProfileSlugFromPath(pathname) {
    const p = normalizeListReturnPath(pathname || '/');
    const m = p.match(/^\/user\/([^/]+)$/);
    return m ? m[1] : null;
}

/** Remember list path+search before navigating to a user profile (profile page "Back"). */
document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href]');
    if (!link) return;
    if (e.defaultPrevented) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (link.classList.contains('no-spa')) return;

    const href = link.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    if (link.getAttribute('target') === '_blank') return;
    if (link.hasAttribute('download')) return;

    let dest;
    try {
        dest = new URL(href, window.location.origin);
    } catch (err) {
        return;
    }
    if (dest.origin !== window.location.origin && dest.origin !== 'null') return;
    if (dest.origin === 'null') return;

    const destSlug = ulpProfileSlugFromPath(dest.pathname || '/');
    if (!destSlug) return;

    const cur = new URL(window.location.href, window.location.origin);
    const curPath = normalizeListReturnPath(cur.pathname || '/');
    /* "Back to profile" from edit must not overwrite the place the user came from before opening the profile. */
    if (curPath === '/profile/edit') return;

    const curSlug = ulpProfileSlugFromPath(cur.pathname || '/');
    if (curSlug && curSlug === destSlug) return;

    const fromStr = curPath + (cur.search || '');
    if (fromStr.length > 2048) return;
    try {
        sessionStorage.setItem('ulp_profile_from', fromStr);
    } catch (err) { /* ignore */ }
}, true);

// Event Delegation for Links (Attached Immediately)
document.addEventListener('click', (e) => {
    if (e.defaultPrevented) return;
    const badge = e.target.closest('.group-badge');
    if (!badge) return;

    const userLink = badge.closest('a.username-tag[href]');
    let targetHref = badge.getAttribute('data-badge-href') || '';
    if (!targetHref && userLink) {
        targetHref = userLink.getAttribute('href') || '';
    }
    // Own profile header uses <span class="username-tag"> (not a link).
    if (!targetHref && badge.closest('.profile-identity-name-row .username-tag')) {
        targetHref = window.location.pathname;
    }
    if (!targetHref) return;

    try {
        const u = new URL(targetHref, window.location.origin);
        if (!u.pathname.startsWith('/user/')) return;
        u.searchParams.set('tab', 'achievements');
        const finalHref = u.pathname + u.search + u.hash;

        e.preventDefault();
        e.stopPropagation();

        const cur = new URL(window.location.href, window.location.origin);
        if (cur.pathname === u.pathname && typeof window.switchPageTab === 'function') {
            const achBtn = document.querySelector('.profile-tab-btn[data-tab="achievements"]');
            if (achBtn) {
                window.switchPageTab('achievements', achBtn);
                return;
            }
        }

        if (window.loadPage) {
            /* false = superseded/aborted nav (rapid clicks), not failure — loadPage already hard-reloads on real errors */
            void window.loadPage(finalHref);
        } else {
            window.location.href = finalHref;
        }
    } catch (err) {
        console.error('SPA: badge navigation parse error', err);
    }
}, true);

document.addEventListener('click', (e) => {
    if (e.defaultPrevented) return; // Ignore events handled by other scripts (like modals)
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const link = e.target.closest('a');
    if (!link) return;

    const modal = document.getElementById('universal-modal');
    const isModalActive = modal && modal.classList.contains('active');
    const isInsideModal = modal && modal.contains(link);

    const href = link.getAttribute('href');
    const target = link.getAttribute('target');

    if (link.hasAttribute('data-ulp-nav-back')) return;

    // Ignore if:
    if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    if (target === '_blank') return;
    if (link.hasAttribute('download')) return;
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return; // Allow new tab
    if (link.classList.contains('no-spa')) return; // Opt-out

    // Handle logout through AJAX + SPA redirect (never navigate GET /logout — CSRF/logout hardening)
    if (href.includes('/logout')) {
        e.preventDefault();
        if (typeof window.spaLogout === 'function') {
            window.spaLogout(href);
        } else if (typeof window.__ulpPostLogoutFallback === 'function') {
            window.__ulpPostLogoutFallback(href);
        }
        return;
    }

        // File downloads must be a full navigation — SPA fetch() triggers the route once and a fallback
        // navigation can hit it again, doubling download counts.
        try {
            const dl = new URL(href, window.location.origin);
            if (dl.pathname.startsWith('/download/')) return;
        } catch (e) { /* ignore */ }

        // Check if internal (same origin)
        try {
            const url = new URL(href, window.location.origin);
        if (url.origin && url.origin !== window.location.origin && url.origin !== 'null') {
            return;
        }

        // Skip if its a javascript: link or other non-navigational origin
        if (url.origin === 'null') return;

        const destPath = window.__ulpNormalizePath(url.pathname || '/');
        if (destPath.indexOf('maintenance.html') !== -1) {
            return;
        }

        e.preventDefault();

        // 2. If navigating away FROM within a modal - CLOSE MODAL first
        if (isModalActive && isInsideModal && window.closeModal) {
            window.closeModal();
        }

        // Use the exposed loadPage or fallback
        if (window.loadPage) {
            void window.loadPage(url.href);
        } else {
            console.warn('SPA: loadPage not ready yet. Reloading.');
            window.location.href = url.href;
        }
    } catch (err) {
        console.error('SPA: URL parsing error', err);
    }
});

// Keep list filter/category in the return anchor when switching tabs on list pages.
document.addEventListener('click', (e) => {
    const chip = e.target.closest(
        '.page-toolbar-page:not(.page-toolbar-page--detail-nav) .directory-tabs-scroll a.filter-chip[data-resource-category-chip], ' +
        '.page-toolbar-page:not(.page-toolbar-page--detail-nav) .directory-tabs-scroll a.filter-chip[data-file-filter-chip]'
    );
    if (!chip) return;

    const path = normalizeListReturnPath(window.location.pathname || '/');
    let listQuery = '';
    try {
        const chipUrl = new URL(chip.getAttribute('href') || '', window.location.origin);
        listQuery = chipUrl.search || '';
    } catch (err) {
        listQuery = '';
    }

    if (path === '/resources') {
        const prev = readListReturnAnchor();
        if (prev && prev.type === 'resource' && prev.id) {
            persistListReturnAnchor({
                ...prev,
                listPath: '/resources',
                listQuery,
                ts: Date.now()
            });
        }
        return;
    }

    if (path === '/') {
        const prev = readListReturnAnchor();
        if (prev && prev.type === 'file' && prev.id) {
            persistListReturnAnchor({
                ...prev,
                listPath: '/',
                listQuery,
                ts: Date.now()
            });
        }
    }
}, true);

// Save list anchor before navigating from a feed card.
document.addEventListener('click', (e) => {
    const card = e.target.closest('.file-item[data-file-id], .resource-item[data-listing-id]');
    if (!card) return;

    const clickedLink = e.target.closest('a[href]');
    // Keep ignoring explicit action controls, but allow detail links.
    if (e.target.closest('button, input, label, form')) return;
    if (clickedLink) {
        const href = clickedLink.getAttribute('href') || '';
        const isDetailLink =
            href.includes('/file/') ||
            href.includes('/resources/') ||
            clickedLink.classList.contains('view-file-btn') ||
            clickedLink.classList.contains('list-card-hit') ||
            clickedLink.classList.contains('forum-topic-list-card-hit');
        if (!isDetailLink) return;
    }

    const url = new URL(window.location.href, window.location.origin);
    const listType = url.pathname.startsWith('/resources') ? 'resource' : (url.pathname === '/' ? 'file' : null);
    if (!listType) return;

    const id = listType === 'resource'
        ? card.getAttribute('data-listing-id')
        : card.getAttribute('data-file-id');
    if (!id) return;

    persistListReturnAnchor({
        type: listType,
        id: String(id),
        listPath: (url.pathname !== '/' && url.pathname.endsWith('/')) ? url.pathname.slice(0, -1) : url.pathname,
        listQuery: url.search || '',
        scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
        ts: Date.now()
    });
}, true);

// Generic fallback: remember return position before opening any detail page link.
// Important for admin/mobile flows where links may not use .file-item/.resource-item cards.
document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href]');
    if (!link) return;
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    let dest;
    try {
        dest = new URL(link.getAttribute('href') || '', window.location.origin);
    } catch (err) {
        return;
    }
    if (dest.origin !== window.location.origin) return;

    const dPath = normalizeListReturnPath(dest.pathname || '/');
    const mFile = dPath.match(/^\/file\/(\d+)/);
    const mRes = dPath.match(/^\/resources\/(\d+)/);
    const mTopic = dPath.match(/^\/discussions\/t\/(\d+)/);
    if (!mFile && !mRes && !mTopic) return;

    const cur = new URL(window.location.href, window.location.origin);
    const currentPath = normalizeListReturnPath(cur.pathname || '/');
    if (currentPath === dPath) return;

    /* Only treat the current page as a "list" we return to — never e.g. edit → topic
       (capture runs before inline preventDefault, so listPath must not become /discussions/actions/.../edit). */
    if (mTopic) {
        const fromForumTopicList =
            currentPath === '/discussions' || /^\/discussions\/c\//.test(currentPath);
        if (!fromForumTopicList) return;
    }
    if (mFile && currentPath !== '/') return;
    if (mRes && currentPath !== '/resources') return;

    const anchorType = mFile ? 'file' : (mRes ? 'resource' : 'forum_topic');
    const anchorId = mFile ? mFile[1] : (mRes ? mRes[1] : mTopic[1]);
    persistListReturnAnchor({
        type: anchorType,
        id: String(anchorId),
        listPath: currentPath,
        listQuery: cur.search || '',
        scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
        ts: Date.now(),
        ...(anchorType === 'forum_topic' ? forumTopicListReturnAnchorFields(currentPath) : {}),
    });
}, true);

// Save forum return anchor before entering category/topic details.
document.addEventListener('click', (e) => {
    function normalizeForumPath(path) {
        if (!path) return '/';
        return (path !== '/' && path.endsWith('/')) ? path.slice(0, -1) : path;
    }

    const categoryCard = e.target.closest('.forum-category-card[data-category-id]');
    if (categoryCard) {
        const url = new URL(window.location.href, window.location.origin);
        const currentPath = normalizeForumPath(url.pathname);
        if (currentPath === '/discussions') {
            const id = categoryCard.getAttribute('data-category-id');
            if (!id) return;
            persistListReturnAnchor({
                type: 'forum_category',
                id: String(id),
                listPath: currentPath,
                listQuery: url.search || '',
                scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
                ts: Date.now()
            });
        }
        return;
    }

    const topicCard = e.target.closest('.forum-topic-list-card[data-topic-id]');
    if (topicCard) {
        const url = new URL(window.location.href, window.location.origin);
        const currentPath = normalizeForumPath(url.pathname);
        if (currentPath === '/discussions' || currentPath.startsWith('/discussions/c/')) {
            const id = topicCard.getAttribute('data-topic-id');
            if (!id) return;
            persistListReturnAnchor({
                type: 'forum_topic',
                id: String(id),
                listPath: currentPath,
                listQuery: url.search || '',
                scrollY: Math.max(0, Math.round(window.pageYOffset || window.scrollY || 0)),
                ts: Date.now(),
                ...forumTopicListReturnAnchorFields(currentPath),
            });
        }
    }
}, true);

// Pagination jump on "..." — compact popover above the button (no system prompt)
(function () {
    let popoverEl = null;
    let backdropEl = null;
    let onKeydown = null;
    let onScrollClose = null;

    function closePageJumpPopover() {
        if (onKeydown) {
            document.removeEventListener('keydown', onKeydown, true);
            onKeydown = null;
        }
        if (onScrollClose) {
            window.removeEventListener('scroll', onScrollClose, true);
            onScrollClose = null;
        }
        if (backdropEl) {
            backdropEl.remove();
            backdropEl = null;
        }
        if (popoverEl) {
            popoverEl.classList.remove('active');
            popoverEl.style.display = 'none';
        }
    }

    function ensurePopover() {
        if (popoverEl) return popoverEl;
        popoverEl = document.createElement('div');
        popoverEl.className = 'page-jump-popover';
        popoverEl.setAttribute('role', 'dialog');
        popoverEl.setAttribute('aria-label', 'Go to page');
        popoverEl.innerHTML =
            '<div class="page-jump-popover-inner">' +
            '<div class="page-jump-popover-header">' +
            '<div class="page-jump-popover-title"><i class="fas fa-ellipsis-h" aria-hidden="true"></i> Go to page</div>' +
            '<div class="page-jump-popover-range" aria-hidden="true"></div>' +
            '</div>' +
            '<div class="page-jump-popover-body">' +
            '<div class="page-jump-popover-row">' +
            '<input type="number" class="page-jump-popover-input" inputmode="numeric" autocomplete="off" placeholder="Page #" />' +
            '<button type="button" class="page-jump-popover-go">' +
            '<span class="page-jump-popover-go-label">Go</span>' +
            '<i class="fas fa-arrow-right" aria-hidden="true"></i>' +
            '</button></div></div></div>';
        document.body.appendChild(popoverEl);
        return popoverEl;
    }

    function openPageJumpPopover(anchor, opts) {
        const { pageParam, max, current, jumpUrl } = opts;
        closePageJumpPopover();

        const el = ensurePopover();
        const rangeEl = el.querySelector('.page-jump-popover-range');
        const input = el.querySelector('.page-jump-popover-input');
        const goBtn = el.querySelector('.page-jump-popover-go');

        rangeEl.textContent = `Pages 1 – ${max}`;
        input.min = String(1);
        input.max = String(max);
        if (Number.isFinite(current) && current >= 1 && current <= max) {
            input.value = String(current);
        } else {
            input.value = '';
        }

        const rect = anchor.getBoundingClientRect();
        el.style.display = 'block';
        el.style.left = `${rect.left + rect.width / 2}px`;
        el.style.top = `${rect.top}px`;
        el.classList.add('active');

        const submit = () => {
            const targetPage = parseInt(String(input.value).trim(), 10);
            if (!Number.isFinite(targetPage) || targetPage < 1 || targetPage > max) {
                if (typeof window.showToast === 'function') {
                    window.showToast(`Enter a page from 1 to ${max}.`, 'warning');
                }
                input.focus();
                return;
            }
            closePageJumpPopover();
            const targetUrl = new URL(jumpUrl, window.location.origin);
            targetUrl.searchParams.set(pageParam, String(targetPage));
            if (window.loadPage) {
                Promise.resolve(window.loadPage(targetUrl.href)).catch(() => {
                    window.location.href = targetUrl.href;
                });
            } else {
                window.location.href = targetUrl.href;
            }
        };

        goBtn.onclick = (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            submit();
        };

        input.onkeydown = (ev) => {
            if (ev.key === 'Enter') {
                ev.preventDefault();
                submit();
            }
        };

        onKeydown = (ev) => {
            if (ev.key === 'Escape') {
                ev.preventDefault();
                closePageJumpPopover();
            }
        };
        document.addEventListener('keydown', onKeydown, true);

        onScrollClose = () => closePageJumpPopover();
        window.addEventListener('scroll', onScrollClose, true);

        backdropEl = document.createElement('div');
        backdropEl.className = 'page-jump-popover-backdrop';
        document.body.appendChild(backdropEl);
        backdropEl.addEventListener('click', () => closePageJumpPopover());

        requestAnimationFrame(() => {
            const margin = 10;
            const halfW = el.offsetWidth / 2 || 100;
            let center = rect.left + rect.width / 2;
            center = Math.max(margin + halfW, Math.min(center, window.innerWidth - margin - halfW));
            el.style.left = `${center}px`;
            input.focus();
            input.select();
        });
    }

    document.addEventListener('click', (e) => {
        const jumpBtn = e.target.closest('.site-page-dots[data-jump-url], .adm-page-dots[data-jump-url]');
        if (!jumpBtn) return;

        e.preventDefault();
        e.stopPropagation();

        const pageParam = jumpBtn.dataset.pageParam || 'page';
        const max = parseInt(jumpBtn.dataset.jumpMax || '1', 10);
        const current = parseInt(jumpBtn.dataset.currentPage || '', 10);
        const jumpUrl = jumpBtn.dataset.jumpUrl;
        if (!jumpUrl || !Number.isFinite(max) || max < 1) return;

        openPageJumpPopover(jumpBtn, { pageParam, max, current, jumpUrl });
    });
})();
