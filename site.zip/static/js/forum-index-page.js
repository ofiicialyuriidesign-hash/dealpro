/**
 * Forum index — mobile categories, realtime, admin bulk.
 */
(function () {
    'use strict';
    function readConfig() {
        var el = document.getElementById('ulp-forum-index-page-config');
        if (!el) return {};
        try { return JSON.parse(el.textContent || '{}'); } catch (e) { return {}; }
    }
    var cfg = readConfig();

(function () {
        var catsToggle = document.getElementById('forum-cats-toggle');
        var catsSidebar = document.querySelector('.forum-modern-sidebar');
        if (catsToggle && catsSidebar) {
            var CATS_MOBILE_STATE_KEY = 'forum-mobile-cats-open';
            var isMobileCats = function () {
                return !!(window.matchMedia && window.matchMedia('(max-width: 768px)').matches);
            };
            var readStoredCatsOpen = function () {
                try {
                    var v = sessionStorage.getItem(CATS_MOBILE_STATE_KEY);
                    if (v === '1') return true;
                    if (v === '0') return false;
                } catch (e) { }
                return null;
            };
            var writeStoredCatsOpen = function (open) {
                try {
                    sessionStorage.setItem(CATS_MOBILE_STATE_KEY, open ? '1' : '0');
                } catch (e) { }
            };
            var setCatsOpen = function (open) {
                catsSidebar.classList.toggle('is-open', !!open);
                catsToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                if (isMobileCats()) writeStoredCatsOpen(!!open);
            };
            var applyMobileCatsOpenBySelection = function () {
                if (!isMobileCats()) return;
                var stored = readStoredCatsOpen();
                if (stored !== null) {
                    setCatsOpen(stored);
                    return;
                }
                var active = catsSidebar.querySelector('.forum-modern-cat-link.active');
                if (!active) return;
                // Mobile UX: keep panel open on parent-category pages; collapse on subcategory pages.
                setCatsOpen(!active.classList.contains('forum-modern-subcat'));
            };
            var closeCats = function () {
                setCatsOpen(false);
            };
            applyMobileCatsOpenBySelection();
            catsToggle.addEventListener('click', function () {
                setCatsOpen(!catsSidebar.classList.contains('is-open'));
            });
            document.addEventListener('click', function (e) {
                if (!catsSidebar.classList.contains('is-open')) return;
                if (catsSidebar.contains(e.target)) return;
                closeCats();
            });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') closeCats();
            });
            catsSidebar.querySelectorAll('.forum-modern-cat-link').forEach(function (link) {
                link.addEventListener('click', function () {
                    if (!isMobileCats()) return;
                    if (link.classList.contains('forum-modern-subcat')) {
                        closeCats();
                    }
                });
            });
        }
        if (!window.__forumCatAccordionBound) {
            window.__forumCatAccordionBound = true;
            document.addEventListener('click', function (e) {
                var btn = e.target.closest('.forum-cat-toggle');
                if (!btn) return;
                e.preventDefault();
                e.stopPropagation();
                var g = btn.closest('.forum-cat-group');
                if (!g) return;
                var open = g.classList.toggle('is-open');
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            });
        }
        function stripForumCardsForViewer() {
            if (typeof window.ulpStripNonPublicForumTopicCards === 'function') {
                window.ulpStripNonPublicForumTopicCards();
            }
        }
        stripForumCardsForViewer();
        if (!window.__forumIndexPageLoadedBound) {
            window.__forumIndexPageLoadedBound = true;
            document.addEventListener('pageLoaded', function (ev) {
                var url = (ev && ev.detail && ev.detail.url) || window.location.href || '';
                var path = '';
                try {
                    path = new URL(url, window.location.origin).pathname || '';
                } catch (e) {
                    path = window.location.pathname || '';
                }
                if (path === '/discussions' || /^\/discussions\/c\//i.test(path)) {
                    stripForumCardsForViewer();
                }
            });
        }

        var socket = window.getSharedSocket ? window.getSharedSocket() : null;
        if (!socket) return;
        if (window.__forumIndexRealtimeBound) return;
        window.__forumIndexRealtimeBound = true;

        socket.on('new_forum_topic', function (data) {
            if (window.location.pathname !== '/discussions' || !window.loadPage) return;
            if (
                data &&
                data.opening_post_approved === false &&
                typeof window.ulpMayViewPendingModerationPayload === 'function' &&
                !window.ulpMayViewPendingModerationPayload({
                    is_approved: false,
                    user_id: data.user_id,
                })
            ) {
                return;
            }
            window.loadPage(window.location.pathname + window.location.search, true);
        });
        socket.on('forum_post_approved', function (payload) {
            if (window.location.pathname !== '/discussions' || !window.loadPage) return;
            if (!payload || !payload.opening_post_approved) return;
            window.loadPage(window.location.pathname + window.location.search, true);
        });
        socket.on('content_removed', function (data) {
            if (!data || data.type !== 'forum_topic') return;
            if (window.location.pathname === '/discussions' && window.loadPage) {
                window.loadPage(window.location.pathname + window.location.search, true);
            }
        });
    })();

    
    if (cfg.isAdmin) {
    window.updateForumTopicSelectionIndex = function () {
        var checked = document.querySelectorAll('.forum-topic-checkbox-index:checked');
        var count = checked.length;
        var countEl = document.getElementById('selection-count-forum-topics-index');
        if (countEl) countEl.textContent = count + ' SELECTED';
        var btn = document.getElementById('delete-selected-forum-topics-index-btn');
        var moveBtn = document.getElementById('move-selected-forum-topics-index-btn');
        var moveSel = document.getElementById('bulk-move-forum-category-index');
        var bar = document.getElementById('bulk-action-bar-forum-topics-index');
        if (btn) btn.disabled = count === 0;
        if (moveBtn) moveBtn.disabled = count === 0 || !moveSel || !String(moveSel.value || '').trim();
        if (bar) bar.classList.toggle('active', count > 0);
        var all = document.querySelectorAll('.forum-topic-checkbox-index');
        var selectAll = document.getElementById('select-all-forum-topics-index');
        if (selectAll && all.length) selectAll.checked = count === all.length;
    };

    window.toggleSelectAllForumTopicsIndex = function (el) {
        document.querySelectorAll('.forum-topic-checkbox-index').forEach(function (cb) {
            cb.checked = !!(el && el.checked);
        });
        window.updateForumTopicSelectionIndex();
    };

    window.bulkMoveForumTopicsIndex = function () {
        var selected = document.querySelectorAll('.forum-topic-checkbox-index:checked');
        var moveSel = document.getElementById('bulk-move-forum-category-index');
        if (!selected.length || !moveSel || !String(moveSel.value || '').trim()) return;
        var cid = moveSel.value;
        if (!confirm('Move ' + selected.length + ' selected topic(s) to this category? Slug changes if the target already has the same URL slug.')) return;
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = cfg.bulkMoveTopicsUrl;
        var csrf = document.querySelector('meta[name="csrf-token"]');
        var csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = 'csrf_token';
        csrfInput.value = csrf ? csrf.content : '';
        form.appendChild(csrfInput);
        var catInp = document.createElement('input');
        catInp.type = 'hidden';
        catInp.name = 'category_id';
        catInp.value = cid;
        form.appendChild(catInp);
        selected.forEach(function (cb) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'topic_ids[]';
            input.value = cb.value;
            form.appendChild(input);
        });
        document.body.appendChild(form);
        form.submit();
    };

    window.bulkDeleteForumTopicsIndex = function () {
        var selected = document.querySelectorAll('.forum-topic-checkbox-index:checked');
        var ids = Array.from(selected).map(function (cb) { return cb.value; });
        if (!ids.length || !window.runBulkForumModeration) return;
        window.runBulkForumModeration({
            endpoint: cfg.bulkDeleteTopicsUrl,
            fieldName: 'topic_ids[]',
            ids: ids,
            verb: 'delete',
            checkboxSelector: '.forum-topic-checkbox-index',
            selectAllId: 'select-all-forum-topics-index',
            onSelectionReset: window.updateForumTopicSelectionIndex,
            reloadPage: true,
        });
    };
    }
})();
