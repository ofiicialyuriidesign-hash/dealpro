/**
 * File detail page — initializes shared discussion module.
 */
(function () {
    'use strict';
    if (typeof window.initUlpDiscussionPage !== 'function') return;
    window.initUlpDiscussionPage({
        configElementId: 'ulp-view-file-page-config',
        roomType: 'file',
        entityIdKey: 'fileId',
        socketHandlersKey: '__ulpViewFileSocketHandlers',
        quillWindowProp: '__fileCommentQuill',
        sendBtnId: 'file-discussion-send-btn',
        cancelBtnId: 'file-discussion-cancel-btn',
        editBarId: 'file-discussion-inline-edit-bar',
        cancelExportName: 'cancelFileDiscussionInlineEdit',
        commentEmitEvent: 'file_comment',
        buildCommentPayload: function (fileId, html) {
            return { file_id: fileId, content: html };
        }
    });
})();
