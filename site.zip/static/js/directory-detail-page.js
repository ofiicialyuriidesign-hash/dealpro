/**
 * Resource listing detail — initializes shared discussion module.
 */
(function () {
    'use strict';
    if (typeof window.initUlpDiscussionPage !== 'function') return;
    window.initUlpDiscussionPage({
        configElementId: 'ulp-directory-detail-page-config',
        roomType: 'resource',
        entityIdKey: 'listingId',
        socketHandlersKey: '__ulpViewResourceSocketHandlers',
        quillWindowProp: '__resourceCommentQuill',
        sendBtnId: 'resource-discussion-send-btn',
        cancelBtnId: 'resource-discussion-cancel-btn',
        editBarId: 'resource-discussion-inline-edit-bar',
        cancelExportName: 'cancelResourceDiscussionInlineEdit',
        commentEmitEvent: 'resource_comment',
        buildCommentPayload: function (listingId, html) {
            return { listing_id: listingId, content: html };
        }
    });
})();
